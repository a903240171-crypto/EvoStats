import sys, math, importlib.util as u, inspect
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def load(p, n):
    s = u.spec_from_file_location(n, str(p)); m = u.module_from_spec(s)
    s.loader.exec_module(m); return m

p5f = load(ROOT / "code" / "phase5_validation" / "run_phase5f_d109.py", "p5f")

# ---------- 1. 仓库里已有的下界/星形代码 ----------
print("=" * 80)
print("1. 已有的 lower-bound / star 相关函数")
print("=" * 80)
for name in dir(p5f):
    if any(k in name.lower() for k in ("lower", "bound", "star", "frontier", "match", "certif")):
        obj = getattr(p5f, name)
        if callable(obj):
            print(f"\n--- p5f.{name} ---")
            try:
                print(inspect.getsource(obj))
            except Exception as e:
                print("  (no source)", e)

# ---------- 2. §5 闭式星形公式 ----------
def F_star(r, k):
    """paper Eq: r = k'q + p,  F = p*C(q+2,2) + (k'-p)*C(q+1,2)"""
    kp = min(k, r)
    if kp == 0: return 0
    q, p = divmod(r, kp)
    C = lambda n: n * (n - 1) // 2
    return p * C(q + 2) + (kp - p) * C(q + 1)

# ---------- 3. 纯星形上直接检验 ----------
print("\n" + "=" * 80)
print("2. 纯星形 K_{1,108}: 宽度 B 下 planner 实际 vs 两个候选下界")
print("=" * 80)
DELTA = 108
star = {(0, v) for v in range(1, DELTA + 1)}
print(f"{'B':>3} {'greedy_calls':>13} {'ceil(D/(B-1))':>14} {'match':>7} "
      f"{'greedy_slots':>13} {'F_star(D,calls)':>16}")
for B in [3, 4, 6, 8, 12, 16]:
    g = p5f.bounded_greedy(star, B)
    calls = len(g)
    slots = sum(len(x) * (len(x) - 1) // 2 for x in g)
    dlb = math.ceil(DELTA / (B - 1))
    print(f"{B:>3} {calls:>13} {dlb:>14} {'OK' if calls==dlb else 'DIFF':>7} "
          f"{slots:>13} {F_star(DELTA, calls):>16}")

# ---------- 4. 真实 ACS 图上，度界是否可达 ----------
print("\n" + "=" * 80)
print("3. 真实 141 边图: degree_lb 是否被 planner 达到")
print("=" * 80)
import pandas as pd
sp = pd.read_csv(ROOT / "results" / "phase5f_d109_support_runtime" / "support_pairs.csv")
fz = sp[(sp.floor == 20) & (sp.pg_severe == 1)]
E = {tuple(sorted((int(a), int(b)))) for a, b in zip(fz.i, fz.j)}
deg = {}
for a, b in E:
    deg[a] = deg.get(a, 0) + 1; deg[b] = deg.get(b, 0) + 1
D = max(deg.values())
print(f"edges={len(E)}  max_degree={D}")
print(f"{'B':>3} {'calls':>7} {'deg_lb':>7} {'cap_lb':>7} {'gap':>7}")
for B in [3, 4, 6, 8, 12, 16]:
    g = p5f.bounded_greedy(E, B)
    dlb = math.ceil(D / (B - 1))
    cap = math.ceil(len(E) / (B * (B - 1) // 2))
    lb = max(dlb, cap, 1)
    print(f"{B:>3} {len(g):>7} {dlb:>7} {cap:>7} {len(g)/lb:>7.3f}")
