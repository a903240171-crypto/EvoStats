import sys, math, importlib.util as u
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
def load(p, n):
    s = u.spec_from_file_location(n, str(p)); m = u.module_from_spec(s)
    s.loader.exec_module(m); return m
p5f = load(ROOT / "code" / "phase5_validation" / "run_phase5f_d109.py", "p5f")

sp = pd.read_csv(ROOT / "results" / "phase5f_d109_support_runtime" / "support_pairs.csv")
C = lambda n: n*(n-1)//2

def bounds(E, B, deg):
    D = max(deg.values()) if deg else 0
    mu = 0; used=set()
    for a,b in sorted(E):
        if a not in used and b not in used: mu+=1; used|={a,b}
    return dict(capacity=math.ceil(len(E)/C(B)) if B>1 else len(E),
                degree=math.ceil(D/(B-1)) if B>1 else D,
                matching=math.ceil(mu/max(1,B//2)), mu=mu, Delta=D)

print("="*88); print("A. SUPPORT SPECTRUM (paper Table: support sensitivity)"); print("="*88)
print(f"{'floor':>6}{'severe':>8}{'rate':>9}{'active':>8}{'maxdeg':>8}")
for f in sorted(sp.floor.unique()):
    fz = sp[(sp.floor==f)&(sp.pg_severe==1)]
    E = {tuple(sorted((int(a),int(b)))) for a,b in zip(fz.i,fz.j)}
    d = {}
    for a,b in E: d[a]=d.get(a,0)+1; d[b]=d.get(b,0)+1
    print(f"{f:>6}{len(E):>8}{len(E)/5886:>9.4f}{len(d):>8}{(max(d.values()) if d else 0):>8}")

print("\n"+"="*88); print("B. TABLE 3 PLANNER (floor=20)"); print("="*88)
fz = sp[(sp.floor==20)&(sp.pg_severe==1)]
E20 = {tuple(sorted((int(a),int(b)))) for a,b in zip(fz.i,fz.j)}
deg = {}
for a,b in E20: deg[a]=deg.get(a,0)+1; deg[b]=deg.get(b,0)+1
active = sorted(deg)
print(f"edges={len(E20)}  active_cols={len(active)}  Delta={max(deg.values())}")
print(f"{'B':>4}{'calls':>7}{'slots':>7}{'cap':>6}{'deg':>6}{'match':>7}{'LB':>5}{'gap':>7}")
for B in [3,4,6,8,12,16]:
    g = p5f.bounded_greedy(E20, B)
    s = sum(C(len(x)) for x in g); bd = bounds(E20,B,deg)
    lb = max(bd['capacity'],bd['degree'],bd['matching'],1)
    print(f"{B:>4}{len(g):>7}{s:>7}{bd['capacity']:>6}{bd['degree']:>6}"
          f"{bd['matching']:>7}{lb:>5}{len(g)/lb:>7.3f}")
print(f"per-edge : calls={len(E20)}  slots={len(E20)}")
print(f"closure  : calls=1  slots={C(len(active))}")

print("\n"+"="*88); print("C. ACTION-AWARE COVER (14-call claim, RQ6)"); print("="*88)
oa = ROOT / "results" / "phase5j_retire_refresh_v2" / "hybrid_actions.csv"
if oa.exists():
    ha = pd.read_csv(oa)
    print("cols:", list(ha.columns))
    ac = [c for c in ha.columns if 'action' in c.lower()]
    if ac:
        col = ac[0]; print(ha[col].value_counts().to_string())
        R = {tuple(sorted((int(r.i),int(r.j)))) for r in
             ha[ha[col].astype(str).str.contains('refresh',case=False)].itertuples()}
        Bw, h = 8, len(active)
        print(f"retained refresh edges={len(R)}  active={h}")
        print(f"capacity call LB = ceil({h}/{Bw}) = {math.ceil(h/Bw)}")
        comp={}; par={v:v for v in active}
        def find(x):
            while par[x]!=x: par[x]=par[par[x]]; x=par[x]
            return x
        for a,b in R:
            ra,rb=find(a),find(b)
            if ra!=rb: par[ra]=rb
        for v in active: comp.setdefault(find(v),[]).append(v)
        sizes=sorted((len(c) for c in comp.values() if len(c)>1),reverse=True)
        print(f"non-trivial components of (A,R): {sizes}")
        k=math.ceil(h/Bw); q,p = divmod(h,k)
        print(f"balanced slot LB = {p}*C({q+1},2)+{k-p}*C({q},2) = {p*C(q+1)+(k-p)*C(q)}")
else:
    print("hybrid_actions.csv not found:", oa)

print("\n"+"="*88); print("D. CLOSED-FORM GEOMETRIES (paper Prop 5.2)"); print("="*88)
def F_star(r,k):
    kp=min(k,r); q,p=divmod(r,kp); return p*C(q+2)+(kp-p)*C(q+1)
def F_match(r,k):
    kp=min(k,r); q,p=divmod(r,kp); return p*C(2*(q+1))+(kp-p)*C(2*q)
for r,k in [(8,3),(12,4),(20,5),(108,16)]:
    st={(0,v) for v in range(1,r+1)}
    mt={(2*t,2*t+1) for t in range(r)}
    gs=p5f.bounded_greedy(st,max(2,math.ceil(r/k)+1))
    print(f"star r={r:>4} k={k:>3}: F_star={F_star(r,k):>6} | "
          f"match r={r:>4}: F_match={F_match(r,k):>6}")
