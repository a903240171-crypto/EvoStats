import sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code" / "phase6_review"))
import run_no_hub_geometry_ablation as m

SP    = ROOT / "results" / "phase5f_d109_support_runtime" / "support_pairs.csv"
OUT   = ROOT / "results" / "phase6a_no_hub_ablation_frozen"
HUB   = "H_RMSP"
FLOOR = 20
WIDTHS= [3, 4, 6, 8, 12, 16]
OUT.mkdir(parents=True, exist_ok=True)

sp = pd.read_csv(SP)
fz = sp[(sp["floor"] == FLOOR) & (sp["pg_severe"] == 1)]
li = fz["variable_i"].map(lambda x: str(x).strip())
ri = fz["variable_j"].map(lambda x: str(x).strip())
name_edges = {m.canonical_edge(a, b) for a, b in zip(li, ri)}
idx_edges  = {tuple(sorted((int(a), int(b)))) for a, b in zip(fz["i"], fz["j"])}
print("[frozen] records=%d  NAME edges=%d  INDEX edges=%d"
      % (len(fz), len(name_edges), len(idx_edges)))
if not (len(fz) == len(name_edges) == len(idx_edges)):
    raise SystemExit("EDGE IDENTITY MISMATCH - stop and inspect")

full  = name_edges
nohub = {e for e in full if HUB not in e}
conds = {"full": full, "no_hub": nohub}

stats = [m.graph_stats(n, e, HUB) for n, e in conds.items()]
sdf   = pd.DataFrame(stats)
by    = {s["condition"]: s for s in stats}

rows = []
for c, e in conds.items():
    for w in WIDTHS:
        g = m.greedy_bounded_groups(e, w)
        rows.append(m.plan_summary(c, e, w, g, by[c]["matching_size"]))
pdf = pd.DataFrame(rows)

sdf.to_csv(OUT / "graph_geometry_summary.csv", index=False)
pdf.to_csv(OUT / "planner_summary.csv", index=False)

print("=" * 92)
print(sdf[["condition","edges","active_vertices","components","max_degree",
           "degree_gini","hub_degree","hub_edge_fraction","matching_size",
           "edge_cover_vertex_lb"]].to_string(index=False))
print()
print(pdf[["condition","width","calls","total_pair_slots","useful_fraction",
           "capacity_call_lb","matching_call_lb","lower_bound_calls",
           "call_gap"]].to_string(index=False))
print()
print("[write]", OUT.resolve())
