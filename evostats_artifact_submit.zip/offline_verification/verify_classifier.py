from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "results" / "phase5k_cheap_hybrid_e2e"

cd = pd.read_csv(D / "classifier_detail.csv")
mm = pd.read_csv(D / "classifier_mismatches.csv")
oa = pd.read_csv(ROOT / "results" / "phase5j_retire_refresh_v2" / "hybrid_actions.csv")

print("=" * 84)
print("classifier_detail cols :", list(cd.columns), " rows =", len(cd))
print("mismatches       cols :", list(mm.columns), " rows =", len(mm))
print("=" * 84)
print(cd.head(3).to_string(index=False))
print("-" * 84)
print(mm.to_string(index=False))

# oracle labels
oa["_e"] = [tuple(sorted((int(a), int(b)))) for a, b in zip(oa.i, oa.j)]
orc = {e: ("retire" if "retire" == str(a).strip().lower() else "refresh")
       for e, a in zip(oa["_e"], oa.hybrid_action)}
print("\noracle:", pd.Series(list(orc.values())).value_counts().to_dict())

# predicted labels: find the action-like column
cand = [c for c in cd.columns if any(k in c.lower()
        for k in ("action", "predict", "label", "decision", "retire"))]
print("candidate prediction columns:", cand)

if {"i", "j"} <= set(cd.columns) and cand:
    col = cand[0]
    cd["_e"] = [tuple(sorted((int(a), int(b)))) for a, b in zip(cd.i, cd.j)]
    def norm(v):
        s = str(v).strip().lower()
        if s in ("1", "true", "retire"): return "retire"
        if s in ("0", "false", "refresh", "retain_and_refresh"): return "refresh"
        return s
    pred = {e: norm(v) for e, v in zip(cd["_e"], cd[col])}
    print(f"\nusing column {col!r}:",
          pd.Series(list(pred.values())).value_counts().to_dict())

    common = set(pred) & set(orc)
    agree = sum(pred[e] == orc[e] for e in common)
    o_ref = {e for e in common if orc[e] == "refresh"}
    p_ref = {e for e in common if pred[e] == "refresh"}
    p_ret = {e for e in common if pred[e] == "retire"}
    false_retire = {e for e in p_ret if orc[e] == "refresh"}

    print("\n" + "=" * 84)
    print("REPRODUCED CLAIMS")
    print("=" * 84)
    print(f"  pairs compared     : {len(common)}")
    print(f"  agreement          : {agree}/{len(common)} = {agree/len(common):.4f}")
    print(f"  refresh recall     : {len(o_ref & p_ref)}/{len(o_ref)} = "
          f"{len(o_ref & p_ref)/max(1,len(o_ref)):.4f}")
    print(f"  refresh precision  : {len(o_ref & p_ref)}/{len(p_ref)} = "
          f"{len(o_ref & p_ref)/max(1,len(p_ref)):.4f}")
    print(f"  FALSE RETIRE       : {len(false_retire)}   {sorted(false_retire)}")
    dis = sorted(e for e in common if pred[e] != orc[e])
    print(f"  disagreements      : {len(dis)}  {dis}")
    for e in dis:
        r = cd[cd["_e"] == e]
        print(f"    pair {e}: oracle={orc[e]} pred={pred[e]}")
        print(r.to_string(index=False))
else:
    print("\nNo i/j or action column found - paste the cols line above.")
