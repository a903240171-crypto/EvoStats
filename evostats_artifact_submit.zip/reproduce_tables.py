#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import sys

root = Path(__file__).resolve().parent
required = [
    'support_spectrum_d109.csv',
    'planner_runtime_d109.csv',
    'proactive_end_to_end_d109.csv',
    'proactive_vs_feedback.csv',
    'frontier_exact_audit.csv',
]
missing = []

for name in required:
    path = root / 'tables' / name
    if not path.exists():
        print(f'[missing] {name}')
        missing.append(name)
        continue
    frame = pd.read_csv(path)
    print()
    print(f'{name} ({len(frame)} rows)')
    print(frame.to_string(index=False))

if missing:
    print()
    print('FAIL: missing frozen tables: ' + ', '.join(missing))
    sys.exit(1)

print()
print('PASS: frozen tables loaded.')
