#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent
fail=[]
def h(path):
    x=hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): x.update(c)
    return x.hexdigest()
for line in (root/'checksums.sha256').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    expected,rel=line.split('  ',1)
    p=root/rel
    if not p.exists(): fail.append('missing '+rel)
    elif h(p)!=expected: fail.append('checksum '+rel)
print('Manifest files:',len(json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))['files']))
if fail:
    print('FAIL'); [print(' -',x) for x in fail]; sys.exit(1)
print('PASS: all checksums match.')
