#!/usr/bin/env python3
"""
EvoStats: single-entry reproduction pipeline.

    python run_all.py --dsn postgresql://postgres:PASSWORD@localhost:5432/postgres

What this does
--------------
1. Resolves every script path and input file, failing loudly if anything is missing.
2. Runs the eleven experiments in dependency order.
3. After each step, checks that the declared output files exist and are non-empty.
4. At the end, extracts every number the paper reports and compares it against the
   value just produced.  Any mismatch is printed and the exit code is non-zero.
5. Writes CLAIMS.csv (paper location -> script -> output file -> expected -> actual)
   and MANIFEST.csv (SHA-256 of every input and output).

Why this is an orchestrator and not one merged file
---------------------------------------------------
The individual phase scripts have been audited line by line.  Merging them would
create new, unaudited code and invalidate that audit.  This wrapper calls the
audited scripts unchanged, and adds the three properties that make a run
verifiable: a single parameter block, a clean output directory, and an automatic
reconciliation against the numbers claimed in the paper.

Useful flags
------------
    --fresh          delete output directories before running (default: reuse)
    --dry-run        print the exact commands and exit
    --only 5f,5k     run only the named steps
    --from 5k        resume from a step (assumes upstream outputs exist)
    --offline-only   run only the steps that need no database
    --verify-only    skip execution, just reconcile existing outputs
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

# =============================================================================
# CONFIG -- every experimental constant used anywhere in the paper lives here
# =============================================================================
CONFIG = {
    "support_floor":       20,        # m   : minimum current support
    "severe_threshold":    10.0,      # tau : Q-error threshold for "severe"
    "retire_threshold":    2.0,       # rho : lower-order adequacy tolerance
    "repair_threshold":    2.0,       #       post-repair Q-error target
    "width":               8,         # B   : maximum ANALYZE call width
    "rows":                40000,     #       sampled rows per snapshot
    "statistics_target":   500,       #       PostgreSQL default_statistics_target
    "repeats":             10,        #       randomized runtime repetitions
    "support_thresholds":  "1,5,10,20,50,100",
    "runtime_supports":    "10,20",
    "min_runtime_edges":   10,
    "workload_length":     5000,      #       queries in the feedback baseline
    "controlled_s":        50,        #       planted support size in the 6F bridge
    "alphas":              "inf,4,2,1,0",
    "ranking_seeds":       20,
    "top_k":               5,         #       multi-cell gate: top current + top stale
    "random_k":            5,         #       multi-cell gate: deterministic sample
    "seed_5f":             20260718,
    "seed_5j":             20260719,
    "seed_6d":             20260722,
}

# Canonical frozen evidence.  Everything downstream reads support_pairs.csv from
# phase5f_d109_support_runtime.  results/phase5f_d109_clean is an incomplete
# exploratory run and is NOT used by the paper.
FROZEN_SUPPORT_PAIRS = "results/phase5f_d109_support_runtime/support_pairs.csv"

# =============================================================================
# PIPELINE -- dependency order is the list order
# =============================================================================
def build_steps(R: Path, dsn: str) -> list[dict]:
    """R = project root.  Returns the ordered step definitions."""

    def res(*p) -> str:
        return str(R.joinpath(*p))

    helper   = "run_ambient_width_exact.py"
    p5f      = "run_phase5f_d109.py"
    p5k      = "run_phase5k_cheap_hybrid_e2e.py"
    cache    = res("results", "phase4a_acs_pums_v3", "data")
    datadir  = res("results", "phase4g_ambient_width", "data")
    qerrors  = res("results", "phase4g_ambient_width", "qerrors_d109.csv")
    sp       = res(*FROZEN_SUPPORT_PAIRS.split("/"))
    C        = CONFIG

    common_db = lambda out: [
        "--phase5f-script", "@" + p5f,
        "--phase4g-helper", "@" + helper,
        "--person-cache", cache,
        "--data-dir", datadir,
        "--qerrors", qerrors,
        "--support-pairs", sp,
        "--dsn", dsn,
        "--out", res("results", out),
    ]

    return [
        # ---- Layer 1: produces the frozen severe set -------------------------
        dict(
            id="5f", script=p5f, needs_db=True,
            desc="d=109 support spectrum + refresh runtime (produces support_pairs.csv)",
            args=[
                "--project-root", str(R),
                "--phase4g-result", res("results", "phase4g_ambient_width"),
                "--phase4g-helper", "@" + helper,
                "--person-cache", cache,
                "--data-dir", datadir,
                "--qerrors", qerrors,
                "--dsn", dsn,
                "--out", res("results", "phase5f_d109_support_runtime"),
                "--support-thresholds", C["support_thresholds"],
                "--runtime-supports", C["runtime_supports"],
                "--repeats", str(C["repeats"]),
                "--min-runtime-edges", str(C["min_runtime_edges"]),
            ],
            outputs=["results/phase5f_d109_support_runtime/support_pairs.csv",
                     "results/phase5f_d109_support_runtime/support_summary.csv",
                     "results/phase5f_d109_support_runtime/runtime_summary.csv"],
        ),
        # ---- Layer 2: read the frozen set -----------------------------------
        dict(
            id="5i", script="run_phase5i_binning_sensitivity.py", needs_db=False,
            desc="screen sensitivity across seven binning schemes",
            args=[
                "--phase4g-helper", "@" + helper,
                "--person-cache", cache,
                "--data-dir", datadir,
                "--qerrors", qerrors,
                "--support-pairs", sp,
                "--out", res("results", "phase5i_binning_sensitivity"),
                "--support", str(C["support_floor"]),
            ],
            outputs=["results/phase5i_binning_sensitivity"],
        ),
        dict(
            id="5j_four", script="run_phase5j_four_state_attribution.py", needs_db=True,
            desc="four-state attribution (111.53 -> 111.56 -> 1.28 -> 1.00)",
            args=common_db("phase5j_four_state_attribution") + [
                "--support-floor", str(C["support_floor"]),
                "--severe-threshold", str(int(C["severe_threshold"])),
                "--repaired-threshold", str(int(C["repair_threshold"])),
            ],
            outputs=["results/phase5j_four_state_attribution"],
        ),
        dict(
            id="5j_retire", script="run_phase5j_retire_refresh_v2.py", needs_db=True,
            desc="oracle retire/refresh labels (132/9)",
            args=common_db("phase5j_retire_refresh_v2") + [
                "--support-floor", str(C["support_floor"]),
                "--repaired-threshold", str(int(C["repair_threshold"])),
                "--severe-threshold", str(int(C["severe_threshold"])),
                "--width", str(C["width"]),
                "--repeats", str(C["repeats"]),
            ],
            outputs=["results/phase5j_retire_refresh_v2/hybrid_actions.csv"],
        ),
        dict(
            id="5g", script="run_phase5g_query_feedback.py", needs_db=True,
            desc="oracle query-feedback baseline (uniform + Zipf, 5000 queries)",
            args=[
                "--project-root", str(R),
                "--phase5f-dir", res("results", "phase5f_d109_support_runtime"),
                "--phase5f-script", "@" + p5f,
                "--phase4g-helper", "@" + helper,
                "--dsn", dsn,
                "--out", res("results", "phase5g_query_feedback"),
                "--floor", str(C["support_floor"]),
                "--workload-length", str(C["workload_length"]),
                "--repeats", str(C["repeats"]),
                "--batch-width", str(C["width"]),
            ],
            outputs=["results/phase5g_query_feedback"],
        ),
        # ---- Layer 3: read the oracle labels --------------------------------
        dict(
            id="5k", script=p5k, needs_db=True,
            desc="O(M) classifier vs oracle (140/141 agreement)",
            args=common_db("phase5k_cheap_hybrid_e2e") + [
                "--oracle-actions", res("results", "phase5j_retire_refresh_v2", "hybrid_actions.csv"),
                "--support-floor", str(C["support_floor"]),
                "--retire-threshold", str(C["retire_threshold"]),
                "--width", str(C["width"]),
                "--repeats", str(C["repeats"]),
            ],
            outputs=["results/phase5k_cheap_hybrid_e2e/classifier_detail.csv",
                     "results/phase5k_cheap_hybrid_e2e/classifier_mismatches.csv"],
        ),
        dict(
            id="5l", script="run_phase5l_action_aware_cover.py", needs_db=True,
            desc="action-aware cover (14 calls / 371 slots)",
            args=common_db("phase5l_action_aware_cover") + [
                "--support-floor", str(C["support_floor"]),
                "--retire-threshold", str(C["retire_threshold"]),
                "--repair-threshold", str(C["repair_threshold"]),
                "--width", str(C["width"]),
                "--repeats", str(C["repeats"]),
            ],
            outputs=["results/phase5l_action_aware_cover"],
        ),
        # ---- Layer 4: multi-cell gate ---------------------------------------
        dict(
            id="6c", script="run_phase6c_multicell_phase5k_exact.py", needs_db=True,
            desc="multi-cell decision-safety gate (90 retire / 51 refresh)",
            args=common_db("phase6c_multicell_phase5k_exact") + [
                "--phase5k-script", "@" + p5k,
                "--oracle-actions", res("results", "phase5j_retire_refresh_v2", "hybrid_actions.csv"),
                "--support-floor", str(C["support_floor"]),
                "--retire-threshold", str(C["retire_threshold"]),
                "--width", str(C["width"]),
                "--top-k", str(C["top_k"]),
                "--random-k", str(C["random_k"]),
            ],
            outputs=["results/phase6c_multicell_phase5k_exact"],
        ),
        # ---- Layer 5: paired action audit -----------------------------------
        dict(
            id="6d", script="run_phase6d_action_aware_multicell_exact_v3.py", needs_db=True,
            desc="paired action audit (B8 / one-cell 14 / multi-cell 15)",
            args=common_db("phase6d_action_aware_multicell_exact") + [
                "--phase5k-script", "@" + p5k,
                "--oracle-actions", res("results", "phase5j_retire_refresh_v2", "hybrid_actions.csv"),
                "--phase6c-actions", res("results", "phase6c_multicell_phase5k_exact", "object_multicell_gate.csv"),
                "--phase6c-cells", res("results", "phase6c_multicell_phase5k_exact", "selected_cells_lower_order.csv"),
                "--support-floor", str(C["support_floor"]),
                "--retire-threshold", str(C["retire_threshold"]),
                "--width", str(C["width"]),
                "--repeats", str(C["repeats"]),
            ],
            outputs=["results/phase6d_action_aware_multicell_exact"],
        ),
        # ---- Independent line: discovery-verification bridge -----------------
        dict(
            id="6e", script="run_phase6e_verification_cost_bridge.py", needs_db=True,
            desc="verification-cost observations (input to 6F)",
            args=common_db("phase6e_verification_cost_bridge") + [
                "--support-floor", str(C["support_floor"]),
            ],
            outputs=["results/phase6e_verification_cost_bridge/verification_observations.csv",
                     "results/phase6e_verification_cost_bridge/floor20_templates.csv"],
        ),
        dict(
            id="6f", script="run_phase6f_theorem_correct_bridge.py", needs_db=False,
            desc="theorem-to-verification bridge (115.43 / 226.72 / 41-49x)",
            args=[
                "--phase6e-observations", res("results", "phase6e_verification_cost_bridge",
                                              "verification_observations.csv"),
                "--phase6e-templates", res("results", "phase6e_verification_cost_bridge",
                                           "floor20_templates.csv"),
                "--support-pairs", sp,
                "--out", res("results", "phase6f_theorem_correct_bridge"),
                "--support-floor", str(C["support_floor"]),
                "--controlled-s", str(C["controlled_s"]),
                "--alphas", C["alphas"],
                "--ranking-seeds", str(C["ranking_seeds"]),
            ],
            outputs=["results/phase6f_theorem_correct_bridge"],
        ),
        # ---- Offline: geometry ablation -------------------------------------
        dict(
            id="6a", script="run_6a_p5fplanner.py", needs_db=False,
            desc="leave-one-hub-out geometry ablation (141 -> 33 edges)",
            args=[],  # defaults are hardcoded in the script
            outputs=["results/phase6a_no_hub_ablation_p5fplanner"],
        ),
    ]


# =============================================================================
# CLAIM RECONCILIATION -- every number the paper reports, and where it comes from
# =============================================================================
def paper_claims(R: Path) -> list[dict]:
    """(paper location, description, expected, how to extract it)."""
    import pandas as pd

    def sp_severe(floor):
        f = R / FROZEN_SUPPORT_PAIRS
        d = pd.read_csv(f)
        return len(d[(d.floor == floor) & (d.pg_severe == 1)])

    def classifier(metric):
        d = pd.read_csv(R / "results/phase5k_cheap_hybrid_e2e/classifier_detail.csv")
        o = pd.read_csv(R / "results/phase5j_retire_refresh_v2/hybrid_actions.csv")
        o["_e"] = [tuple(sorted((int(a), int(b)))) for a, b in zip(o.i, o.j)]
        d["_e"] = [tuple(sorted((int(a), int(b)))) for a, b in zip(d.i, d.j)]
        norm = lambda v: "retire" if "retire" == str(v).strip().lower() else "refresh"
        orc = {e: norm(v) for e, v in zip(o["_e"], o.hybrid_action)}
        prd = {e: norm(v) for e, v in zip(d["_e"], d.predicted_action)}
        common = set(orc) & set(prd)
        if metric == "agreement":
            return sum(prd[e] == orc[e] for e in common)
        if metric == "n":
            return len(common)
        if metric == "recall":
            oref = {e for e in common if orc[e] == "refresh"}
            pref = {e for e in common if prd[e] == "refresh"}
            return len(oref & pref) / max(1, len(oref))
        if metric == "false_retire":
            pret = {e for e in common if prd[e] == "retire"}
            return sum(orc[e] == "refresh" for e in pret)

    return [
        dict(loc="Table: support spectrum, m=20", desc="severe pairs at m=20",
             expected=141, get=lambda: sp_severe(20),
             script="run_phase5f_d109.py", out=FROZEN_SUPPORT_PAIRS),
        dict(loc="Table: support spectrum, m=10", desc="severe pairs at m=10",
             expected=413, get=lambda: sp_severe(10),
             script="run_phase5f_d109.py", out=FROZEN_SUPPORT_PAIRS),
        dict(loc="Table: support spectrum, m=100", desc="severe pairs at m=100",
             expected=111, get=lambda: sp_severe(100),
             script="run_phase5f_d109.py", out=FROZEN_SUPPORT_PAIRS),
        dict(loc="RQ6 classifier", desc="pairs compared",
             expected=141, get=lambda: classifier("n"),
             script="run_phase5k_cheap_hybrid_e2e.py",
             out="results/phase5k_cheap_hybrid_e2e/classifier_detail.csv"),
        dict(loc="RQ6 classifier", desc="oracle agreement (140/141)",
             expected=140, get=lambda: classifier("agreement"),
             script="run_phase5k_cheap_hybrid_e2e.py",
             out="results/phase5k_cheap_hybrid_e2e/classifier_detail.csv"),
        dict(loc="RQ6 classifier", desc="refresh recall",
             expected=1.0, get=lambda: classifier("recall"),
             script="run_phase5k_cheap_hybrid_e2e.py",
             out="results/phase5k_cheap_hybrid_e2e/classifier_detail.csv"),
        dict(loc="RQ6 classifier", desc="false retirements",
             expected=0, get=lambda: classifier("false_retire"),
             script="run_phase5k_cheap_hybrid_e2e.py",
             out="results/phase5k_cheap_hybrid_e2e/classifier_detail.csv"),
    ]


# =============================================================================
# RUNNER
# =============================================================================
def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def find_script(root: Path, name: str) -> Path | None:
    for d in ("phase5_validation", "reviewer_validation", "phase6_review", "scripts"):
        c = root / d / name
        if c.exists():
            return c
    hits = [p for p in root.rglob(name)
            if "artifact_release" not in str(p) and "deprecated" not in str(p)]
    return hits[0] if hits else None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path.cwd())
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--dsn", default="postgresql://postgres:postgres@localhost:5432/postgres")
    ap.add_argument("--fresh", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--only", default="")
    ap.add_argument("--from", dest="start", default="")
    ap.add_argument("--offline-only", action="store_true")
    ap.add_argument("--verify-only", action="store_true")
    a = ap.parse_args()

    R = a.root.resolve()
    steps = build_steps(R, a.dsn)
    log_dir = R / f"run_all_logs_{time.strftime('%Y%m%d_%H%M%S')}"
    log_dir.mkdir(parents=True, exist_ok=True)

    # ---- resolve scripts ----------------------------------------------------
    print("=" * 78)
    print("SCRIPT RESOLUTION")
    print("=" * 78)
    missing = []
    for s in steps:
        p = find_script(R, s["script"])
        s["path"] = p
        flag = "OK " if p else "MISS"
        print(f"  [{flag}] {s['id']:10s} {s['script']}")
        if not p:
            missing.append(s["script"])
    if missing:
        print(f"\nERROR: {len(missing)} script(s) not found. Fix paths before running.")
        return 2

    # substitute @script placeholders with resolved absolute paths
    for s in steps:
        s["args"] = [
            (str(find_script(R, v[1:])) if isinstance(v, str) and v.startswith("@") else v)
            for v in s["args"]
        ]

    # ---- select steps -------------------------------------------------------
    sel = steps
    if a.only:
        want = {x.strip() for x in a.only.split(",")}
        sel = [s for s in steps if s["id"] in want]
    if a.start:
        idx = next((i for i, s in enumerate(steps) if s["id"] == a.start), 0)
        sel = steps[idx:]
    if a.offline_only:
        sel = [s for s in sel if not s["needs_db"]]

    if a.dry_run:
        print("\n" + "=" * 78)
        print("COMMANDS (dry run)")
        print("=" * 78)
        for s in sel:
            print(f"\n# {s['id']}: {s['desc']}")
            print(" ".join([a.python, str(s["path"])] + s["args"]))
        return 0

    # ---- execute ------------------------------------------------------------
    results = []
    if not a.verify_only:
        for s in sel:
            if a.fresh:
                for o in s["outputs"]:
                    t = R / o
                    d = t if t.is_dir() else t.parent
                    if d.exists() and d != R:
                        shutil.rmtree(d, ignore_errors=True)

            print("\n" + "=" * 78)
            print(f"STEP {s['id']}  --  {s['desc']}")
            print("=" * 78)
            t0 = time.time()
            logf = log_dir / f"{s['id']}.log"
            with open(logf, "w", encoding="utf-8") as fh:
                pr = subprocess.run([a.python, str(s["path"])] + s["args"],
                                    cwd=R, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True)
                fh.write(pr.stdout or "")
            dt = time.time() - t0
            tail = (pr.stdout or "").strip().splitlines()[-12:]
            print("\n".join(tail))

            ok = pr.returncode == 0
            for o in s["outputs"]:
                t = R / o
                if not t.exists() or (t.is_file() and t.stat().st_size == 0):
                    print(f"  MISSING OUTPUT: {o}")
                    ok = False
            print(f"  -> {'OK' if ok else 'FAILED'}  ({dt:.1f}s, log: {logf.name})")
            results.append(dict(step=s["id"], ok=ok, seconds=round(dt, 1),
                                returncode=pr.returncode, log=str(logf)))
            if not ok:
                print(f"\nStopping: step {s['id']} failed. See {logf}")
                break

    # ---- reconcile ----------------------------------------------------------
    print("\n" + "=" * 78)
    print("CLAIM RECONCILIATION")
    print("=" * 78)
    rows, bad = [], 0
    for c in paper_claims(R):
        try:
            actual = c["get"]()
            exp = c["expected"]
            match = (abs(actual - exp) < 1e-6) if isinstance(exp, float) else (actual == exp)
        except Exception as e:
            actual, match = f"ERROR: {e}", False
        if not match:
            bad += 1
        print(f"  [{'OK ' if match else 'BAD'}] {c['loc']:36s} {c['desc']:28s} "
              f"expected={c['expected']!s:>8}  actual={actual!s:>8}")
        rows.append(dict(paper_location=c["loc"], description=c["desc"],
                         expected=c["expected"], actual=actual,
                         match=match, script=c["script"], output_file=c["out"]))

    with open(R / "CLAIMS.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    # ---- manifest -----------------------------------------------------------
    man = []
    for s in steps:
        if s["path"]:
            man.append(dict(kind="script", path=str(s["path"].relative_to(R)),
                            sha256=sha256(s["path"])))
    for pat in ("results/**/*.csv", "results/**/*.json"):
        for p in sorted(R.glob(pat)):
            if p.is_file() and p.stat().st_size < 50 * 1 << 20:
                man.append(dict(kind="output", path=str(p.relative_to(R)),
                                sha256=sha256(p)))
    with open(R / "MANIFEST.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["kind", "path", "sha256"])
        w.writeheader()
        w.writerows(man)

    (R / "RUN_CONFIG.json").write_text(
        json.dumps(dict(config=CONFIG, steps=results,
                        canonical_support_pairs=FROZEN_SUPPORT_PAIRS,
                        timestamp=time.strftime("%Y-%m-%d %H:%M:%S")), indent=2),
        encoding="utf-8")

    print("\n" + "=" * 78)
    print(f"  steps run     : {len(results)}  "
          f"({sum(1 for r in results if r['ok'])} ok, "
          f"{sum(1 for r in results if not r['ok'])} failed)")
    print(f"  claims checked: {len(rows)}  ({len(rows)-bad} match, {bad} mismatch)")
    print(f"  wrote         : CLAIMS.csv, MANIFEST.csv ({len(man)} files), RUN_CONFIG.json")
    print(f"  logs          : {log_dir.name}")
    print("=" * 78)
    return 1 if (bad or any(not r["ok"] for r in results)) else 0


if __name__ == "__main__":
    sys.exit(main())
