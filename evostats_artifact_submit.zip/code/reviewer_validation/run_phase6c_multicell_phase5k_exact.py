#!/usr/bin/env python3
r"""
Phase 6C: exact multi-cell extension of the paper's Phase 5K policy.

This runner deliberately extends, rather than replaces, the frozen Phase 5K
scientific contract.

Required reproduction gate
--------------------------
1. Reconstruct the exact frozen Phase 5F A -> ANALYZE -> replace by B state.
2. Reuse Phase 5K's Eq. (19) lower-order classifier on the original verified
   cell for every harmful pair.
3. Require the paper split and oracle comparison:
      harmful = 141
      predicted retire = 131
      predicted refresh = 10
      oracle agreement = 140 / 141
      false retire = 0
   No multi-cell conclusion is produced if this gate fails.

Multi-cell extension
--------------------
For every Phase-5K predicted-retire object, select supported equality cells
from four evidence sources:
  * the original audited max-ratio cell;
  * top-K current-support cells;
  * top-K cells from the object's actual stale PostgreSQL MCV payload;
  * K deterministic random current-supported cells.

The stale-MCV cells are read from pg_statistic_ext_data after reconstructing
the exact stale catalog. "Reference-hot" cells are not used as an MCV proxy.

For each selected cell, apply the same Phase 5K lower-order test:

    n * P_B(c_i = v_i) * P_B(c_j = v_j)

An object remains a multi-cell retire candidate only if every selected
supported cell has lower-order Q-error <= rho. Any uncertainty is converted
to refresh.

System validation
-----------------
Each policy starts from an independently reconstructed stale catalog and then
executes the exact Phase 5K order:
  * DROP the policy's predicted-retire objects;
  * execute the same frozen B8 groups.

Policies:
  b8_refresh:
      retire none.
  phase5k_original:
      retire the original 131 Phase-5K predictions.
  multicell_gate:
      retire only objects passing the expanded lower-order audit.

After action execution, the runner verifies:
  * all 141 original frozen severe predicates; and
  * every selected multi-cell predicate.

This is a safety audit. It intentionally keeps the frozen B8 groups. The
action-aware cover should be recomputed only after the new retained-edge set
is known.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def geometric_mean(values: list[float]) -> float:
    if not values:
        return float("nan")
    return float(
        math.exp(
            sum(math.log(max(float(value), 1e-300)) for value in values)
            / len(values)
        )
    )


def pair_counts(
    matrix: np.ndarray,
    i: int,
    j: int,
    card_i: int,
    card_j: int,
) -> np.ndarray:
    flat = (
        matrix[:, i].astype(np.int64) * int(card_j)
        + matrix[:, j].astype(np.int64)
    )
    return np.bincount(
        flat,
        minlength=int(card_i) * int(card_j),
    ).reshape(int(card_i), int(card_j))


def deterministic_random_indices(
    eligible_flat: np.ndarray,
    k: int,
    seed_text: str,
) -> np.ndarray:
    if k <= 0 or len(eligible_flat) == 0:
        return np.asarray([], dtype=np.int64)
    digest = hashlib.sha256(seed_text.encode("utf-8")).digest()
    seed = int.from_bytes(digest[:8], "little") % (2**32)
    rng = np.random.default_rng(seed)
    take = min(int(k), len(eligible_flat))
    return np.sort(rng.choice(eligible_flat, size=take, replace=False))


def parse_mcv_value(value: Any) -> int:
    if value is None:
        raise ValueError("NULL MCV value")
    text = str(value).strip()
    # PostgreSQL text output for integer-valued categorical columns.
    if text.startswith('"') and text.endswith('"'):
        text = text[1:-1]
    return int(float(text))


def read_stale_mcv_cells(
    conn,
    schema: str,
    edges: set[tuple[int, int]],
    top_k: int,
) -> dict[tuple[int, int], list[dict[str, Any]]]:
    """
    Read each pair object's actual stale MCV payload from PostgreSQL.

    Values are returned in the statistics object's column order. All EvoStats
    pair objects are created as ON c{i}, c{j} with i < j.
    """
    result: dict[tuple[int, int], list[dict[str, Any]]] = {
        edge: [] for edge in edges
    }
    sql = f"""
        SELECT
            item.index,
            item.values,
            item.nulls,
            item.frequency,
            item.base_frequency
        FROM pg_statistic_ext AS e
        JOIN pg_statistic_ext_data AS d
          ON d.stxoid = e.oid
        CROSS JOIN LATERAL pg_mcv_list_items(d.stxdmcv) AS item
        WHERE e.stxrelid = %s::regclass
          AND e.stxname = %s
        ORDER BY item.frequency DESC, item.index
        LIMIT %s
    """
    with conn.cursor() as cur:
        for edge in sorted(edges):
            i, j = edge
            cur.execute(
                sql,
                (
                    f"{qi(schema)}.fact",
                    f"evs_{i}_{j}",
                    max(int(top_k) * 20, int(top_k)),
                ),
            )
            rows = []
            for index, values, nulls, frequency, base_frequency in cur.fetchall():
                if values is None or len(values) != 2:
                    continue
                if nulls is not None and any(bool(flag) for flag in nulls):
                    continue
                try:
                    vi = parse_mcv_value(values[0])
                    vj = parse_mcv_value(values[1])
                except (TypeError, ValueError):
                    continue
                rows.append(
                    {
                        "value_i": vi,
                        "value_j": vj,
                        "mcv_index": int(index),
                        "stale_mcv_frequency": float(frequency),
                        "stale_mcv_base_frequency": float(base_frequency),
                    }
                )
            result[edge] = rows
    return result


def select_cells_for_edge(
    *,
    B: np.ndarray,
    cards: list[int],
    edge: tuple[int, int],
    original_cell: tuple[int, int],
    stale_mcv_rows: list[dict[str, Any]],
    support_floor: int,
    top_k: int,
    random_k: int,
) -> list[dict[str, Any]]:
    i, j = edge
    c1 = pair_counts(B, i, j, cards[i], cards[j])
    eligible = c1 >= int(support_floor)
    eligible_flat = np.flatnonzero(eligible.ravel())

    selected: dict[tuple[int, int], dict[str, Any]] = {}

    def add_cell(
        vi: int,
        vj: int,
        source: str,
        *,
        mcv_index: int | None = None,
        stale_mcv_frequency: float | None = None,
        stale_mcv_base_frequency: float | None = None,
    ) -> None:
        vi, vj = int(vi), int(vj)
        if not (0 <= vi < cards[i] and 0 <= vj < cards[j]):
            return
        row = selected.setdefault(
            (vi, vj),
            {
                "sources": set(),
                "mcv_index": None,
                "stale_mcv_frequency": None,
                "stale_mcv_base_frequency": None,
            },
        )
        row["sources"].add(source)
        if mcv_index is not None:
            row["mcv_index"] = int(mcv_index)
            row["stale_mcv_frequency"] = float(stale_mcv_frequency)
            row["stale_mcv_base_frequency"] = float(
                stale_mcv_base_frequency
            )

    add_cell(
        int(original_cell[0]),
        int(original_cell[1]),
        "original_audited",
    )

    if len(eligible_flat):
        ordered_current = eligible_flat[
            np.argsort(
                c1.ravel()[eligible_flat],
                kind="stable",
            )[::-1]
        ]
        for flat in ordered_current[: min(top_k, len(ordered_current))]:
            vi, vj = np.unravel_index(
                int(flat),
                (cards[i], cards[j]),
            )
            add_cell(int(vi), int(vj), "top_current_support")

        random_flats = deterministic_random_indices(
            eligible_flat,
            random_k,
            f"{i}|{j}|phase6c-phase5k",
        )
        for flat in random_flats:
            vi, vj = np.unravel_index(
                int(flat),
                (cards[i], cards[j]),
            )
            add_cell(int(vi), int(vj), "random_supported")

    # Select actual stale-MCV entries that remain inside the supported scope.
    accepted_mcv = 0
    for item in stale_mcv_rows:
        vi = int(item["value_i"])
        vj = int(item["value_j"])
        if not (0 <= vi < cards[i] and 0 <= vj < cards[j]):
            continue
        if int(c1[vi, vj]) < int(support_floor):
            continue
        add_cell(
            vi,
            vj,
            "stale_mcv_supported",
            mcv_index=int(item["mcv_index"]),
            stale_mcv_frequency=float(item["stale_mcv_frequency"]),
            stale_mcv_base_frequency=float(
                item["stale_mcv_base_frequency"]
            ),
        )
        accepted_mcv += 1
        if accepted_mcv >= int(top_k):
            break

    rows: list[dict[str, Any]] = []
    for (vi, vj), meta in sorted(selected.items()):
        rows.append(
            {
                "i": i,
                "j": j,
                "value_i": vi,
                "value_j": vj,
                "current_count": int(c1[vi, vj]),
                "supported": int(c1[vi, vj] >= int(support_floor)),
                "sources": "|".join(sorted(meta["sources"])),
                "mcv_index": meta["mcv_index"],
                "stale_mcv_frequency": meta["stale_mcv_frequency"],
                "stale_mcv_base_frequency": meta[
                    "stale_mcv_base_frequency"
                ],
            }
        )
    return rows


def add_lower_order_evidence(
    B: np.ndarray,
    templates: list[dict[str, Any]],
    threshold: float,
) -> list[dict[str, Any]]:
    n = int(B.shape[0])
    requested: dict[int, set[int]] = {}
    for row in templates:
        requested.setdefault(int(row["i"]), set()).add(int(row["value_i"]))
        requested.setdefault(int(row["j"]), set()).add(int(row["value_j"]))

    counts: dict[tuple[int, int], int] = {}
    for column, values in requested.items():
        vector = B[:, column].astype(np.int64)
        histogram = np.bincount(
            vector,
            minlength=int(vector.max()) + 1,
        )
        for value in values:
            counts[(column, value)] = (
                int(histogram[value]) if value < len(histogram) else 0
            )

    result = []
    for row in templates:
        i, j = int(row["i"]), int(row["j"])
        vi, vj = int(row["value_i"]), int(row["value_j"])
        count_i = counts[(i, vi)]
        count_j = counts[(j, vj)]
        actual = int(row["current_count"])
        estimate = (count_i * count_j) / n
        q = max(
            max(float(estimate), 1.0) / max(float(actual), 1.0),
            max(float(actual), 1.0) / max(float(estimate), 1.0),
        )
        result.append(
            {
                **row,
                "marginal_count_i": count_i,
                "marginal_count_j": count_j,
                "lower_order_estimate": float(estimate),
                "lower_order_qerror": float(q),
                "cell_lower_order_adequate": int(q <= float(threshold)),
            }
        )
    return result


def evaluate_cells(
    *,
    pg4g,
    conn,
    schema: str,
    templates: list[dict[str, Any]],
    policy: str,
    progress_every: int,
) -> list[dict[str, Any]]:
    rows = []
    total = len(templates)
    for index, row in enumerate(templates, start=1):
        q, estimate, actual = pg4g.explain_q(
            conn,
            schema,
            int(row["i"]),
            int(row["j"]),
            int(row["value_i"]),
            int(row["value_j"]),
        )
        if int(round(float(actual))) != int(row["current_count"]):
            raise RuntimeError(
                "PostgreSQL/current-snapshot count mismatch for "
                f"({row['i']},{row['j']}) cell "
                f"({row['value_i']},{row['value_j']}): "
                f"PG={actual}, B={row['current_count']}"
            )
        rows.append(
            {
                **row,
                "policy": policy,
                "postgres_estimated_rows": float(estimate),
                "postgres_actual_rows": float(actual),
                "postgres_qerror": float(q),
            }
        )
        if (
            progress_every > 0
            and (index % progress_every == 0 or index == total)
        ):
            print(
                f"[progress] {policy} cells {index}/{total}",
                flush=True,
            )
    return rows


def summarize_policy(
    policy: str,
    retired: set[tuple[int, int]],
    refreshed: set[tuple[int, int]],
    action_seconds: float,
    original_repair: dict[str, Any],
    cell_rows: list[dict[str, Any]],
    threshold: float,
) -> dict[str, Any]:
    qvalues = [float(row["postgres_qerror"]) for row in cell_rows]
    failed = [value for value in qvalues if value > float(threshold)]
    return {
        "policy": policy,
        "retired_pairs": len(retired),
        "refreshed_pairs": len(refreshed),
        "action_seconds": float(action_seconds),
        "original_repair_fraction": float(original_repair["repair"]),
        "original_qerror_geomean": float(original_repair["fresh_qgeo"]),
        "selected_cells": len(qvalues),
        "selected_cell_repair_fraction": (
            1.0 - len(failed) / len(qvalues) if qvalues else float("nan")
        ),
        "selected_qerror_geomean": geometric_mean(qvalues),
        "selected_qerror_median": (
            statistics.median(qvalues) if qvalues else float("nan")
        ),
        "selected_qerror_p90": qtile(qvalues, 0.90),
        "selected_qerror_max": max(qvalues) if qvalues else float("nan"),
        "selected_failed_cells": len(failed),
    }


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase5f-script", type=Path, required=True)
    ap.add_argument("--phase4g-helper", type=Path, required=True)
    ap.add_argument("--phase5k-script", type=Path, required=True)
    ap.add_argument("--person-cache", type=Path, required=True)
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--qerrors", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--oracle-actions", type=Path, required=True)
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument(
        "--schema",
        default="evostats_phase6c_multicell_phase5k",
    )
    ap.add_argument("--rows", type=int, default=40000)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--support-floor", type=int, default=20)
    ap.add_argument("--retire-threshold", type=float, default=2.0)
    ap.add_argument("--width", type=int, default=8)
    ap.add_argument("--top-k", type=int, default=5)
    ap.add_argument("--random-k", type=int, default=5)
    ap.add_argument("--progress-every", type=int, default=250)
    return ap.parse_args()


def main() -> int:
    args = parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(
        args.phase5f_script.resolve(),
        "phase5f_exact_phase6c",
    )
    pg4g = load_module(
        args.phase4g_helper.resolve(),
        "phase4g_exact_phase6c",
    )
    phase5k = load_module(
        args.phase5k_script.resolve(),
        "phase5k_exact_phase6c",
    )

    qframe = pd.read_csv(args.qerrors)
    support = pd.read_csv(args.support_pairs)
    _, A, B, cards, names, metadata = phase5f.reconstruct_exact_phase4g(
        args,
        qframe,
    )

    severe_frame = support[
        (support["floor"] == args.support_floor)
        & (support["pg_severe"] == 1)
    ].copy()
    if len(severe_frame) == 0:
        raise RuntimeError("No frozen severe pairs")

    harmful = {
        (int(row.i), int(row.j))
        for row in severe_frame.itertuples(index=False)
    }
    rows_by_edge = {
        (int(row["i"]), int(row["j"])): row
        for row in severe_frame.to_dict("records")
    }

    (
        phase5k_retire,
        phase5k_refresh,
        phase5k_detail,
        phase5k_seconds,
    ) = phase5k.classify_from_current_snapshot(
        B,
        rows_by_edge,
        args.retire_threshold,
    )
    oracle = phase5k.load_oracle_actions(args.oracle_actions)
    agreement = phase5k.agreement_report(phase5k_detail, oracle)

    expected_split = {
        "harmful": 141,
        "retire": 131,
        "refresh": 10,
    }
    observed_split = {
        "harmful": len(harmful),
        "retire": len(phase5k_retire),
        "refresh": len(phase5k_refresh),
    }
    if observed_split != expected_split:
        raise RuntimeError(
            "Phase 5K reproduction failed: "
            f"expected={expected_split}, observed={observed_split}"
        )
    if not agreement.get("available"):
        raise RuntimeError("Phase 5J oracle actions were not loaded")
    if int(agreement["pairs_compared"]) != 141:
        raise RuntimeError(
            f"Oracle comparison count is {agreement['pairs_compared']}, "
            "expected 141"
        )
    if abs(float(agreement["exact_agreement"]) - (140 / 141)) > 1e-12:
        raise RuntimeError(
            "Phase 5K/oracle agreement did not reproduce 140/141"
        )
    if int(agreement["fn_refresh"]) != 0:
        raise RuntimeError(
            "Phase 5K reproduction has a false-retire decision"
        )
    if int(agreement["fp_refresh"]) != 1:
        raise RuntimeError(
            "Phase 5K reproduction did not recover the one conservative "
            "extra refresh"
        )

    print(
        "[phase5k gate] "
        f"harmful={len(harmful)} "
        f"retire={len(phase5k_retire)} "
        f"refresh={len(phase5k_refresh)} "
        f"agreement=140/141 false_retire=0",
        flush=True,
    )

    groups = phase5f.bounded_greedy(harmful, args.width)

    conn = pg4g.connect(args.dsn)
    try:
        pg4g.create_schema(conn, args.schema, len(names))
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, len(names))

        # Exact stale catalog is required before reading actual stale MCVs.
        phase5f.establish_stale(
            pg4g,
            conn,
            args.schema,
            A,
            B,
            args.statistics_target,
        )
        stale_mcv = read_stale_mcv_cells(
            conn,
            args.schema,
            phase5k_retire,
            args.top_k,
        )

        templates: list[dict[str, Any]] = []
        for edge in sorted(phase5k_retire):
            original = rows_by_edge[edge]
            selected = select_cells_for_edge(
                B=B,
                cards=cards,
                edge=edge,
                original_cell=(
                    int(original["value_i"]),
                    int(original["value_j"]),
                ),
                stale_mcv_rows=stale_mcv.get(edge, []),
                support_floor=args.support_floor,
                top_k=args.top_k,
                random_k=args.random_k,
            )
            for row in selected:
                row["variable_i"] = str(original["variable_i"])
                row["variable_j"] = str(original["variable_j"])
                templates.append(row)

        templates = add_lower_order_evidence(
            B,
            templates,
            args.retire_threshold,
        )

        original_rows = [
            row
            for row in templates
            if "original_audited" in str(row["sources"]).split("|")
        ]
        if len(original_rows) != len(phase5k_retire):
            raise RuntimeError(
                "Original-cell count mismatch for Phase 5K retirees"
            )
        original_fail = [
            row
            for row in original_rows
            if int(row["cell_lower_order_adequate"]) != 1
        ]
        if original_fail:
            write_csv(
                args.out / "ORIGINAL_PHASE5K_REPRODUCTION_FAILURES.csv",
                original_fail,
            )
            raise RuntimeError(
                "Expanded classifier failed to reproduce one or more "
                "original Phase 5K retire decisions"
            )

        by_edge: dict[tuple[int, int], list[dict[str, Any]]] = {}
        for row in templates:
            by_edge.setdefault(
                (int(row["i"]), int(row["j"])),
                [],
            ).append(row)

        object_rows: list[dict[str, Any]] = []
        multicell_retire: set[tuple[int, int]] = set()
        promoted_refresh: set[tuple[int, int]] = set()

        for edge in sorted(phase5k_retire):
            rows = [
                row
                for row in by_edge[edge]
                if int(row["supported"]) == 1
            ]
            failed = [
                row
                for row in rows
                if int(row["cell_lower_order_adequate"]) != 1
            ]
            if failed:
                promoted_refresh.add(edge)
            else:
                multicell_retire.add(edge)

            qvalues = [float(row["lower_order_qerror"]) for row in rows]
            worst = max(
                rows,
                key=lambda row: float(row["lower_order_qerror"]),
            )
            object_rows.append(
                {
                    "i": edge[0],
                    "j": edge[1],
                    "variable_i": rows_by_edge[edge]["variable_i"],
                    "variable_j": rows_by_edge[edge]["variable_j"],
                    "selected_supported_cells": len(rows),
                    "failed_lower_order_cells": len(failed),
                    "multicell_action": (
                        "retire" if not failed else "refresh"
                    ),
                    "lower_order_qerror_geomean": geometric_mean(qvalues),
                    "lower_order_qerror_median": statistics.median(qvalues),
                    "lower_order_qerror_p90": qtile(qvalues, 0.90),
                    "lower_order_qerror_max": max(qvalues),
                    "worst_value_i": int(worst["value_i"]),
                    "worst_value_j": int(worst["value_j"]),
                    "worst_sources": str(worst["sources"]),
                }
            )

        multicell_refresh = set(phase5k_refresh) | promoted_refresh

        print(
            "[multicell gate] "
            f"selected_cells={len(templates)} "
            f"retire={len(multicell_retire)} "
            f"refresh={len(multicell_refresh)} "
            f"promoted_refresh={len(promoted_refresh)}",
            flush=True,
        )

        policies = [
            ("b8_refresh", set()),
            ("phase5k_original", set(phase5k_retire)),
            ("multicell_gate", set(multicell_retire)),
        ]
        policy_rows: list[dict[str, Any]] = []
        evaluated_cells: list[dict[str, Any]] = []

        severe_records = severe_frame.to_dict("records")
        for policy, retire_edges in policies:
            phase5k.ensure_pair_statistics(
                conn,
                args.schema,
                harmful,
            )
            phase5f.establish_stale(
                pg4g,
                conn,
                args.schema,
                A,
                B,
                args.statistics_target,
            )

            start = time.perf_counter()
            if retire_edges:
                phase5k.drop_pair_statistics(
                    conn,
                    args.schema,
                    retire_edges,
                )
            phase5k.run_groups(
                pg4g,
                conn,
                args.schema,
                groups,
                args.statistics_target,
            )
            action_seconds = time.perf_counter() - start

            original_repair = phase5f.verify_repair(
                pg4g,
                conn,
                args.schema,
                severe_records,
                harmful,
            )
            cell_rows = evaluate_cells(
                pg4g=pg4g,
                conn=conn,
                schema=args.schema,
                templates=templates,
                policy=policy,
                progress_every=args.progress_every,
            )
            evaluated_cells.extend(cell_rows)

            refreshed_edges = harmful - retire_edges
            summary = summarize_policy(
                policy,
                retire_edges,
                refreshed_edges,
                action_seconds,
                original_repair,
                cell_rows,
                args.retire_threshold,
            )
            policy_rows.append(summary)

            print(
                f"[policy] {policy} "
                f"original_repair={summary['original_repair_fraction']:.4f} "
                f"selected_repair="
                f"{summary['selected_cell_repair_fraction']:.4f} "
                f"Qmax={summary['selected_qerror_max']:.4f}",
                flush=True,
            )
    finally:
        conn.close()

    mcv_covered_objects = sum(
        any(
            "stale_mcv_supported" in str(row["sources"]).split("|")
            for row in by_edge[edge]
        )
        for edge in phase5k_retire
    )
    mcv_selected_cells = sum(
        "stale_mcv_supported" in str(row["sources"]).split("|")
        for row in templates
    )

    report = {
        "experiment": "phase6c_multicell_phase5k_exact",
        "scientific_contract": (
            "Exact Phase 5K Eq. (19) classifier extended to multiple "
            "supported cells; Phase 5J labels are used only as a "
            "retrospective reproduction oracle."
        ),
        "phase5k_reproduction": {
            "harmful": len(harmful),
            "predicted_retire": len(phase5k_retire),
            "predicted_refresh": len(phase5k_refresh),
            "classifier_seconds": phase5k_seconds,
            "oracle_agreement": {
                key: value
                for key, value in agreement.items()
                if key != "mismatches"
            },
        },
        "cell_selection": {
            "selected_cells": len(templates),
            "predicted_retire_objects_audited": len(phase5k_retire),
            "objects_with_supported_stale_mcv_cell": mcv_covered_objects,
            "selected_stale_mcv_cells": mcv_selected_cells,
            "top_current_per_object": args.top_k,
            "top_stale_mcv_per_object": args.top_k,
            "random_supported_per_object": args.random_k,
            "support_floor": args.support_floor,
        },
        "multicell_gate": {
            "retire": len(multicell_retire),
            "refresh": len(multicell_refresh),
            "original_refresh": len(phase5k_refresh),
            "promoted_from_retire_to_refresh": len(promoted_refresh),
            "retire_threshold": args.retire_threshold,
        },
        "execution": {
            "frozen_b8_calls": len(groups),
            "frozen_b8_max_width": max(len(group) for group in groups),
            "policies": policy_rows,
            "note": (
                "This safety audit intentionally keeps the frozen B8 "
                "groups. Recompute the mixed action-aware cover after the "
                "new retained-edge set is known."
            ),
        },
        "reconstruction_metadata": metadata,
    }

    write_csv(args.out / "phase5k_classifier_detail.csv", phase5k_detail)
    write_csv(
        args.out / "phase5k_classifier_mismatches.csv",
        agreement.get("mismatches", []),
    )
    write_csv(args.out / "selected_cells_lower_order.csv", templates)
    write_csv(args.out / "object_multicell_gate.csv", object_rows)
    write_csv(
        args.out / "promoted_refresh_objects.csv",
        [
            row
            for row in object_rows
            if row["multicell_action"] == "refresh"
        ],
    )
    write_csv(args.out / "system_cell_results.csv", evaluated_cells)
    write_csv(args.out / "policy_summary.csv", policy_rows)
    (args.out / "gate_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    report_lines = [
        "=" * 72,
        "PHASE 6C: MULTI-CELL PHASE-5K AUDIT",
        "=" * 72,
        f"harmful objects                   : {len(harmful)}",
        f"Phase 5K predicted retire         : {len(phase5k_retire)}",
        f"Phase 5K predicted refresh        : {len(phase5k_refresh)}",
        "Phase 5K/oracle agreement         : 140/141",
        "Phase 5K false retire             : 0",
        f"selected supported cells          : {len(templates)}",
        f"objects with stale-MCV evidence   : {mcv_covered_objects}",
        f"multi-cell retire                 : {len(multicell_retire)}",
        f"multi-cell refresh                : {len(multicell_refresh)}",
        f"promoted refresh                  : {len(promoted_refresh)}",
        "",
    ]
    for row in policy_rows:
        report_lines.extend(
            [
                f"{row['policy']}:",
                f"  retired/refreshed   = "
                f"{row['retired_pairs']}/{row['refreshed_pairs']}",
                f"  original repair     = "
                f"{row['original_repair_fraction']:.4f}",
                f"  selected repair     = "
                f"{row['selected_cell_repair_fraction']:.4f}",
                f"  selected Qgeo/Qmax  = "
                f"{row['selected_qerror_geomean']:.4f}/"
                f"{row['selected_qerror_max']:.4f}",
                f"  action seconds      = "
                f"{row['action_seconds']:.4f}",
                "",
            ]
        )
    (args.out / "REPORT.txt").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )

    print("\n" + "\n".join(report_lines))
    print(f"report: {args.out / 'REPORT.txt'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
