#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, json, math, random, statistics
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

Edge = tuple[int, int]


def canon(i: int, j: int) -> Edge:
    return (i, j) if i < j else (j, i)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def qtile(xs, q):
    return float(np.quantile(np.asarray(xs, dtype=float), q))


def load_inputs(obs_path: Path, tpl_path: Path, support_path: Path, floor: int):
    obs = pd.read_csv(obs_path)
    tpl = pd.read_csv(tpl_path)
    sup = pd.read_csv(support_path)

    need_obs = {"repeat", "i", "j", "probe_seconds"}
    need_tpl = {"i", "j", "qhat", "variable_i", "variable_j"}
    need_sup = {"floor", "i", "j", "pg_severe"}
    if not need_obs.issubset(obs.columns):
        raise RuntimeError(f"observations lack {sorted(need_obs-set(obs.columns))}")
    if not need_tpl.issubset(tpl.columns):
        raise RuntimeError(f"templates lack {sorted(need_tpl-set(tpl.columns))}")
    if not need_sup.issubset(sup.columns):
        raise RuntimeError(f"support lacks {sorted(need_sup-set(sup.columns))}")

    edges, qhat, names = [], {}, {}
    for r in tpl.itertuples(index=False):
        e = canon(int(r.i), int(r.j))
        edges.append(e)
        qhat[e] = float(r.qhat)
        names[int(r.i)] = str(r.variable_i)
        names[int(r.j)] = str(r.variable_j)
    if len(edges) != len(set(edges)):
        raise RuntimeError("duplicate templates")

    costs: dict[int, dict[Edge, float]] = {}
    for r in obs.itertuples(index=False):
        rep = int(r.repeat)
        e = canon(int(r.i), int(r.j))
        if e in costs.setdefault(rep, {}):
            raise RuntimeError(f"duplicate observation rep={rep}, edge={e}")
        costs[rep][e] = float(r.probe_seconds)

    truth = {
        canon(int(r.i), int(r.j))
        for r in sup[sup["floor"] == floor].itertuples(index=False)
        if int(r.pg_severe) == 1
    }

    expected = set(edges)
    for rep, mapping in costs.items():
        if set(mapping) != expected:
            raise RuntimeError(f"rep {rep} does not cover all {len(edges)} edges")

    return edges, qhat, names, costs, truth


def replay(order: list[Edge], truth: set[Edge], costs: dict[Edge, float]):
    found, sec = set(), 0.0
    first_p, first_s = None, None
    for k, e in enumerate(order, 1):
        sec += costs[e]
        if e in truth:
            found.add(e)
            if first_p is None:
                first_p, first_s = k, sec
        if len(found) == len(truth):
            return {
                "first_hit_probes": first_p,
                "first_hit_seconds": first_s,
                "full_recall_probes": k,
                "full_recall_seconds": sec,
            }
    raise RuntimeError("full recall not reached")


def random_order(edges, seed):
    out = list(edges)
    random.Random(seed).shuffle(out)
    return out


def qhat_order(edges, qhat):
    return sorted(edges, key=lambda e: (-qhat[e], e))


def real_trials(edges, qhat, truth, costs_by_rep, seed):
    rows = []
    fixed = {
        "max_ratio": qhat_order(edges, qhat),
        "exhaustive_natural": sorted(edges),
    }
    for rep, costs in sorted(costs_by_rep.items()):
        orders = {
            "random": random_order(edges, seed + rep),
            **fixed,
        }
        for strategy, order in orders.items():
            rows.append({
                "repeat": rep,
                "strategy": strategy,
                **replay(order, truth, costs),
            })
    return rows


def make_hub(d: int, hub: int, s: int) -> set[Edge]:
    leaves = [v for v in range(d) if v != hub]
    return {canon(hub, leaves[k]) for k in range(s)}


def make_matching(d: int, hub: int, s: int) -> set[Edge]:
    vs = [v for v in range(d) if v != hub]
    if 2*s > len(vs):
        raise RuntimeError("matching too large")
    return {canon(vs[2*k], vs[2*k+1]) for k in range(s)}


def noisy_order(edges, truth, alpha, seed):
    rng = np.random.default_rng(seed)
    z = rng.normal(size=len(edges))
    scores = {}
    for e, noise in zip(edges, z):
        if math.isinf(alpha):
            scores[e] = (1e9 if e in truth else 0.0) + float(noise)
        else:
            scores[e] = float(alpha) * int(e in truth) + float(noise)
    return sorted(edges, key=lambda e: (-scores[e], e))


def alternating_incident(first: Edge, ranked: list[Edge], probed: set[Edge]):
    u, v = first
    a = [e for e in ranked if u in e and e not in probed]
    b = [e for e in ranked if v in e and e not in probed]
    out, seen = [], set()
    for k in range(max(len(a), len(b))):
        if k < len(a) and a[k] not in seen:
            seen.add(a[k]); out.append(a[k])
        if k < len(b) and b[k] not in seen:
            seen.add(b[k]); out.append(b[k])
    return out


def theorem_exact_order(ranked: list[Edge], truth: set[Edge], s: int):
    """
    Correct single-hub exact-localization implementation.

    1. Scan to first positive edge (u,v).
    2. Alternate unseen incident probes of u and v.
    3. Under a pure single-hub support, only the hub endpoint can obtain a
       second positive. That second positive identifies the unique hub.
    4. Close only that hub's remaining incident edges.
    5. On matching, no endpoint obtains a second positive; exhaust the two
       endpoint stars, then resume ranked scan until all positives are found.
    """
    probed, positives, output = set(), set(), []
    first = None

    for e in ranked:
        probed.add(e); output.append(e)
        if e in truth:
            positives.add(e); first = e
            break
    if first is None:
        raise RuntimeError("no first hit")

    u, v = first
    deg = {u: 1, v: 1}
    hub = None

    for e in alternating_incident(first, ranked, probed):
        probed.add(e); output.append(e)
        if e in truth:
            positives.add(e)
            for x in (u, v):
                if x in e:
                    deg[x] += 1
                    if deg[x] >= 2:
                        hub = x
                        break
        if hub is not None:
            break

    if hub is not None:
        for e in ranked:
            if hub in e and e not in probed:
                probed.add(e); output.append(e)
                if e in truth:
                    positives.add(e)
        if len(positives) != s:
            raise RuntimeError(f"hub closure recovered {len(positives)}/{s}")
        return output, hub, 1

    for e in ranked:
        if e in probed:
            continue
        probed.add(e); output.append(e)
        if e in truth:
            positives.add(e)
        if len(positives) == s:
            break
    if len(positives) != s:
        raise RuntimeError("matching fallback failed")
    return output, None, 0


def controlled_trials(edges, supports, costs_by_rep, alphas, ranking_seeds, seed):
    rows = []
    for geometry, truth in supports.items():
        s = len(truth)
        for ai, alpha in enumerate(alphas):
            label = "inf" if math.isinf(alpha) else str(alpha)
            for rs in range(ranking_seeds):
                rank_seed = seed + ai*1_000_000 + rs*10_000 + (
                    0 if geometry == "single_hub" else 500_000
                )
                ranked = noisy_order(edges, truth, alpha, rank_seed)
                exact, hub, success = theorem_exact_order(ranked, truth, s)

                for rep, costs in sorted(costs_by_rep.items()):
                    flat = replay(ranked, truth, costs)
                    exact_result = replay(exact, truth, costs)
                    rows.append({
                        "geometry": geometry, "s": s, "alpha": label,
                        "ranking_seed": rs, "measurement_repeat": rep,
                        "strategy": "flat_ranked",
                        "probes": flat["full_recall_probes"],
                        "verification_seconds": flat["full_recall_seconds"],
                        "first_hit_probes": flat["first_hit_probes"],
                        "identified_hub": None,
                        "identification_succeeded": None,
                    })
                    rows.append({
                        "geometry": geometry, "s": s, "alpha": label,
                        "ranking_seed": rs, "measurement_repeat": rep,
                        "strategy": "theorem_hub_exact",
                        "probes": exact_result["full_recall_probes"],
                        "verification_seconds": exact_result["full_recall_seconds"],
                        "first_hit_probes": exact_result["first_hit_probes"],
                        "identified_hub": hub,
                        "identification_succeeded": success,
                    })
    return rows


def summarize_real(rows):
    out = []
    for strategy in sorted({r["strategy"] for r in rows}):
        s = [r for r in rows if r["strategy"] == strategy]
        vals = [r["full_recall_seconds"] for r in s]
        out.append({
            "strategy": strategy,
            "repeats": len(s),
            "first_hit_probes_median": statistics.median(
                r["first_hit_probes"] for r in s
            ),
            "first_hit_seconds_median": statistics.median(
                r["first_hit_seconds"] for r in s
            ),
            "full_recall_probes_median": statistics.median(
                r["full_recall_probes"] for r in s
            ),
            "full_recall_seconds_median": statistics.median(vals),
            "full_recall_seconds_iqr": qtile(vals,.75)-qtile(vals,.25),
        })
    return out


def summarize_controlled(rows):
    out = []
    keys = sorted({
        (r["geometry"], r["alpha"], r["strategy"])
        for r in rows
    })
    for geometry, alpha, strategy in keys:
        s = [
            r for r in rows
            if r["geometry"] == geometry
            and r["alpha"] == alpha
            and r["strategy"] == strategy
        ]
        probes = [r["probes"] for r in s]
        secs = [r["verification_seconds"] for r in s]
        out.append({
            "geometry": geometry, "alpha": alpha, "strategy": strategy,
            "trials": len(s),
            "first_hit_probes_median": statistics.median(
                r["first_hit_probes"] for r in s
            ),
            "probes_median": statistics.median(probes),
            "probes_iqr": qtile(probes,.75)-qtile(probes,.25),
            "verification_seconds_median": statistics.median(secs),
            "verification_seconds_iqr": qtile(secs,.75)-qtile(secs,.25),
            "identification_success_rate": (
                statistics.mean(
                    float(r["identification_succeeded"]) for r in s
                ) if strategy == "theorem_hub_exact" else None
            ),
        })

    lookup = {
        (r["geometry"], r["alpha"], r["strategy"]): r for r in out
    }
    for r in out:
        if r["strategy"] == "theorem_hub_exact":
            f = lookup[(r["geometry"], r["alpha"], "flat_ranked")]
            r["probe_speedup_vs_flat"] = f["probes_median"]/r["probes_median"]
            r["time_speedup_vs_flat"] = (
                f["verification_seconds_median"]/
                r["verification_seconds_median"]
            )
        else:
            r["probe_speedup_vs_flat"] = 1.0
            r["time_speedup_vs_flat"] = 1.0
    return out


def parse_alphas(text):
    return [
        float("inf") if x.strip().lower() == "inf" else float(x)
        for x in text.split(",")
    ]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase6e-observations", type=Path, required=True)
    ap.add_argument("--phase6e-templates", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--support-floor", type=int, default=20)
    ap.add_argument("--controlled-s", type=int, default=50)
    ap.add_argument("--alphas", default="inf,4,2,1,0")
    ap.add_argument("--ranking-seeds", type=int, default=20)
    ap.add_argument("--seed", type=int, default=20260722)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    edges, qhat, names, costs, truth = load_inputs(
        args.phase6e_observations,
        args.phase6e_templates,
        args.support_pairs,
        args.support_floor,
    )
    d, M = max(v for e in edges for v in e)+1, len(edges)
    if (d, M, len(truth)) != (109, 5886, 141):
        raise RuntimeError(f"expected 109/5886/141, got {d}/{M}/{len(truth)}")

    degree = {v:0 for v in range(d)}
    for u,v in truth:
        degree[u]+=1; degree[v]+=1
    hub = max(degree, key=degree.get)
    if degree[hub] != 108:
        raise RuntimeError(f"expected real max degree 108, got {degree[hub]}")

    s = min(args.controlled_s, (d-1)//2)
    supports = {
        "single_hub": make_hub(d, hub, s),
        "matching": make_matching(d, hub, s),
    }

    # hard geometry gates
    if sum(hub in e for e in supports["single_hub"]) != s:
        raise RuntimeError("hub construction failed")
    mv = [v for e in supports["matching"] for v in e]
    if len(mv) != len(set(mv)):
        raise RuntimeError("matching construction failed")

    real_rows = real_trials(edges, qhat, truth, costs, args.seed)
    controlled_rows = controlled_trials(
        edges, supports, costs, parse_alphas(args.alphas),
        args.ranking_seeds, args.seed
    )
    real_summary = summarize_real(real_rows)
    controlled_summary = summarize_controlled(controlled_rows)

    theory = {
        "d": d, "M": M, "real_severe_edges": len(truth),
        "real_hub_vertex": hub, "real_hub_name": names[hub],
        "real_hub_degree": degree[hub], "controlled_s": s,
        "random_first_hit_expectation": (M+1)/(s+1),
        "single_hub_scale_M_over_s_plus_d": M/s + d,
        "correct_strategy": (
            "first hit; alternate the two endpoint stars until one endpoint "
            "gets a second positive; close only that endpoint"
        ),
    }

    write_csv(args.out/"real_pipeline_trials.csv", real_rows)
    write_csv(args.out/"real_pipeline_summary.csv", real_summary)
    write_csv(args.out/"controlled_trials.csv", controlled_rows)
    write_csv(args.out/"controlled_summary.csv", controlled_summary)

    report = {
        "experiment": "phase6f_theorem_correct_bridge",
        "scientific_contract": {
            "real_acs": (
                "Exact frozen ACS truth and real PostgreSQL probe costs; "
                "no single-hub theorem claim on the mixed support."
            ),
            "controlled": (
                "Equal-size pure hub and matching supports; real PostgreSQL "
                "times calibrate pair-probe cost."
            ),
            "forbidden_old_heuristic": (
                "No eager closure of every vertex crossing a positive-degree "
                "threshold."
            ),
        },
        "theory": theory,
        "real_pipeline_summary": real_summary,
        "controlled_summary": controlled_summary,
    }
    (args.out/"gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "="*72,
        "PHASE 6F THEOREM-CORRECT BRIDGE COMPLETE",
        "="*72,
        f"d/M                         : {d}/{M}",
        f"real support                : {len(truth)}",
        f"real hub                    : {names[hub]} degree={degree[hub]}",
        f"controlled s                : {s}",
        f"controlled E[first hit]     : {(M+1)/(s+1):.4f}",
        f"M/s + d                     : {M/s+d:.4f}",
        "",
        "REAL ACS",
    ]
    for r in real_summary:
        lines.append(
            f"{r['strategy']:20s}: first={r['first_hit_probes_median']:.1f}, "
            f"full={r['full_recall_probes_median']:.1f} probes/"
            f"{r['full_recall_seconds_median']:.4f}s"
        )
    lines += ["", "CONTROLLED"]
    for r in controlled_summary:
        if r["strategy"] == "theorem_hub_exact":
            lines.append(
                f"{r['geometry']:10s} alpha={r['alpha']:>3s}: "
                f"{r['probes_median']:.1f} probes/"
                f"{r['verification_seconds_median']:.4f}s, "
                f"vs-flat={r['probe_speedup_vs_flat']:.3f}x probes/"
                f"{r['time_speedup_vs_flat']:.3f}x time, "
                f"identify={r['identification_success_rate']:.3f}"
            )
    text = "\n".join(lines)
    (args.out/"REPORT.txt").write_text(text, encoding="utf-8")
    print(text)
    print(f"report: {args.out/'REPORT.txt'}")


if __name__ == "__main__":
    main()
