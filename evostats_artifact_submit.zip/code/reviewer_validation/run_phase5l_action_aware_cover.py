#!/usr/bin/env python3
"""
Phase 5L: action-aware vertex-and-edge cover.

Purpose
-------
This is the final optimization after Phase 5K.

After cheap retire/refresh classification:

* every active column must be ANALYZED at least once, because retired
  multivariate objects fall back to current single-column statistics;
* every retained refresh pair must have both columns in at least one
  ANALYZE group, because its multivariate object must be recomputed;
* every group has width at most B.

This runner constructs a bounded action-aware cover satisfying both the
vertex and edge requirements, then compares it against:

1. frozen B8 refresh;
2. Phase 5K safe hybrid using the complete frozen B8 groups;
3. action-aware hybrid using the new minimum-call cover.

Every policy starts from an independently reconstructed exact Phase 5F stale
state. Classification, planning, DROP, and ANALYZE costs are included in the
hybrid end-to-end time. Verification is performed after timing.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import random
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Generic utilities
# ---------------------------------------------------------------------------

def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)

    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def stat_name(i: int, j: int) -> str:
    i, j = sorted((int(i), int(j)))
    # Exact frozen Phase 4G/5F naming convention.
    return f"evs_{i}_{j}"


def qerror(estimated: float, actual: float) -> float:
    estimated = max(float(estimated), 1.0)
    actual = max(float(actual), 1.0)
    return max(estimated / actual, actual / estimated)


# ---------------------------------------------------------------------------
# Cheap classifier: same scientific definition as Phase 5K
# ---------------------------------------------------------------------------

def classify_from_current_snapshot(
    B: np.ndarray,
    rows_by_edge: dict[tuple[int, int], dict[str, Any]],
    threshold: float,
) -> tuple[
    set[tuple[int, int]],
    set[tuple[int, int]],
    list[dict[str, Any]],
    float,
]:
    """
    Predict retire versus refresh from current lower-order adequacy.

    For each verified harmful cell:
        independence estimate =
            n * P_B(c_i=v_i) * P_B(c_j=v_j)

    The actual current cell count is already part of exact verification.
    The implementation recomputes it from B and checks consistency.

    No PostgreSQL query, ANALYZE, DROP, or oracle action label is used.
    """
    start = time.perf_counter()
    n = int(B.shape[0])

    requested: dict[int, set[int]] = {}
    for row in rows_by_edge.values():
        requested.setdefault(int(row["i"]), set()).add(int(row["value_i"]))
        requested.setdefault(int(row["j"]), set()).add(int(row["value_j"]))

    counts: dict[tuple[int, int], int] = {}
    for column, values in requested.items():
        vector = B[:, column].astype(np.int64, copy=False)
        histogram = np.bincount(
            vector,
            minlength=int(vector.max()) + 1,
        )
        for value in values:
            counts[(column, value)] = (
                int(histogram[value]) if value < len(histogram) else 0
            )

    retire: set[tuple[int, int]] = set()
    refresh: set[tuple[int, int]] = set()
    detail: list[dict[str, Any]] = []

    for edge in sorted(rows_by_edge):
        row = rows_by_edge[edge]
        i, j = edge
        vi, vj = int(row["value_i"]), int(row["value_j"])

        count_i = counts[(i, vi)]
        count_j = counts[(j, vj)]
        independence_estimate = (count_i * count_j) / n

        actual_from_b = int(
            np.count_nonzero((B[:, i] == vi) & (B[:, j] == vj))
        )
        actual_from_support = int(round(float(row["pg_actual_rows"])))
        if actual_from_support != actual_from_b:
            raise RuntimeError(
                f"Current-count mismatch for {edge}: "
                f"support={actual_from_support}, B={actual_from_b}"
            )

        indep_q = qerror(independence_estimate, actual_from_b)
        action = "retire" if indep_q <= threshold else "refresh"

        if action == "retire":
            retire.add(edge)
        else:
            refresh.add(edge)

        detail.append(
            {
                "i": i,
                "j": j,
                "variable_i": row["variable_i"],
                "variable_j": row["variable_j"],
                "value_i": vi,
                "value_j": vj,
                "marginal_count_i": count_i,
                "marginal_count_j": count_j,
                "actual_rows": actual_from_b,
                "independence_estimate": independence_estimate,
                "independence_qerror": indep_q,
                "predicted_action": action,
            }
        )

    return retire, refresh, detail, time.perf_counter() - start


# ---------------------------------------------------------------------------
# Action-aware vertex-and-edge cover
# ---------------------------------------------------------------------------

def connected_components(
    required_edges: set[tuple[int, int]],
) -> list[set[int]]:
    adjacency: dict[int, set[int]] = {}
    for u, v in required_edges:
        adjacency.setdefault(u, set()).add(v)
        adjacency.setdefault(v, set()).add(u)

    components: list[set[int]] = []
    unseen = set(adjacency)

    while unseen:
        root = min(unseen)
        stack = [root]
        component: set[int] = set()
        unseen.remove(root)

        while stack:
            node = stack.pop()
            component.add(node)
            for neighbour in sorted(adjacency[node]):
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    stack.append(neighbour)

        components.append(component)

    return sorted(
        components,
        key=lambda component: (-len(component), tuple(sorted(component))),
    )


def _pack_components_into_k_bins(
    components: list[set[int]],
    k: int,
    width: int,
) -> list[set[int]] | None:
    """
    Exact backtracking for the non-singleton refresh components.

    Singleton active columns are filled later and therefore do not enlarge
    this search. In the current experiment there are only a few components.
    """
    bins: list[set[int]] = [set() for _ in range(k)]
    items = sorted(
        components,
        key=lambda component: (-len(component), tuple(sorted(component))),
    )

    def recurse(index: int) -> bool:
        if index == len(items):
            return True

        item = items[index]
        seen_loads: set[int] = set()

        for bin_index in range(k):
            load = len(bins[bin_index])
            if load in seen_loads:
                continue
            seen_loads.add(load)

            if load + len(item) > width:
                continue

            bins[bin_index].update(item)
            if recurse(index + 1):
                return True
            bins[bin_index].difference_update(item)

            # Symmetry: trying another empty bin is equivalent.
            if load == 0:
                break

        return False

    if recurse(0):
        return bins
    return None


def balanced_object_ops_lower_bound(vertices: int, calls: int) -> int:
    """
    Minimum possible sum C(|G|,2) for disjoint groups with a fixed number
    of calls, ignoring edge co-location constraints.
    """
    small = vertices // calls
    large_count = vertices % calls
    small_count = calls - large_count
    return (
        small_count * choose2(small)
        + large_count * choose2(small + 1)
    )


def build_action_aware_cover(
    active_vertices: set[int],
    required_edges: set[tuple[int, int]],
    width: int,
) -> tuple[list[set[int]], dict[str, Any]]:
    """
    Build a disjoint minimum-call cover when every connected component of
    the retained refresh graph fits within one group.

    Required semantics:
      * every active vertex occurs exactly once;
      * every retained refresh edge is contained in one group;
      * group width <= B.

    Because groups are disjoint, ordinary-column statistics are refreshed
    once each, without repeated column scans across calls.
    """
    if width < 2:
        raise ValueError("width must be at least 2")

    for u, v in required_edges:
        if u not in active_vertices or v not in active_vertices:
            raise RuntimeError(
                f"Refresh edge {(u, v)} is outside active vertex set"
            )

    components = connected_components(required_edges)
    oversized = [
        component for component in components if len(component) > width
    ]
    if oversized:
        raise RuntimeError(
            "A retained-refresh connected component exceeds the width "
            f"bound B={width}: sizes={[len(c) for c in oversized]}. "
            "This exact disjoint-cover construction is not applicable."
        )

    vertices_in_components = set().union(*components) if components else set()
    singleton_vertices = sorted(active_vertices - vertices_in_components)

    lower_bound_calls = math.ceil(len(active_vertices) / width)
    bins: list[set[int]] | None = None
    calls = lower_bound_calls

    while bins is None:
        bins = _pack_components_into_k_bins(components, calls, width)
        if bins is None:
            calls += 1

    # Fill singleton vertices into the currently smallest group. This
    # balances group sizes and minimizes induced pair operations for the
    # fixed number of calls.
    for vertex in singleton_vertices:
        candidates = [
            index
            for index, group in enumerate(bins)
            if len(group) < width
        ]
        if not candidates:
            raise RuntimeError("Internal error: no capacity for singleton")
        destination = min(
            candidates,
            key=lambda index: (len(bins[index]), index),
        )
        bins[destination].add(vertex)

    groups = [group for group in bins if group]
    groups.sort(key=lambda group: (min(group), tuple(sorted(group))))

    validate_action_aware_cover(
        groups,
        active_vertices,
        required_edges,
        width,
    )

    metrics = {
        "calls": len(groups),
        "call_lower_bound": lower_bound_calls,
        "call_optimal": len(groups) == lower_bound_calls,
        "object_ops_upper_bound": sum(
            choose2(len(group)) for group in groups
        ),
        "balanced_object_ops_lower_bound": (
            balanced_object_ops_lower_bound(
                len(active_vertices),
                len(groups),
            )
        ),
        "max_width": max(len(group) for group in groups),
        "min_width": min(len(group) for group in groups),
        "active_vertices": len(active_vertices),
        "required_refresh_edges": len(required_edges),
        "refresh_components": len(components),
        "refresh_component_sizes": [
            len(component) for component in components
        ],
        "disjoint_vertex_cover": True,
    }
    return groups, metrics


def validate_action_aware_cover(
    groups: list[set[int]],
    active_vertices: set[int],
    required_edges: set[tuple[int, int]],
    width: int,
) -> None:
    if not groups:
        raise RuntimeError("Action-aware plan is empty")

    if any(len(group) == 0 or len(group) > width for group in groups):
        raise RuntimeError("Action-aware plan violates width bound")

    flattened = [
        vertex for group in groups for vertex in sorted(group)
    ]
    if set(flattened) != active_vertices:
        missing = active_vertices - set(flattened)
        extra = set(flattened) - active_vertices
        raise RuntimeError(
            f"Vertex coverage mismatch: missing={sorted(missing)}, "
            f"extra={sorted(extra)}"
        )

    if len(flattened) != len(set(flattened)):
        raise RuntimeError(
            "Action-aware groups are not disjoint; a column would be "
            "ANALYZED more than once"
        )

    missed_edges = [
        edge
        for edge in sorted(required_edges)
        if not any(set(edge) <= group for group in groups)
    ]
    if missed_edges:
        raise RuntimeError(
            f"Action-aware plan misses refresh edges: {missed_edges}"
        )


# ---------------------------------------------------------------------------
# PostgreSQL actions
# ---------------------------------------------------------------------------

def ensure_pair_statistics(
    conn,
    schema: str,
    edges: set[tuple[int, int]],
) -> int:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT stxname
            FROM pg_statistic_ext
            WHERE stxrelid = %s::regclass
            """,
            (f"{qi(schema)}.fact",),
        )
        existing = {str(row[0]) for row in cur.fetchall()}

        created = 0
        for i, j in sorted(edges):
            name = stat_name(i, j)
            if name in existing:
                continue
            cur.execute(
                f"""
                CREATE STATISTICS {qi(schema)}.{qi(name)}
                (dependencies, mcv)
                ON c{i}, c{j}
                FROM {qi(schema)}.fact
                """
            )
            created += 1

    return created


def drop_pair_statistics(
    conn,
    schema: str,
    edges: set[tuple[int, int]],
) -> float:
    start = time.perf_counter()
    with conn.cursor() as cur:
        for i, j in sorted(edges):
            cur.execute(
                f"DROP STATISTICS IF EXISTS "
                f"{qi(schema)}.{qi(stat_name(i, j))}"
            )
    return time.perf_counter() - start


def run_groups(
    pg4g,
    conn,
    schema: str,
    groups: list[set[int]],
    target: int,
) -> float:
    start = time.perf_counter()
    for group in groups:
        pg4g.analyze_group(
            conn,
            schema,
            group,
            target,
        )
    return time.perf_counter() - start


def verify_detailed(
    pg4g,
    conn,
    schema: str,
    rows_by_edge: dict[tuple[int, int], dict[str, Any]],
    edges: set[tuple[int, int]],
    threshold: float,
) -> dict[str, Any]:
    qvalues: list[float] = []

    for edge in sorted(edges):
        row = rows_by_edge[edge]
        value, _, _ = pg4g.explain_q(
            conn,
            schema,
            edge[0],
            edge[1],
            int(row["value_i"]),
            int(row["value_j"]),
        )
        qvalues.append(float(value))

    return {
        "repair_fraction": sum(
            value <= threshold for value in qvalues
        ) / len(qvalues),
        "qerror_geomean": statistics.geometric_mean(qvalues),
        "qerror_median": statistics.median(qvalues),
        "qerror_p90": qtile(qvalues, 0.90),
        "qerror_max": max(qvalues),
    }


# ---------------------------------------------------------------------------
# Summaries
# ---------------------------------------------------------------------------

def summarize_trials(
    trials: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    policies = [
        "b8_refresh",
        "safe_hybrid_full_b8",
        "action_aware_hybrid",
    ]
    summary: list[dict[str, Any]] = []

    for policy in policies:
        rows = [row for row in trials if row["policy"] == policy]
        values = [float(row["total_seconds"]) for row in rows]

        summary.append(
            {
                "policy": policy,
                "repeats": len(rows),
                "groups_median": int(
                    statistics.median(
                        int(row["groups"]) for row in rows
                    )
                ),
                "object_ops_upper_bound_median": int(
                    statistics.median(
                        int(row["object_ops_upper_bound"])
                        for row in rows
                    )
                ),
                "total_seconds_median": statistics.median(values),
                "total_seconds_iqr": (
                    qtile(values, 0.75) - qtile(values, 0.25)
                ),
                "classify_seconds_median": statistics.median(
                    float(row["classify_seconds"]) for row in rows
                ),
                "planner_seconds_median": statistics.median(
                    float(row["planner_seconds"]) for row in rows
                ),
                "drop_seconds_median": statistics.median(
                    float(row["drop_seconds"]) for row in rows
                ),
                "analyze_seconds_median": statistics.median(
                    float(row["analyze_seconds"]) for row in rows
                ),
                "repair_fraction_median": statistics.median(
                    float(row["repair_fraction"]) for row in rows
                ),
                "qerror_geomean_median": statistics.median(
                    float(row["qerror_geomean"]) for row in rows
                ),
                "qerror_max_median": statistics.median(
                    float(row["qerror_max"]) for row in rows
                ),
                "retired_pairs_median": int(
                    statistics.median(
                        int(row["retired_pairs"]) for row in rows
                    )
                ),
                "refreshed_pairs_median": int(
                    statistics.median(
                        int(row["refreshed_pairs"]) for row in rows
                    )
                ),
            }
        )

    b8_time = next(
        row["total_seconds_median"]
        for row in summary
        if row["policy"] == "b8_refresh"
    )
    safe_time = next(
        row["total_seconds_median"]
        for row in summary
        if row["policy"] == "safe_hybrid_full_b8"
    )

    for row in summary:
        row["speedup_vs_b8"] = (
            b8_time / row["total_seconds_median"]
        )
        row["speedup_vs_safe_hybrid"] = (
            safe_time / row["total_seconds_median"]
        )

    return summary


# ---------------------------------------------------------------------------
# Main experiment
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase5f-script", type=Path, required=True)
    parser.add_argument("--phase4g-helper", type=Path, required=True)
    parser.add_argument("--person-cache", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--qerrors", type=Path, required=True)
    parser.add_argument("--support-pairs", type=Path, required=True)
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--schema",
        default="evostats_phase5l_action_aware",
    )
    parser.add_argument("--rows", type=int, default=40000)
    parser.add_argument("--statistics-target", type=int, default=500)
    parser.add_argument("--support-floor", type=int, default=20)
    parser.add_argument("--retire-threshold", type=float, default=2.0)
    parser.add_argument("--repair-threshold", type=float, default=2.0)
    parser.add_argument("--width", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260719)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(args.phase5f_script, "phase5f_exact")
    pg4g = load_module(args.phase4g_helper, "phase4g_exact")

    qframe = pd.read_csv(args.qerrors)
    support = pd.read_csv(args.support_pairs)

    loaded_helper, A, B, cards, names, metadata = (
        phase5f.reconstruct_exact_phase4g(args, qframe)
    )
    if loaded_helper is None:
        raise RuntimeError("Exact Phase 4G reconstruction failed")

    severe_frame = support[
        (support["floor"] == args.support_floor)
        & (support["pg_severe"] == 1)
    ].copy()
    if severe_frame.empty:
        raise RuntimeError("No frozen severe pairs")

    harmful = {
        (int(row.i), int(row.j))
        for row in severe_frame.itertuples(index=False)
    }
    rows_by_edge = {
        (int(row["i"]), int(row["j"])): row
        for row in severe_frame.to_dict("records")
    }
    active_vertices = {
        vertex for edge in harmful for vertex in edge
    }

    # Deterministic preview and strict plan validation.
    preview_retire, preview_refresh, classifier_detail, preview_classify_s = (
        classify_from_current_snapshot(
            B,
            rows_by_edge,
            args.retire_threshold,
        )
    )
    preview_plan, preview_plan_metrics = build_action_aware_cover(
        active_vertices,
        preview_refresh,
        args.width,
    )
    full_b8_groups = phase5f.bounded_greedy(
        harmful,
        args.width,
    )

    print(
        f"[phase5l] harmful={len(harmful)} "
        f"active_vertices={len(active_vertices)} "
        f"retire={len(preview_retire)} "
        f"refresh={len(preview_refresh)}",
        flush=True,
    )
    print(
        f"[phase5l] frozen_B8 calls={len(full_b8_groups)} "
        f"ops={sum(choose2(len(g)) for g in full_b8_groups)}",
        flush=True,
    )
    print(
        f"[phase5l] action_aware calls={len(preview_plan)} "
        f"lower_bound={preview_plan_metrics['call_lower_bound']} "
        f"call_optimal={preview_plan_metrics['call_optimal']} "
        f"ops={preview_plan_metrics['object_ops_upper_bound']} "
        f"balanced_ops_lb="
        f"{preview_plan_metrics['balanced_object_ops_lower_bound']}",
        flush=True,
    )
    print(
        "[phase5l] group sizes="
        + ",".join(str(len(group)) for group in preview_plan),
        flush=True,
    )

    write_csv(args.out / "classifier_detail.csv", classifier_detail)
    write_csv(
        args.out / "action_aware_groups.csv",
        [
            {
                "group_id": index,
                "width": len(group),
                "columns": ",".join(
                    str(column) for column in sorted(group)
                ),
            }
            for index, group in enumerate(preview_plan, start=1)
        ],
    )

    plan_metadata = {
        "active_vertices": len(active_vertices),
        "harmful_edges": len(harmful),
        "predicted_retire_edges": len(preview_retire),
        "required_refresh_edges": len(preview_refresh),
        "frozen_b8": {
            "calls": len(full_b8_groups),
            "object_ops_upper_bound": sum(
                choose2(len(group)) for group in full_b8_groups
            ),
            "group_sizes": [len(group) for group in full_b8_groups],
        },
        "action_aware": {
            **preview_plan_metrics,
            "group_sizes": [len(group) for group in preview_plan],
            "groups": [
                sorted(group) for group in preview_plan
            ],
        },
    }
    (args.out / "plan_metadata.json").write_text(
        json.dumps(plan_metadata, indent=2),
        encoding="utf-8",
    )

    policies = [
        "b8_refresh",
        "safe_hybrid_full_b8",
        "action_aware_hybrid",
    ]
    trials: list[dict[str, Any]] = []
    rng = random.Random(args.seed)

    conn = pg4g.connect(args.dsn)
    try:
        pg4g.create_schema(conn, args.schema, len(names))
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, len(names))

        for repetition in range(1, args.repeats + 1):
            order = policies.copy()
            rng.shuffle(order)

            for order_index, policy in enumerate(order, start=1):
                print(
                    f"[runtime] rep={repetition}/{args.repeats} "
                    f"policy={policy}",
                    flush=True,
                )

                ensure_pair_statistics(
                    conn,
                    args.schema,
                    harmful,
                )
                phase5f.establish_stale(
                    pg4g,
                    conn,
                    args.schema,
                    A,
                    B,
                    args.statistics_target,
                )

                classify_seconds = 0.0
                planner_seconds = 0.0
                drop_seconds = 0.0

                start_total = time.perf_counter()

                if policy == "b8_refresh":
                    retire = set()
                    refresh = harmful
                    groups = full_b8_groups

                else:
                    (
                        retire,
                        refresh,
                        _,
                        classify_seconds,
                    ) = classify_from_current_snapshot(
                        B,
                        rows_by_edge,
                        args.retire_threshold,
                    )

                    if policy == "safe_hybrid_full_b8":
                        groups = full_b8_groups

                    elif policy == "action_aware_hybrid":
                        planner_start = time.perf_counter()
                        groups, dynamic_metrics = (
                            build_action_aware_cover(
                                active_vertices,
                                refresh,
                                args.width,
                            )
                        )
                        planner_seconds = (
                            time.perf_counter() - planner_start
                        )

                        if groups != preview_plan:
                            raise RuntimeError(
                                "Action-aware planner is not deterministic"
                            )
                    else:
                        raise ValueError(policy)

                    drop_seconds = drop_pair_statistics(
                        conn,
                        args.schema,
                        retire,
                    )

                analyze_seconds = run_groups(
                    pg4g,
                    conn,
                    args.schema,
                    groups,
                    args.statistics_target,
                )
                total_seconds = time.perf_counter() - start_total

                verification = verify_detailed(
                    pg4g,
                    conn,
                    args.schema,
                    rows_by_edge,
                    harmful,
                    args.repair_threshold,
                )

                trials.append(
                    {
                        "repeat": repetition,
                        "order": order_index,
                        "policy": policy,
                        "groups": len(groups),
                        "object_ops_upper_bound": sum(
                            choose2(len(group)) for group in groups
                        ),
                        "retired_pairs": len(retire),
                        "refreshed_pairs": len(refresh),
                        "classify_seconds": classify_seconds,
                        "planner_seconds": planner_seconds,
                        "drop_seconds": drop_seconds,
                        "analyze_seconds": analyze_seconds,
                        "total_seconds": total_seconds,
                        **verification,
                    }
                )

                print(
                    f"  total={total_seconds:.3f}s "
                    f"calls={len(groups)} "
                    f"repair={verification['repair_fraction']:.3f} "
                    f"qmax={verification['qerror_max']:.3f}",
                    flush=True,
                )

    finally:
        conn.close()

    summary = summarize_trials(trials)
    write_csv(args.out / "runtime_trials.csv", trials)
    write_csv(args.out / "runtime_summary.csv", summary)

    action_summary = next(
        row
        for row in summary
        if row["policy"] == "action_aware_hybrid"
    )

    gate = {
        "experiment": "phase5l_action_aware_cover",
        "classification": {
            "single_pass_seconds": preview_classify_s,
            "retire_edges": len(preview_retire),
            "refresh_edges": len(preview_refresh),
            "retire_threshold": args.retire_threshold,
        },
        "plan": plan_metadata,
        "runtime_summary": summary,
        "acceptance_gate": {
            "required": {
                "repair_fraction_median": 1.0,
                "qerror_max_median_lte": args.repair_threshold,
                "speedup_vs_safe_hybrid_gt": 1.0,
            },
            "observed": {
                "repair_fraction_median": (
                    action_summary["repair_fraction_median"]
                ),
                "qerror_max_median": (
                    action_summary["qerror_max_median"]
                ),
                "speedup_vs_safe_hybrid": (
                    action_summary["speedup_vs_safe_hybrid"]
                ),
                "speedup_vs_b8": (
                    action_summary["speedup_vs_b8"]
                ),
            },
            "passed": bool(
                action_summary["repair_fraction_median"] == 1.0
                and action_summary["qerror_max_median"]
                <= args.repair_threshold
                and action_summary["speedup_vs_safe_hybrid"] > 1.0
            ),
        },
        "scientific_interpretation": (
            "The action-aware planner converts retired harmful objects "
            "into vertex requirements (fresh ordinary statistics) and "
            "retained objects into edge requirements (fresh multivariate "
            "statistics), then constructs a bounded minimum-call cover."
        ),
        "reconstruction_metadata": metadata,
    }
    (args.out / "gate_report.json").write_text(
        json.dumps(gate, indent=2),
        encoding="utf-8",
    )

    print("\nPLAN")
    print(json.dumps(plan_metadata, indent=2))
    print("\nRUNTIME SUMMARY")
    print(pd.DataFrame(summary).to_string(index=False))
    print("\nGATE")
    print(json.dumps(gate["acceptance_gate"], indent=2))


if __name__ == "__main__":
    main()
