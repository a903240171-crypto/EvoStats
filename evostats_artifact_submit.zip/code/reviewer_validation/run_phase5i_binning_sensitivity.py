#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import average_precision_score, roc_auc_score


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def canonical_pair(i: int, j: int) -> str:
    return f"{min(i, j)}||{max(i, j)}"


def encode_joint(
    ref_i: np.ndarray,
    ref_j: np.ndarray,
    cur_i: np.ndarray,
    cur_j: np.ndarray,
) -> tuple[dict[int, int], dict[int, int]]:
    values_i = np.unique(np.concatenate([ref_i, cur_i]))
    values_j = np.unique(np.concatenate([ref_j, cur_j]))
    map_i = {value: idx for idx, value in enumerate(values_i)}
    map_j = {value: idx for idx, value in enumerate(values_j)}
    width = len(values_j)

    def counts(x: np.ndarray, y: np.ndarray) -> dict[int, int]:
        xi = np.fromiter(
            (map_i[value] for value in x), dtype=np.int64, count=len(x)
        )
        yj = np.fromiter(
            (map_j[value] for value in y), dtype=np.int64, count=len(y)
        )
        keys, values = np.unique(xi * width + yj, return_counts=True)
        return dict(zip(keys.tolist(), values.tolist()))

    return counts(ref_i, ref_j), counts(cur_i, cur_j)


def max_ratio(
    ref_i: np.ndarray,
    ref_j: np.ndarray,
    cur_i: np.ndarray,
    cur_j: np.ndarray,
    support: int,
) -> float:
    ref_counts, cur_counts = encode_joint(
        ref_i, ref_j, cur_i, cur_j
    )
    n0, n1 = len(ref_i), len(cur_i)
    best = 1.0
    for key, current_count in cur_counts.items():
        if current_count < support:
            continue
        p1 = current_count / n1
        p0 = max(ref_counts.get(key, 0) / n0, 1.0 / n0)
        best = max(best, p0 / p1, p1 / p0)
    return float(best)


def norm_text(series: pd.Series) -> pd.Series:
    return series.astype("string").fillna("<NA>")


def numeric_fraction(series: pd.Series) -> float:
    text = norm_text(series)
    numeric = pd.to_numeric(text, errors="coerce")
    return float(numeric.notna().mean())


def fit_numeric_bins(
    reference: pd.Series,
    method: str,
    bins: int,
) -> np.ndarray:
    values = pd.to_numeric(reference, errors="coerce").dropna().to_numpy()
    if len(values) == 0 or np.min(values) == np.max(values):
        return np.asarray([-np.inf, np.inf])

    if method == "quantile":
        edges = np.quantile(values, np.linspace(0, 1, bins + 1))
    elif method == "width":
        edges = np.linspace(np.min(values), np.max(values), bins + 1)
    else:
        raise ValueError(method)

    edges = np.unique(edges)
    if len(edges) < 2:
        return np.asarray([-np.inf, np.inf])
    edges[0] = -np.inf
    edges[-1] = np.inf
    return edges


def transform_numeric(
    reference: pd.Series,
    current: pd.Series,
    method: str,
    bins: int,
) -> tuple[np.ndarray, np.ndarray]:
    edges = fit_numeric_bins(reference, method, bins)
    ref = pd.cut(
        pd.to_numeric(reference, errors="coerce"),
        bins=edges,
        labels=False,
        include_lowest=True,
    ).fillna(-1)
    cur = pd.cut(
        pd.to_numeric(current, errors="coerce"),
        bins=edges,
        labels=False,
        include_lowest=True,
    ).fillna(-1)
    return ref.to_numpy(dtype=np.int32), cur.to_numpy(dtype=np.int32)


def transform_categorical(
    reference: pd.Series,
    current: pd.Series,
    top_k: int | None,
) -> tuple[np.ndarray, np.ndarray]:
    ref = norm_text(reference)
    cur = norm_text(current)
    if top_k is not None:
        keep = set(
            ref.value_counts(dropna=False).head(top_k).index.astype(str)
        )
        ref = ref.where(ref.isin(keep), "<OTHER>")
        cur = cur.where(cur.isin(keep), "<OTHER>")

    both = pd.concat([ref, cur], ignore_index=True)
    codes, _ = pd.factorize(both, sort=True)
    return (
        codes[: len(ref)].astype(np.int32),
        codes[len(ref) :].astype(np.int32),
    )


@dataclass(frozen=True)
class Strategy:
    name: str
    numeric_method: str | None = None
    numeric_bins: int | None = None
    top_k: int | None = None


STRATEGIES = [
    Strategy("baseline_exact"),
    Strategy("quantile_5", "quantile", 5),
    Strategy("quantile_10", "quantile", 10),
    Strategy("quantile_20", "quantile", 20),
    Strategy("equal_width_10", "width", 10),
    Strategy("equal_width_20", "width", 20),
    Strategy("topcat_20", top_k=20),
    Strategy("topcat_50", top_k=50),
    Strategy("quantile10_topcat50", "quantile", 10, 50),
]


def reconstruct_raw_phase4g(args, qframe: pd.DataFrame):
    pg4g = load_module(args.phase4g_helper, "phase4g_raw_helper")

    p19 = pg4g.find_person_csv(args.person_cache, 2019)
    p21 = pg4g.find_person_csv(args.person_cache, 2021)
    hpaths = {}
    for year in (2019, 2021):
        zip_path = args.data_dir / f"acs_{year}_hca.zip"
        if not pg4g.valid_zip(zip_path):
            raise FileNotFoundError(zip_path)
        hpaths[year] = pg4g.extract_csv(
            zip_path, args.data_dir, year, "housing"
        )

    pa = pg4g.uniform_sample_csv(p19, args.rows, 2019)
    pb = pg4g.uniform_sample_csv(p21, args.rows, 2021)
    ha = pg4g.load_matching_housing(
        hpaths[2019], set(pa["SERIALNO"].astype(str))
    )
    hb = pg4g.load_matching_housing(
        hpaths[2021], set(pb["SERIALNO"].astype(str))
    )

    pvars, _ = pg4g.select_vars(pa, pb, "P", 50, 24, 0.2)
    hvars, _ = pg4g.select_vars(ha, hb, "H", 80, 24, 0.3)
    ja, jb, names = pg4g.build_join(
        pa, pb, ha, hb, pvars, hvars
    )
    A, B, cards = pg4g.encode(ja, jb, names)

    expected = [None] * len(names)
    for row in qframe.itertuples(index=False):
        expected[int(row.i)] = str(row.variable_i)
        expected[int(row.j)] = str(row.variable_j)
    if names != expected:
        raise RuntimeError("Phase 4G variable order mismatch")

    return pg4g, ja[names].copy(), jb[names].copy(), A, B, cards, names


def make_encoded_columns(
    ja: pd.DataFrame,
    jb: pd.DataFrame,
    A: np.ndarray,
    B: np.ndarray,
    names: list[str],
    numeric_columns: set[str],
    strategy: Strategy,
) -> tuple[list[np.ndarray], list[np.ndarray]]:
    ref_columns = []
    cur_columns = []

    for idx, name in enumerate(names):
        if strategy.name == "baseline_exact":
            ref_columns.append(A[:, idx].astype(np.int32, copy=False))
            cur_columns.append(B[:, idx].astype(np.int32, copy=False))
            continue

        is_numeric = name in numeric_columns
        if is_numeric and strategy.numeric_method is not None:
            ref, cur = transform_numeric(
                ja[name],
                jb[name],
                strategy.numeric_method,
                int(strategy.numeric_bins),
            )
        else:
            ref, cur = transform_categorical(
                ja[name], jb[name], strategy.top_k
            )
        ref_columns.append(ref)
        cur_columns.append(cur)

    return ref_columns, cur_columns


def full_recall_budget(y: np.ndarray, scores: np.ndarray) -> float:
    positives = int(y.sum())
    if positives == 0:
        return float("nan")
    found = 0
    for rank, index in enumerate(
        np.argsort(-scores, kind="mergesort"), start=1
    ):
        found += int(y[index])
        if found == positives:
            return rank / len(y)
    return 1.0


def evaluate(
    labels: pd.DataFrame,
    scores: pd.DataFrame,
    baseline: pd.DataFrame | None,
) -> dict[str, Any]:
    merged = labels.merge(scores, on=["i", "j"], how="inner")
    y = merged["label"].to_numpy(dtype=int)
    s = merged["score"].to_numpy(dtype=float)

    result = {
        "pairs": len(merged),
        "positives": int(y.sum()),
        "base_rate": float(y.mean()),
        "auroc": float(roc_auc_score(y, s)),
        "auprc": float(average_precision_score(y, s)),
        "full_recall_budget": float(full_recall_budget(y, s)),
    }
    if baseline is not None:
        joined = merged.merge(
            baseline.rename(columns={"score": "baseline_score"}),
            on=["i", "j"],
            how="inner",
        )
        result["spearman_vs_baseline"] = float(
            spearmanr(
                joined["score"], joined["baseline_score"]
            ).statistic
        )
        k = max(
            1,
            int(
                math.ceil(
                    result["full_recall_budget"] * len(joined)
                )
            ),
        )
        new_top = set(
            canonical_pair(int(row.i), int(row.j))
            for row in joined.nlargest(k, "score").itertuples(index=False)
        )
        base_top = set(
            canonical_pair(int(row.i), int(row.j))
            for row in joined.nlargest(
                k, "baseline_score"
            ).itertuples(index=False)
        )
        result["topk_jaccard_vs_baseline"] = len(
            new_top & base_top
        ) / max(1, len(new_top | base_top))
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase4g-helper", type=Path, required=True)
    ap.add_argument("--person-cache", type=Path, required=True)
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--qerrors", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--rows", type=int, default=40000)
    ap.add_argument("--support", type=int, default=20)
    ap.add_argument("--numeric-threshold", type=float, default=0.98)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    qframe = pd.read_csv(args.qerrors)
    support_pairs = pd.read_csv(args.support_pairs)

    pg4g, ja, jb, A, B, cards, names = reconstruct_raw_phase4g(
        args, qframe
    )

    numeric_columns = {
        name
        for name in names
        if numeric_fraction(ja[name]) >= args.numeric_threshold
        and pd.to_numeric(ja[name], errors="coerce").nunique(dropna=True)
        > 10
    }

    labels = support_pairs[
        support_pairs["floor"] == args.support
    ][["i", "j", "pg_severe"]].copy()
    labels = labels.rename(columns={"pg_severe": "label"})
    labels["i"] = labels["i"].astype(int)
    labels["j"] = labels["j"].astype(int)
    labels["label"] = labels["label"].astype(int)

    metadata = {
        "experiment": "phase5i_binning_sensitivity",
        "ground_truth": (
            "Frozen exact PostgreSQL m=20 labels from Phase 5F. "
            "Only the max-ratio screen encoding changes."
        ),
        "rows_reference": len(ja),
        "rows_current": len(jb),
        "d": len(names),
        "pairs": len(labels),
        "support_floor": args.support,
        "numeric_detection_threshold": args.numeric_threshold,
        "numeric_columns": sorted(numeric_columns),
        "strategies": [strategy.name for strategy in STRATEGIES],
    }
    (args.out / "metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    metric_rows = []
    baseline_scores = None

    pairs = [
        (int(row.i), int(row.j))
        for row in labels.itertuples(index=False)
    ]

    for strategy in STRATEGIES:
        print(f"[phase5i] strategy={strategy.name}", flush=True)
        ref_columns, cur_columns = make_encoded_columns(
            ja,
            jb,
            A,
            B,
            names,
            numeric_columns,
            strategy,
        )

        score_rows = []
        for count, (i, j) in enumerate(pairs, start=1):
            score_rows.append(
                {
                    "i": i,
                    "j": j,
                    "variable_i": names[i],
                    "variable_j": names[j],
                    "score": max_ratio(
                        ref_columns[i],
                        ref_columns[j],
                        cur_columns[i],
                        cur_columns[j],
                        args.support,
                    ),
                }
            )
            if count % 1000 == 0 or count == len(pairs):
                print(
                    f"  [pairs] {count}/{len(pairs)}",
                    flush=True,
                )

        scores = pd.DataFrame(score_rows)
        scores.to_csv(
            args.out / f"scores_{strategy.name}.csv",
            index=False,
        )

        metrics = evaluate(labels, scores[["i", "j", "score"]], baseline_scores)
        metric_rows.append({"strategy": strategy.name, **metrics})

        if strategy.name == "baseline_exact":
            baseline_scores = scores[["i", "j", "score"]].copy()

    summary = pd.DataFrame(metric_rows)
    summary.to_csv(
        args.out / "binning_sensitivity_summary.csv",
        index=False,
    )

    baseline = summary[
        summary["strategy"] == "baseline_exact"
    ].iloc[0]
    report = {
        "baseline_auroc": float(baseline["auroc"]),
        "baseline_auprc": float(baseline["auprc"]),
        "baseline_full_recall_budget": float(
            baseline["full_recall_budget"]
        ),
        "worst_auroc": float(summary["auroc"].min()),
        "worst_auprc": float(summary["auprc"].min()),
        "largest_full_recall_budget": float(
            summary["full_recall_budget"].max()
        ),
        "scientific_scope": (
            "Screen sensitivity only. Exact PostgreSQL labels remain "
            "fixed; the experiment does not redefine operational "
            "staleness for every discretization."
        ),
    }
    (args.out / "gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(summary.to_string(index=False))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
