#!/usr/bin/env python3
"""
Phase 5J v2: retire-versus-refresh policy audit.

This runner answers the actual systems question left open by Phase 5F:

    Given the verified m=20 harmful multivariate statistics objects,
    is it cheaper and still correct to retire them, refresh them, or use
    a hybrid retire/refresh policy?

The frozen Phase 5F protocol is reused exactly:
2019 A -> ANALYZE -> replace rows by 2021 B.

Policies:
  full_refresh:
      ANALYZE the complete table.
  b8_refresh:
      Keep all objects and execute the frozen B8 grouped refresh.
  retire_all:
      DROP all verified harmful pair objects, then execute the same B8
      column groups so current single-column statistics are refreshed.
  hybrid:
      DROP only pairs repaired by the retire-all counterfactual; retain
      and refresh the residual pairs through the same frozen B8 groups.

Important:
- "Retireable" is defined under one explicit global policy:
  all verified harmful pair objects are removed and current ordinary
  column statistics are refreshed.
- It is not claimed as a per-object causal effect.
- Every timed repetition reconstructs the same stale catalog first.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import random
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def stat_name(i: int, j: int) -> str:
    i, j = sorted((int(i), int(j)))
    return f"evs_{i}_{j}"


def ensure_pair_statistics(conn, schema: str, edges: set[tuple[int, int]]) -> int:
    """Recreate any pair objects dropped by a prior policy repetition."""
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT stxname
            FROM pg_statistic_ext
            WHERE stxrelid = %s::regclass
            """,
            (f"{qi(schema)}.fact",),
        )
        existing = {str(row[0]) for row in cur.fetchall()}
        created = 0
        for i, j in sorted(edges):
            name = stat_name(i, j)
            if name in existing:
                continue
            cur.execute(
                f"""
                CREATE STATISTICS {qi(schema)}.{qi(name)}
                (dependencies, mcv)
                ON c{i}, c{j}
                FROM {qi(schema)}.fact
                """
            )
            created += 1
    return created


def drop_pair_statistics(
    conn,
    schema: str,
    edges: set[tuple[int, int]],
) -> float:
    start = time.perf_counter()
    with conn.cursor() as cur:
        for i, j in sorted(edges):
            cur.execute(
                f"DROP STATISTICS IF EXISTS "
                f"{qi(schema)}.{qi(stat_name(i, j))}"
            )
    return time.perf_counter() - start


def extended_payload_digest(
    conn,
    schema: str,
    edges: set[tuple[int, int]],
) -> tuple[int, str]:
    """
    Digest only the named harmful pair objects. Used to prove that the
    ordinary-column refresh in the attribution stage did not refresh their
    old multivariate payload.
    """
    names = [stat_name(i, j) for i, j in sorted(edges)]
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT
                count(*)::bigint,
                md5(
                    coalesce(
                        string_agg(
                            e.stxname || ':' || d::text,
                            '|' ORDER BY e.stxname
                        ),
                        ''
                    )
                )
            FROM pg_statistic_ext AS e
            JOIN pg_statistic_ext_data AS d
              ON d.stxoid = e.oid
            WHERE e.stxrelid = %s::regclass
              AND e.stxname = ANY(%s)
            """,
            (f"{qi(schema)}.fact", names),
        )
        count, digest = cur.fetchone()
    return int(count), str(digest)


def analyze_columns_individually(
    conn,
    schema: str,
    columns: set[int],
    target: int,
) -> float:
    """
    Refresh current ordinary statistics without recomputing any two-column
    extended-statistics payload: each ANALYZE command contains one column.
    """
    start = time.perf_counter()
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target={int(target)}")
        for index, column in enumerate(sorted(columns), start=1):
            cur.execute(
                f"ANALYZE {qi(schema)}.fact (c{column})"
            )
            if index % 20 == 0 or index == len(columns):
                print(
                    f"[fresh singles] {index}/{len(columns)}",
                    flush=True,
                )
    return time.perf_counter() - start


def evaluate_edges(
    pg4g,
    conn,
    schema: str,
    rows_by_edge: dict[tuple[int, int], dict[str, Any]],
    edges: set[tuple[int, int]],
    state: str,
) -> list[dict[str, Any]]:
    results = []
    for index, edge in enumerate(sorted(edges), start=1):
        row = rows_by_edge[edge]
        qerror, estimate, actual = pg4g.explain_q(
            conn,
            schema,
            edge[0],
            edge[1],
            int(row["value_i"]),
            int(row["value_j"]),
        )
        results.append(
            {
                "state": state,
                "i": edge[0],
                "j": edge[1],
                "variable_i": row["variable_i"],
                "variable_j": row["variable_j"],
                "value_i": int(row["value_i"]),
                "value_j": int(row["value_j"]),
                "estimated_rows": float(estimate),
                "actual_rows": float(actual),
                "qerror": float(qerror),
            }
        )
        if index % 50 == 0 or index == len(edges):
            print(
                f"[evaluate {state}] {index}/{len(edges)}",
                flush=True,
            )
    return results


def q_summary(
    state: str,
    rows: list[dict[str, Any]],
    repaired_threshold: float,
    severe_threshold: float,
) -> dict[str, Any]:
    values = [float(row["qerror"]) for row in rows]
    return {
        "state": state,
        "pairs": len(values),
        "qerror_geomean": statistics.geometric_mean(
            max(value, 1.0) for value in values
        ),
        "qerror_median": statistics.median(values),
        "qerror_p90": qtile(values, 0.90),
        "qerror_max": max(values),
        "repaired_fraction": sum(
            value <= repaired_threshold for value in values
        ) / len(values),
        "severe_fraction": sum(
            value >= severe_threshold for value in values
        ) / len(values),
    }


def plan_metrics(groups: list[set[int]]) -> dict[str, int]:
    return {
        "calls": len(groups),
        "object_ops_upper_bound": sum(
            choose2(len(group)) for group in groups
        ),
        "max_width": max((len(group) for group in groups), default=0),
    }


def run_b8_groups(
    pg4g,
    conn,
    schema: str,
    groups: list[set[int]],
    target: int,
) -> float:
    start = time.perf_counter()
    for group in groups:
        pg4g.analyze_group(conn, schema, group, target)
    return time.perf_counter() - start


def run_policy(
    *,
    phase5f,
    pg4g,
    conn,
    schema: str,
    A: np.ndarray,
    B: np.ndarray,
    target: int,
    all_harmful: set[tuple[int, int]],
    retire_edges: set[tuple[int, int]],
    groups: list[set[int]],
    policy: str,
) -> dict[str, Any]:
    # Restore any statistics object removed by the previous repetition.
    recreated = ensure_pair_statistics(conn, schema, all_harmful)

    # Reconstruct the exact frozen stale state. ANALYZE A populates every
    # restored pair object before rows are replaced by B.
    phase5f.establish_stale(
        pg4g,
        conn,
        schema,
        A,
        B,
        target,
    )

    drop_seconds = 0.0
    analyze_seconds = 0.0

    start = time.perf_counter()
    if policy == "full_refresh":
        analyze_seconds = pg4g.analyze_all(conn, schema, target)
    elif policy == "b8_refresh":
        analyze_seconds = run_b8_groups(
            pg4g, conn, schema, groups, target
        )
    elif policy == "retire_all":
        drop_seconds = drop_pair_statistics(
            conn, schema, all_harmful
        )
        # Same frozen B8 column groups: this refreshes current ordinary
        # statistics for every active column. Dropped pair objects stay absent.
        analyze_seconds = run_b8_groups(
            pg4g, conn, schema, groups, target
        )
    elif policy == "hybrid":
        drop_seconds = drop_pair_statistics(
            conn, schema, retire_edges
        )
        # Retained residual harmful objects are refreshed by the same B8 groups.
        analyze_seconds = run_b8_groups(
            pg4g, conn, schema, groups, target
        )
    else:
        raise ValueError(policy)

    action_seconds = time.perf_counter() - start
    return {
        "policy": policy,
        "recreated_before_reset": recreated,
        "drop_seconds": drop_seconds,
        "analyze_seconds": analyze_seconds,
        "action_seconds": action_seconds,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase5f-script", type=Path, required=True)
    ap.add_argument("--phase4g-helper", type=Path, required=True)
    ap.add_argument("--person-cache", type=Path, required=True)
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--qerrors", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument(
        "--schema",
        default="evostats_phase5j_retire_refresh",
    )
    ap.add_argument("--rows", type=int, default=40000)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--support-floor", type=int, default=20)
    ap.add_argument("--repaired-threshold", type=float, default=2.0)
    ap.add_argument("--severe-threshold", type=float, default=10.0)
    ap.add_argument("--width", type=int, default=8)
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--seed", type=int, default=20260719)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(args.phase5f_script, "phase5f_exact")
    pg4g = load_module(args.phase4g_helper, "phase4g_exact")

    qframe = pd.read_csv(args.qerrors)
    support = pd.read_csv(args.support_pairs)
    pg4g_from_phase5f, A, B, cards, names, metadata = (
        phase5f.reconstruct_exact_phase4g(args, qframe)
    )
    if pg4g_from_phase5f is None:
        raise RuntimeError("Exact Phase 4G reconstruction failed")

    severe_frame = support[
        (support["floor"] == args.support_floor)
        & (support["pg_severe"] == 1)
    ].copy()
    harmful = {
        (int(row.i), int(row.j))
        for row in severe_frame.itertuples(index=False)
    }
    rows_by_edge = {
        (int(row["i"]), int(row["j"])): row
        for row in severe_frame.to_dict("records")
    }
    if not harmful:
        raise RuntimeError("No verified harmful pairs")

    active_columns = {v for edge in harmful for v in edge}
    groups = phase5f.bounded_greedy(harmful, args.width)
    metrics = plan_metrics(groups)

    print(
        f"[phase5j-v2] d={len(names)} harmful={len(harmful)} "
        f"active={len(active_columns)} B{args.width}_calls={metrics['calls']}",
        flush=True,
    )

    conn = pg4g.connect(args.dsn)
    attribution_rows: list[dict[str, Any]] = []
    attribution_summary: list[dict[str, Any]] = []
    runtime_trials: list[dict[str, Any]] = []

    try:
        pg4g.create_schema(conn, args.schema, len(names))
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, len(names))

        # --------------------------------------------------------------
        # Attribution stage
        # --------------------------------------------------------------
        phase5f.establish_stale(
            pg4g, conn, args.schema, A, B, args.statistics_target
        )
        stale_rows = evaluate_edges(
            pg4g,
            conn,
            args.schema,
            rows_by_edge,
            harmful,
            "stale_catalog",
        )
        attribution_rows.extend(stale_rows)
        attribution_summary.append(
            q_summary(
                "stale_catalog",
                stale_rows,
                args.repaired_threshold,
                args.severe_threshold,
            )
        )

        before_digest = extended_payload_digest(
            conn, args.schema, harmful
        )
        singles_seconds = analyze_columns_individually(
            conn,
            args.schema,
            active_columns,
            args.statistics_target,
        )
        after_digest = extended_payload_digest(
            conn, args.schema, harmful
        )
        if before_digest != after_digest:
            raise RuntimeError(
                "Invalid attribution state: refreshing ordinary columns "
                "changed harmful multivariate payloads."
            )

        fresh_singles_stale_multi_rows = evaluate_edges(
            pg4g,
            conn,
            args.schema,
            rows_by_edge,
            harmful,
            "fresh_singles_stale_multivariate",
        )
        attribution_rows.extend(fresh_singles_stale_multi_rows)
        attribution_summary.append(
            q_summary(
                "fresh_singles_stale_multivariate",
                fresh_singles_stale_multi_rows,
                args.repaired_threshold,
                args.severe_threshold,
            )
        )

        # Explicit global retirement policy: remove all verified harmful
        # pair objects after refreshing current ordinary stats.
        retirement_drop_seconds = drop_pair_statistics(
            conn, args.schema, harmful
        )
        retired_rows = evaluate_edges(
            pg4g,
            conn,
            args.schema,
            rows_by_edge,
            harmful,
            "retire_all_harmful",
        )
        attribution_rows.extend(retired_rows)
        attribution_summary.append(
            q_summary(
                "retire_all_harmful",
                retired_rows,
                args.repaired_threshold,
                args.severe_threshold,
            )
        )

        retire_q = {
            (int(row["i"]), int(row["j"])): float(row["qerror"])
            for row in retired_rows
        }
        retireable = {
            edge
            for edge in harmful
            if retire_q[edge] <= args.repaired_threshold
        }
        residual = harmful - retireable

        policy_rows = []
        for edge in sorted(harmful):
            row = rows_by_edge[edge]
            policy_rows.append(
                {
                    "i": edge[0],
                    "j": edge[1],
                    "variable_i": row["variable_i"],
                    "variable_j": row["variable_j"],
                    "value_i": int(row["value_i"]),
                    "value_j": int(row["value_j"]),
                    "retire_all_qerror": retire_q[edge],
                    "hybrid_action": (
                        "retire"
                        if edge in retireable
                        else "retain_and_refresh"
                    ),
                }
            )

        # Validate the hybrid state once before timing.
        ensure_pair_statistics(conn, args.schema, harmful)
        phase5f.establish_stale(
            pg4g, conn, args.schema, A, B, args.statistics_target
        )
        drop_pair_statistics(conn, args.schema, retireable)
        run_b8_groups(
            pg4g,
            conn,
            args.schema,
            groups,
            args.statistics_target,
        )
        hybrid_rows = evaluate_edges(
            pg4g,
            conn,
            args.schema,
            rows_by_edge,
            harmful,
            "hybrid_retire_refresh",
        )
        attribution_rows.extend(hybrid_rows)
        attribution_summary.append(
            q_summary(
                "hybrid_retire_refresh",
                hybrid_rows,
                args.repaired_threshold,
                args.severe_threshold,
            )
        )

        # --------------------------------------------------------------
        # Randomized policy-cost stage
        # --------------------------------------------------------------
        policies = [
            "full_refresh",
            "b8_refresh",
            "retire_all",
            "hybrid",
        ]
        rng = random.Random(args.seed)

        for repetition in range(1, args.repeats + 1):
            order = policies.copy()
            rng.shuffle(order)
            for order_index, policy in enumerate(order, start=1):
                print(
                    f"[runtime] rep={repetition}/{args.repeats} "
                    f"policy={policy}",
                    flush=True,
                )
                timing = run_policy(
                    phase5f=phase5f,
                    pg4g=pg4g,
                    conn=conn,
                    schema=args.schema,
                    A=A,
                    B=B,
                    target=args.statistics_target,
                    all_harmful=harmful,
                    retire_edges=retireable,
                    groups=groups,
                    policy=policy,
                )
                repair = phase5f.verify_repair(
                    pg4g,
                    conn,
                    args.schema,
                    severe_frame.to_dict("records"),
                    harmful,
                )
                runtime_trials.append(
                    {
                        "repeat": repetition,
                        "order": order_index,
                        **timing,
                        "repair_fraction": float(repair["repair"]),
                        "qerror_geomean": float(
                            repair["fresh_qgeo"]
                        ),
                    }
                )
    finally:
        conn.close()

    write_csv(args.out / "attribution_detail.csv", attribution_rows)
    write_csv(args.out / "attribution_summary.csv", attribution_summary)
    write_csv(args.out / "hybrid_actions.csv", policy_rows)
    write_csv(args.out / "runtime_trials.csv", runtime_trials)

    runtime_summary = []
    for policy in [
        "full_refresh",
        "b8_refresh",
        "retire_all",
        "hybrid",
    ]:
        rows = [
            row for row in runtime_trials if row["policy"] == policy
        ]
        values = [float(row["action_seconds"]) for row in rows]
        runtime_summary.append(
            {
                "policy": policy,
                "harmful_pairs": len(harmful),
                "retired_pairs": (
                    len(harmful)
                    if policy == "retire_all"
                    else len(retireable)
                    if policy == "hybrid"
                    else 0
                ),
                "retained_refreshed_pairs": (
                    len(residual)
                    if policy == "hybrid"
                    else len(harmful)
                    if policy in {"b8_refresh", "full_refresh"}
                    else 0
                ),
                **metrics,
                "seconds_median": statistics.median(values),
                "seconds_iqr": qtile(values, 0.75)
                - qtile(values, 0.25),
                "drop_seconds_median": statistics.median(
                    float(row["drop_seconds"]) for row in rows
                ),
                "analyze_seconds_median": statistics.median(
                    float(row["analyze_seconds"]) for row in rows
                ),
                "repair_fraction_median": statistics.median(
                    float(row["repair_fraction"]) for row in rows
                ),
                "qerror_geomean_median": statistics.median(
                    float(row["qerror_geomean"]) for row in rows
                ),
            }
        )

    full_time = next(
        row["seconds_median"]
        for row in runtime_summary
        if row["policy"] == "full_refresh"
    )
    b8_time = next(
        row["seconds_median"]
        for row in runtime_summary
        if row["policy"] == "b8_refresh"
    )
    for row in runtime_summary:
        row["speedup_vs_full"] = (
            full_time / row["seconds_median"]
        )
        row["speedup_vs_b8"] = (
            b8_time / row["seconds_median"]
        )

    write_csv(args.out / "runtime_summary.csv", runtime_summary)

    report = {
        "experiment": "phase5j_retire_refresh_v2",
        "harmful_pairs": len(harmful),
        "active_columns": len(active_columns),
        "retireable_under_global_retirement_policy": len(retireable),
        "residual_requiring_refresh_or_further_action": len(residual),
        "retirement_definition": (
            "A pair is marked retireable only when its predicate has "
            f"Q-error <= {args.repaired_threshold} after all verified "
            "harmful pair objects are dropped and current ordinary "
            "statistics are refreshed. This is a global-policy outcome, "
            "not a per-object causal claim."
        ),
        "b8_plan": metrics,
        "attribution_summary": attribution_summary,
        "runtime_summary": runtime_summary,
        "setup_costs_not_in_policy_runtime": {
            "fresh_single_columns_attribution_seconds": singles_seconds,
            "retirement_drop_attribution_seconds": retirement_drop_seconds,
            "note": (
                "These one-time attribution costs classify the policy and "
                "are not included in randomized action timing. Each timed "
                "policy begins from an independently reconstructed stale "
                "catalog."
            ),
        },
        "reconstruction_metadata": metadata,
    }
    (args.out / "gate_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("\nATTRIBUTION SUMMARY")
    print(pd.DataFrame(attribution_summary).to_string(index=False))
    print(
        f"\nPOLICY SPLIT: retire={len(retireable)} "
        f"retain+refresh={len(residual)}"
    )
    print("\nRUNTIME SUMMARY")
    print(pd.DataFrame(runtime_summary).to_string(index=False))
    print("\n" + json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
