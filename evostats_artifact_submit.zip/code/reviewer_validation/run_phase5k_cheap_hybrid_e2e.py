#!/usr/bin/env python3
"""
Phase 5K: end-to-end cheap retire-or-refresh policy.

Scientific contract
-------------------
The policy starts from the exact frozen Phase 5F stale state.

The retire/refresh classifier does NOT:
  * DROP statistics to probe a counterfactual,
  * ANALYZE current data,
  * execute PostgreSQL COUNT/EXPLAIN queries, or
  * use Phase 5J oracle labels.

It uses information already available after EvoStats screening/verification:
the current snapshot B, the verified harmful cell, and its current count.

For each harmful pair (i,j) and verified cell (vi,vj), it computes the
current lower-order independence estimate

    n * P_B(c_i=vi) * P_B(c_j=vj)

directly from B. If its Q-error against the already verified current cell
count is <= threshold, the stale multivariate object is predicted safe to
retire; otherwise it is retained for refresh.

Execution policy
----------------
  cheap_hybrid:
      classify (timed)
      DROP predicted-retire harmful objects (timed)
      execute the SAME frozen B8 groups (timed)

The complete B8 groups are intentionally retained. Running only the nine
residual pair groups would be invalid: the endpoints of retired objects still
need current ordinary-column statistics. The B8 calls refresh those ordinary
statistics while dropped pair objects remain absent and residual objects are
refreshed.

Comparator:
  b8_refresh:
      execute the frozen B8 groups without retirement.

Both policies are reconstructed independently from the same stale catalog in
every repetition and are verified on all frozen m=20 severe predicates.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import random
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def stat_name(i: int, j: int) -> str:
    i, j = sorted((int(i), int(j)))
    return f"evs_{i}_{j}"


def ensure_pair_statistics(
    conn,
    schema: str,
    edges: set[tuple[int, int]],
) -> int:
    """Restore harmful pair objects dropped by a previous repetition."""
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT stxname
            FROM pg_statistic_ext
            WHERE stxrelid = %s::regclass
            """,
            (f"{qi(schema)}.fact",),
        )
        existing = {str(row[0]) for row in cur.fetchall()}
        created = 0
        for i, j in sorted(edges):
            name = stat_name(i, j)
            if name in existing:
                continue
            cur.execute(
                f"""
                CREATE STATISTICS {qi(schema)}.{qi(name)}
                (dependencies, mcv)
                ON c{i}, c{j}
                FROM {qi(schema)}.fact
                """
            )
            created += 1
    return created


def drop_pair_statistics(
    conn,
    schema: str,
    edges: set[tuple[int, int]],
) -> float:
    start = time.perf_counter()
    with conn.cursor() as cur:
        for i, j in sorted(edges):
            cur.execute(
                f"DROP STATISTICS IF EXISTS "
                f"{qi(schema)}.{qi(stat_name(i, j))}"
            )
    return time.perf_counter() - start


def run_groups(
    pg4g,
    conn,
    schema: str,
    groups: list[set[int]],
    target: int,
) -> float:
    start = time.perf_counter()
    for group in groups:
        pg4g.analyze_group(conn, schema, group, target)
    return time.perf_counter() - start


def qerror(estimated: float, actual: float) -> float:
    estimated = max(float(estimated), 1.0)
    actual = max(float(actual), 1.0)
    return max(estimated / actual, actual / estimated)


def classify_from_current_snapshot(
    B: np.ndarray,
    rows_by_edge: dict[tuple[int, int], dict[str, Any]],
    threshold: float,
) -> tuple[set[tuple[int, int]], set[tuple[int, int]], list[dict[str, Any]], float]:
    """
    O(n*d_active + M) classifier using only the already reconstructed current
    snapshot and verified harmful cells. No PostgreSQL calls occur here.
    """
    start = time.perf_counter()
    n = int(B.shape[0])

    # Cache only the marginal counts actually requested by harmful cells.
    requested: dict[int, set[int]] = {}
    for row in rows_by_edge.values():
        requested.setdefault(int(row["i"]), set()).add(int(row["value_i"]))
        requested.setdefault(int(row["j"]), set()).add(int(row["value_j"]))

    counts: dict[tuple[int, int], int] = {}
    for column, values in requested.items():
        vector = B[:, column]
        # bincount is substantially faster than one scan per value.
        card = int(vector.max()) + 1
        histogram = np.bincount(vector.astype(np.int64), minlength=card)
        for value in values:
            counts[(column, value)] = (
                int(histogram[value]) if value < len(histogram) else 0
            )

    retire: set[tuple[int, int]] = set()
    refresh: set[tuple[int, int]] = set()
    detail: list[dict[str, Any]] = []

    for edge in sorted(rows_by_edge):
        row = rows_by_edge[edge]
        i, j = edge
        vi, vj = int(row["value_i"]), int(row["value_j"])
        count_i = counts[(i, vi)]
        count_j = counts[(j, vj)]

        independence_estimate = (count_i * count_j) / n

        # Use the exact verified current count from the frozen support table.
        # Recompute from B as a consistency check.
        actual_from_b = int(
            np.count_nonzero((B[:, i] == vi) & (B[:, j] == vj))
        )
        actual_from_support = int(
            round(
                float(
                    row.get(
                        "pg_actual_rows",
                        row.get("current_count", actual_from_b),
                    )
                )
            )
        )
        if actual_from_support != actual_from_b:
            raise RuntimeError(
                f"Current-count mismatch for edge {edge}: "
                f"support={actual_from_support}, B={actual_from_b}"
            )

        indep_q = qerror(independence_estimate, actual_from_b)
        action = "retire" if indep_q <= threshold else "refresh"
        (retire if action == "retire" else refresh).add(edge)

        detail.append(
            {
                "i": i,
                "j": j,
                "variable_i": row["variable_i"],
                "variable_j": row["variable_j"],
                "value_i": vi,
                "value_j": vj,
                "marginal_count_i": count_i,
                "marginal_count_j": count_j,
                "actual_rows": actual_from_b,
                "independence_estimate": independence_estimate,
                "independence_qerror": indep_q,
                "predicted_action": action,
            }
        )

    seconds = time.perf_counter() - start
    return retire, refresh, detail, seconds


def load_oracle_actions(
    path: Path | None,
) -> dict[tuple[int, int], str] | None:
    if path is None or not path.exists():
        return None
    frame = pd.read_csv(path)
    required = {"i", "j", "hybrid_action"}
    if not required.issubset(frame.columns):
        raise RuntimeError(
            f"Oracle action file lacks columns: {sorted(required - set(frame.columns))}"
        )
    return {
        (int(row.i), int(row.j)): str(row.hybrid_action)
        for row in frame.itertuples(index=False)
    }


def agreement_report(
    prediction: list[dict[str, Any]],
    oracle: dict[tuple[int, int], str] | None,
) -> dict[str, Any]:
    if oracle is None:
        return {"available": False}

    tp = fp = tn = fn = 0
    mismatches = []
    for row in prediction:
        edge = (int(row["i"]), int(row["j"]))
        pred_refresh = row["predicted_action"] == "refresh"
        oracle_action = oracle.get(edge)
        if oracle_action is None:
            mismatches.append(
                {**row, "oracle_action": "MISSING"}
            )
            continue
        true_refresh = oracle_action == "retain_and_refresh"
        if pred_refresh and true_refresh:
            tp += 1
        elif pred_refresh and not true_refresh:
            fp += 1
        elif not pred_refresh and true_refresh:
            fn += 1
        else:
            tn += 1
        if pred_refresh != true_refresh:
            mismatches.append(
                {**row, "oracle_action": oracle_action}
            )

    total = tp + fp + tn + fn
    return {
        "available": True,
        "pairs_compared": total,
        "exact_agreement": (tp + tn) / total if total else float("nan"),
        "refresh_precision": tp / (tp + fp) if tp + fp else 1.0,
        "refresh_recall": tp / (tp + fn) if tp + fn else 1.0,
        "retire_precision": tn / (tn + fn) if tn + fn else 1.0,
        "retire_recall": tn / (tn + fp) if tn + fp else 1.0,
        "tp_refresh": tp,
        "fp_refresh": fp,
        "tn_retire": tn,
        "fn_refresh": fn,
        "mismatches": mismatches,
    }


def policy_summary(
    trials: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    result = []
    for policy in sorted({str(row["policy"]) for row in trials}):
        rows = [row for row in trials if row["policy"] == policy]
        total = [float(row["total_seconds"]) for row in rows]
        result.append(
            {
                "policy": policy,
                "repeats": len(rows),
                "total_seconds_median": statistics.median(total),
                "total_seconds_iqr": qtile(total, 0.75) - qtile(total, 0.25),
                "classify_seconds_median": statistics.median(
                    float(row["classify_seconds"]) for row in rows
                ),
                "drop_seconds_median": statistics.median(
                    float(row["drop_seconds"]) for row in rows
                ),
                "refresh_seconds_median": statistics.median(
                    float(row["refresh_seconds"]) for row in rows
                ),
                "repair_fraction_median": statistics.median(
                    float(row["repair_fraction"]) for row in rows
                ),
                "qerror_geomean_median": statistics.median(
                    float(row["qerror_geomean"]) for row in rows
                ),
                "retired_pairs": int(
                    statistics.median(
                        int(row["retired_pairs"]) for row in rows
                    )
                ),
                "refreshed_pairs": int(
                    statistics.median(
                        int(row["refreshed_pairs"]) for row in rows
                    )
                ),
            }
        )

    b8 = next(
        row["total_seconds_median"]
        for row in result
        if row["policy"] == "b8_refresh"
    )
    for row in result:
        row["speedup_vs_b8"] = b8 / row["total_seconds_median"]
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase5f-script", type=Path, required=True)
    ap.add_argument("--phase4g-helper", type=Path, required=True)
    ap.add_argument("--person-cache", type=Path, required=True)
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--qerrors", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--oracle-actions", type=Path)
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument(
        "--schema",
        default="evostats_phase5k_cheap_hybrid",
    )
    ap.add_argument("--rows", type=int, default=40000)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--support-floor", type=int, default=20)
    ap.add_argument("--retire-threshold", type=float, default=2.0)
    ap.add_argument("--width", type=int, default=8)
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--seed", type=int, default=20260719)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(args.phase5f_script, "phase5f_exact")
    pg4g = load_module(args.phase4g_helper, "phase4g_exact")

    qframe = pd.read_csv(args.qerrors)
    support = pd.read_csv(args.support_pairs)
    pg4g_loaded, A, B, cards, names, metadata = (
        phase5f.reconstruct_exact_phase4g(args, qframe)
    )
    if pg4g_loaded is None:
        raise RuntimeError("Exact Phase 4G reconstruction failed")

    severe_frame = support[
        (support["floor"] == args.support_floor)
        & (support["pg_severe"] == 1)
    ].copy()
    if len(severe_frame) == 0:
        raise RuntimeError("No frozen severe pairs")

    harmful = {
        (int(row.i), int(row.j))
        for row in severe_frame.itertuples(index=False)
    }
    rows_by_edge = {
        (int(row["i"]), int(row["j"])): row
        for row in severe_frame.to_dict("records")
    }

    # One deterministic classifier pass for labels and oracle comparison.
    predicted_retire, predicted_refresh, classifier_detail, classifier_seconds = (
        classify_from_current_snapshot(
            B,
            rows_by_edge,
            args.retire_threshold,
        )
    )
    oracle = load_oracle_actions(args.oracle_actions)
    agreement = agreement_report(classifier_detail, oracle)

    print(
        f"[classifier] harmful={len(harmful)} "
        f"retire={len(predicted_retire)} "
        f"refresh={len(predicted_refresh)} "
        f"seconds={classifier_seconds:.6f}",
        flush=True,
    )
    if agreement.get("available"):
        print(
            f"[classifier] exact_agreement="
            f"{agreement['exact_agreement']:.4f} "
            f"refresh_precision={agreement['refresh_precision']:.4f} "
            f"refresh_recall={agreement['refresh_recall']:.4f}",
            flush=True,
        )

    groups = phase5f.bounded_greedy(harmful, args.width)
    trials: list[dict[str, Any]] = []

    conn = pg4g.connect(args.dsn)
    try:
        pg4g.create_schema(conn, args.schema, len(names))
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, len(names))

        policies = ["b8_refresh", "cheap_hybrid"]
        rng = random.Random(args.seed)

        for repetition in range(1, args.repeats + 1):
            order = policies.copy()
            rng.shuffle(order)

            for order_index, policy in enumerate(order, start=1):
                print(
                    f"[runtime] rep={repetition}/{args.repeats} "
                    f"policy={policy}",
                    flush=True,
                )

                ensure_pair_statistics(
                    conn,
                    args.schema,
                    harmful,
                )
                phase5f.establish_stale(
                    pg4g,
                    conn,
                    args.schema,
                    A,
                    B,
                    args.statistics_target,
                )

                classify_time = 0.0
                drop_time = 0.0

                start_total = time.perf_counter()
                if policy == "cheap_hybrid":
                    retire, refresh, _, classify_time = (
                        classify_from_current_snapshot(
                            B,
                            rows_by_edge,
                            args.retire_threshold,
                        )
                    )
                    drop_time = drop_pair_statistics(
                        conn,
                        args.schema,
                        retire,
                    )
                else:
                    retire = set()
                    refresh = harmful

                refresh_time = run_groups(
                    pg4g,
                    conn,
                    args.schema,
                    groups,
                    args.statistics_target,
                )
                total_time = time.perf_counter() - start_total

                repair = phase5f.verify_repair(
                    pg4g,
                    conn,
                    args.schema,
                    severe_frame.to_dict("records"),
                    harmful,
                )

                trials.append(
                    {
                        "repeat": repetition,
                        "order": order_index,
                        "policy": policy,
                        "retired_pairs": len(retire),
                        "refreshed_pairs": len(refresh),
                        "classify_seconds": classify_time,
                        "drop_seconds": drop_time,
                        "refresh_seconds": refresh_time,
                        "total_seconds": total_time,
                        "repair_fraction": float(repair["repair"]),
                        "qerror_geomean": float(
                            repair["fresh_qgeo"]
                        ),
                    }
                )
    finally:
        conn.close()

    summary = policy_summary(trials)

    write_csv(args.out / "classifier_detail.csv", classifier_detail)
    write_csv(
        args.out / "classifier_mismatches.csv",
        agreement.get("mismatches", []),
    )
    write_csv(args.out / "runtime_trials.csv", trials)
    write_csv(args.out / "runtime_summary.csv", summary)

    report = {
        "experiment": "phase5k_cheap_hybrid_e2e",
        "harmful_pairs": len(harmful),
        "classifier": {
            "definition": (
                "Current-snapshot marginal independence estimate computed "
                "directly from B and compared against the already verified "
                "current harmful-cell count."
            ),
            "retire_threshold": args.retire_threshold,
            "predicted_retire": len(predicted_retire),
            "predicted_refresh": len(predicted_refresh),
            "single_pass_seconds": classifier_seconds,
            "oracle_agreement": {
                key: value
                for key, value in agreement.items()
                if key != "mismatches"
            },
        },
        "execution": {
            "b8_groups": len(groups),
            "b8_max_width": max(len(group) for group in groups),
            "note": (
                "Cheap hybrid uses the complete frozen B8 groups. "
                "Residual-only groups would not refresh current ordinary "
                "statistics for retired-object endpoints and are therefore "
                "not a valid comparator."
            ),
            "runtime_summary": summary,
        },
        "reconstruction_metadata": metadata,
    }
    (args.out / "gate_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("\nCLASSIFIER")
    print(
        pd.DataFrame(classifier_detail)
        .sort_values("independence_qerror", ascending=False)
        .head(15)
        .to_string(index=False)
    )
    print("\nRUNTIME SUMMARY")
    print(pd.DataFrame(summary).to_string(index=False))
    print("\n" + json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
