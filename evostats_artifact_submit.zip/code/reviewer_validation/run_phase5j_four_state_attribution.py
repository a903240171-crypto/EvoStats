#!/usr/bin/env python3
"""
Phase 5J: four-state attribution audit for EvoStats.

States on the same current snapshot B:
A. stale single-column + stale multivariate statistics
B. fresh single-column + stale multivariate statistics
C. fresh single-column + no multivariate statistics
D. fresh single-column + fresh multivariate statistics

The script reuses the exact frozen Phase 4G/5F reconstruction and evaluates
the complete m=20 severe set. It does not modify phase5_validation.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def qgeo(values: list[float]) -> float:
    values = [max(float(v), 1.0) for v in values]
    return statistics.geometric_mean(values) if values else 1.0


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def ext_stats_hash(conn, schema: str) -> tuple[int, str | None]:
    """
    Hash pg_statistic_ext_data rows so State B can verify that one-column
    ANALYZE calls refreshed only single-column statistics and left the old
    multivariate payload unchanged.
    """
    sql = """
    SELECT
        count(*)::bigint,
        md5(
            coalesce(
                string_agg(
                    e.stxname || ':' || d::text,
                    '|' ORDER BY e.stxname
                ),
                ''
            )
        )
    FROM pg_statistic_ext AS e
    JOIN pg_statistic_ext_data AS d
      ON d.stxoid = e.oid
    WHERE e.stxrelid = %s::regclass
    """
    relation = f"{qi(schema)}.fact"
    with conn.cursor() as cur:
        cur.execute(sql, (relation,))
        count, digest = cur.fetchone()
    return int(count), str(digest) if digest is not None else None


def refresh_single_columns_only(
    conn,
    schema: str,
    d: int,
    target: int,
) -> float:
    """
    Refresh each ordinary column separately. Because every ANALYZE command
    contains only one column, no two-column extended-statistics object is
    eligible for recomputation.
    """
    start = time.perf_counter()
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target={int(target)}")
        for index in range(d):
            cur.execute(
                f"ANALYZE {qi(schema)}.fact (c{index})"
            )
            if (index + 1) % 25 == 0 or index + 1 == d:
                print(
                    f"[single-column ANALYZE] {index + 1}/{d}",
                    flush=True,
                )
    return time.perf_counter() - start


def drop_extended_statistics(conn, schema: str) -> int:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT e.stxname
            FROM pg_statistic_ext AS e
            WHERE e.stxrelid = %s::regclass
            ORDER BY e.stxname
            """,
            (f"{qi(schema)}.fact",),
        )
        names = [str(row[0]) for row in cur.fetchall()]
        for name in names:
            cur.execute(
                f"DROP STATISTICS IF EXISTS {qi(schema)}.{qi(name)}"
            )
    return len(names)


def evaluate_state(
    pg4g,
    conn,
    schema: str,
    state: str,
    severe_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows = []
    for index, row in enumerate(severe_rows, start=1):
        qerror, estimated, actual = pg4g.explain_q(
            conn,
            schema,
            int(row["i"]),
            int(row["j"]),
            int(row["value_i"]),
            int(row["value_j"]),
        )
        rows.append(
            {
                "state": state,
                "i": int(row["i"]),
                "j": int(row["j"]),
                "variable_i": str(row["variable_i"]),
                "variable_j": str(row["variable_j"]),
                "value_i": int(row["value_i"]),
                "value_j": int(row["value_j"]),
                "estimated_rows": float(estimated),
                "actual_rows": float(actual),
                "qerror": float(qerror),
            }
        )
        if index % 50 == 0 or index == len(severe_rows):
            print(
                f"[evaluate {state}] {index}/{len(severe_rows)}",
                flush=True,
            )
    return rows


def summarize_state(
    state: str,
    rows: list[dict[str, Any]],
    severe_threshold: float,
    repaired_threshold: float,
) -> dict[str, Any]:
    qs = [float(row["qerror"]) for row in rows]
    return {
        "state": state,
        "pairs": len(rows),
        "qerror_geomean": qgeo(qs),
        "qerror_median": statistics.median(qs),
        "qerror_p90": qtile(qs, 0.90),
        "qerror_max": max(qs, default=1.0),
        "severe_fraction": (
            sum(q >= severe_threshold for q in qs) / len(qs)
            if qs else 0.0
        ),
        "repaired_fraction": (
            sum(q <= repaired_threshold for q in qs) / len(qs)
            if qs else 1.0
        ),
    }


def classify_pairs(
    wide: pd.DataFrame,
    severe_threshold: float,
    repaired_threshold: float,
) -> pd.DataFrame:
    required = {"A", "B", "C", "D"}
    if not required.issubset(set(wide.columns)):
        raise RuntimeError(
            f"Missing states in pivot: {sorted(required - set(wide.columns))}"
        )

    def classify(row) -> str:
        a, b, c, d = (
            float(row["A"]),
            float(row["B"]),
            float(row["C"]),
            float(row["D"]),
        )
        if b <= repaired_threshold:
            return "single_refresh_sufficient"
        if b >= severe_threshold and c <= repaired_threshold:
            return "retire_sufficient"
        if (
            b >= severe_threshold
            and c >= severe_threshold
            and d <= repaired_threshold
        ):
            return "multivariate_refresh_required"
        if d > repaired_threshold:
            return "fresh_multivariate_not_fully_repaired"
        return "mixed_or_intermediate"

    out = wide.reset_index().copy()
    out["attribution"] = out.apply(classify, axis=1)
    return out


def prepare_common_schema(
    pg4g,
    conn,
    schema: str,
    A: np.ndarray,
    d: int,
) -> None:
    pg4g.create_schema(conn, schema, d)
    pg4g.load_array(conn, schema, A)
    pg4g.create_stats(conn, schema, d)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase5f-script", type=Path, required=True)
    ap.add_argument("--phase4g-helper", type=Path, required=True)
    ap.add_argument("--person-cache", type=Path, required=True)
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--qerrors", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument(
        "--schema-prefix",
        default="evostats_phase5j",
    )
    ap.add_argument("--rows", type=int, default=40000)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--support-floor", type=int, default=20)
    ap.add_argument("--severe-threshold", type=float, default=10.0)
    ap.add_argument("--repaired-threshold", type=float, default=2.0)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(args.phase5f_script, "phase5f_exact")
    pg4g = load_module(args.phase4g_helper, "phase4g_exact")
    qframe = pd.read_csv(args.qerrors)
    support = pd.read_csv(args.support_pairs)

    pg4g_from_phase5f, A, B, cards, names, metadata = (
        phase5f.reconstruct_exact_phase4g(args, qframe)
    )
    if pg4g_from_phase5f is None:
        raise RuntimeError("Exact Phase 4G helper failed to load")

    severe_frame = support[
        (support["floor"] == args.support_floor)
        & (support["pg_severe"] == 1)
    ].copy()
    if severe_frame.empty:
        raise RuntimeError(
            f"No severe pairs at support floor {args.support_floor}"
        )

    severe_rows = severe_frame.to_dict("records")
    d = len(names)
    print(
        f"[phase5j] d={d} severe_pairs={len(severe_rows)} "
        f"floor={args.support_floor}",
        flush=True,
    )

    states: dict[str, list[dict[str, Any]]] = {}
    state_metadata: list[dict[str, Any]] = []

    conn = pg4g.connect(args.dsn)
    try:
        # State A: old single-column + old multivariate statistics, current data.
        schema_a = f"{args.schema_prefix}_a"
        prepare_common_schema(pg4g, conn, schema_a, A, d)
        pg4g.analyze_all(conn, schema_a, args.statistics_target)
        hash_a_before = ext_stats_hash(conn, schema_a)
        pg4g.replace_rows(conn, schema_a, B)
        hash_a_after = ext_stats_hash(conn, schema_a)
        if hash_a_before != hash_a_after:
            raise RuntimeError(
                "State A extended statistics changed after row replacement"
            )
        states["A"] = evaluate_state(
            pg4g, conn, schema_a, "A", severe_rows
        )
        state_metadata.append(
            {
                "state": "A",
                "description": (
                    "stale single-column + stale multivariate statistics"
                ),
                "schema": schema_a,
                "extended_statistics_count": hash_a_after[0],
                "extended_statistics_hash": hash_a_after[1],
            }
        )

        # State B: refresh ordinary columns one at a time while preserving
        # the old multivariate payload.
        schema_b = f"{args.schema_prefix}_b"
        prepare_common_schema(pg4g, conn, schema_b, A, d)
        pg4g.analyze_all(conn, schema_b, args.statistics_target)
        hash_b_old = ext_stats_hash(conn, schema_b)
        pg4g.replace_rows(conn, schema_b, B)
        single_seconds = refresh_single_columns_only(
            conn,
            schema_b,
            d,
            args.statistics_target,
        )
        hash_b_new = ext_stats_hash(conn, schema_b)
        if hash_b_old != hash_b_new:
            raise RuntimeError(
                "State B invalid: one-column ANALYZE changed the "
                "multivariate-statistics payload"
            )
        states["B"] = evaluate_state(
            pg4g, conn, schema_b, "B", severe_rows
        )
        state_metadata.append(
            {
                "state": "B",
                "description": (
                    "fresh single-column + stale multivariate statistics"
                ),
                "schema": schema_b,
                "single_column_refresh_seconds": single_seconds,
                "extended_statistics_count": hash_b_new[0],
                "extended_statistics_hash": hash_b_new[1],
                "multivariate_payload_preserved": True,
            }
        )

        # State C: same fresh ordinary statistics as B, then remove all
        # multivariate objects without another ANALYZE.
        schema_c = f"{args.schema_prefix}_c"
        prepare_common_schema(pg4g, conn, schema_c, A, d)
        pg4g.analyze_all(conn, schema_c, args.statistics_target)
        pg4g.replace_rows(conn, schema_c, B)
        refresh_single_columns_only(
            conn,
            schema_c,
            d,
            args.statistics_target,
        )
        dropped = drop_extended_statistics(conn, schema_c)
        remaining_count, remaining_hash = ext_stats_hash(conn, schema_c)
        if remaining_count != 0:
            raise RuntimeError(
                f"State C still has {remaining_count} extended statistics"
            )
        states["C"] = evaluate_state(
            pg4g, conn, schema_c, "C", severe_rows
        )
        state_metadata.append(
            {
                "state": "C",
                "description": (
                    "fresh single-column + no multivariate statistics"
                ),
                "schema": schema_c,
                "dropped_extended_statistics": dropped,
                "extended_statistics_count": remaining_count,
                "extended_statistics_hash": remaining_hash,
            }
        )

        # State D: current data with fresh ordinary and multivariate stats.
        schema_d = f"{args.schema_prefix}_d"
        pg4g.create_schema(conn, schema_d, d)
        pg4g.load_array(conn, schema_d, B)
        pg4g.create_stats(conn, schema_d, d)
        full_refresh_seconds = pg4g.analyze_all(
            conn,
            schema_d,
            args.statistics_target,
        )
        hash_d = ext_stats_hash(conn, schema_d)
        states["D"] = evaluate_state(
            pg4g, conn, schema_d, "D", severe_rows
        )
        state_metadata.append(
            {
                "state": "D",
                "description": (
                    "fresh single-column + fresh multivariate statistics"
                ),
                "schema": schema_d,
                "full_refresh_seconds": full_refresh_seconds,
                "extended_statistics_count": hash_d[0],
                "extended_statistics_hash": hash_d[1],
            }
        )
    finally:
        conn.close()

    detail_rows = [
        row
        for state in ("A", "B", "C", "D")
        for row in states[state]
    ]
    write_csv(args.out / "four_state_detail.csv", detail_rows)
    write_csv(args.out / "state_metadata.csv", state_metadata)

    summaries = [
        summarize_state(
            state,
            states[state],
            args.severe_threshold,
            args.repaired_threshold,
        )
        for state in ("A", "B", "C", "D")
    ]
    write_csv(args.out / "four_state_summary.csv", summaries)

    detail = pd.DataFrame(detail_rows)
    wide = detail.pivot_table(
        index=[
            "i",
            "j",
            "variable_i",
            "variable_j",
            "value_i",
            "value_j",
        ],
        columns="state",
        values="qerror",
        aggfunc="first",
    )
    attribution = classify_pairs(
        wide,
        args.severe_threshold,
        args.repaired_threshold,
    )
    attribution.to_csv(
        args.out / "pair_attribution.csv",
        index=False,
        encoding="utf-8-sig",
    )

    counts = (
        attribution["attribution"]
        .value_counts(dropna=False)
        .rename_axis("attribution")
        .reset_index(name="pairs")
    )
    counts["fraction"] = counts["pairs"] / len(attribution)
    counts.to_csv(
        args.out / "attribution_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    summary_by_state = {row["state"]: row for row in summaries}
    report = {
        "experiment": "phase5j_four_state_attribution",
        "support_floor": args.support_floor,
        "severe_pairs": len(severe_rows),
        "state_A_qgeo": summary_by_state["A"]["qerror_geomean"],
        "state_B_qgeo": summary_by_state["B"]["qerror_geomean"],
        "state_C_qgeo": summary_by_state["C"]["qerror_geomean"],
        "state_D_qgeo": summary_by_state["D"]["qerror_geomean"],
        "attribution_counts": {
            str(row.attribution): int(row.pairs)
            for row in counts.itertuples(index=False)
        },
        "decision_guide": {
            "single_refresh_sufficient": (
                "The original error is largely removed by refreshing "
                "ordinary column statistics."
            ),
            "retire_sufficient": (
                "The stale multivariate object remains harmful after "
                "ordinary-column refresh, but dropping it repairs the pair."
            ),
            "multivariate_refresh_required": (
                "Fresh ordinary statistics and deletion remain inaccurate; "
                "a fresh multivariate object is needed."
            ),
            "mixed_or_intermediate": (
                "The pair does not fall cleanly into the conservative "
                "Q>=10 / Q<=2 attribution categories."
            ),
        },
        "scientific_scope": (
            "Attribution audit over the frozen m=20 severe set. "
            "This is optional reviewer validation and does not alter the "
            "frozen Phase 5 results."
        ),
        "reconstruction_metadata": metadata,
    }
    (args.out / "gate_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("\nFOUR-STATE SUMMARY")
    print(pd.DataFrame(summaries).to_string(index=False))
    print("\nPAIR ATTRIBUTION")
    print(counts.to_string(index=False))
    print("\n" + json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
