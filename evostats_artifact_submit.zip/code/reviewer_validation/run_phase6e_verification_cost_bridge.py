#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, importlib.util, itertools, json, math, random, statistics, time
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields, seen = [], set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key); fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)


def qtile(xs, q):
    return float(np.quantile(np.asarray(xs, dtype=float), q))


def reconstruct_templates(phase5f, A, B, cards, names, floor):
    start = time.perf_counter()
    out = []
    for n, (i, j) in enumerate(itertools.combinations(range(B.shape[1]), 2), 1):
        c0, c1 = phase5f.pair_counts(A, B, i, j, cards[i], cards[j])
        cell = phase5f.select_cell(c0, c1, len(A), len(B), floor)
        out.append({
            "i": i, "j": j,
            "variable_i": names[i], "variable_j": names[j],
            "value_i": int(cell["value_i"]), "value_j": int(cell["value_j"]),
            "old_count": int(cell["old_count"]),
            "current_count": int(cell["current_count"]),
            "eligible": int(cell["eligible"]),
            "qhat": float(cell["qhat"]),
        })
        if n % 1000 == 0 or n == math.comb(B.shape[1], 2):
            print(f"[screen] {n}/{math.comb(B.shape[1], 2)}", flush=True)
    return out, time.perf_counter() - start


def normalize_support(df):
    req = {"floor", "i", "j", "pg_severe"}
    if not req.issubset(df.columns):
        raise RuntimeError(f"support_pairs.csv lacks {sorted(req-set(df.columns))}")
    vi = next((x for x in ("value_i", "worst_i") if x in df.columns), None)
    vj = next((x for x in ("value_j", "worst_j") if x in df.columns), None)
    ac = next((x for x in ("pg_actual_rows", "actual_rows", "current_count") if x in df.columns), None)
    if vi is None or vj is None or ac is None:
        raise RuntimeError("support_pairs.csv lacks floor-specific cell/count columns")
    return df.rename(columns={vi:"support_value_i", vj:"support_value_j", ac:"support_actual_rows"})


def check_templates(templates, support):
    lookup = {(int(r.i), int(r.j)): r for r in support.itertuples(index=False)}
    bad = []
    for t in templates:
        r = lookup.get((t["i"], t["j"]))
        if r is None or (
            t["value_i"] != int(r.support_value_i)
            or t["value_j"] != int(r.support_value_j)
            or t["current_count"] != int(round(float(r.support_actual_rows)))
        ):
            bad.append((t["i"], t["j"]))
    if bad:
        raise RuntimeError(f"floor template mismatch; first={bad[:10]}")


def verify_all_once(pg4g, phase5f, conn, schema, A, B, target, templates,
                    qthr, floor, physical_order, rep, progress_every):
    phase5f.establish_stale(pg4g, conn, schema, A, B, target)
    lookup = {(t["i"], t["j"]): t for t in templates}
    rows = []
    for idx, edge in enumerate(physical_order, 1):
        t = lookup[edge]
        st = time.perf_counter()
        q, est, act = pg4g.explain_q(
            conn, schema, edge[0], edge[1], t["value_i"], t["value_j"]
        )
        sec = time.perf_counter() - st
        if int(round(float(act))) != int(t["current_count"]):
            raise RuntimeError(f"actual mismatch {edge}: PG={act}, B={t['current_count']}")
        positive = int(t["current_count"] >= floor and float(q) >= qthr)
        rows.append({
            "repeat": rep, "physical_index": idx, **t,
            "postgres_estimated_rows": float(est),
            "postgres_actual_rows": float(act),
            "postgres_qerror": float(q),
            "positive": positive,
            "probe_seconds": sec,
        })
        if idx % progress_every == 0 or idx == len(physical_order):
            print(f"[verify] rep={rep} {idx}/{len(physical_order)}", flush=True)
    return rows


def shuffled(edges, seed):
    out = list(edges); random.Random(seed).shuffle(out); return out


def flat_order(templates):
    return [(r["i"], r["j"]) for r in sorted(
        templates, key=lambda r: (-r["qhat"], r["i"], r["j"])
    )]


def adaptive_order(templates, outcomes, trigger):
    global_q = flat_order(templates)
    qhat = {(r["i"], r["j"]): r["qhat"] for r in templates}
    incident = {}
    for e in global_q:
        incident.setdefault(e[0], []).append(e)
        incident.setdefault(e[1], []).append(e)
    for v in incident:
        incident[v].sort(key=lambda e: (-qhat[e], e))
    probed, closed, promoted, output = set(), set(), [], []
    posdeg, gi = {}, 0

    def promote(v):
        if v in closed: return
        closed.add(v)
        for e in incident.get(v, []):
            if e not in probed and e not in promoted:
                promoted.append(e)
        promoted.sort(key=lambda e: (-qhat[e], e))

    while len(output) < len(global_q):
        while promoted and promoted[0] in probed:
            promoted.pop(0)
        if promoted:
            e = promoted.pop(0)
        else:
            while gi < len(global_q) and global_q[gi] in probed:
                gi += 1
            if gi >= len(global_q): break
            e = global_q[gi]; gi += 1
        if e in probed: continue
        probed.add(e); output.append(e)
        if outcomes[e]:
            for v in e:
                posdeg[v] = posdeg.get(v, 0) + 1
                if posdeg[v] >= trigger:
                    promote(v)
    if len(output) != len(global_q):
        raise RuntimeError("adaptive order incomplete")
    return output


def milestones(rep, strategy, order, obs, truth, screen_seconds):
    targets = {
        "first_hit": 1,
        "recall_50": math.ceil(.5*len(truth)),
        "recall_90": math.ceil(.9*len(truth)),
        "recall_100": len(truth),
    }
    found, emitted, sec, rows = set(), set(), 0.0, []
    for k, e in enumerate(order, 1):
        sec += obs[e]["probe_seconds"]
        if e in truth: found.add(e)
        for name, target in targets.items():
            if name not in emitted and len(found) >= target:
                emitted.add(name)
                rows.append({
                    "repeat": rep, "strategy": strategy, "milestone": name,
                    "target_edges": target, "found_edges": len(found),
                    "recall": len(found)/len(truth), "probes": k,
                    "candidate_fraction": k/len(order),
                    "verification_seconds": sec,
                    "screen_seconds": screen_seconds,
                    "screen_plus_verification_seconds": screen_seconds+sec,
                })
    if "recall_100" not in emitted:
        raise RuntimeError(f"{strategy} failed full recall")
    return rows


def summarize(rows):
    out = []
    for strategy, milestone in sorted({(r["strategy"], r["milestone"]) for r in rows}):
        rs = [r for r in rows if r["strategy"] == strategy and r["milestone"] == milestone]
        probes = [r["probes"] for r in rs]
        secs = [r["verification_seconds"] for r in rs]
        totals = [r["screen_plus_verification_seconds"] for r in rs]
        out.append({
            "strategy": strategy, "milestone": milestone, "repeats": len(rs),
            "probes_median": statistics.median(probes),
            "probes_iqr": qtile(probes,.75)-qtile(probes,.25),
            "verification_seconds_median": statistics.median(secs),
            "verification_seconds_iqr": qtile(secs,.75)-qtile(secs,.25),
            "screen_plus_verification_seconds_median": statistics.median(totals),
            "screen_plus_verification_seconds_iqr": qtile(totals,.75)-qtile(totals,.25),
        })
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase5f-script", type=Path, required=True)
    ap.add_argument("--phase4g-helper", type=Path, required=True)
    ap.add_argument("--person-cache", type=Path, required=True)
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--qerrors", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_phase6e_verification_bridge")
    ap.add_argument("--rows", type=int, default=40000)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--support-floor", type=int, default=20)
    ap.add_argument("--q-threshold", type=float, default=10.0)
    ap.add_argument("--hub-trigger", type=int, default=3)
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--seed", type=int, default=20260722)
    ap.add_argument("--progress-every", type=int, default=500)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(args.phase5f_script.resolve(), "phase5f_phase6e")
    pg4g = load_module(args.phase4g_helper.resolve(), "phase4g_phase6e")
    qframe = pd.read_csv(args.qerrors)
    support = normalize_support(pd.read_csv(args.support_pairs))
    sf = support[support["floor"] == args.support_floor].copy()

    _, A, B, cards, names, metadata = phase5f.reconstruct_exact_phase4g(args, qframe)
    d, M = B.shape[1], math.comb(B.shape[1], 2)
    if (d, M) != (109, 5886):
        raise RuntimeError(f"expected 109/5886, got {d}/{M}")
    if len(sf) != M:
        raise RuntimeError(f"expected {M} support rows, got {len(sf)}")

    templates, screen_seconds = reconstruct_templates(
        phase5f, A, B, cards, names, args.support_floor
    )
    check_templates(templates, sf)

    truth = {(int(r.i), int(r.j)) for r in sf.itertuples(index=False) if int(r.pg_severe)==1}
    if len(truth) != 141:
        raise RuntimeError(f"expected 141 severe edges, got {len(truth)}")

    edges = [(t["i"],t["j"]) for t in templates]
    flat = flat_order(templates)
    all_obs, all_ms = [], []

    conn = pg4g.connect(args.dsn)
    try:
        pg4g.create_schema(conn, args.schema, d)
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, d)

        for rep in range(1, args.repeats+1):
            physical = shuffled(edges, args.seed + 100000*rep)
            obs_rows = verify_all_once(
                pg4g, phase5f, conn, args.schema, A, B,
                args.statistics_target, templates, args.q_threshold,
                args.support_floor, physical, rep, args.progress_every
            )
            all_obs.extend(obs_rows)
            obs = {(r["i"],r["j"]): r for r in obs_rows}
            observed = {e for e,r in obs.items() if r["positive"]}
            if observed != truth:
                raise RuntimeError(
                    f"PG truth mismatch missing={sorted(truth-observed)[:10]} "
                    f"extra={sorted(observed-truth)[:10]}"
                )
            outcomes = {e:r["positive"] for e,r in obs.items()}
            orders = {
                "random": shuffled(edges, args.seed+rep),
                "max_ratio": flat,
                "hub_adaptive": adaptive_order(templates, outcomes, args.hub_trigger),
                "exhaustive": edges,
            }
            for name, order in orders.items():
                all_ms.extend(milestones(rep,name,order,obs,truth,screen_seconds))

            fr = next(r for r in all_ms if r["repeat"]==rep and r["strategy"]=="max_ratio" and r["milestone"]=="recall_100")
            ar = next(r for r in all_ms if r["repeat"]==rep and r["strategy"]=="hub_adaptive" and r["milestone"]=="recall_100")
            print(f"[bridge] rep={rep}/{args.repeats} flat={fr['probes']} probes/{fr['verification_seconds']:.4f}s adaptive={ar['probes']} probes/{ar['verification_seconds']:.4f}s", flush=True)
    finally:
        conn.close()

    summary = summarize(all_ms)
    degree = {v:0 for v in range(d)}
    for u,v in truth: degree[u]+=1; degree[v]+=1
    hub = max(degree, key=degree.get)

    report = {
        "experiment":"phase6e_verification_cost_bridge",
        "scientific_contract":"Logical strategies replay the same real PostgreSQL per-probe measurements in each repetition. Ordering uses only qhat and already observed outcomes.",
        "theory_bridge":{
            "d":d,"M":M,"severe_edges":len(truth),
            "random_first_hit_expectation":(M+1)/(len(truth)+1),
            "single_hub_scale_M_over_s_plus_d":M/len(truth)+d,
            "observed_hub_vertex":hub,
            "observed_hub_name":names[hub],
            "observed_max_degree":degree[hub],
            "hub_trigger":args.hub_trigger,
            "screen_seconds_single_pass":screen_seconds,
        },
        "strategy_summary":summary,
        "reconstruction_metadata":metadata,
    }
    write_csv(args.out/"verification_observations.csv", all_obs)
    write_csv(args.out/"verification_milestones.csv", all_ms)
    write_csv(args.out/"strategy_summary.csv", summary)
    write_csv(args.out/"floor20_templates.csv", templates)
    (args.out/"gate_report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")

    print("\n"+"="*72)
    print("PHASE 6E VERIFICATION-COST BRIDGE COMPLETE")
    print("="*72)
    print(f"d={d} M={M} severe={len(truth)} hub={names[hub]} degree={degree[hub]}")
    print(f"theory random first hit E[T]={(M+1)/(len(truth)+1):.4f}")
    print(f"screen seconds={screen_seconds:.6f}")
    for r in summary:
        if r["milestone"] in ("first_hit","recall_100"):
            print(f"{r['strategy']:12s} {r['milestone']:10s}: probes={r['probes_median']:.1f} verify={r['verification_seconds_median']:.4f}s total={r['screen_plus_verification_seconds_median']:.4f}s")
    print(f"report: {args.out/'gate_report.json'}")


if __name__ == "__main__":
    main()
