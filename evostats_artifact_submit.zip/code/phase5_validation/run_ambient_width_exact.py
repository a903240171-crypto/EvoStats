#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,itertools,json,math,statistics,time,urllib.error,urllib.request,zipfile
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
import psycopg
from psycopg import sql

CENSUS_BASE='https://www2.census.gov/programs-surveys/acs/data/pums/{year}/1-Year/csv_hca.zip'

def choose2(n:int)->int:return n*(n-1)//2

def qi(x:str)->str:return '"'+x.replace('"','""')+'"'

def write_csv(path:Path,rows:list[dict[str,Any]])->None:
    if not rows:path.write_text('',encoding='utf-8');return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)

def valid_zip(path:Path)->bool:
    if not path.exists() or path.stat().st_size==0:return False
    try:
        with zipfile.ZipFile(path) as zf:return zf.testzip() is None
    except zipfile.BadZipFile:return False

def download_resumable(url:str,path:Path,retries:int=6)->None:
    if valid_zip(path):print(f'[download] cached {path.name}',flush=True);return
    part=path.with_suffix(path.suffix+'.part')
    if path.exists() and not valid_zip(path):
        if part.exists():path.unlink()
        else:path.replace(part)
    for attempt in range(1,retries+1):
        offset=part.stat().st_size if part.exists() else 0
        headers={'User-Agent':'EvoStats-Research/1.0'}
        if offset:headers['Range']=f'bytes={offset}-'
        print(f'[download] attempt={attempt}/{retries} resume={offset:,} {url}',flush=True)
        try:
            req=urllib.request.Request(url,headers=headers)
            with urllib.request.urlopen(req,timeout=300) as response:
                status=getattr(response,'status',response.getcode())
                mode='ab' if offset>0 and status==206 else 'wb'
                with part.open(mode) as f:
                    while True:
                        block=response.read(1024*1024)
                        if not block:break
                        f.write(block)
            if valid_zip(part):part.replace(path);print(f'[download] complete {path.name}',flush=True);return
        except (urllib.error.URLError,TimeoutError,OSError) as exc:
            print(f'[download] interrupted {type(exc).__name__}: {exc}',flush=True)
        if attempt<retries:time.sleep(min(30,2**attempt))
    raise RuntimeError(f'Failed to download {url}')

def extract_csv(zip_path:Path,out_dir:Path,year:int,kind:str)->Path:
    target=out_dir/f'{year}_{kind}.csv'
    if target.exists():return target
    with zipfile.ZipFile(zip_path) as zf:
        members=[n for n in zf.namelist() if n.lower().endswith('.csv')]
        if not members:raise RuntimeError(f'No CSV in {zip_path}')
        member=sorted(members,key=len)[0]
        with zf.open(member) as src,target.open('wb') as dst:
            while True:
                block=src.read(1024*1024)
                if not block:break
                dst.write(block)
    return target

def find_person_csv(data_dir:Path,year:int)->Path:
    cs=sorted(data_dir.glob(f'*{year}*.csv'))
    ps=[p for p in cs if 'person' in p.name.lower() or 'psam_p' in p.name.lower()]
    if ps:return ps[0]
    zs=[p for p in sorted(data_dir.glob(f'*{year}*.zip')) if '_p' in p.name.lower() or 'pca' in p.name.lower()]
    if not zs:raise FileNotFoundError(f'No cached person PUMS for {year}')
    return extract_csv(zs[0],data_dir,year,'person')

def uniform_sample_csv(path:Path,n:int,seed:int)->pd.DataFrame:
    rng=np.random.default_rng(seed);frames=[];keys=[]
    for chunk in pd.read_csv(path,dtype=str,chunksize=50000,low_memory=False):
        k=rng.random(len(chunk))
        if len(chunk)>n:
            idx=np.argpartition(k,n-1)[:n];chunk=chunk.iloc[idx].copy();k=k[idx]
        frames.append(chunk);keys.append(k)
        if sum(len(x) for x in frames)>3*n:
            f=pd.concat(frames,ignore_index=True);kk=np.concatenate(keys);idx=np.argpartition(kk,n-1)[:n]
            frames=[f.iloc[idx].copy()];keys=[kk[idx]]
    f=pd.concat(frames,ignore_index=True);kk=np.concatenate(keys)
    if len(f)>n:idx=np.argpartition(kk,n-1)[:n];f=f.iloc[idx]
    return f.reset_index(drop=True)

def load_matching_housing(path:Path,serials:set[str])->pd.DataFrame:
    frames=[]
    for chunk in pd.read_csv(path,dtype=str,chunksize=50000,low_memory=False):
        if 'SERIALNO' not in chunk.columns:raise RuntimeError('Housing PUMS has no SERIALNO')
        hit=chunk[chunk['SERIALNO'].isin(serials)]
        if len(hit):frames.append(hit)
    if not frames:raise RuntimeError('No housing rows matched sampled persons')
    return pd.concat(frames,ignore_index=True).drop_duplicates('SERIALNO')

def norm(s:pd.Series)->pd.Series:
    return s.astype('string').fillna('<NA>').str.strip().replace({'':'<NA>','nan':'<NA>','None':'<NA>'})

def allocation_flag(name:str)->bool:
    u=name.upper();return u.startswith('F') and u.endswith('P')

def select_vars(a:pd.DataFrame,b:pd.DataFrame,prefix:str,max_vars:int,max_card:int,max_missing:float):
    excluded=('PWGTP','WGTP','SERIALNO','SPORDER','ADJINC','ADJHSG');rows=[]
    for c in sorted(set(a.columns)&set(b.columns)):
        if c.upper().startswith(excluded) or allocation_flag(c):continue
        sa,sb=norm(a[c]),norm(b[c]);card=len(set(sa.unique())|set(sb.unique()));miss=max(float((sa=='<NA>').mean()),float((sb=='<NA>').mean()))
        ok=2<=card<=max_card and miss<=max_missing;score=math.log1p(card)-4*miss
        rows.append({'source':prefix,'variable':c,'prefixed_variable':f'{prefix}_{c}','cardinality':card,'missing':miss,'eligible':int(ok),'selection_score':score})
    chosen=sorted([r for r in rows if r['eligible']],key=lambda r:(-r['selection_score'],r['variable']))[:max_vars]
    selected=[r['variable'] for r in chosen];ss=set(selected)
    for r in rows:r['selected']=int(r['variable'] in ss)
    return selected,rows

def build_join(pa,pb,ha,hb,pvars,hvars):
    pa=pa[['SERIALNO']+pvars].copy().rename(columns={c:f'P_{c}' for c in pvars})
    pb=pb[['SERIALNO']+pvars].copy().rename(columns={c:f'P_{c}' for c in pvars})
    ha=ha[['SERIALNO']+hvars].copy().rename(columns={c:f'H_{c}' for c in hvars})
    hb=hb[['SERIALNO']+hvars].copy().rename(columns={c:f'H_{c}' for c in hvars})
    ja=pa.merge(ha,on='SERIALNO',how='inner',validate='many_to_one');jb=pb.merge(hb,on='SERIALNO',how='inner',validate='many_to_one')
    if len(ja)<.98*len(pa) or len(jb)<.98*len(pb):raise RuntimeError('Join lost too many person rows')
    vars_=[f'P_{c}' for c in pvars]+[f'H_{c}' for c in hvars]
    return ja[vars_],jb[vars_],vars_

def encode(a,b,vars_):
    A=np.empty((len(a),len(vars_)),dtype=np.int16);B=np.empty((len(b),len(vars_)),dtype=np.int16);cards=[]
    for j,c in enumerate(vars_):
        sa,sb=norm(a[c]),norm(b[c]);cats=sorted(set(sa.unique())|set(sb.unique()));mp={v:i for i,v in enumerate(cats)};cards.append(len(cats))
        A[:,j]=sa.map(mp).astype(np.int16).to_numpy();B[:,j]=sb.map(mp).astype(np.int16).to_numpy()
    return A,B,cards

def worst_cell(A,B,i,j,ci,cj):
    def joint(X):
        z=np.bincount(X[:,i].astype(np.int64)*cj+X[:,j].astype(np.int64),minlength=ci*cj).reshape(ci,cj).astype(float);return z/len(X)
    p0,p1=joint(A),joint(B);mask=p1>0;q=np.zeros_like(p1);q[mask]=np.maximum(np.maximum(p0[mask],1/len(A))/p1[mask],p1[mask]/np.maximum(p0[mask],1/len(A)))
    idx=np.unravel_index(int(np.argmax(q)),q.shape);return int(idx[0]),int(idx[1])

def connect(dsn):
    conn=psycopg.connect(dsn,autocommit=True)
    with conn.cursor() as cur:
        cur.execute('SET jit=off');cur.execute('SET max_parallel_workers_per_gather=0');cur.execute('SET statement_timeout=0');cur.execute('SET track_io_timing=on')
    return conn

def create_schema(conn,schema,d):
    cols=','.join(f'c{i} integer NOT NULL' for i in range(d))
    with conn.cursor() as cur:
        cur.execute(f'DROP SCHEMA IF EXISTS {qi(schema)} CASCADE');cur.execute(f'CREATE SCHEMA {qi(schema)}');cur.execute(f'CREATE TABLE {qi(schema)}.fact(id bigint PRIMARY KEY,{cols})');cur.execute(f'ALTER TABLE {qi(schema)}.fact SET (autovacuum_enabled=false,toast.autovacuum_enabled=false)')

def load_array(conn,schema,X):
    cols=['id']+[f'c{i}' for i in range(X.shape[1])]
    with conn.cursor() as cur:
        with cur.copy(sql.SQL('COPY {}.fact ({}) FROM STDIN').format(sql.Identifier(schema),sql.SQL(',').join(sql.Identifier(c) for c in cols))) as cp:
            for idx,row in enumerate(X):cp.write_row([idx]+[int(v) for v in row])

def create_stats(conn,schema,d):
    total=choose2(d)
    with conn.cursor() as cur:
        for n,(i,j) in enumerate(itertools.combinations(range(d),2),1):
            cur.execute(f'CREATE STATISTICS {qi(schema)}.{qi(f"evs_{i}_{j}")} (dependencies,mcv) ON c{i},c{j} FROM {qi(schema)}.fact')
            if n%2000==0 or n==total:print(f'[statistics] {n}/{total}',flush=True)

def analyze_all(conn,schema,target):
    with conn.cursor() as cur:
        cur.execute(f'SET default_statistics_target={target}');t=time.perf_counter();cur.execute(f'ANALYZE {qi(schema)}.fact');return time.perf_counter()-t

def analyze_group(conn,schema,group,target):
    cols=','.join(f'c{i}' for i in sorted(group))
    with conn.cursor() as cur:
        cur.execute(f'SET default_statistics_target={target}');t=time.perf_counter();cur.execute(f'ANALYZE {qi(schema)}.fact ({cols})');return time.perf_counter()-t

def replace_rows(conn,schema,X):
    with conn.cursor() as cur:cur.execute(f'TRUNCATE TABLE {qi(schema)}.fact')
    load_array(conn,schema,X)

def find_scan(plan):
    if plan.get('Relation Name')=='fact':return plan
    for child in plan.get('Plans',[]) or []:
        z=find_scan(child)
        if z is not None:return z
    return None

def explain_q(conn,schema,i,j,vi,vj):
    with conn.cursor() as cur:
        cur.execute(f'EXPLAIN (ANALYZE,TIMING OFF,FORMAT JSON) SELECT COUNT(*) FROM {qi(schema)}.fact WHERE c{i}=%s AND c{j}=%s',(vi,vj));root=cur.fetchone()[0][0]['Plan'];scan=find_scan(root)
        est=max(float(scan.get('Plan Rows',0)),1);act=max(float(scan.get('Actual Rows',0)),1);return max(est/act,act/est),est,act

def bounded_greedy(edges,B):
    deg={}
    for u,v in edges:deg[u]=deg.get(u,0)+1;deg[v]=deg.get(v,0)+1
    ordered=sorted(edges,key=lambda e:-(deg[e[0]]+deg[e[1]]));groups=[]
    for e in ordered:
        best=None;inc=None
        for k,g in enumerate(groups):
            merged=g|set(e)
            if len(merged)>B:continue
            delta=choose2(len(merged))-choose2(len(g))
            if inc is None or delta<inc:best,inc=k,delta
        if best is None:groups.append(set(e))
        else:groups[best].update(e)
    return groups

def covered(groups):
    out=set()
    for g in groups:out.update(itertools.combinations(sorted(g),2))
    return out

def plan_metrics(groups):return {'calls':len(groups),'object_ops':sum(choose2(len(g)) for g in groups),'unique_objects':len(covered(groups)),'max_group_columns':max((len(g) for g in groups),default=0)}

def run_width(conn,schema,A,B,cards,vars_,target,qthr,repeats,out):
    d=A.shape[1];M=choose2(d);print(f'\n[width] d={d} M={M}',flush=True)
    create_schema(conn,schema,d);load_array(conn,schema,A);create_stats(conn,schema,d);initial=analyze_all(conn,schema,target);replace_rows(conn,schema,B)
    wc=[]
    for n,(i,j) in enumerate(itertools.combinations(range(d),2),1):
        vi,vj=worst_cell(A,B,i,j,cards[i],cards[j]);wc.append((i,j,vi,vj))
        if n%2000==0 or n==M:print(f'[worst] {n}/{M}',flush=True)
    qrows=[]
    for n,(i,j,vi,vj) in enumerate(wc,1):
        q,est,act=explain_q(conn,schema,i,j,vi,vj);qrows.append({'d':d,'i':i,'j':j,'variable_i':vars_[i],'variable_j':vars_[j],'worst_i':vi,'worst_j':vj,'estimated_rows':est,'actual_rows':act,'stale_qerror':q})
        if n%2000==0 or n==M:print(f'[qerror] {n}/{M}',flush=True)
    write_csv(out/f'qerrors_d{d}.csv',qrows)
    edges={(int(r['i']),int(r['j'])) for r in qrows if float(r['stale_qerror'])>=qthr};active={v for e in edges for v in e}
    plans={'full':[set(range(d))]}
    if edges:plans.update({'one_closure':[set(active)],'B4':bounded_greedy(edges,4),'B6':bounded_greedy(edges,6),'B8':bounded_greedy(edges,8),'B12':bounded_greedy(edges,12),'per_edge':[set(e) for e in sorted(edges)]})
    trials=[]
    for name,groups in plans.items():
        if edges and not edges<=covered(groups):raise RuntimeError(f'{name} misses edges')
        reps=1 if name=='full' else repeats;met=plan_metrics(groups)
        for rep in range(1,reps+1):
            print(f'[timing] d={d} {name} {rep}/{reps} calls={met["calls"]} obj={met["object_ops"]}',flush=True)
            replace_rows(conn,schema,A);analyze_all(conn,schema,target);replace_rows(conn,schema,B);t=time.perf_counter()
            if name=='full':analyze_all(conn,schema,target)
            else:
                for g in groups:analyze_group(conn,schema,g,target)
            trials.append({'d':d,'M':M,'strategy':name,'repeat':rep,**met,'seconds':time.perf_counter()-t})
    write_csv(out/f'timing_trials_d{d}.csv',trials)
    sums=[]
    for name in plans:
        rs=[r for r in trials if r['strategy']==name];base=rs[0];sums.append({'strategy':name,'calls':base['calls'],'object_ops':base['object_ops'],'unique_objects':base['unique_objects'],'max_group_columns':base['max_group_columns'],'seconds_mean':statistics.mean(r['seconds'] for r in rs),'seconds_std':statistics.pstdev(r['seconds'] for r in rs)})
    full=next(r['seconds_mean'] for r in sums if r['strategy']=='full')
    for r in sums:r['speedup_vs_full']=full/r['seconds_mean']
    sums.sort(key=lambda r:r['seconds_mean']);best=sums[0];fresh=[]
    if edges:
        replace_rows(conn,schema,A);analyze_all(conn,schema,target);replace_rows(conn,schema,B)
        if best['strategy']=='full':analyze_all(conn,schema,target)
        else:
            for g in plans[best['strategy']]:analyze_group(conn,schema,g,target)
        lookup={(int(r['i']),int(r['j'])):r for r in qrows}
        for i,j in edges:
            r=lookup[(i,j)];q,_,_=explain_q(conn,schema,i,j,int(r['worst_i']),int(r['worst_j']));fresh.append(q)
    return {'d':d,'M':M,'person_columns':min(50,d),'housing_columns':max(0,d-50),'stale_edges_q10':len(edges),'support_density':len(edges)/M,'active_columns':len(active),'active_fraction':len(active)/d if d else 0,'initial_full_analyze_seconds':initial,'strategies':sums,'best_strategy':best,'fresh_qerror_geomean':statistics.geometric_mean(fresh) if fresh else 1,'repair_pass':max(fresh)<=2 if fresh else True}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--dsn',required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--person-cache',type=Path,required=True);ap.add_argument('--data-dir',type=Path,required=True);ap.add_argument('--rows',type=int,default=40000);ap.add_argument('--person-vars',type=int,default=50);ap.add_argument('--housing-vars',type=int,default=80);ap.add_argument('--max-cardinality',type=int,default=24);ap.add_argument('--statistics-target',type=int,default=500);ap.add_argument('--q-threshold',type=float,default=10);ap.add_argument('--repeats',type=int,default=2);ap.add_argument('--widths',default='50,75,100,125');ap.add_argument('--schema-prefix',default='evostats_ambient_width');args=ap.parse_args()
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=True);args.data_dir.mkdir(parents=True,exist_ok=True)
    p19=find_person_csv(args.person_cache,2019);p21=find_person_csv(args.person_cache,2021);hpaths={}
    for year in (2019,2021):
        zp=args.data_dir/f'acs_{year}_hca.zip';download_resumable(CENSUS_BASE.format(year=year),zp);hpaths[year]=extract_csv(zp,args.data_dir,year,'housing')
    pa=uniform_sample_csv(p19,args.rows,2019);pb=uniform_sample_csv(p21,args.rows,2021);ha=load_matching_housing(hpaths[2019],set(pa['SERIALNO'].astype(str)));hb=load_matching_housing(hpaths[2021],set(pb['SERIALNO'].astype(str)))
    pvars,pinv=select_vars(pa,pb,'P',args.person_vars,args.max_cardinality,.2);hvars,hinv=select_vars(ha,hb,'H',args.housing_vars,args.max_cardinality,.3);write_csv(out/'variable_inventory.csv',pinv+hinv)
    ja,jb,vars_=build_join(pa,pb,ha,hb,pvars,hvars);A,B,cards=encode(ja,jb,vars_);honest=A.shape[1];req=[int(x) for x in args.widths.split(',') if x.strip()];widths=sorted({w for w in req if 50<=w<=honest}|{honest})
    if honest<=53:raise RuntimeError(f'Joined table only reached d={honest}')
    print(f'[variables] person={len(pvars)} housing={len(hvars)} honest_max_d={honest} widths={widths}',flush=True)
    conn=connect(args.dsn);results=[]
    try:
        for w in widths:results.append(run_width(conn,f'{args.schema_prefix}_{w}',A[:,:w],B[:,:w],cards[:w],vars_[:w],args.statistics_target,args.q_threshold,args.repeats,out))
    finally:conn.close()
    rows=[]
    for r in results:
        best=r['best_strategy'];full=next(x['seconds_mean'] for x in r['strategies'] if x['strategy']=='full');rows.append({'d':r['d'],'M':r['M'],'person_columns':r['person_columns'],'housing_columns':r['housing_columns'],'stale_edges_q10':r['stale_edges_q10'],'support_density':r['support_density'],'active_columns':r['active_columns'],'active_fraction':r['active_fraction'],'best_strategy':best['strategy'],'best_seconds':best['seconds_mean'],'full_seconds':full,'speedup_vs_full':best['speedup_vs_full'],'best_calls':best['calls'],'best_object_ops':best['object_ops'],'fresh_qerror_geomean':r['fresh_qerror_geomean'],'repair_pass':r['repair_pass']})
    write_csv(out/'ambient_width_summary.csv',rows)
    logd=np.log([r['d'] for r in rows]);fb=float(np.polyfit(logd,np.log([r['full_seconds'] for r in rows]),1)[0]) if len(rows)>=2 else float('nan');bb=float(np.polyfit(logd,np.log([r['best_seconds'] for r in rows]),1)[0]) if len(rows)>=2 else float('nan')
    report={'honest_max_d':honest,'person_variables':len(pvars),'housing_variables':len(hvars),'width_results':rows,'full_time_width_exponent':fb,'best_time_width_exponent':bb,'speedup_increases_with_width':rows[-1]['speedup_vs_full']>rows[0]['speedup_vs_full'] if len(rows)>=2 else False,'largest_width_repair_pass':rows[-1]['repair_pass']};report['ambient_width_go']=report['speedup_increases_with_width'] and report['largest_width_repair_pass'] and rows[-1]['speedup_vs_full']>=8;report['decision']='GO: real denormalized ambient width amplifies planner benefit' if report['ambient_width_go'] else 'NO AMPLIFICATION: freeze at existing real result';(out/'gate_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    lines=['EVOSTATS PHASE 4G AMBIENT-WIDTH THEOREM REPORT','='*78,f'person variables: {len(pvars)}',f'housing variables: {len(hvars)}',f'honest maximum d: {honest}','','WIDTH RESULTS']
    for r in rows:lines.append(f"d={r['d']:3d} M={r['M']:5d} s={r['stale_edges_q10']:4d} h={r['active_columns']:3d} h/d={r['active_fraction']:.3f} best={r['best_strategy']:10s} time={r['best_seconds']:.2f}s full={r['full_seconds']:.2f}s speedup={r['speedup_vs_full']:.2f}x repair={r['repair_pass']}")
    lines+=['',f'full width exponent: {fb:.3f}',f'best width exponent: {bb:.3f}','','DECISION',json.dumps(report,indent=2)];text='\n'.join(lines);(out/'gate_report.txt').write_text(text,encoding='utf-8');print('\n'+text)
if __name__=='__main__':main()
