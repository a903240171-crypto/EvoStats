# EvoStats Artifact Packager

Copy these files into:

```text
D:\ICDE-SignedSketch\vldb 升级版\phase5_validation
```

Recommended command:

```powershell
powershell -ExecutionPolicy Bypass -File `
  "D:\ICDE-SignedSketch\vldb 升级版\phase5_validation\package_evostats_artifact.ps1" `
  -IncludeDerivedData
```

The derived d=109 encoded arrays make the final feedback experiment easier to
replay. Raw ACS PUMS data are never copied.

Output:

```text
D:\ICDE-SignedSketch\vldb 升级版\artifact_release\evostats_artifact\
D:\ICDE-SignedSketch\vldb 升级版\artifact_release\evostats_artifact.zip
```

The artifact contains:

```text
README.md
MANIFEST.json
checksums.sha256
CLAIMS_PROVENANCE.csv
PACKAGING_REPORT.txt
validate_artifact.py
reproduce_tables.py
code/
results/
tables/
environment/
paper/        # when local paper material already exists
```

Excluded:

```text
raw ACS inputs
caches
PostgreSQL storage
virtual environments
Git internals
credentials
temporary files
files larger than 250 MB
```

Validate locally:

```powershell
cd "D:\ICDE-SignedSketch\vldb 升级版\artifact_release\evostats_artifact"
C:\Users\90324\Desktop\acsac_project\agentdojo\.venv\Scripts\python.exe validate_artifact.py
C:\Users\90324\Desktop\acsac_project\agentdojo\.venv\Scripts\python.exe reproduce_tables.py
```

Inspect before upload:

```text
PACKAGING_REPORT.txt
CLAIMS_PROVENANCE.csv
environment\git_status.txt
```


## v4 canonical result mapping

```text
phase0_catalog_blindness            -> phase0_unified + pg_relabel_figure1
phase1_residual                     -> phase1_statistic
phase2_discovery                    -> phase2_v2_theory_aligned
phase3_pg_hub                       -> phase3_pg_end_to_end_v2
phase5b_qratio_audit_protocol_fixed -> phase5b_qratio_audit
```

The failed Phase 2 v1 and superseded Phase 3 v1 outputs are not packaged.
