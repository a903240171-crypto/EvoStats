#!/usr/bin/env python3
"""
Merge the original 40K/2M phi microbenchmark with the 200K/1M extension.

The purpose is narrow:
1. Test whether PostgreSQL's isolated batch-cost coefficients plateau once the
   relation exceeds the expected ANALYZE sample budget.
2. Quantify uncertainty with within-width bootstrap resampling.
3. Avoid claiming an exact proportional law from only two effective sample
   sizes.

The fitted model is:
    phi_n(B) = a_n + u_n B + c_n choose(B, 2)

PostgreSQL's standard scalar-statistics code uses approximately
300 * statistics_target sample rows, capped by the relation size.  This script
therefore reports:
    expected_sample_rows = min(n, 300 * target)

It does not use isolated phi values as absolute additive predictions for a
multi-call plan; repeated ANALYZE calls on one relation can be faster due to
cache warming.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import nnls


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def percentile(values: list[float], q: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=np.float64), q))


def fit_three_term(widths: list[int], medians: list[float]) -> dict[str, float]:
    X = np.asarray(
        [[1.0, float(b), float(choose2(b))] for b in widths],
        dtype=np.float64,
    )
    y = np.asarray(medians, dtype=np.float64)
    coef, _ = nnls(X, y)
    pred = X @ coef
    denom = float(np.sum((y - y.mean()) ** 2))
    r2 = (
        1.0 - float(np.sum((y - pred) ** 2)) / denom
        if denom > 0 else 1.0
    )
    a, u, c = [float(v) for v in coef]
    star_width = (
        1.0 + math.sqrt(max(0.0, 2.0 * (a + u) / c))
        if c > 0 else float("nan")
    )
    matching_width = (
        math.sqrt(max(0.0, 2.0 * a / c))
        if c > 0 else float("nan")
    )
    return {
        "a": a,
        "u": u,
        "c": c,
        "r2": r2,
        "star_width": star_width,
        "matching_width": matching_width,
    }


def bootstrap_coefficients(
    rows: list[dict[str, str]],
    rng: np.random.Generator,
    repeats: int,
) -> dict[str, list[float]]:
    by_width: dict[int, list[float]] = {}
    for row in rows:
        by_width.setdefault(int(row["width"]), []).append(float(row["seconds"]))

    widths = sorted(by_width)
    result = {
        "a": [], "u": [], "c": [],
        "r2": [], "star_width": [], "matching_width": [],
    }

    for _ in range(repeats):
        medians = []
        for width in widths:
            values = np.asarray(by_width[width], dtype=np.float64)
            sample = rng.choice(values, size=len(values), replace=True)
            medians.append(float(np.median(sample)))
        fit = fit_three_term(widths, medians)
        for key in result:
            result[key].append(float(fit[key]))
    return result


def summarize_bootstrap(values: list[float]) -> tuple[float, float, float]:
    return (
        statistics.median(values),
        percentile(values, 0.025),
        percentile(values, 0.975),
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline-dir", type=Path, required=True)
    ap.add_argument("--saturation-dir", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--bootstrap", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=20260718)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    sources = [
        args.baseline_dir / "phi_trials.csv",
        args.saturation_dir / "phi_trials.csv",
    ]
    all_rows: list[dict[str, str]] = []
    for source in sources:
        if not source.exists():
            raise FileNotFoundError(source)
        all_rows.extend(read_csv(source))

    by_n: dict[int, list[dict[str, str]]] = {}
    for row in all_rows:
        by_n.setdefault(int(row["rows"]), []).append(row)

    expected_n = [40_000, 200_000, 1_000_000, 2_000_000]
    missing = [n for n in expected_n if n not in by_n]
    if missing:
        raise RuntimeError(f"Missing row-count experiments: {missing}")

    cap = 300 * args.statistics_target
    rng = np.random.default_rng(args.seed)
    summaries: list[dict[str, Any]] = []
    bootstrap_by_n: dict[int, dict[str, list[float]]] = {}

    for n_rows in sorted(by_n):
        rows = by_n[n_rows]
        by_width: dict[int, list[float]] = {}
        for row in rows:
            by_width.setdefault(int(row["width"]), []).append(
                float(row["seconds"])
            )
        widths = sorted(by_width)
        medians = [statistics.median(by_width[b]) for b in widths]
        fit = fit_three_term(widths, medians)
        boot = bootstrap_coefficients(rows, rng, args.bootstrap)
        bootstrap_by_n[n_rows] = boot

        summary: dict[str, Any] = {
            "rows": n_rows,
            "expected_sample_rows": min(n_rows, cap),
            "sample_fraction": min(n_rows, cap) / n_rows,
            "width_count": len(widths),
            "trials": len(rows),
            "fit_r2": fit["r2"],
        }
        for key in ("a", "u", "c", "star_width", "matching_width"):
            median, low, high = summarize_bootstrap(boot[key])
            summary[f"{key}_median"] = median
            summary[f"{key}_ci_low"] = low
            summary[f"{key}_ci_high"] = high
        summaries.append(summary)

    write_csv(args.out / "phi_saturation_summary.csv", summaries)

    above_cap = [row for row in summaries if row["rows"] >= cap]
    c_above = [float(row["c_median"]) for row in above_cap]
    plateau_mean = statistics.mean(c_above)
    plateau_spread = (
        (max(c_above) - min(c_above)) / plateau_mean
        if plateau_mean > 0 else float("inf")
    )
    c_40 = next(float(row["c_median"]) for row in summaries if row["rows"] == 40_000)
    observed_ratio = plateau_mean / c_40
    expected_ratio = cap / 40_000

    if plateau_spread <= 0.20:
        plateau_label = "SUPPORTED"
    elif plateau_spread <= 0.35:
        plateau_label = "WEAKLY SUPPORTED"
    else:
        plateau_label = "NOT SUPPORTED"

    scale_ratio = observed_ratio / expected_ratio
    sample_budget_consistent = 0.60 <= scale_ratio <= 1.60

    report = {
        "statistics_target": args.statistics_target,
        "expected_sample_cap": cap,
        "rows": summaries,
        "above_cap_c_mean": plateau_mean,
        "above_cap_c_relative_spread": plateau_spread,
        "plateau_assessment": plateau_label,
        "observed_plateau_to_40k_c_ratio": observed_ratio,
        "expected_sample_ratio_150k_to_40k": expected_ratio,
        "observed_over_expected_ratio": scale_ratio,
        "sample_budget_scale_consistent": sample_budget_consistent,
        "interpretation": (
            "The isolated pair-object coefficient is consistent with a "
            "sample-budget plateau above 300*target."
            if plateau_label != "NOT SUPPORTED" and sample_budget_consistent
            else
            "The simple sample-budget explanation is incomplete; retain the "
            "empirical phi_n(B) table without a saturation claim."
        ),
        "plan_cost_caveat": (
            "Isolated phi_n(B) is used for ranking batch widths. It is not an "
            "absolute additive model for multi-call plans, whose repeated "
            "ANALYZE calls can benefit from relation-level cache warming."
        ),
    }
    (args.out / "saturation_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5A.2 - ANALYZE SAMPLE-CAP SATURATION",
        "=" * 78,
        f"statistics target          : {args.statistics_target}",
        f"expected sample cap        : {cap:,} rows",
        "",
        "COEFFICIENTS (bootstrap median and 95% CI)",
    ]
    for row in summaries:
        lines += [
            (
                f"n={row['rows']:,}; expected_sample="
                f"{row['expected_sample_rows']:,}"
            ),
            (
                f"  a={row['a_median']:.6f} "
                f"[{row['a_ci_low']:.6f}, {row['a_ci_high']:.6f}]"
            ),
            (
                f"  u={row['u_median']:.6f} "
                f"[{row['u_ci_low']:.6f}, {row['u_ci_high']:.6f}]"
            ),
            (
                f"  c={row['c_median']:.6f} "
                f"[{row['c_ci_low']:.6f}, {row['c_ci_high']:.6f}]"
            ),
            (
                f"  star_width={row['star_width_median']:.3f} "
                f"[{row['star_width_ci_low']:.3f}, "
                f"{row['star_width_ci_high']:.3f}]"
            ),
            "",
        ]

    lines += [
        "SATURATION AUDIT",
        f"above-cap c relative spread : {plateau_spread:.3f}",
        f"plateau assessment          : {plateau_label}",
        f"observed plateau/40K ratio  : {observed_ratio:.3f}",
        f"expected sample ratio       : {expected_ratio:.3f}",
        f"observed/expected           : {scale_ratio:.3f}",
        (
            "sample-budget consistency  : "
            f"{'YES' if sample_budget_consistent else 'NO'}"
        ),
        "",
        "INTERPRETATION",
        report["interpretation"],
        "",
        "PLAN-COST CAVEAT",
        report["plan_cost_caveat"],
    ]
    text = "\n".join(lines)
    (args.out / "saturation_report.txt").write_text(text, encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
