#!/usr/bin/env python3
"""
EvoStats Phase 5B.3 — Workload-Aligned Max-Ratio Audit (protocol-fixed)
======================================================

Why this experiment exists
--------------------------
The residual detector uses an L1 functional over the whole contingency table:

    D_ij = 1/4 ||R_ij^(1) - R_ij^(0)||_1.

The operational PostgreSQL label is instead driven by the worst queried cell,
i.e. a max-like multiplicative error.  No monotone mapping exists between
these functionals without a lower-mass assumption.

This audit replaces only the aggregation functional.  It computes, for every
pair, a worst-cell empirical multiplicative ratio

    Qhat_ij = max_ab max(p0_ab / p1_ab, p1_ab / p0_ab),

using a one-row floor for zero cells.  It then measures:

1. ranking quality against the existing real PostgreSQL Q>=10 edge labels;
2. natural-threshold performance at Qhat>=2,5,10,25;
3. verification-budget curves for top 1%,2%,5%,10%,20% of all pairs;
4. live PostgreSQL cost of exact candidate verification plus B4 refresh.

Interpretation discipline
-------------------------
Qhat is a workload-aligned proxy, not the PostgreSQL estimator itself.
PostgreSQL MCV truncation, dependency heuristics, clamping, and sampling can
still cause disagreement.  Exact PostgreSQL verification remains the second
stage in deployable results.

The existing Phase 4C workload chooses one worst empirical-ratio cell per pair.
This audit therefore evaluates the exact operational functional used to define
that workload.  Claims must remain scoped to pairwise equality predicates and
worst-cell operational staleness.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import itertools
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def rank_metrics(
    scores: np.ndarray,
    labels: np.ndarray,
) -> dict[str, float]:
    from sklearn.metrics import average_precision_score, roc_auc_score

    if labels.min() == labels.max():
        return {"auroc": float("nan"), "auprc": float("nan")}
    return {
        "auroc": float(roc_auc_score(labels, scores)),
        "auprc": float(average_precision_score(labels, scores)),
    }


def score_pair(
    X0: np.ndarray,
    X1: np.ndarray,
    i: int,
    j: int,
    ci: int,
    cj: int,
    min_support: int,
) -> dict[str, Any]:
    n0 = len(X0)
    n1 = len(X1)
    k = ci * cj

    c0 = np.bincount(
        X0[:, i].astype(np.int64) * cj
        + X0[:, j].astype(np.int64),
        minlength=k,
    ).astype(np.int64)
    c1 = np.bincount(
        X1[:, i].astype(np.int64) * cj
        + X1[:, j].astype(np.int64),
        minlength=k,
    ).astype(np.int64)

    # Exact Phase 4C workload functional:
    # prefer a non-empty current cell so the label does not depend on
    # actual-row clamping. Old zero cells use a one-row floor.
    p0 = np.maximum(c0 / n0, 1.0 / n0)
    p1 = c1 / n1
    raw_ratio = np.zeros_like(p1, dtype=np.float64)
    current_nonempty = c1 > 0
    raw_ratio[current_nonempty] = np.maximum(
        p0[current_nonempty] / p1[current_nonempty],
        p1[current_nonempty] / p0[current_nonempty],
    )
    raw_idx = int(np.argmax(raw_ratio))

    # Jeffreys smoothing sensitivity analysis.
    alpha = 0.5
    pj0 = (c0 + alpha) / (n0 + alpha * k)
    pj1 = (c1 + alpha) / (n1 + alpha * k)
    jeff_ratio = np.maximum(pj0 / pj1, pj1 / pj0)
    jeff_idx = int(np.argmax(jeff_ratio))

    # Minimum-support sensitivity analysis.  A cell is eligible if it has at
    # least min_support observations in either snapshot.
    supported = (
        (np.maximum(c0, c1) >= min_support)
        & current_nonempty
    )
    supported_ratio = np.where(supported, raw_ratio, 1.0)
    supported_idx = int(np.argmax(supported_ratio))

    raw_a, raw_b = divmod(raw_idx, cj)
    jeff_a, jeff_b = divmod(jeff_idx, cj)
    supp_a, supp_b = divmod(supported_idx, cj)

    return {
        "raw_qhat": float(raw_ratio[raw_idx]),
        "raw_i_value": int(raw_a),
        "raw_j_value": int(raw_b),
        "raw_count0": int(c0[raw_idx]),
        "raw_count1": int(c1[raw_idx]),
        "jeffreys_qhat": float(jeff_ratio[jeff_idx]),
        "jeffreys_i_value": int(jeff_a),
        "jeffreys_j_value": int(jeff_b),
        "supported_qhat": float(supported_ratio[supported_idx]),
        "supported_i_value": int(supp_a),
        "supported_j_value": int(supp_b),
        "supported_count0": int(c0[supported_idx]),
        "supported_count1": int(c1[supported_idx]),
    }


def bounded_greedy(
    edges: set[tuple[int, int]],
    max_vertices: int,
) -> list[set[int]]:
    degree: dict[int, int] = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1

    ordered = sorted(
        edges,
        key=lambda edge: -(degree[edge[0]] + degree[edge[1]]),
    )
    groups: list[set[int]] = []

    for edge in ordered:
        best_index = None
        best_increment = None
        for index, group in enumerate(groups):
            merged = group | set(edge)
            if len(merged) > max_vertices:
                continue
            increment = choose2(len(merged)) - choose2(len(group))
            if best_increment is None or increment < best_increment:
                best_index = index
                best_increment = increment
        if best_index is None:
            groups.append(set(edge))
        else:
            groups[best_index].update(edge)
    return groups


def explain_qerror(
    helper,
    conn,
    schema: str,
    i: int,
    j: int,
    value_i: int,
    value_j: int,
) -> float:
    result = helper.explain_pair(
        conn, schema, i, j, value_i, value_j
    )
    return float(result["q_error"])


def establish_stale(
    helper,
    conn,
    schema: str,
    A: np.ndarray,
    B: np.ndarray,
    target: int,
) -> None:
    # Reset reference data, then fully refresh all catalog statistics.
    # TRUNCATE is safe before the reference ANALYZE because ANALYZE rewrites
    # reltuples/relpages and all extended statistics.
    with conn.cursor() as cur:
        cur.execute(f'TRUNCATE TABLE "{schema}".fact')
    helper.load_array(conn, schema, A)
    helper.analyze_all(conn, schema, target)

    # Critical protocol detail: Phase 4C replaced the reference snapshot with
    # DELETE+COPY, not TRUNCATE+COPY. TRUNCATE resets relation metadata and
    # therefore changes PostgreSQL estimates even when extended statistics are
    # unchanged. Use the exact Phase 4C transition here.
    helper.replace_with_current(conn, schema, B)


def refresh_groups(
    helper,
    conn,
    schema: str,
    groups: list[set[int]],
    target: int,
) -> float:
    start = time.perf_counter()
    for group in groups:
        helper.analyze_columns(conn, schema, sorted(group), target)
    return time.perf_counter() - start


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--cache-dir", type=Path, required=True)
    ap.add_argument("--phase4c-dir", type=Path, required=True)
    ap.add_argument("--helper", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_qratio_audit")
    ap.add_argument("--rows", type=int, default=40_000)
    ap.add_argument("--max-vars", type=int, default=50)
    ap.add_argument("--max-cardinality", type=int, default=24)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--q-threshold", type=float, default=10.0)
    ap.add_argument("--batch-width", type=int, default=4)
    ap.add_argument("--min-support", type=int, default=10)
    ap.add_argument("--repeats", type=int, default=10)
    args = ap.parse_args()

    if args.repeats < 10:
        raise ValueError("Final audit requires at least 10 repetitions")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    helper = load_module(args.helper, "phase4c_helper")

    qframe = pd.read_csv(args.phase4c_dir / "real_pair_qerrors.csv")
    severe_edges = {
        (int(row.i), int(row.j))
        for row in qframe.itertuples(index=False)
        if float(row.stale_qerror) >= args.q_threshold
    }

    path_a = helper.find_cached_csv(args.cache_dir, 2019)
    path_b = helper.find_cached_csv(args.cache_dir, 2021)
    raw_a = helper.uniform_sample_csv(path_a, args.rows, 2019)
    raw_b = helper.uniform_sample_csv(path_b, args.rows, 2021)
    variables, _ = helper.select_variables(
        raw_a, raw_b, args.max_vars, args.max_cardinality
    )
    A, B, categories = helper.encode_frames(raw_a, raw_b, variables)
    cards = [len(values) for values in categories]

    d = len(variables)
    M = choose2(d)
    if len(qframe) != M:
        raise RuntimeError(f"Expected {M} Phase 4C rows, found {len(qframe)}")

    for row in qframe.itertuples(index=False):
        i, j = int(row.i), int(row.j)
        if variables[i] != row.variable_i or variables[j] != row.variable_j:
            raise RuntimeError(f"Variable mismatch at pair {(i, j)}")

    pairs = list(itertools.combinations(range(d), 2))

    # Warm-up and repeated online scoring time.
    _ = [
        score_pair(
            A, B, i, j, cards[i], cards[j], args.min_support
        )
        for i, j in pairs
    ]

    score_times: list[float] = []
    scored_rows: list[dict[str, Any]] = []
    for repeat in range(args.repeats):
        start = time.perf_counter()
        values = [
            score_pair(
                A, B, i, j, cards[i], cards[j], args.min_support
            )
            for i, j in pairs
        ]
        score_times.append(time.perf_counter() - start)
        if repeat == 0:
            lookup = {
                (int(row.i), int(row.j)): row
                for row in qframe.itertuples(index=False)
            }
            for (i, j), score in zip(pairs, values):
                truth = lookup[(i, j)]
                score.update({
                    "i": i,
                    "j": j,
                    "variable_i": variables[i],
                    "variable_j": variables[j],
                    "pg_stale_qerror": float(truth.stale_qerror),
                    "pg_severe": int(
                        float(truth.stale_qerror) >= args.q_threshold
                    ),
                    "phase4c_worst_i": int(truth.worst_i),
                    "phase4c_worst_j": int(truth.worst_j),
                    "raw_cell_matches_phase4c": int(
                        int(score["raw_i_value"]) == int(truth.worst_i)
                        and int(score["raw_j_value"]) == int(truth.worst_j)
                    ),
                })
                scored_rows.append(score)

    write_csv(out / "qratio_scores.csv", scored_rows)

    labels = np.asarray(
        [int(row["pg_severe"]) for row in scored_rows],
        dtype=np.int64,
    )

    variants = {
        "raw": "raw_qhat",
        "jeffreys": "jeffreys_qhat",
        "supported": "supported_qhat",
    }

    metric_rows: list[dict[str, Any]] = []
    for variant, column in variants.items():
        scores = np.asarray(
            [float(row[column]) for row in scored_rows],
            dtype=np.float64,
        )
        rank = rank_metrics(np.log10(np.maximum(scores, 1.0)), labels)
        metric_rows.append({
            "variant": variant,
            "auroc": rank["auroc"],
            "auprc": rank["auprc"],
            "base_rate": float(labels.mean()),
        })

    threshold_rows: list[dict[str, Any]] = []
    for variant, column in variants.items():
        scores = np.asarray(
            [float(row[column]) for row in scored_rows],
            dtype=np.float64,
        )
        for threshold in (2.0, 5.0, 10.0, 25.0):
            selected = scores >= threshold
            tp = int(np.sum(selected & (labels == 1)))
            fp = int(np.sum(selected & (labels == 0)))
            fn = int(np.sum((~selected) & (labels == 1)))
            threshold_rows.append({
                "variant": variant,
                "threshold": threshold,
                "selected": int(selected.sum()),
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "precision": tp / max(tp + fp, 1),
                "recall": tp / max(tp + fn, 1),
            })

    budget_rows: list[dict[str, Any]] = []
    budget_fracs = (0.01, 0.02, 0.05, 0.10, 0.20)
    for variant, column in variants.items():
        order = sorted(
            range(M),
            key=lambda idx: float(scored_rows[idx][column]),
            reverse=True,
        )
        for fraction in budget_fracs:
            count = max(1, int(math.ceil(fraction * M)))
            selected_idx = set(order[:count])
            tp = sum(
                int(scored_rows[idx]["pg_severe"])
                for idx in selected_idx
            )
            budget_rows.append({
                "variant": variant,
                "budget_fraction": fraction,
                "candidate_count": count,
                "severe_found": tp,
                "precision": tp / count,
                "recall": tp / len(severe_edges),
            })

    write_csv(out / "ranking_metrics.csv", metric_rows)
    write_csv(out / "threshold_summary.csv", threshold_rows)
    write_csv(out / "budget_summary.csv", budget_rows)

    # Live exact verification and refresh for raw-score budget prefixes.
    raw_order = sorted(
        range(M),
        key=lambda idx: float(scored_rows[idx]["raw_qhat"]),
        reverse=True,
    )
    max_budget = int(math.ceil(max(budget_fracs) * M))
    max_indices = raw_order[:max_budget]

    conn = helper.connect(args.dsn)
    live_rows: list[dict[str, Any]] = []
    verification_first: list[dict[str, Any]] = []
    try:
        helper.create_schema_and_table(conn, args.schema, d)
        helper.load_array(conn, args.schema, A)
        helper.create_all_statistics(conn, args.schema, d)

        # One-time protocol reconstruction gate. Before evaluating a detector,
        # verify that this script reproduces the exact Phase 4C PostgreSQL
        # ground truth. This catches state-transition mistakes such as using
        # TRUNCATE where the original experiment used DELETE.
        establish_stale(
            helper, conn, args.schema, A, B,
            args.statistics_target
        )
        reconstructed_rows = []
        reconstructed_severe: set[tuple[int, int]] = set()
        for row in scored_rows:
            q_error = explain_qerror(
                helper,
                conn,
                args.schema,
                int(row["i"]),
                int(row["j"]),
                int(row["phase4c_worst_i"]),
                int(row["phase4c_worst_j"]),
            )
            edge = (int(row["i"]), int(row["j"]))
            if q_error >= args.q_threshold:
                reconstructed_severe.add(edge)
            reconstructed_rows.append({
                "i": edge[0],
                "j": edge[1],
                "stored_pg_qerror": float(row["pg_stale_qerror"]),
                "reconstructed_pg_qerror": q_error,
                "stored_severe": int(edge in severe_edges),
                "reconstructed_severe": int(
                    q_error >= args.q_threshold
                ),
            })
        write_csv(
            out / "phase4c_reconstruction_audit.csv",
            reconstructed_rows,
        )
        missing_edges = sorted(severe_edges - reconstructed_severe)
        extra_edges = sorted(reconstructed_severe - severe_edges)
        if reconstructed_severe != severe_edges:
            raise RuntimeError(
                "Phase 4C stale-state reconstruction failed: "
                f"stored={len(severe_edges)}, "
                f"reconstructed={len(reconstructed_severe)}, "
                f"missing={missing_edges[:10]}, "
                f"extra={extra_edges[:10]}. "
                "Detector evaluation is invalid until the PostgreSQL "
                "ground-truth protocol is reproduced exactly."
            )

        for repeat in range(1, args.repeats + 1):
            # Verify the largest prefix once; smaller budgets reuse cumulative
            # prefix times from the same stale state.
            establish_stale(
                helper, conn, args.schema, A, B,
                args.statistics_target
            )

            qerrors: list[float] = []
            cumulative_seconds: list[float] = []
            start = time.perf_counter()
            for position, index in enumerate(max_indices, start=1):
                row = scored_rows[index]
                q_error = explain_qerror(
                    helper,
                    conn,
                    args.schema,
                    int(row["i"]),
                    int(row["j"]),
                    int(row["phase4c_worst_i"]),
                    int(row["phase4c_worst_j"]),
                )
                qerrors.append(q_error)
                cumulative_seconds.append(time.perf_counter() - start)
                if repeat == 1:
                    verification_first.append({
                        "rank": position,
                        "i": int(row["i"]),
                        "j": int(row["j"]),
                        "variable_i": row["variable_i"],
                        "variable_j": row["variable_j"],
                        "raw_qhat": float(row["raw_qhat"]),
                        "raw_count0": int(row["raw_count0"]),
                        "raw_count1": int(row["raw_count1"]),
                        "verified_pg_qerror": q_error,
                        "verified_severe": int(
                            q_error >= args.q_threshold
                        ),
                    })

            for fraction in budget_fracs:
                count = max(1, int(math.ceil(fraction * M)))
                prefix_q = qerrors[:count]
                verified_edges = {
                    (
                        int(scored_rows[max_indices[pos]]["i"]),
                        int(scored_rows[max_indices[pos]]["j"]),
                    )
                    for pos, q_error in enumerate(prefix_q)
                    if q_error >= args.q_threshold
                }
                groups = bounded_greedy(
                    verified_edges, args.batch_width
                )

                # Refresh on a clean stale state for this budget.
                establish_stale(
                    helper, conn, args.schema, A, B,
                    args.statistics_target
                )
                refresh_seconds = refresh_groups(
                    helper,
                    conn,
                    args.schema,
                    groups,
                    args.statistics_target,
                )

                true_edge_recall = (
                    len(verified_edges & severe_edges)
                    / len(severe_edges)
                )
                live_rows.append({
                    "repeat": repeat,
                    "budget_fraction": fraction,
                    "candidate_count": count,
                    "verified_severe_edges": len(verified_edges),
                    "true_severe_recall": true_edge_recall,
                    "verification_seconds": cumulative_seconds[count - 1],
                    "refresh_calls": len(groups),
                    "refresh_object_ops": sum(
                        choose2(len(group)) for group in groups
                    ),
                    "refresh_seconds": refresh_seconds,
                    "score_seconds": score_times[repeat - 1],
                    "end_to_end_seconds": (
                        score_times[repeat - 1]
                        + cumulative_seconds[count - 1]
                        + refresh_seconds
                    ),
                })
    finally:
        conn.close()

    write_csv(out / "live_budget_trials.csv", live_rows)
    write_csv(
        out / "candidate_verification_first_repeat.csv",
        verification_first,
    )

    live_summary: list[dict[str, Any]] = []
    for fraction in budget_fracs:
        rows = [
            row for row in live_rows
            if float(row["budget_fraction"]) == fraction
        ]
        def med(key: str) -> float:
            return statistics.median(float(row[key]) for row in rows)
        def iqr(key: str) -> float:
            values = [float(row[key]) for row in rows]
            return float(np.quantile(values, 0.75)
                         - np.quantile(values, 0.25))

        live_summary.append({
            "budget_fraction": fraction,
            "candidate_count": int(rows[0]["candidate_count"]),
            "verified_severe_edges_median":
                med("verified_severe_edges"),
            "true_severe_recall_median":
                med("true_severe_recall"),
            "verification_seconds_median":
                med("verification_seconds"),
            "verification_seconds_iqr":
                iqr("verification_seconds"),
            "refresh_calls_median":
                med("refresh_calls"),
            "refresh_object_ops_median":
                med("refresh_object_ops"),
            "refresh_seconds_median":
                med("refresh_seconds"),
            "refresh_seconds_iqr":
                iqr("refresh_seconds"),
            "end_to_end_seconds_median":
                med("end_to_end_seconds"),
            "end_to_end_seconds_iqr":
                iqr("end_to_end_seconds"),
        })
    write_csv(out / "live_budget_summary.csv", live_summary)

    score_median = statistics.median(score_times)
    score_iqr = float(
        np.quantile(score_times, 0.75)
        - np.quantile(score_times, 0.25)
    )
    raw_match_rate = statistics.mean(
        int(row["raw_cell_matches_phase4c"])
        for row in scored_rows
    )

    report = {
        "d": d,
        "M": M,
        "severe_edges": len(severe_edges),
        "score_seconds_median": score_median,
        "score_seconds_iqr": score_iqr,
        "raw_cell_match_rate_with_phase4c": raw_match_rate,
        "phase4c_reconstructed_severe_edges": len(reconstructed_severe),
        "phase4c_reconstruction_exact": reconstructed_severe == severe_edges,
        "ranking_metrics": metric_rows,
        "threshold_results": threshold_rows,
        "offline_budget_results": budget_rows,
        "live_budget_results": live_summary,
        "scope": (
            "Pairwise equality predicates under the Phase 4C worst-cell "
            "operational workload."
        ),
        "warning": (
            "The max over many cells has an extreme-value bias and is "
            "sensitive to rare cells. Jeffreys and minimum-support variants "
            "are reported as sensitivity analyses; exact PostgreSQL "
            "verification remains mandatory."
        ),
    }
    (out / "gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5B.3 - WORKLOAD-ALIGNED MAX-RATIO AUDIT",
        "=" * 78,
        f"d / M                     : {d} / {M}",
        f"real PG Q>=10 edges       : {len(severe_edges)}",
        (
            f"all-pair score time       : {score_median:.3f}s "
            f"IQR={score_iqr:.3f}s"
        ),
        (
            f"raw-cell match Phase 4C   : {raw_match_rate:.3f}"
        ),
        (
            "Phase 4C support rebuilt  : "
            f"{len(reconstructed_severe)}/{len(severe_edges)} exact"
        ),
        "",
        "RANKING QUALITY",
    ]
    for row in metric_rows:
        lines.append(
            f"  {row['variant']:10s} "
            f"AUROC={row['auroc']:.3f} "
            f"AUPRC={row['auprc']:.3f} "
            f"base={row['base_rate']:.3f}"
        )

    lines += ["", "NATURAL THRESHOLDS"]
    for row in threshold_rows:
        if float(row["threshold"]) in (5.0, 10.0):
            lines.append(
                f"  {row['variant']:10s} Qhat>={row['threshold']:4.0f} "
                f"selected={row['selected']:4d} "
                f"P={row['precision']:.3f} "
                f"R={row['recall']:.3f}"
            )

    lines += ["", "LIVE RAW-RATIO SCREEN + EXACT PG VERIFY + B4 REFRESH"]
    for row in live_summary:
        lines.append(
            f"  budget={100*row['budget_fraction']:4.0f}% "
            f"candidates={row['candidate_count']:3d} "
            f"recall={row['true_severe_recall_median']:.3f} "
            f"verify={row['verification_seconds_median']:.3f}s "
            f"refresh={row['refresh_seconds_median']:.3f}s "
            f"end2end={row['end_to_end_seconds_median']:.3f}s"
        )

    lines += [
        "",
        "MANDATORY INTERPRETATION",
        (
            "This score is aligned with the worst-cell operational "
            "functional; it is not a generic guarantee for arbitrary query "
            "workloads."
        ),
        (
            "Do not report raw Qhat as PostgreSQL Q-error. Report it as a "
            "screening score followed by exact PG verification."
        ),
    ]
    text = "\n".join(lines)
    (out / "gate_report.txt").write_text(text, encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
