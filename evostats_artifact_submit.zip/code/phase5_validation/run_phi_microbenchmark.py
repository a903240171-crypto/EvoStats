#!/usr/bin/env python3
"""
EvoStats Phase 5A — Independent PostgreSQL Batch-Cost Microbenchmark
====================================================================

Measures the cost function phi_n(B) of one PostgreSQL

    ANALYZE fact (c_1, ..., c_B)

call independently of any refresh plan.  The experiment randomizes batch order,
uses at least ten repetitions per width, reports median/IQR, and fits only
non-negative cost models:

    M1: phi(B) = a + c * choose(B, 2)
    M2: phi(B) = a + u * B + c * choose(B, 2)

The fitted model is a diagnostic.  The system can always use the empirical
lookup table phi_hat(B) rather than assuming either parametric form.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import nnls


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def percentile(values: list[float], q: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=np.float64), q))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location("phase4c", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import helper: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def create_replication_base(conn, mod, schema: str, base: np.ndarray) -> None:
    """Load the 40K real sample once, then preserve it in PostgreSQL."""
    with conn.cursor() as cur:
        cur.execute(f'TRUNCATE TABLE "{schema}".fact')
    mod.load_array(conn, schema, base)
    with conn.cursor() as cur:
        cur.execute(f'DROP TABLE IF EXISTS "{schema}".base')
        cur.execute(
            f'CREATE TABLE "{schema}".base '
            f'(LIKE "{schema}".fact INCLUDING DEFAULTS INCLUDING CONSTRAINTS)'
        )
        cur.execute(
            f'INSERT INTO "{schema}".base SELECT * FROM "{schema}".fact'
        )
        cur.execute(
            f'ALTER TABLE "{schema}".base SET '
            f'(autovacuum_enabled=false, toast.autovacuum_enabled=false)'
        )


def materialize_replicated(
    conn,
    schema: str,
    base_rows: int,
    n_rows: int,
    d: int,
) -> float:
    """Replicate the exact real sample inside PostgreSQL."""
    if n_rows % base_rows != 0:
        raise ValueError(
            f"n_rows={n_rows} must be an integer multiple of base rows={base_rows}"
        )
    copies = n_rows // base_rows
    columns = ",".join(f"c{i}" for i in range(d))
    query = (
        f'INSERT INTO "{schema}".fact(id,{columns}) '
        f'SELECT (g.copy_id::bigint * %s + b.id)::bigint, {columns} '
        f'FROM "{schema}".base b '
        f'CROSS JOIN generate_series(0,%s-1) AS g(copy_id)'
    )
    with conn.cursor() as cur:
        cur.execute(f'TRUNCATE TABLE "{schema}".fact')
        start = time.perf_counter()
        cur.execute(query, (base_rows, copies))
        return time.perf_counter() - start


def fit_model(widths: list[int], medians: list[float], with_linear: bool) -> dict[str, Any]:
    if with_linear:
        X = np.asarray(
            [[1.0, float(b), float(choose2(b))] for b in widths],
            dtype=np.float64,
        )
        names = ["a_seconds", "u_seconds_per_column", "c_seconds_per_pair_object"]
    else:
        X = np.asarray(
            [[1.0, float(choose2(b))] for b in widths],
            dtype=np.float64,
        )
        names = ["a_seconds", "c_seconds_per_pair_object"]

    y = np.asarray(medians, dtype=np.float64)
    coef, residual_norm = nnls(X, y)
    pred = X @ coef
    residuals = y - pred
    denom = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - float(np.sum(residuals ** 2)) / denom if denom > 0 else 1.0

    loo_rel_errors = []
    loo_rows = []
    for held in range(len(widths)):
        keep = [idx for idx in range(len(widths)) if idx != held]
        coef_held, _ = nnls(X[keep], y[keep])
        p = float(X[held] @ coef_held)
        rel = abs(p - y[held]) / max(y[held], 1e-9)
        loo_rel_errors.append(rel)
        loo_rows.append({
            "held_width": widths[held],
            "actual_median_seconds": float(y[held]),
            "predicted_seconds": p,
            "absolute_relative_error": rel,
        })

    result = {
        "model": "a+uB+cC2" if with_linear else "a+cC2",
        **{name: float(value) for name, value in zip(names, coef)},
        "residual_norm": float(residual_norm),
        "r_squared": r2,
        "leave_one_width_out_median_relative_error": float(
            statistics.median(loo_rel_errors)
        ),
        "leave_one_width_out_max_relative_error": float(max(loo_rel_errors)),
        "predictions": [
            {
                "width": int(b),
                "actual_median_seconds": float(actual),
                "predicted_seconds": float(p),
                "residual_seconds": float(actual - p),
            }
            for b, actual, p in zip(widths, medians, pred)
        ],
        "leave_one_width_out": loo_rows,
    }

    a = result["a_seconds"]
    c = result["c_seconds_per_pair_object"]
    u = result.get("u_seconds_per_column", 0.0)
    if c > 0:
        matching_width = math.sqrt(max(0.0, 2.0 * a / c))
        star_width = 1.0 + math.sqrt(max(0.0, 2.0 * (a + u) / c))
        result["matching_optimal_width_continuous"] = matching_width
        result["star_optimal_width_continuous"] = star_width
        result["matching_optimal_width_rounded"] = max(2, int(round(matching_width)))
        result["star_optimal_width_rounded"] = max(2, int(round(star_width)))
    else:
        result["matching_optimal_width_continuous"] = None
        result["star_optimal_width_continuous"] = None
        result["matching_optimal_width_rounded"] = None
        result["star_optimal_width_rounded"] = None
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--cache-dir", type=Path, required=True)
    ap.add_argument("--helper", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_phi_microbench")
    ap.add_argument("--base-rows", type=int, default=40_000)
    ap.add_argument("--n-values", default="40000,2000000")
    ap.add_argument("--widths", default="1,2,3,4,6,8,12,16,24,32,40,50")
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--warmups", type=int, default=1)
    ap.add_argument("--max-vars", type=int, default=50)
    ap.add_argument("--max-cardinality", type=int, default=24)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--seed", type=int, default=20260718)
    args = ap.parse_args()

    if args.repeats < 10:
        raise ValueError("Use at least 10 repetitions for the final audit")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    mod = load_module(args.helper)

    path_a = mod.find_cached_csv(args.cache_dir, 2019)
    path_b = mod.find_cached_csv(args.cache_dir, 2021)
    raw_a = mod.uniform_sample_csv(path_a, args.base_rows, 2019)
    raw_b = mod.uniform_sample_csv(path_b, args.base_rows, 2021)
    variables, inventory = mod.select_variables(
        raw_a, raw_b, args.max_vars, args.max_cardinality
    )
    _, B, categories = mod.encode_frames(raw_a, raw_b, variables)
    d = len(variables)

    widths = sorted({
        int(value) for value in args.widths.split(",")
        if value.strip() and 1 <= int(value) <= d
    })
    n_values = [int(value) for value in args.n_values.split(",") if value.strip()]
    for n_rows in n_values:
        if n_rows % args.base_rows != 0:
            raise ValueError(
                f"{n_rows} is not a multiple of base_rows={args.base_rows}"
            )

    variable_rows = []
    inv_by_name = {str(row["variable"]): row for row in inventory}
    for idx, name in enumerate(variables):
        variable_rows.append({
            "column_index": idx,
            "variable": name,
            "cardinality": len(categories[idx]),
            "selection_score": inv_by_name.get(name, {}).get("selection_score", ""),
        })
    write_csv(out / "selected_variables.csv", variable_rows)

    conn = mod.connect(args.dsn)
    raw_trials: list[dict[str, Any]] = []
    try:
        mod.create_schema_and_table(conn, args.schema, d)
        create_replication_base(conn, mod, args.schema, B)
        materialize_replicated(
            conn, args.schema, args.base_rows, args.base_rows, d
        )
        mod.create_all_statistics(conn, args.schema, d)

        for n_rows in n_values:
            print(f"\n[phi] materializing n={n_rows:,}", flush=True)
            load_seconds = materialize_replicated(
                conn, args.schema, args.base_rows, n_rows, d
            )
            full_warmup = mod.analyze_all(
                conn, args.schema, args.statistics_target
            )
            rng = np.random.default_rng(args.seed + n_rows)

            for width in widths:
                for warmup in range(args.warmups):
                    group = sorted(
                        int(v) for v in rng.choice(d, size=width, replace=False)
                    )
                    mod.analyze_columns(
                        conn, args.schema, group, args.statistics_target
                    )

            schedule = [
                (width, rep)
                for width in widths
                for rep in range(1, args.repeats + 1)
            ]
            rng.shuffle(schedule)

            for order_index, (width, rep) in enumerate(schedule, start=1):
                group = sorted(
                    int(v) for v in rng.choice(d, size=width, replace=False)
                )
                print(
                    f"[phi] n={n_rows:,} {order_index}/{len(schedule)} "
                    f"B={width} rep={rep}",
                    flush=True,
                )
                elapsed = mod.analyze_columns(
                    conn, args.schema, group, args.statistics_target
                )
                cards = [len(categories[idx]) for idx in group]
                raw_trials.append({
                    "rows": n_rows,
                    "width": width,
                    "repeat": rep,
                    "randomized_order": order_index,
                    "seconds": elapsed,
                    "pair_objects": choose2(width),
                    "sum_cardinality": sum(cards),
                    "mean_cardinality": statistics.mean(cards),
                    "max_cardinality": max(cards),
                    "columns": json.dumps(group),
                    "column_names": json.dumps([variables[idx] for idx in group]),
                    "materialize_seconds": load_seconds,
                    "full_warmup_seconds": full_warmup,
                })
    finally:
        conn.close()

    write_csv(out / "phi_trials.csv", raw_trials)

    summary_rows: list[dict[str, Any]] = []
    model_reports: dict[str, Any] = {}
    for n_rows in n_values:
        medians = []
        local_widths = []
        for width in widths:
            values = [
                float(row["seconds"])
                for row in raw_trials
                if row["rows"] == n_rows and row["width"] == width
            ]
            median = statistics.median(values)
            local_widths.append(width)
            medians.append(median)
            summary_rows.append({
                "rows": n_rows,
                "width": width,
                "pair_objects": choose2(width),
                "n_trials": len(values),
                "seconds_median": median,
                "seconds_q25": percentile(values, 0.25),
                "seconds_q75": percentile(values, 0.75),
                "seconds_iqr": percentile(values, 0.75) - percentile(values, 0.25),
                "seconds_min": min(values),
                "seconds_max": max(values),
            })

        model1 = fit_model(local_widths, medians, with_linear=False)
        model2 = fit_model(local_widths, medians, with_linear=True)
        selected = min(
            [model1, model2],
            key=lambda model: model[
                "leave_one_width_out_median_relative_error"
            ],
        )
        model_reports[str(n_rows)] = {
            "model_a_plus_cC2": model1,
            "model_a_plus_uB_plus_cC2": model2,
            "selected_model": selected["model"],
            "selected": selected,
        }

    write_csv(out / "phi_summary.csv", summary_rows)
    (out / "model_summary.json").write_text(
        json.dumps(model_reports, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5A — INDEPENDENT BATCH-COST MICROBENCHMARK",
        "=" * 78,
        f"d={d}; widths={widths}; repetitions={args.repeats}",
        "",
    ]
    for n_rows in n_values:
        report = model_reports[str(n_rows)]
        selected = report["selected"]
        lines += [
            f"ROWS={n_rows:,}",
            f"selected model: {report['selected_model']}",
            f"LOO median relative error: "
            f"{selected['leave_one_width_out_median_relative_error']:.3f}",
            f"a={selected['a_seconds']:.6f}s",
            f"u={selected.get('u_seconds_per_column', 0.0):.6f}s/column",
            f"c={selected['c_seconds_per_pair_object']:.6f}s/object",
            f"star predicted width: "
            f"{selected['star_optimal_width_continuous']}",
            f"matching predicted width: "
            f"{selected['matching_optimal_width_continuous']}",
            "",
        ]
        for row in summary_rows:
            if row["rows"] == n_rows:
                lines.append(
                    f"  B={row['width']:2d} C2={row['pair_objects']:4d} "
                    f"median={row['seconds_median']:.4f}s "
                    f"IQR={row['seconds_iqr']:.4f}s"
                )
        lines.append("")

    report_text = "\n".join(lines)
    (out / "gate_report.txt").write_text(report_text, encoding="utf-8")
    print("\n" + report_text)


if __name__ == "__main__":
    main()
