#!/usr/bin/env python3
"""
EvoStats Phase 5B — Proactive vs Exact Query-Feedback Baseline
===============================================================

This is an idealized reactive upper bound, not a claim to reproduce LEO/COA.
The baseline receives exact estimate-versus-actual feedback after each query.
It is therefore at least as informative as a practical query-feedback signal.

The workload replays the real pair templates measured in Phase 4C.  For each
strategy, the script records how many harmful queries occur before the stale
statistics are exposed and repaired.

Workload simulation is repeated across at least ten random seeds.  PostgreSQL
refresh actions are then replayed live for the primary workload so that the
maintenance times are real, while the feedback trace comes from the exact
Phase-4C EXPLAIN ANALYZE measurements.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import itertools
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def quantile(values: list[float], q: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=np.float64), q))


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location("phase4c", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import helper: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def bounded_greedy(
    edges: set[tuple[int, int]], max_vertices: int
) -> list[set[int]]:
    if not edges:
        return []
    degree: dict[int, int] = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1

    ordered = sorted(
        edges,
        key=lambda edge: -(degree[edge[0]] + degree[edge[1]]),
    )
    groups: list[set[int]] = []
    for edge in ordered:
        best_index = None
        best_increment = None
        for index, group in enumerate(groups):
            merged = group | set(edge)
            if len(merged) > max_vertices:
                continue
            increment = choose2(len(merged)) - choose2(len(group))
            if best_increment is None or increment < best_increment:
                best_index = index
                best_increment = increment
        if best_index is None:
            groups.append(set(edge))
        else:
            groups[best_index].update(edge)
    return groups


def closure(groups: list[set[int]]) -> set[tuple[int, int]]:
    result: set[tuple[int, int]] = set()
    for group in groups:
        result.update(itertools.combinations(sorted(group), 2))
    return result


def plan_metrics(groups: list[set[int]]) -> dict[str, int]:
    return {
        "calls": len(groups),
        "object_ops": sum(choose2(len(group)) for group in groups),
        "unique_objects": len(closure(groups)),
        "column_ops": sum(len(group) for group in groups),
    }


def read_calibrated_width(model_path: Path | None, rows: int) -> int | None:
    if model_path is None or not model_path.exists():
        return None
    payload = json.loads(model_path.read_text(encoding="utf-8"))
    key = str(rows)
    if key not in payload:
        keys = sorted(payload, key=lambda value: abs(int(value) - rows))
        if not keys:
            return None
        key = keys[0]
    selected = payload[key]["selected"]
    widths = [
        selected.get("star_optimal_width_rounded"),
        selected.get("matching_optimal_width_rounded"),
    ]
    widths = [int(value) for value in widths if value is not None]
    if not widths:
        return None
    return max(2, int(round(statistics.median(widths))))


def workload_indices(
    frame: pd.DataFrame,
    length: int,
    kind: str,
    seed: int,
    zipf_alpha: float,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = len(frame)
    if kind == "uniform":
        probabilities = np.full(n, 1.0 / n)
    elif kind == "zipf":
        order = rng.permutation(n)
        rank_weights = 1.0 / np.power(
            np.arange(1, n + 1, dtype=np.float64), zipf_alpha
        )
        probabilities = np.empty(n, dtype=np.float64)
        probabilities[order] = rank_weights
        probabilities /= probabilities.sum()
    elif kind == "probability":
        values = frame["new_prob"].astype(float).to_numpy()
        floor = 1.0 / max(1, int(frame["stale_actual_rows"].max()))
        probabilities = np.maximum(values, floor)
        probabilities /= probabilities.sum()
    else:
        raise ValueError(f"Unknown workload kind: {kind}")
    return rng.choice(n, size=length, replace=True, p=probabilities)


def simulate_strategy(
    templates: pd.DataFrame,
    workload: np.ndarray,
    severe_edges: set[tuple[int, int]],
    strategy: str,
    batch_width: int,
    window: int,
    threshold: float,
    d: int,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    repaired: set[tuple[int, int]] = set()
    discovered: set[tuple[int, int]] = set()
    pending: set[tuple[int, int]] = set()
    events: list[dict[str, Any]] = []

    if strategy == "full_pre":
        groups = [set(range(d))]
        repaired |= closure(groups)
        events.append({"query_index": 0, "groups": groups, "full": True})
    elif strategy == "proactive":
        groups = bounded_greedy(severe_edges, batch_width)
        repaired |= closure(groups)
        events.append({"query_index": 0, "groups": groups, "full": False})

    harmed_queries = 0
    severe_query_count = 0
    excess_log_risk = 0.0
    first_harm = None
    protection_checkpoints: dict[int, float] = {}
    checkpoints = {
        max(1, int(len(workload) * frac)): frac
        for frac in (0.10, 0.25, 0.50, 1.00)
    }

    def flush(query_index: int) -> None:
        nonlocal repaired, pending
        unresolved = {
            edge for edge in pending if edge not in repaired
        }
        if not unresolved:
            pending.clear()
            return
        if strategy == "reactive_immediate":
            groups = [set(edge) for edge in sorted(unresolved)]
        else:
            groups = bounded_greedy(unresolved, batch_width)
        repaired |= closure(groups)
        events.append({
            "query_index": query_index,
            "groups": groups,
            "full": False,
        })
        pending.clear()

    for query_index, template_index in enumerate(workload, start=1):
        row = templates.iloc[int(template_index)]
        edge = (int(row["i"]), int(row["j"]))
        qerror = 1.0 if edge in repaired else float(row["stale_qerror"])
        if edge in severe_edges:
            severe_query_count += 1
        if qerror >= threshold:
            harmed_queries += 1
            excess_log_risk += max(0.0, math.log10(qerror / threshold))
            if first_harm is None:
                first_harm = query_index
            discovered.add(edge)
            pending.add(edge)
            if strategy == "reactive_immediate":
                flush(query_index)

        if strategy.startswith("reactive_window") and query_index % window == 0:
            flush(query_index)

        if query_index in checkpoints:
            protected = len(severe_edges & repaired) / max(len(severe_edges), 1)
            protection_checkpoints[query_index] = protected

    if strategy.startswith("reactive_window"):
        flush(len(workload))

    metrics = {
        "strategy": strategy,
        "batch_width": batch_width if strategy not in {"never", "full_pre"} else 0,
        "window": window if strategy.startswith("reactive_window") else 0,
        "workload_length": len(workload),
        "harmed_queries": harmed_queries,
        "harm_rate": harmed_queries / len(workload),
        "severe_query_count": severe_query_count,
        "excess_log10_risk": excess_log_risk,
        "first_harm_query": first_harm if first_harm is not None else 0,
        "discovered_severe_edges": len(discovered & severe_edges),
        "discovered_severe_fraction": len(discovered & severe_edges) / max(len(severe_edges), 1),
        "repaired_severe_edges": len(repaired & severe_edges),
        "repaired_severe_fraction": len(repaired & severe_edges) / max(len(severe_edges), 1),
        "event_count": len(events),
        "analyze_calls": sum(len(event["groups"]) for event in events),
        "object_ops": sum(
            choose2(len(group))
            for event in events
            for group in event["groups"]
        ),
        "unique_refreshed_objects": len(
            set().union(*(closure(event["groups"]) for event in events))
            if events else set()
        ),
    }
    for query_index, frac in checkpoints.items():
        metrics[f"protected_at_{int(frac * 100)}pct_queries"] = (
            protection_checkpoints.get(query_index, 0.0)
        )
    return metrics, events


def establish_stale(conn, mod, schema: str, A: np.ndarray, B: np.ndarray, target: int) -> None:
    with conn.cursor() as cur:
        cur.execute(f'TRUNCATE TABLE "{schema}".fact')
    mod.load_array(conn, schema, A)
    mod.analyze_all(conn, schema, target)
    with conn.cursor() as cur:
        cur.execute(f'TRUNCATE TABLE "{schema}".fact')
    mod.load_array(conn, schema, B)


def replay_events(
    conn,
    mod,
    schema: str,
    events: list[dict[str, Any]],
    target: int,
) -> tuple[float, int, int]:
    start = time.perf_counter()
    calls = 0
    objects = 0
    for event in events:
        if event["full"]:
            mod.analyze_all(conn, schema, target)
            calls += 1
            # object count is filled by caller for full plan.
        else:
            for group in event["groups"]:
                mod.analyze_columns(conn, schema, sorted(group), target)
                calls += 1
                objects += choose2(len(group))
    return time.perf_counter() - start, calls, objects


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--cache-dir", type=Path, required=True)
    ap.add_argument("--phase4c-dir", type=Path, required=True)
    ap.add_argument("--helper", type=Path, required=True)
    ap.add_argument("--microbenchmark-json", type=Path, default=None)
    ap.add_argument("--schema", default="evostats_query_feedback")
    ap.add_argument("--rows", type=int, default=40_000)
    ap.add_argument("--max-vars", type=int, default=50)
    ap.add_argument("--max-cardinality", type=int, default=24)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--q-threshold", type=float, default=10.0)
    ap.add_argument("--workload-length", type=int, default=5000)
    ap.add_argument("--workloads", default="uniform,zipf,probability")
    ap.add_argument("--primary-workload", default="zipf")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--zipf-alpha", type=float, default=1.1)
    ap.add_argument("--windows", default="50,200")
    ap.add_argument("--fallback-batch-width", type=int, default=4)
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--verify-first-seed", action="store_true")
    args = ap.parse_args()

    if args.seeds < 10:
        raise ValueError("Use at least 10 seeds for the final baseline")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    mod = load_module(args.helper)

    templates = pd.read_csv(args.phase4c_dir / "real_pair_qerrors.csv")
    required = {"i", "j", "variable_i", "variable_j", "stale_qerror", "new_prob"}
    missing = required - set(templates.columns)
    if missing:
        raise RuntimeError(f"real_pair_qerrors.csv missing columns: {sorted(missing)}")
    severe = templates[templates["stale_qerror"] >= args.q_threshold]
    severe_edges = {
        (int(row.i), int(row.j)) for row in severe.itertuples(index=False)
    }
    if not severe_edges:
        raise RuntimeError("No severe stale edges found")

    path_a = mod.find_cached_csv(args.cache_dir, 2019)
    path_b = mod.find_cached_csv(args.cache_dir, 2021)
    raw_a = mod.uniform_sample_csv(path_a, args.rows, 2019)
    raw_b = mod.uniform_sample_csv(path_b, args.rows, 2021)
    variables, _ = mod.select_variables(
        raw_a, raw_b, args.max_vars, args.max_cardinality
    )
    A, B, _ = mod.encode_frames(raw_a, raw_b, variables)
    d = len(variables)
    M = choose2(d)

    for row in templates.itertuples(index=False):
        i, j = int(row.i), int(row.j)
        if variables[i] != row.variable_i or variables[j] != row.variable_j:
            raise RuntimeError(f"Variable-order mismatch at {(i, j)}")

    calibrated = read_calibrated_width(args.microbenchmark_json, args.rows)
    batch_width = calibrated or args.fallback_batch_width
    batch_width = min(max(2, batch_width), d)
    windows = [int(value) for value in args.windows.split(",") if value.strip()]
    workloads = [value.strip() for value in args.workloads.split(",") if value.strip()]

    strategy_specs = [
        ("never", 0),
        ("full_pre", 0),
        ("proactive", 0),
        ("reactive_immediate", 0),
    ] + [(f"reactive_window_{window}", window) for window in windows]

    simulation_rows: list[dict[str, Any]] = []
    event_store: dict[tuple[str, int, str], list[dict[str, Any]]] = {}
    for workload_kind in workloads:
        for seed_index in range(args.seeds):
            seed = 10_000 * (seed_index + 1) + sum(ord(c) for c in workload_kind)
            workload = workload_indices(
                templates,
                args.workload_length,
                workload_kind,
                seed,
                args.zipf_alpha,
            )
            if seed_index == 0:
                trace_rows = []
                for query_index, template_index in enumerate(workload, start=1):
                    row = templates.iloc[int(template_index)]
                    trace_rows.append({
                        "query_index": query_index,
                        "template_index": int(template_index),
                        "i": int(row["i"]),
                        "j": int(row["j"]),
                        "variable_i": row["variable_i"],
                        "variable_j": row["variable_j"],
                        "stale_qerror": float(row["stale_qerror"]),
                        "severe": int(float(row["stale_qerror"]) >= args.q_threshold),
                    })
                write_csv(out / f"workload_{workload_kind}_seed0.csv", trace_rows)

            for strategy, window in strategy_specs:
                metrics, events = simulate_strategy(
                    templates=templates,
                    workload=workload,
                    severe_edges=severe_edges,
                    strategy=strategy,
                    batch_width=batch_width,
                    window=window,
                    threshold=args.q_threshold,
                    d=d,
                )
                metrics.update({
                    "workload": workload_kind,
                    "seed_index": seed_index,
                    "seed": seed,
                    "d": d,
                    "M": M,
                    "severe_edges": len(severe_edges),
                    "calibrated_batch_width": batch_width,
                })
                simulation_rows.append(metrics)
                event_store[(workload_kind, seed_index, strategy)] = events

    write_csv(out / "feedback_simulation_trials.csv", simulation_rows)

    summary_rows: list[dict[str, Any]] = []
    metric_names = [
        "harmed_queries",
        "harm_rate",
        "excess_log10_risk",
        "discovered_severe_fraction",
        "repaired_severe_fraction",
        "analyze_calls",
        "object_ops",
        "unique_refreshed_objects",
        "protected_at_10pct_queries",
        "protected_at_25pct_queries",
        "protected_at_50pct_queries",
        "protected_at_100pct_queries",
    ]
    for workload_kind in workloads:
        for strategy, _ in strategy_specs:
            rows = [
                row for row in simulation_rows
                if row["workload"] == workload_kind and row["strategy"] == strategy
            ]
            record: dict[str, Any] = {
                "workload": workload_kind,
                "strategy": strategy,
                "n_seeds": len(rows),
                "batch_width": batch_width,
            }
            for metric in metric_names:
                values = [float(row[metric]) for row in rows]
                record[f"{metric}_median"] = statistics.median(values)
                record[f"{metric}_q25"] = quantile(values, 0.25)
                record[f"{metric}_q75"] = quantile(values, 0.75)
                record[f"{metric}_iqr"] = quantile(values, 0.75) - quantile(values, 0.25)
            summary_rows.append(record)
    write_csv(out / "feedback_simulation_summary.csv", summary_rows)

    live_rows: list[dict[str, Any]] = []
    if args.live:
        if args.primary_workload not in workloads:
            raise ValueError("primary workload must be included in --workloads")
        conn = mod.connect(args.dsn)
        try:
            mod.create_schema_and_table(conn, args.schema, d)
            mod.load_array(conn, args.schema, A)
            mod.create_all_statistics(conn, args.schema, d)

            live_strategies = [
                "full_pre",
                "proactive",
                "reactive_immediate",
            ] + [f"reactive_window_{window}" for window in windows]

            template_lookup = {
                (int(row.i), int(row.j)): row
                for row in templates.itertuples(index=False)
            }

            for seed_index in range(args.seeds):
                for strategy in live_strategies:
                    events = event_store[(args.primary_workload, seed_index, strategy)]
                    print(
                        f"[feedback-live] seed={seed_index + 1}/{args.seeds} "
                        f"strategy={strategy} events={len(events)}",
                        flush=True,
                    )
                    establish_stale(
                        conn, mod, args.schema, A, B, args.statistics_target
                    )
                    elapsed, calls, objects = replay_events(
                        conn, mod, args.schema, events, args.statistics_target
                    )
                    if strategy == "full_pre":
                        objects = M

                    verification_fraction = None
                    verification_qmax = None
                    if args.verify_first_seed and seed_index == 0:
                        repaired = set().union(
                            *(closure(event["groups"]) for event in events)
                        ) if events else set()
                        target_edges = sorted(severe_edges & repaired)
                        qvalues = []
                        for edge in target_edges:
                            row = template_lookup[edge]
                            result = mod.explain_pair(
                                conn,
                                args.schema,
                                int(row.i),
                                int(row.j),
                                int(row.worst_i),
                                int(row.worst_j),
                            )
                            qvalues.append(float(result["q_error"]))
                        if qvalues:
                            verification_fraction = sum(q <= 2.0 for q in qvalues) / len(qvalues)
                            verification_qmax = max(qvalues)

                    live_rows.append({
                        "workload": args.primary_workload,
                        "seed_index": seed_index,
                        "strategy": strategy,
                        "batch_width": batch_width,
                        "refresh_seconds": elapsed,
                        "analyze_calls": calls,
                        "object_ops": objects,
                        "verification_repaired_fraction": verification_fraction,
                        "verification_qerror_max": verification_qmax,
                    })
        finally:
            conn.close()

        write_csv(out / "feedback_live_trials.csv", live_rows)

        live_summary = []
        for strategy in sorted({row["strategy"] for row in live_rows}):
            rows = [row for row in live_rows if row["strategy"] == strategy]
            values = [float(row["refresh_seconds"]) for row in rows]
            live_summary.append({
                "workload": args.primary_workload,
                "strategy": strategy,
                "n_seeds": len(rows),
                "refresh_seconds_median": statistics.median(values),
                "refresh_seconds_q25": quantile(values, 0.25),
                "refresh_seconds_q75": quantile(values, 0.75),
                "refresh_seconds_iqr": quantile(values, 0.75) - quantile(values, 0.25),
                "analyze_calls_median": statistics.median(
                    [float(row["analyze_calls"]) for row in rows]
                ),
                "object_ops_median": statistics.median(
                    [float(row["object_ops"]) for row in rows]
                ),
            })
        write_csv(out / "feedback_live_summary.csv", live_summary)

    report = {
        "d": d,
        "M": M,
        "q_threshold": args.q_threshold,
        "severe_edges": len(severe_edges),
        "workload_length": args.workload_length,
        "workloads": workloads,
        "seeds": args.seeds,
        "calibrated_batch_width": batch_width,
        "calibrated_width_source": (
            str(args.microbenchmark_json)
            if calibrated is not None else "fallback"
        ),
        "baseline_interpretation": (
            "Idealized exact query-feedback upper bound: exact Q-error is revealed "
            "after each query; the first harmful query cannot be prevented reactively."
        ),
        "simulation_summary": summary_rows,
        "live_refresh_trials_run": bool(args.live),
    }
    (out / "gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5B — PROACTIVE VS EXACT QUERY FEEDBACK",
        "=" * 78,
        f"d={d}; M={M}; severe Q>={args.q_threshold:g} edges={len(severe_edges)}",
        f"workload length={args.workload_length}; seeds={args.seeds}",
        f"calibrated batch width={batch_width}",
        "",
        "The reactive baseline receives exact est-vs-act feedback after each query.",
        "It is an idealized upper bound, not a literal LEO/COA reimplementation.",
        "",
    ]
    for workload_kind in workloads:
        lines.append(f"WORKLOAD={workload_kind}")
        for row in summary_rows:
            if row["workload"] != workload_kind:
                continue
            lines.append(
                f"  {row['strategy']:22s} "
                f"harm={row['harmed_queries_median']:.1f} "
                f"[{row['harmed_queries_q25']:.1f},{row['harmed_queries_q75']:.1f}] "
                f"protected@50%={row['protected_at_50pct_queries_median']:.3f} "
                f"protected@end={row['protected_at_100pct_queries_median']:.3f} "
                f"calls={row['analyze_calls_median']:.1f} "
                f"objects={row['object_ops_median']:.1f}"
            )
        lines.append("")

    if live_rows:
        lines.append("LIVE POSTGRESQL REFRESH TIMES")
        for strategy in sorted({row["strategy"] for row in live_rows}):
            values = [
                float(row["refresh_seconds"])
                for row in live_rows if row["strategy"] == strategy
            ]
            lines.append(
                f"  {strategy:22s} median={statistics.median(values):.3f}s "
                f"IQR={quantile(values, 0.75)-quantile(values, 0.25):.3f}s"
            )

    text = "\n".join(lines)
    (out / "gate_report.txt").write_text(text, encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
