#!/usr/bin/env python3
"""
EvoStats Phase 5D — Minimum-Support Operational Robustness
==========================================================

This is the last upstream robustness audit before the final unified system run.

The current operational label chooses, for each pair, the current-nonempty
cell with the largest empirical multiplicative shift.  A reviewer can ask
whether the resulting Q>=10 support is driven only by one-row or very rare
cells.  This script therefore recomputes the entire operational workload at
minimum current-cell supports:

    m in {1, 5, 10, 20, 50, 100} rows.

For every m and every pair:
  1. choose the largest-ratio cell among cells with current count >= m;
  2. execute that exact equality query against stale PostgreSQL statistics;
  3. record real PostgreSQL Q-error;
  4. evaluate max-ratio ranking, AUPRC, verification-budget recall, and graph
     geometry.

The m=1 protocol must exactly reconstruct the existing Phase 4C 48-edge
Q>=10 support.  The script aborts if it does not.

This experiment does not time refresh plans.  Its sole purpose is to choose
an honest operational support floor before the final unified end-to-end run.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import itertools
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                fields.append(key)
                seen.add(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import helper module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=np.float64), q))


def explicit_matching(edges: set[tuple[int, int]]) -> set[tuple[int, int]]:
    degree: dict[int, int] = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1
    used: set[int] = set()
    result: set[tuple[int, int]] = set()
    for edge in sorted(
        edges,
        key=lambda item: (
            degree[item[0]] + degree[item[1]],
            max(degree[item[0]], degree[item[1]]),
            item,
        ),
    ):
        u, v = edge
        if u not in used and v not in used:
            used.add(u)
            used.add(v)
            result.add(edge)
    return result


def components(edges: set[tuple[int, int]]) -> list[set[int]]:
    adjacency: dict[int, set[int]] = {}
    for u, v in edges:
        adjacency.setdefault(u, set()).add(v)
        adjacency.setdefault(v, set()).add(u)
    seen: set[int] = set()
    result: list[set[int]] = []
    for start in sorted(adjacency):
        if start in seen:
            continue
        stack = [start]
        component: set[int] = set()
        while stack:
            vertex = stack.pop()
            if vertex in seen:
                continue
            seen.add(vertex)
            component.add(vertex)
            stack.extend(adjacency.get(vertex, set()) - seen)
        result.append(component)
    return result


def graph_geometry(
    d: int,
    edges: set[tuple[int, int]],
) -> dict[str, Any]:
    active = {vertex for edge in edges for vertex in edge}
    degree = {vertex: 0 for vertex in active}
    for u, v in edges:
        degree[u] += 1
        degree[v] += 1
    comps = components(edges)
    return {
        "stale_edges": len(edges),
        "support_density": len(edges) / choose2(d),
        "active_vertices": len(active),
        "active_fraction": len(active) / d,
        "max_degree": max(degree.values(), default=0),
        "top1_edge_fraction": (
            max(degree.values()) / len(edges) if edges else 0.0
        ),
        "certified_matching_size": len(explicit_matching(edges)),
        "components": len(comps),
        "largest_component_vertices": max(
            (len(component) for component in comps),
            default=0,
        ),
    }


def pair_counts(
    A: np.ndarray,
    B: np.ndarray,
    i: int,
    j: int,
    ci: int,
    cj: int,
) -> tuple[np.ndarray, np.ndarray]:
    c0 = np.bincount(
        A[:, i].astype(np.int64) * cj
        + A[:, j].astype(np.int64),
        minlength=ci * cj,
    ).reshape(ci, cj).astype(np.int64)
    c1 = np.bincount(
        B[:, i].astype(np.int64) * cj
        + B[:, j].astype(np.int64),
        minlength=ci * cj,
    ).reshape(ci, cj).astype(np.int64)
    return c0, c1


def support_aligned_cell(
    c0: np.ndarray,
    c1: np.ndarray,
    n0: int,
    n1: int,
    min_current_support: int,
) -> dict[str, Any]:
    eligible = c1 >= min_current_support
    if not bool(np.any(eligible)):
        return {
            "eligible": 0,
            "qhat": 1.0,
            "value_i": -1,
            "value_j": -1,
            "old_count": 0,
            "current_count": 0,
            "old_prob": 0.0,
            "current_prob": 0.0,
        }

    p0 = np.maximum(c0 / n0, 1.0 / n0)
    p1 = c1 / n1
    ratio = np.ones_like(p1, dtype=np.float64)
    ratio[eligible] = np.maximum(
        p0[eligible] / p1[eligible],
        p1[eligible] / p0[eligible],
    )
    flat_index = int(np.argmax(ratio))
    value_i, value_j = np.unravel_index(flat_index, ratio.shape)
    return {
        "eligible": 1,
        "qhat": float(ratio[value_i, value_j]),
        "value_i": int(value_i),
        "value_j": int(value_j),
        "old_count": int(c0[value_i, value_j]),
        "current_count": int(c1[value_i, value_j]),
        "old_prob": float(c0[value_i, value_j] / n0),
        "current_prob": float(c1[value_i, value_j] / n1),
    }


def establish_stale(
    helper,
    conn,
    schema: str,
    A: np.ndarray,
    B: np.ndarray,
    target: int,
) -> None:
    with conn.cursor() as cursor:
        cursor.execute(f'TRUNCATE TABLE "{schema}".fact')
    helper.load_array(conn, schema, A)
    helper.analyze_all(conn, schema, target)
    helper.replace_with_current(conn, schema, B)


def rank_metrics(
    scores: np.ndarray,
    labels: np.ndarray,
) -> dict[str, float]:
    if len(labels) == 0 or labels.min() == labels.max():
        return {"auroc": float("nan"), "auprc": float("nan")}
    log_scores = np.log10(np.maximum(scores, 1.0))
    return {
        "auroc": float(roc_auc_score(labels, log_scores)),
        "auprc": float(average_precision_score(labels, log_scores)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--phase4c-dir", type=Path, required=True)
    parser.add_argument("--helper", type=Path, required=True)
    parser.add_argument("--schema", default="evostats_phase5d_support")
    parser.add_argument("--rows", type=int, default=40_000)
    parser.add_argument("--max-vars", type=int, default=50)
    parser.add_argument("--max-cardinality", type=int, default=24)
    parser.add_argument("--statistics-target", type=int, default=500)
    parser.add_argument("--q-threshold", type=float, default=10.0)
    parser.add_argument(
        "--support-thresholds",
        default="1,5,10,20,50,100",
    )
    parser.add_argument(
        "--budget-fractions",
        default="0.01,0.02,0.05,0.10,0.20",
    )
    parser.add_argument("--score-repeats", type=int, default=10)
    args = parser.parse_args()

    support_thresholds = sorted({
        int(value.strip())
        for value in args.support_thresholds.split(",")
        if value.strip()
    })
    budget_fractions = sorted({
        float(value.strip())
        for value in args.budget_fractions.split(",")
        if value.strip()
    })
    if 1 not in support_thresholds:
        raise ValueError("Support threshold 1 is required as the reconstruction gate")
    if args.score_repeats < 10:
        raise ValueError("Use at least 10 score repetitions")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    helper = load_module(args.helper, "phase4c_helper")

    phase4c = pd.read_csv(args.phase4c_dir / "real_pair_qerrors.csv")
    stored_severe_m1 = {
        (int(row.i), int(row.j))
        for row in phase4c.itertuples(index=False)
        if float(row.stale_qerror) >= args.q_threshold
    }

    path_a = helper.find_cached_csv(args.cache_dir, 2019)
    path_b = helper.find_cached_csv(args.cache_dir, 2021)
    raw_a = helper.uniform_sample_csv(path_a, args.rows, 2019)
    raw_b = helper.uniform_sample_csv(path_b, args.rows, 2021)
    variables, _ = helper.select_variables(
        raw_a,
        raw_b,
        args.max_vars,
        args.max_cardinality,
    )
    A, B, categories = helper.encode_frames(raw_a, raw_b, variables)
    cards = [len(values) for values in categories]
    d = len(variables)
    M = choose2(d)

    if len(phase4c) != M:
        raise RuntimeError(f"Expected {M} Phase 4C rows, found {len(phase4c)}")
    for row in phase4c.itertuples(index=False):
        i, j = int(row.i), int(row.j)
        if variables[i] != row.variable_i or variables[j] != row.variable_j:
            raise RuntimeError(f"Variable order mismatch at pair {(i, j)}")

    pairs = list(itertools.combinations(range(d), 2))
    count_cache: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]] = {}
    for index, (i, j) in enumerate(pairs, start=1):
        count_cache[(i, j)] = pair_counts(
            A, B, i, j, cards[i], cards[j]
        )
        if index % 250 == 0 or index == M:
            print(f"[counts] {index}/{M}", flush=True)

    # Repeated all-pair screening time for every support floor.
    score_times: dict[int, list[float]] = {
        support: [] for support in support_thresholds
    }
    screens: dict[int, list[dict[str, Any]]] = {}

    for repeat in range(1, args.score_repeats + 1):
        for support in support_thresholds:
            start = time.perf_counter()
            rows: list[dict[str, Any]] = []
            for i, j in pairs:
                c0, c1 = count_cache[(i, j)]
                cell = support_aligned_cell(
                    c0, c1, len(A), len(B), support
                )
                rows.append({
                    "min_current_support": support,
                    "i": i,
                    "j": j,
                    "variable_i": variables[i],
                    "variable_j": variables[j],
                    **cell,
                })
            score_times[support].append(time.perf_counter() - start)
            if repeat == 1:
                screens[support] = rows
        print(
            f"[screen] repeat={repeat}/{args.score_repeats}",
            flush=True,
        )

    all_screen_rows = [
        row
        for support in support_thresholds
        for row in screens[support]
    ]
    write_csv(out / "support_aligned_screens.csv", all_screen_rows)

    # Reconstruct one exact stale PostgreSQL state and execute every unique
    # support-aligned query template. The state is unchanged across queries.
    conn = helper.connect(args.dsn)
    query_cache: dict[tuple[int, int, int, int], dict[str, Any]] = {}
    try:
        helper.create_schema_and_table(conn, args.schema, d)
        helper.load_array(conn, args.schema, A)
        helper.create_all_statistics(conn, args.schema, d)
        establish_stale(
            helper,
            conn,
            args.schema,
            A,
            B,
            args.statistics_target,
        )

        unique_templates = sorted({
            (
                int(row["i"]),
                int(row["j"]),
                int(row["value_i"]),
                int(row["value_j"]),
            )
            for row in all_screen_rows
            if int(row["eligible"]) == 1
        })
        print(
            f"[pg] unique support-aligned templates={len(unique_templates)}",
            flush=True,
        )
        for index, template in enumerate(unique_templates, start=1):
            i, j, value_i, value_j = template
            start = time.perf_counter()
            result = helper.explain_pair(
                conn,
                args.schema,
                i,
                j,
                value_i,
                value_j,
            )
            query_cache[template] = {
                **result,
                "query_seconds": time.perf_counter() - start,
            }
            if index % 500 == 0 or index == len(unique_templates):
                print(
                    f"[pg-query] {index}/{len(unique_templates)}",
                    flush=True,
                )
    finally:
        conn.close()

    detailed_rows: list[dict[str, Any]] = []
    summary_rows: list[dict[str, Any]] = []
    budget_rows: list[dict[str, Any]] = []
    severe_sets: dict[int, set[tuple[int, int]]] = {}

    for support in support_thresholds:
        rows = screens[support]
        labels: list[int] = []
        scores: list[float] = []
        severe_edges: set[tuple[int, int]] = set()
        eligible_count = 0

        for row in rows:
            edge = (int(row["i"]), int(row["j"]))
            if int(row["eligible"]) == 1:
                eligible_count += 1
                template = (
                    edge[0],
                    edge[1],
                    int(row["value_i"]),
                    int(row["value_j"]),
                )
                pg = query_cache[template]
                qerror = float(pg["q_error"])
                estimated = float(pg["estimated_rows"])
                actual = float(pg["actual_rows"])
                query_seconds = float(pg["query_seconds"])
            else:
                qerror = 1.0
                estimated = 0.0
                actual = 0.0
                query_seconds = 0.0

            severe = int(qerror >= args.q_threshold)
            if severe:
                severe_edges.add(edge)
            labels.append(severe)
            scores.append(float(row["qhat"]))
            detailed_rows.append({
                **row,
                "pg_estimated_rows": estimated,
                "pg_actual_rows": actual,
                "pg_qerror": qerror,
                "pg_severe": severe,
                "pg_query_seconds": query_seconds,
            })

        severe_sets[support] = severe_edges
        score_array = np.asarray(scores, dtype=np.float64)
        label_array = np.asarray(labels, dtype=np.int64)
        metrics = rank_metrics(score_array, label_array)
        geometry = graph_geometry(d, severe_edges)

        order = sorted(
            range(M),
            key=lambda index: scores[index],
            reverse=True,
        )
        minimum_full_recall_budget = float("nan")
        if severe_edges:
            for count in range(1, M + 1):
                found = sum(labels[index] for index in order[:count])
                if found == len(severe_edges):
                    minimum_full_recall_budget = count / M
                    break

        current_counts = [
            int(row["current_count"])
            for row, label in zip(rows, labels)
            if label == 1
        ]
        query_seconds = [
            float(query_cache[
                (
                    int(row["i"]),
                    int(row["j"]),
                    int(row["value_i"]),
                    int(row["value_j"]),
                )
            ]["query_seconds"])
            for row in rows
            if int(row["eligible"]) == 1
        ]

        overlap_m1 = (
            len(severe_edges & stored_severe_m1)
            / max(len(severe_edges), 1)
        )
        retained_from_m1 = (
            len(severe_edges & stored_severe_m1)
            / max(len(stored_severe_m1), 1)
        )

        summary_rows.append({
            "min_current_support": support,
            "candidate_pairs": M,
            "eligible_pairs": eligible_count,
            "severe_edges_q10": len(severe_edges),
            "base_rate": len(severe_edges) / M,
            "auroc": metrics["auroc"],
            "auprc": metrics["auprc"],
            "score_seconds_median": statistics.median(
                score_times[support]
            ),
            "score_seconds_iqr": (
                qtile(score_times[support], 0.75)
                - qtile(score_times[support], 0.25)
            ),
            "query_seconds_median": (
                statistics.median(query_seconds)
                if query_seconds else float("nan")
            ),
            "minimum_budget_for_full_recall":
                minimum_full_recall_budget,
            "severe_current_count_min":
                min(current_counts) if current_counts else "",
            "severe_current_count_median":
                statistics.median(current_counts)
                if current_counts else "",
            "severe_current_count_q25":
                qtile(current_counts, 0.25)
                if current_counts else "",
            "severe_current_count_q75":
                qtile(current_counts, 0.75)
                if current_counts else "",
            "overlap_precision_vs_m1": overlap_m1,
            "m1_severe_retained": retained_from_m1,
            **geometry,
        })

        for fraction in budget_fractions:
            count = max(1, int(math.ceil(fraction * M)))
            selected = order[:count]
            found = sum(labels[index] for index in selected)
            budget_rows.append({
                "min_current_support": support,
                "budget_fraction": fraction,
                "candidate_count": count,
                "severe_edges": len(severe_edges),
                "severe_found": found,
                "precision": found / count,
                "recall": (
                    found / len(severe_edges)
                    if severe_edges else 1.0
                ),
            })

    write_csv(out / "support_sensitivity_pairs.csv", detailed_rows)
    write_csv(out / "support_sensitivity_summary.csv", summary_rows)
    write_csv(out / "support_budget_curves.csv", budget_rows)

    # Exact reconstruction gate for the original m=1 workload.
    reconstructed_m1 = severe_sets[1]
    if reconstructed_m1 != stored_severe_m1:
        missing = sorted(stored_severe_m1 - reconstructed_m1)
        extra = sorted(reconstructed_m1 - stored_severe_m1)
        raise RuntimeError(
            "m=1 failed to reconstruct Phase 4C severe support: "
            f"stored={len(stored_severe_m1)}, "
            f"reconstructed={len(reconstructed_m1)}, "
            f"missing={missing[:10]}, extra={extra[:10]}"
        )

    # A conservative paper-floor suggestion. It is advisory only:
    # choose the largest support floor that retains at least half the original
    # severe support and achieves full recall within a 20% verification budget.
    viable = []
    budget_lookup = {
        (
            int(row["min_current_support"]),
            float(row["budget_fraction"]),
        ): row
        for row in budget_rows
    }
    for row in summary_rows:
        support = int(row["min_current_support"])
        top20 = budget_lookup[(support, 0.20)]
        if (
            int(row["severe_edges_q10"])
            >= max(10, len(stored_severe_m1) // 2)
            and float(top20["recall"]) >= 0.999
        ):
            viable.append(support)
    suggested_floor = max(viable) if viable else 1

    report = {
        "d": d,
        "M": M,
        "q_threshold": args.q_threshold,
        "support_thresholds": support_thresholds,
        "phase4c_m1_reconstruction_exact": True,
        "stored_m1_severe_edges": len(stored_severe_m1),
        "summary": summary_rows,
        "suggested_floor_advisory": suggested_floor,
        "selection_rule": (
            "Largest tested current-count floor retaining at least half of "
            "the original severe support (and at least 10 edges) with full "
            "recall at a 20% verification budget."
        ),
        "mandatory_interpretation": [
            "A support floor changes the audit workload and therefore changes "
            "the operational stale graph; it is not post-hoc filtering of the "
            "original 48 edges.",
            "Use AUPRC and budget recall as the primary screen metrics.",
            "Do not choose the paper floor automatically if the resulting "
            "queries are not operationally meaningful.",
        ],
    }
    (out / "gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5D - MINIMUM-SUPPORT OPERATIONAL ROBUSTNESS",
        "=" * 78,
        f"d / M                         : {d} / {M}",
        f"Phase 4C m=1 severe support  : {len(stored_severe_m1)}",
        "m=1 reconstruction            : PASS",
        "",
        "SUPPORT SENSITIVITY",
    ]
    for row in summary_rows:
        top20 = budget_lookup[(
            int(row["min_current_support"]), 0.20
        )]
        lines.append(
            f"  min_actual={int(row['min_current_support']):3d} "
            f"severe={int(row['severe_edges_q10']):3d} "
            f"AUPRC={float(row['auprc']):.3f} "
            f"AUROC={float(row['auroc']):.3f} "
            f"top20_R={float(top20['recall']):.3f} "
            f"full_R_budget="
            f"{float(row['minimum_budget_for_full_recall']):.3f} "
            f"active={int(row['active_vertices']):2d} "
            f"Delta={int(row['max_degree']):2d} "
            f"m1_retained={float(row['m1_severe_retained']):.3f}"
        )

    lines += [
        "",
        f"ADVISORY NEXT FLOOR: {suggested_floor}",
        (
            "This is a mechanical suggestion, not a scientific decision. "
            "Inspect the support table before the final unified system run."
        ),
        "",
        "NEXT",
        (
            "Run the final unified proactive/reactive/full benchmark on the "
            "chosen minimum-current-support floor."
        ),
    ]
    text = "\n".join(lines)
    (out / "gate_report.txt").write_text(text, encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
