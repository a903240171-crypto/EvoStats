#!/usr/bin/env python3
"""
EvoStats Phase 5C — Refresh-Frontier Optimality Audit
=====================================================

This is the final planner experiment.  It does three things:

A. Exact small-graph audit
   - enumerates every useful column batch on graphs with <=12 active vertices;
   - solves F_G(k) exactly with scipy.optimize.milp;
   - validates the clique, star, and matching closed forms;
   - reports the gap of the agglomerative greedy frontier.

B. Real-graph frontier sandwich
   - loads the real ACS person-only operational stale graph (Phase 4C);
   - optionally loads the joined person-housing d=109 graph (Phase 4G);
   - computes a nested greedy upper frontier;
   - computes certified lower bounds from a maximum-degree star and an
     explicitly constructed matching.

C. Randomized PostgreSQL runtime audit
   - reruns the final person-only refresh plans >=10 times;
   - randomizes strategy order inside every repetition;
   - reconstructs the exact Phase 4C DELETE+COPY stale state before each plan;
   - reports median and IQR;
   - uses isolated phi_n(B) only as a rank-oriented surrogate.

The script never claims that sum(phi_n(|U|)) is an absolute predictor of
multi-call runtime.
"""

from __future__ import annotations

import argparse
import csv
import heapq
import importlib.util
import itertools
import json
import math
import random
import statistics
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

try:
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import csc_matrix, vstack
except Exception as exc:  # pragma: no cover - explicit environment gate
    raise RuntimeError(
        "Phase 5C requires scipy.optimize.milp (SciPy >= 1.9). "
        "Upgrade SciPy in the experiment virtual environment."
    ) from exc


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def percentile(values: list[float], q: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=np.float64), q))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                fields.append(key)
                seen.add(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import helper module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def normalize_edge(u: int, v: int) -> tuple[int, int]:
    if u == v:
        raise ValueError("Self edges are not valid stale statistics")
    return (u, v) if u < v else (v, u)


def covered_objects(groups: Iterable[set[int]]) -> set[tuple[int, int]]:
    result: set[tuple[int, int]] = set()
    for group in groups:
        result.update(itertools.combinations(sorted(group), 2))
    return result


def active_vertices(edges: set[tuple[int, int]]) -> set[int]:
    return {vertex for edge in edges for vertex in edge}


def plan_metrics(groups: list[set[int]]) -> dict[str, int]:
    return {
        "calls": len(groups),
        "column_ops": sum(len(group) for group in groups),
        "object_ops": sum(choose2(len(group)) for group in groups),
        "unique_objects": len(covered_objects(groups)),
        "max_width": max((len(group) for group in groups), default=0),
    }


def connected_components(edges: set[tuple[int, int]]) -> list[set[int]]:
    adjacency: dict[int, set[int]] = {}
    for u, v in edges:
        adjacency.setdefault(u, set()).add(v)
        adjacency.setdefault(v, set()).add(u)

    components: list[set[int]] = []
    seen: set[int] = set()
    for start in sorted(adjacency):
        if start in seen:
            continue
        stack = [start]
        component: set[int] = set()
        while stack:
            vertex = stack.pop()
            if vertex in seen:
                continue
            seen.add(vertex)
            component.add(vertex)
            stack.extend(adjacency.get(vertex, set()) - seen)
        components.append(component)
    return sorted(components, key=lambda group: (-len(group), sorted(group)))


def bounded_greedy(
    edges: set[tuple[int, int]],
    max_vertices: int,
) -> list[set[int]]:
    """Degree-ordered greedy used by the existing PostgreSQL experiments."""
    if max_vertices < 2:
        raise ValueError("A refresh batch must contain at least two columns")

    degree: dict[int, int] = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1

    ordered = sorted(
        edges,
        key=lambda edge: (
            -(degree[edge[0]] + degree[edge[1]]),
            edge,
        ),
    )
    groups: list[set[int]] = []

    for edge in ordered:
        best_index: int | None = None
        best_increment: int | None = None
        for index, group in enumerate(groups):
            merged = group | set(edge)
            if len(merged) > max_vertices:
                continue
            increment = choose2(len(merged)) - choose2(len(group))
            if (
                best_increment is None
                or increment < best_increment
                or (
                    increment == best_increment
                    and tuple(sorted(group))
                    < tuple(sorted(groups[best_index]))
                )
            ):
                best_index = index
                best_increment = increment
        if best_index is None:
            groups.append(set(edge))
        else:
            groups[best_index].update(edge)

    return groups


def greedy_matching(edges: set[tuple[int, int]]) -> set[tuple[int, int]]:
    """
    Construct an explicit matching certificate.

    It need not be maximum.  Its cardinality is still a valid certified
    matching size and therefore yields a valid lower bound.
    """
    degree: dict[int, int] = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1

    used: set[int] = set()
    matching: set[tuple[int, int]] = set()
    for edge in sorted(
        edges,
        key=lambda item: (
            degree[item[0]] + degree[item[1]],
            max(degree[item[0]], degree[item[1]]),
            item,
        ),
    ):
        u, v = edge
        if u not in used and v not in used:
            matching.add(edge)
            used.add(u)
            used.add(v)
    return matching


def star_frontier(edge_count: int, calls: int) -> int:
    if edge_count <= 0:
        return 0
    k = min(max(1, calls), edge_count)
    q, r = divmod(edge_count, k)
    return (
        r * choose2(q + 2)
        + (k - r) * choose2(q + 1)
    )


def matching_frontier(edge_count: int, calls: int) -> int:
    if edge_count <= 0:
        return 0
    k = min(max(1, calls), edge_count)
    q, r = divmod(edge_count, k)
    return (
        r * choose2(2 * (q + 1))
        + (k - r) * choose2(2 * q)
    )


def certified_frontier_lower_bound(
    edges: set[tuple[int, int]],
    calls: int,
) -> dict[str, int]:
    """
    A valid lower bound for arbitrary graphs.

    Any plan covering G must also cover:
      - all s stale edges (object work >= s);
      - the Delta edges incident to a maximum-degree vertex;
      - every edge in an explicitly constructed matching.

    The corresponding star and matching frontiers therefore lower-bound F_G.
    """
    if not edges:
        return {
            "edge_lb": 0,
            "star_lb": 0,
            "matching_lb": 0,
            "combined_lb": 0,
            "max_degree": 0,
            "certified_matching_size": 0,
        }

    degree: dict[int, int] = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1
    max_degree = max(degree.values())
    matching_size = len(greedy_matching(edges))

    edge_lb = len(edges)
    star_lb = star_frontier(max_degree, calls)
    matching_lb = matching_frontier(matching_size, calls)
    return {
        "edge_lb": edge_lb,
        "star_lb": star_lb,
        "matching_lb": matching_lb,
        "combined_lb": max(edge_lb, star_lb, matching_lb),
        "max_degree": max_degree,
        "certified_matching_size": matching_size,
    }


@dataclass
class MergeNode:
    vertices: frozenset[int]
    left: int | None
    right: int | None


def agglomerative_frontier(
    edges: set[tuple[int, int]],
    phi,
) -> tuple[list[dict[str, Any]], dict[int, tuple[int, ...]], dict[int, MergeNode]]:
    """
    Build a nested upper frontier by repeatedly merging the pair of batches
    with the smallest increase in object work.

    Starts from one batch per stale edge (k=s, work=s) and ends at one closure
    batch over V(S).  Every cut is a valid covering plan.
    """
    if not edges:
        return [], {}, {}

    nodes: dict[int, MergeNode] = {}
    active: set[int] = set()
    next_id = 0
    for edge in sorted(edges):
        nodes[next_id] = MergeNode(frozenset(edge), None, None)
        active.add(next_id)
        next_id += 1

    def merge_delta(first: int, second: int) -> tuple[int, int, tuple[int, ...]]:
        a = nodes[first].vertices
        b = nodes[second].vertices
        union = a | b
        delta = choose2(len(union)) - choose2(len(a)) - choose2(len(b))
        return delta, len(union), tuple(sorted(union))

    heap: list[tuple[int, int, tuple[int, ...], int, int]] = []
    initial = sorted(active)
    for pos, first in enumerate(initial):
        for second in initial[pos + 1:]:
            delta, width, key = merge_delta(first, second)
            heapq.heappush(heap, (delta, width, key, first, second))

    snapshots: dict[int, tuple[int, ...]] = {}
    rows: list[dict[str, Any]] = []

    def record() -> None:
        ids = tuple(sorted(active))
        groups = [set(nodes[node_id].vertices) for node_id in ids]
        metrics = plan_metrics(groups)
        rows.append({
            "calls": metrics["calls"],
            "object_ops": metrics["object_ops"],
            "column_ops": metrics["column_ops"],
            "unique_objects": metrics["unique_objects"],
            "max_width": metrics["max_width"],
            "surrogate_seconds": sum(phi(len(group)) for group in groups),
        })
        snapshots[len(ids)] = ids

    record()

    while len(active) > 1:
        while heap:
            _, _, _, first, second = heapq.heappop(heap)
            if first in active and second in active:
                break
        else:
            raise RuntimeError("Agglomerative heap exhausted")

        active.remove(first)
        active.remove(second)
        merged_id = next_id
        next_id += 1
        nodes[merged_id] = MergeNode(
            nodes[first].vertices | nodes[second].vertices,
            first,
            second,
        )
        active.add(merged_id)

        for other in sorted(active):
            if other == merged_id:
                continue
            delta, width, key = merge_delta(merged_id, other)
            heapq.heappush(
                heap,
                (delta, width, key, min(merged_id, other), max(merged_id, other)),
            )
        record()

    rows.sort(key=lambda row: row["calls"])
    return rows, snapshots, nodes


def reconstruct_plan(
    calls: int,
    snapshots: dict[int, tuple[int, ...]],
    nodes: dict[int, MergeNode],
) -> list[set[int]]:
    if calls not in snapshots:
        raise KeyError(f"No agglomerative plan with calls={calls}")
    return [set(nodes[node_id].vertices) for node_id in snapshots[calls]]


@dataclass
class ExactBatchFamily:
    vertices: list[int]
    edges: list[tuple[int, int]]
    groups: list[tuple[int, ...]]
    costs: np.ndarray
    incidence: csc_matrix


def enumerate_exact_batches(
    edges: set[tuple[int, int]],
) -> ExactBatchFamily:
    vertices = sorted(active_vertices(edges))
    if len(vertices) > 12:
        raise ValueError(
            "Exact MILP defaults to at most 12 active vertices; "
            f"received {len(vertices)}"
        )

    edge_list = sorted(edges)
    groups: list[tuple[int, ...]] = []
    row_indices: list[int] = []
    col_indices: list[int] = []

    for width in range(2, len(vertices) + 1):
        for group in itertools.combinations(vertices, width):
            group_set = set(group)
            covered = [
                edge_index
                for edge_index, edge in enumerate(edge_list)
                if edge[0] in group_set and edge[1] in group_set
            ]
            if not covered:
                continue
            column = len(groups)
            groups.append(group)
            for edge_index in covered:
                row_indices.append(edge_index)
                col_indices.append(column)

    data = np.ones(len(row_indices), dtype=np.float64)
    incidence = csc_matrix(
        (data, (row_indices, col_indices)),
        shape=(len(edge_list), len(groups)),
    )
    costs = np.asarray(
        [choose2(len(group)) for group in groups],
        dtype=np.float64,
    )
    return ExactBatchFamily(
        vertices=vertices,
        edges=edge_list,
        groups=groups,
        costs=costs,
        incidence=incidence,
    )


def exact_frontier_milp(
    family: ExactBatchFamily,
    calls: int,
    time_limit: float,
) -> dict[str, Any]:
    n_groups = len(family.groups)
    call_row = csc_matrix(np.ones((1, n_groups), dtype=np.float64))
    matrix = vstack([family.incidence, call_row], format="csc")
    lower = np.concatenate([
        np.ones(len(family.edges), dtype=np.float64),
        np.asarray([-np.inf]),
    ])
    upper = np.concatenate([
        np.full(len(family.edges), np.inf, dtype=np.float64),
        np.asarray([float(calls)]),
    ])

    result = milp(
        c=family.costs,
        integrality=np.ones(n_groups, dtype=np.int8),
        bounds=Bounds(
            np.zeros(n_groups, dtype=np.float64),
            np.ones(n_groups, dtype=np.float64),
        ),
        constraints=LinearConstraint(matrix, lower, upper),
        options={
            "time_limit": float(time_limit),
            "mip_rel_gap": 0.0,
            "presolve": True,
        },
    )

    if result.x is None:
        raise RuntimeError(
            f"MILP failed for calls={calls}: "
            f"status={result.status}, message={result.message}"
        )

    selected = [
        family.groups[index]
        for index, value in enumerate(result.x)
        if value >= 0.5
    ]
    return {
        "calls_budget": calls,
        "exact_object_ops": int(round(float(result.fun))),
        "selected_calls": len(selected),
        "solver_status": int(result.status),
        "solver_message": str(result.message),
        "solver_mip_gap": (
            float(result.mip_gap)
            if getattr(result, "mip_gap", None) is not None
            else float("nan")
        ),
        "selected_groups": json.dumps([list(group) for group in selected]),
    }


def make_exact_graphs(seed: int) -> dict[str, tuple[int, set[tuple[int, int]]]]:
    rng = np.random.default_rng(seed)

    graphs: dict[str, tuple[int, set[tuple[int, int]]]] = {}

    # Clique K7.
    graphs["clique_K7"] = (
        7,
        set(itertools.combinations(range(7), 2)),
    )

    # Star with ten leaves.
    graphs["star_10"] = (
        11,
        {(0, leaf) for leaf in range(1, 11)},
    )

    # Six disjoint edges.
    graphs["matching_6"] = (
        12,
        {(2 * index, 2 * index + 1) for index in range(6)},
    )

    # Two dense components.
    two_cliques = set(itertools.combinations(range(5), 2))
    two_cliques |= set(itertools.combinations(range(5, 10), 2))
    graphs["two_cliques_5_5"] = (10, two_cliques)

    # Dense core plus diffuse remainder.
    mixed = set(itertools.combinations(range(5), 2))
    mixed |= {(5, 6), (7, 8), (9, 10), (10, 11)}
    graphs["clique_plus_diffuse"] = (12, mixed)

    # Block plus cross-block sparse edges.
    block = set(itertools.combinations(range(4), 2))
    block |= set(itertools.combinations(range(4, 8), 2))
    block |= {(1, 8), (3, 9), (6, 10), (7, 11)}
    graphs["blocks_plus_cross"] = (12, block)

    er_edges: set[tuple[int, int]] = set()
    for edge in itertools.combinations(range(12), 2):
        if rng.random() < 0.22:
            er_edges.add(edge)
    if len(er_edges) < 8:
        er_edges |= {(i, i + 1) for i in range(8)}
    graphs["erdos_renyi_12"] = (12, er_edges)

    return graphs


def selected_exact_k_values(name: str, edge_count: int) -> list[int]:
    if name in {"star_10", "matching_6"}:
        return list(range(1, edge_count + 1))
    if name == "clique_K7":
        return [1, 2, 4, 8, edge_count]
    base = {1, 2, 3, 4, 6, 8, edge_count}
    return sorted(k for k in base if 1 <= k <= edge_count)


def phi_from_model(model_path: Path, rows: int):
    report = json.loads(model_path.read_text(encoding="utf-8"))
    if str(rows) not in report:
        available = ", ".join(sorted(report))
        raise KeyError(
            f"No phi model for rows={rows}. Available row counts: {available}"
        )
    selected = report[str(rows)]["selected"]
    a = float(selected["a_seconds"])
    u = float(selected.get("u_seconds_per_column", 0.0))
    c = float(selected["c_seconds_per_pair_object"])

    def phi(width: int) -> float:
        return a + u * width + c * choose2(width)

    return phi, {
        "rows": rows,
        "model": selected["model"],
        "a_seconds": a,
        "u_seconds_per_column": u,
        "c_seconds_per_pair_object": c,
        "loo_median_relative_error":
            float(selected["leave_one_width_out_median_relative_error"]),
    }


def graph_summary(
    name: str,
    d: int,
    edges: set[tuple[int, int]],
) -> dict[str, Any]:
    vertices = active_vertices(edges)
    degree: dict[int, int] = {vertex: 0 for vertex in vertices}
    for u, v in edges:
        degree[u] += 1
        degree[v] += 1
    matching = greedy_matching(edges)
    components = connected_components(edges)
    return {
        "graph": name,
        "d": d,
        "M": choose2(d),
        "stale_edges": len(edges),
        "support_density": len(edges) / max(choose2(d), 1),
        "active_vertices": len(vertices),
        "active_fraction": len(vertices) / d,
        "max_degree": max(degree.values(), default=0),
        "mean_active_degree": (
            statistics.mean(degree.values()) if degree else 0.0
        ),
        "certified_matching_size": len(matching),
        "components": len(components),
        "largest_component_vertices": max(
            (len(component) for component in components),
            default=0,
        ),
    }


def run_exact_audit(
    out: Path,
    phi,
    seed: int,
    time_limit: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    exact_rows: list[dict[str, Any]] = []
    graph_rows: list[dict[str, Any]] = []

    for name, (d, edges) in make_exact_graphs(seed).items():
        print(
            f"[exact] {name}: d={d}, s={len(edges)}, "
            f"active={len(active_vertices(edges))}",
            flush=True,
        )
        graph_rows.append(graph_summary(name, d, edges))
        family = enumerate_exact_batches(edges)
        greedy_rows, _, _ = agglomerative_frontier(edges, phi)
        greedy_by_k = {int(row["calls"]): row for row in greedy_rows}

        for calls in selected_exact_k_values(name, len(edges)):
            exact = exact_frontier_milp(family, calls, time_limit)
            greedy = greedy_by_k[calls]
            lower = certified_frontier_lower_bound(edges, calls)

            closed_form: int | None = None
            if name == "clique_K7":
                closed_form = len(edges)
            elif name == "star_10":
                closed_form = star_frontier(len(edges), calls)
            elif name == "matching_6":
                closed_form = matching_frontier(len(edges), calls)

            exact_rows.append({
                "graph": name,
                "d": d,
                "stale_edges": len(edges),
                "calls": calls,
                "exact_object_ops": exact["exact_object_ops"],
                "greedy_object_ops": int(greedy["object_ops"]),
                "greedy_gap": (
                    float(greedy["object_ops"])
                    / float(exact["exact_object_ops"])
                ),
                "certified_lower_bound": lower["combined_lb"],
                "lower_bound_ratio": (
                    lower["combined_lb"]
                    / float(exact["exact_object_ops"])
                ),
                "closed_form": (
                    closed_form if closed_form is not None else ""
                ),
                "closed_form_matches": (
                    int(closed_form == exact["exact_object_ops"])
                    if closed_form is not None else ""
                ),
                "solver_status": exact["solver_status"],
                "solver_mip_gap": exact["solver_mip_gap"],
                "selected_calls": exact["selected_calls"],
                "selected_groups": exact["selected_groups"],
            })

    write_csv(out / "exact_frontier_audit.csv", exact_rows)
    write_csv(out / "exact_graph_summary.csv", graph_rows)
    return exact_rows, graph_rows


def load_person_graph(
    phase4c_dir: Path,
    q_threshold: float,
) -> tuple[int, set[tuple[int, int]], pd.DataFrame]:
    frame = pd.read_csv(phase4c_dir / "real_pair_qerrors.csv")
    d = 1 + int(max(frame["i"].max(), frame["j"].max()))
    selected = frame[frame["stale_qerror"] >= q_threshold].copy()
    edges = {
        normalize_edge(int(row.i), int(row.j))
        for row in selected.itertuples(index=False)
    }
    if not edges:
        raise RuntimeError("Person-only graph has no severe edges")
    return d, edges, frame


def discover_joined_qerrors(
    project_root: Path,
    explicit_path: Path | None,
) -> Path | None:
    if explicit_path is not None:
        return explicit_path if explicit_path.exists() else None

    preferred = (
        project_root
        / "results"
        / "phase4g_ambient_width"
        / "qerrors_d109.csv"
    )
    if preferred.exists():
        return preferred

    candidates = sorted(
        (project_root / "results").rglob("qerrors_d109.csv"),
        key=lambda path: (
            "phase4g" not in str(path).lower(),
            len(str(path)),
            str(path),
        ),
    )
    return candidates[0] if candidates else None


def load_joined_graph(
    path: Path,
    q_threshold: float,
) -> tuple[int, set[tuple[int, int]], pd.DataFrame]:
    frame = pd.read_csv(path)
    d = 1 + int(max(frame["i"].max(), frame["j"].max()))
    edges = {
        normalize_edge(int(row.i), int(row.j))
        for row in frame.itertuples(index=False)
        if float(row.stale_qerror) >= q_threshold
    }
    if not edges:
        raise RuntimeError(f"Joined graph has no severe edges: {path}")
    return d, edges, frame


def run_real_frontier(
    out: Path,
    name: str,
    d: int,
    edges: set[tuple[int, int]],
    phi,
) -> tuple[list[dict[str, Any]], dict[int, tuple[int, ...]], dict[int, MergeNode]]:
    rows, snapshots, nodes = agglomerative_frontier(edges, phi)
    graph = graph_summary(name, d, edges)

    output: list[dict[str, Any]] = []
    for row in rows:
        calls = int(row["calls"])
        lower = certified_frontier_lower_bound(edges, calls)
        output.append({
            "graph": name,
            "d": d,
            "M": choose2(d),
            "stale_edges": len(edges),
            **row,
            **lower,
            "greedy_over_lower": (
                float(row["object_ops"]) / lower["combined_lb"]
                if lower["combined_lb"] > 0
                else 1.0
            ),
            "full_object_ops": choose2(d),
        })

    write_csv(out / f"frontier_{name}.csv", output)
    (out / f"graph_summary_{name}.json").write_text(
        json.dumps(graph, indent=2), encoding="utf-8"
    )
    return output, snapshots, nodes


def plan_surrogate(groups: list[set[int]], phi) -> float:
    return sum(phi(len(group)) for group in groups)


def build_runtime_plans(
    d: int,
    edges: set[tuple[int, int]],
    phi,
    frontier_rows: list[dict[str, Any]],
    snapshots: dict[int, tuple[int, ...]],
    nodes: dict[int, MergeNode],
) -> dict[str, list[set[int]]]:
    active = active_vertices(edges)
    plans: dict[str, list[set[int]]] = {
        "full": [set(range(d))],
        "one_closure": [set(active)],
        "components": connected_components(edges),
        "per_edge": [set(edge) for edge in sorted(edges)],
    }
    for width in (3, 4, 6, 8, 12, 16):
        if width <= d:
            plans[f"greedy_B{width}"] = bounded_greedy(edges, width)

    best_frontier_row = min(
        frontier_rows,
        key=lambda row: (
            float(row["surrogate_seconds"]),
            int(row["object_ops"]),
            int(row["calls"]),
        ),
    )
    best_calls = int(best_frontier_row["calls"])
    plans["frontier_phi_best"] = reconstruct_plan(
        best_calls, snapshots, nodes
    )

    for name, groups in plans.items():
        if not edges <= covered_objects(groups):
            missing = sorted(edges - covered_objects(groups))
            raise RuntimeError(
                f"Runtime plan {name} misses stale edges: {missing[:10]}"
            )
    return plans


def verify_repair(
    helper,
    conn,
    schema: str,
    severe_frame: pd.DataFrame,
) -> dict[str, float]:
    qvalues: list[float] = []
    for row in severe_frame.itertuples(index=False):
        result = helper.explain_pair(
            conn,
            schema,
            int(row.i),
            int(row.j),
            int(row.worst_i),
            int(row.worst_j),
        )
        qvalues.append(float(result["q_error"]))
    return {
        "fresh_qerror_geomean": statistics.geometric_mean(qvalues),
        "fresh_qerror_max": max(qvalues),
        "repaired_fraction": (
            sum(qvalue <= 2.0 for qvalue in qvalues) / len(qvalues)
        ),
    }


def run_postgres_runtime(
    args,
    out: Path,
    d: int,
    edges: set[tuple[int, int]],
    full_frame: pd.DataFrame,
    phi,
    plans: dict[str, list[set[int]]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    helper = load_module(args.helper, "phase4c_helper")

    path_a = helper.find_cached_csv(args.cache_dir, 2019)
    path_b = helper.find_cached_csv(args.cache_dir, 2021)
    raw_a = helper.uniform_sample_csv(path_a, args.rows, 2019)
    raw_b = helper.uniform_sample_csv(path_b, args.rows, 2021)
    variables, _ = helper.select_variables(
        raw_a,
        raw_b,
        args.max_vars,
        args.max_cardinality,
    )
    A, B, _ = helper.encode_frames(raw_a, raw_b, variables)
    if A.shape[1] != d:
        raise RuntimeError(
            f"Phase 4C reconstruction width mismatch: {A.shape[1]} vs {d}"
        )

    severe_frame = full_frame[
        full_frame["stale_qerror"] >= args.q_threshold
    ].copy()
    for row in severe_frame.itertuples(index=False):
        i, j = int(row.i), int(row.j)
        if variables[i] != row.variable_i or variables[j] != row.variable_j:
            raise RuntimeError(f"Variable order mismatch at {(i, j)}")

    plan_rows: list[dict[str, Any]] = []
    for strategy, groups in plans.items():
        metrics = plan_metrics(groups)
        for index, group in enumerate(groups, start=1):
            plan_rows.append({
                "strategy": strategy,
                "group_index": index,
                "group_width": len(group),
                "closure_objects": choose2(len(group)),
                "columns": json.dumps(sorted(group)),
                "column_names": json.dumps(
                    [variables[column] for column in sorted(group)]
                ),
                **metrics,
                "surrogate_seconds": plan_surrogate(groups, phi),
            })
    write_csv(out / "runtime_group_plans.csv", plan_rows)

    conn = helper.connect(args.dsn)
    trials: list[dict[str, Any]] = []
    rng = random.Random(args.seed)

    def establish_stale() -> None:
        with conn.cursor() as cursor:
            cursor.execute(f'TRUNCATE TABLE "{args.schema}".fact')
        helper.load_array(conn, args.schema, A)
        helper.analyze_all(
            conn, args.schema, args.statistics_target
        )
        helper.replace_with_current(conn, args.schema, B)

    try:
        helper.create_schema_and_table(conn, args.schema, d)
        helper.load_array(conn, args.schema, A)
        helper.create_all_statistics(conn, args.schema, d)

        # Unrecorded warm-up, followed by a complete stale-state reset.
        establish_stale()
        helper.analyze_columns(
            conn,
            args.schema,
            sorted(next(iter(plans["greedy_B4"]))),
            args.statistics_target,
        )

        strategies = sorted(plans)
        for repeat in range(1, args.repeats + 1):
            order = strategies.copy()
            rng.shuffle(order)
            for order_index, strategy in enumerate(order, start=1):
                groups = plans[strategy]
                metrics = plan_metrics(groups)
                print(
                    f"[runtime] rep={repeat}/{args.repeats} "
                    f"order={order_index}/{len(order)} "
                    f"strategy={strategy} calls={metrics['calls']} "
                    f"objects={metrics['object_ops']}",
                    flush=True,
                )
                establish_stale()

                start = time.perf_counter()
                if strategy == "full":
                    helper.analyze_all(
                        conn, args.schema, args.statistics_target
                    )
                else:
                    for group in groups:
                        helper.analyze_columns(
                            conn,
                            args.schema,
                            sorted(group),
                            args.statistics_target,
                        )
                elapsed = time.perf_counter() - start
                repair = verify_repair(
                    helper, conn, args.schema, severe_frame
                )

                trials.append({
                    "repeat": repeat,
                    "randomized_order": order_index,
                    "strategy": strategy,
                    **metrics,
                    "surrogate_seconds": plan_surrogate(groups, phi),
                    "seconds": elapsed,
                    **repair,
                })
    finally:
        conn.close()

    write_csv(out / "runtime_trials.csv", trials)

    summary: list[dict[str, Any]] = []
    for strategy in sorted(plans):
        rows = [row for row in trials if row["strategy"] == strategy]
        seconds = [float(row["seconds"]) for row in rows]
        base = rows[0]
        summary.append({
            "strategy": strategy,
            "calls": int(base["calls"]),
            "column_ops": int(base["column_ops"]),
            "object_ops": int(base["object_ops"]),
            "unique_objects": int(base["unique_objects"]),
            "max_width": int(base["max_width"]),
            "surrogate_seconds": float(base["surrogate_seconds"]),
            "seconds_median": statistics.median(seconds),
            "seconds_q25": percentile(seconds, 0.25),
            "seconds_q75": percentile(seconds, 0.75),
            "seconds_iqr": percentile(seconds, 0.75)
                - percentile(seconds, 0.25),
            "fresh_qerror_geomean_median": statistics.median(
                float(row["fresh_qerror_geomean"]) for row in rows
            ),
            "fresh_qerror_max_median": statistics.median(
                float(row["fresh_qerror_max"]) for row in rows
            ),
            "repaired_fraction_median": statistics.median(
                float(row["repaired_fraction"]) for row in rows
            ),
        })

    full_seconds = next(
        row["seconds_median"]
        for row in summary
        if row["strategy"] == "full"
    )
    surrogate_order = {
        row["strategy"]: rank
        for rank, row in enumerate(
            sorted(
                summary,
                key=lambda item: (
                    item["surrogate_seconds"],
                    item["object_ops"],
                ),
            ),
            start=1,
        )
    }
    runtime_order = {
        row["strategy"]: rank
        for rank, row in enumerate(
            sorted(summary, key=lambda item: item["seconds_median"]),
            start=1,
        )
    }

    for row in summary:
        row["speedup_vs_full"] = full_seconds / row["seconds_median"]
        row["surrogate_rank"] = surrogate_order[row["strategy"]]
        row["runtime_rank"] = runtime_order[row["strategy"]]
        row["rank_error"] = abs(
            row["surrogate_rank"] - row["runtime_rank"]
        )

    summary.sort(key=lambda item: item["seconds_median"])
    write_csv(out / "runtime_summary.csv", summary)
    return trials, summary


def make_plots(
    out: Path,
    exact_rows: list[dict[str, Any]],
    real_frontiers: dict[str, list[dict[str, Any]]],
    runtime_summary: list[dict[str, Any]] | None,
) -> None:
    import matplotlib.pyplot as plt

    canonical = ["clique_K7", "star_10", "matching_6"]
    plt.figure(figsize=(7.2, 4.8))
    for graph in canonical:
        rows = sorted(
            [row for row in exact_rows if row["graph"] == graph],
            key=lambda row: row["calls"],
        )
        plt.plot(
            [row["calls"] for row in rows],
            [row["exact_object_ops"] for row in rows],
            marker="o",
            label=graph,
        )
    plt.xlabel("Call budget k")
    plt.ylabel("Exact object frontier F_G(k)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out / "canonical_frontiers.pdf")
    plt.close()

    for name, rows in real_frontiers.items():
        ordered = sorted(rows, key=lambda row: row["calls"])
        # Log-spaced decimation keeps the figure readable while preserving
        # endpoints and the small-k region.
        indices = {
            0,
            len(ordered) - 1,
            *[
                min(len(ordered) - 1, int(round(value)))
                for value in np.geomspace(
                    1, max(1, len(ordered) - 1), num=30
                )
            ],
        }
        selected = [ordered[index] for index in sorted(indices)]
        plt.figure(figsize=(7.2, 4.8))
        plt.plot(
            [row["calls"] for row in selected],
            [row["object_ops"] for row in selected],
            marker="o",
            label="Greedy upper frontier",
        )
        plt.plot(
            [row["calls"] for row in selected],
            [row["combined_lb"] for row in selected],
            marker="x",
            label="Certified lower bound",
        )
        plt.axhline(
            selected[0]["full_object_ops"],
            linestyle="--",
            label="Full refresh",
        )
        plt.xlabel("Calls k")
        plt.ylabel("Object work")
        plt.title(name.replace("_", " "))
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / f"frontier_{name}.pdf")
        plt.close()

    if runtime_summary:
        ordered = sorted(
            runtime_summary,
            key=lambda row: row["seconds_median"],
        )
        labels = [row["strategy"] for row in ordered]
        values = [row["seconds_median"] for row in ordered]
        errors = [
            [
                row["seconds_median"] - row["seconds_q25"]
                for row in ordered
            ],
            [
                row["seconds_q75"] - row["seconds_median"]
                for row in ordered
            ],
        ]
        plt.figure(figsize=(8.4, 5.0))
        positions = np.arange(len(labels))
        plt.bar(positions, values, yerr=np.asarray(errors))
        plt.xticks(positions, labels, rotation=35, ha="right")
        plt.ylabel("PostgreSQL runtime (s), median and IQR")
        plt.tight_layout()
        plt.savefig(out / "runtime_rank_person.pdf")
        plt.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--phase4c-dir", type=Path, required=True)
    parser.add_argument("--phi-model", type=Path, required=True)
    parser.add_argument("--helper", type=Path, required=True)
    parser.add_argument("--joined-qerrors", type=Path)
    parser.add_argument("--schema", default="evostats_phase5c_frontier")
    parser.add_argument("--q-threshold", type=float, default=10.0)
    parser.add_argument("--rows", type=int, default=40_000)
    parser.add_argument("--max-vars", type=int, default=50)
    parser.add_argument("--max-cardinality", type=int, default=24)
    parser.add_argument("--statistics-target", type=int, default=500)
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260718)
    parser.add_argument("--milp-time-limit", type=float, default=120.0)
    parser.add_argument("--offline-only", action="store_true")
    args = parser.parse_args()

    if not args.offline_only and args.repeats < 10:
        raise ValueError("Final PostgreSQL audit requires repeats >= 10")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    phi, phi_report = phi_from_model(args.phi_model, args.rows)
    (out / "phi_model_used.json").write_text(
        json.dumps(phi_report, indent=2), encoding="utf-8"
    )

    exact_rows, exact_graph_rows = run_exact_audit(
        out=out,
        phi=phi,
        seed=args.seed,
        time_limit=args.milp_time_limit,
    )

    person_d, person_edges, person_frame = load_person_graph(
        args.phase4c_dir, args.q_threshold
    )
    person_frontier, person_snapshots, person_nodes = run_real_frontier(
        out,
        "acs_person",
        person_d,
        person_edges,
        phi,
    )

    joined_path = discover_joined_qerrors(
        args.project_root.resolve(),
        args.joined_qerrors.resolve()
        if args.joined_qerrors is not None
        else None,
    )
    real_frontiers = {"acs_person": person_frontier}
    joined_report: dict[str, Any]
    if joined_path is not None:
        joined_d, joined_edges, _ = load_joined_graph(
            joined_path, args.q_threshold
        )
        joined_frontier, _, _ = run_real_frontier(
            out,
            "acs_person_housing",
            joined_d,
            joined_edges,
            phi,
        )
        real_frontiers["acs_person_housing"] = joined_frontier
        joined_report = {
            "status": "loaded",
            "path": str(joined_path),
            **graph_summary(
                "acs_person_housing", joined_d, joined_edges
            ),
        }
    else:
        joined_report = {
            "status": "not_found",
            "message": (
                "qerrors_d109.csv was not found. Person-only Phase 5C "
                "continues; joined frontier is skipped."
            ),
        }

    runtime_summary: list[dict[str, Any]] | None = None
    runtime_trials: list[dict[str, Any]] | None = None
    if not args.offline_only:
        plans = build_runtime_plans(
            person_d,
            person_edges,
            phi,
            person_frontier,
            person_snapshots,
            person_nodes,
        )
        runtime_trials, runtime_summary = run_postgres_runtime(
            args,
            out,
            person_d,
            person_edges,
            person_frame,
            phi,
            plans,
        )

    make_plots(
        out,
        exact_rows,
        real_frontiers,
        runtime_summary,
    )

    exact_gaps = [
        float(row["greedy_gap"]) for row in exact_rows
    ]
    formula_rows = [
        row for row in exact_rows
        if row["closed_form"] != ""
    ]
    formula_pass = all(
        int(row["closed_form_matches"]) == 1
        for row in formula_rows
    )

    person_graph = graph_summary(
        "acs_person", person_d, person_edges
    )
    runtime_best = (
        min(
            runtime_summary,
            key=lambda row: row["seconds_median"],
        )
        if runtime_summary else None
    )

    report = {
        "phi_model": phi_report,
        "exact_audit": {
            "instances": len(exact_graph_rows),
            "points": len(exact_rows),
            "closed_form_validation_pass": formula_pass,
            "greedy_gap_median": statistics.median(exact_gaps),
            "greedy_gap_max": max(exact_gaps),
        },
        "person_graph": person_graph,
        "joined_graph": joined_report,
        "postgres_runtime_best": runtime_best,
        "claims": {
            "exact_optimum_scope": (
                "Exact only for enumerated small graphs."
            ),
            "real_graph_scope": (
                "Greedy upper frontier plus certified star/matching "
                "lower bounds; no exact-OPT claim."
            ),
            "cost_model_scope": (
                "Isolated phi ranks candidate plans; all absolute "
                "PostgreSQL runtimes are measured directly."
            ),
        },
    }
    (out / "gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5C - REFRESH-FRONTIER OPTIMALITY AUDIT",
        "=" * 78,
        "",
        "EXACT SMALL-GRAPH AUDIT",
        f"instances                 : {len(exact_graph_rows)}",
        f"frontier points           : {len(exact_rows)}",
        f"closed-form validation    : {'PASS' if formula_pass else 'FAIL'}",
        f"greedy gap median         : {statistics.median(exact_gaps):.3f}",
        f"greedy gap max            : {max(exact_gaps):.3f}",
        "",
        "REAL PERSON GRAPH",
        f"d / M                     : {person_d} / {choose2(person_d)}",
        f"severe edges              : {len(person_edges)}",
        f"active vertices           : {person_graph['active_vertices']}",
        f"max degree                : {person_graph['max_degree']}",
        (
            "certified matching size  : "
            f"{person_graph['certified_matching_size']}"
        ),
        "",
        "JOINED GRAPH",
        json.dumps(joined_report, indent=2),
    ]

    if runtime_summary:
        lines += ["", "RANDOMIZED POSTGRESQL RUNTIME"]
        for row in runtime_summary:
            lines.append(
                f"  {row['strategy']:18s} "
                f"calls={row['calls']:3d} "
                f"obj={row['object_ops']:4d} "
                f"time={row['seconds_median']:.3f}s "
                f"IQR={row['seconds_iqr']:.3f}s "
                f"speedup={row['speedup_vs_full']:.2f}x "
                f"sur_rank={row['surrogate_rank']} "
                f"pg_rank={row['runtime_rank']} "
                f"repair={row['repaired_fraction_median']:.3f}"
            )

    lines += [
        "",
        "MANDATORY INTERPRETATION",
        (
            "Exact OPT is claimed only for the small enumerated graphs. "
            "Real graphs use a lower-upper sandwich."
        ),
        (
            "The isolated phi model is rank-oriented and is not used as "
            "an additive wall-clock predictor."
        ),
    ]
    text = "\n".join(lines)
    (out / "gate_report.txt").write_text(text, encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
