#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import pandas as pd

RESULT_DIRS = [
    # Canonical frozen result directories. Superseded experiments are
    # deliberately excluded.
    'phase0_unified',
    'pg_relabel_figure1',
    'phase1_statistic',
    'phase2_v2_theory_aligned',
    'phase3_pg_end_to_end_v2',
    'phase4c_real_acs_pg',
    'phase4g_ambient_width',
    'phase5a_phi_microbenchmark',
    'phase5b_detection_audit',
    'phase5b_qratio_audit',
    'phase5c_frontier_audit',
    'phase5d_support_sensitivity',
    'phase5f_d109_support_runtime',
    'phase5g_query_feedback',
]

RESULT_SUFFIXES = {'.csv', '.json', '.txt', '.pdf', '.png', '.svg', '.tex', '.md', '.yaml', '.yml'}
CODE_SUFFIXES = {'.py', '.ps1', '.sh', '.sql', '.md', '.txt', '.yaml', '.yml', '.toml', '.json'}
EXCLUDED_PARTS = {'.git', '.venv', 'venv', '__pycache__', '.pytest_cache', '.mypy_cache', '.idea', '.vscode', 'node_modules', 'pgdata', 'raw', 'cache', 'tmp', 'temp'}
EXCLUDED_NAMES = {'.env', 'pgpass.conf', 'postmaster.pid'}

REQUIRED = [
    # Catalog blindness and controlled relabeling witness.
    'results/phase0_unified/gate_report.json',
    'results/phase0_unified/query_detail.csv',
    'results/pg_relabel_figure1/figure1_report.json',
    'results/pg_relabel_figure1/query_results.csv',

    # Diagnostic statistic and theory-aligned discovery.
    'results/phase1_statistic/mechanism_results.csv',
    'results/phase1_statistic/null_calibration.csv',
    'results/phase2_v2_theory_aligned/summary.csv',
    'results/phase2_v2_theory_aligned/trial_detail.csv',

    # Final PostgreSQL hub witness and baseline comparison.
    'results/phase3_pg_end_to_end_v2/query_results.csv',
    'results/phase3_pg_end_to_end_v2/table1_strength_vs_shape.csv',

    # Real ACS and operational screening.
    'results/phase4c_real_acs_pg/real_pair_qerrors.csv',
    'results/phase4g_ambient_width/qerrors_d109.csv',
    'results/phase5b_qratio_audit/phase4c_reconstruction_audit.csv',
    'results/phase5b_qratio_audit/ranking_metrics.csv',
    'results/phase5b_qratio_audit/live_budget_summary.csv',

    # Cost, frontier, and final end-to-end evaluation.
    'results/phase5a_phi_microbenchmark/model_summary.json',
    'results/phase5c_frontier_audit/exact_frontier_audit.csv',
    'results/phase5c_frontier_audit/runtime_summary.csv',
    'results/phase5d_support_sensitivity/support_sensitivity_summary.csv',
    'results/phase5f_d109_support_runtime/support_sensitivity_summary.csv',
    'results/phase5f_d109_support_runtime/runtime_summary.csv',
    'results/phase5f_d109_support_runtime/end2end_summary.csv',
    'results/phase5g_query_feedback/feedback_summary.csv',
    'results/phase5g_query_feedback/final_strategy_table.csv',
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def run(command: list[str], cwd: Path | None = None) -> dict[str, Any]:
    try:
        p = subprocess.run(command, cwd=str(cwd) if cwd else None, capture_output=True, text=True, timeout=60, check=False)
        return {'command': command, 'returncode': p.returncode, 'stdout': p.stdout.strip(), 'stderr': p.stderr.strip()}
    except Exception as exc:
        return {'command': command, 'returncode': -1, 'stdout': '', 'stderr': repr(exc)}


def excluded(path: Path) -> bool:
    if path.name.lower() in EXCLUDED_NAMES:
        return True
    return bool({p.lower() for p in path.parts} & EXCLUDED_PARTS)


def copy_file(src: Path, dst: Path, project_root: Path, copied: list[dict[str, Any]]) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    copied.append({'source': str(src.relative_to(project_root)), 'artifact_path': str(dst), 'bytes': dst.stat().st_size})


def locate_result_dir(project_root: Path, name: str) -> Path | None:
    direct = project_root / 'results' / name
    if direct.exists():
        return direct
    candidates = sorted(
        [p for p in (project_root / 'results').glob('*') if p.is_dir() and name.lower() in p.name.lower()],
        key=lambda p: (len(p.name), p.name),
    )
    return candidates[0] if candidates else None


def copy_code(project_root: Path, artifact_root: Path, copied: list[dict[str, Any]]) -> None:
    found = 0
    for directory_name in ('phase5_validation', 'scripts', 'src'):
        directory = project_root / directory_name
        if not directory.exists():
            continue
        for src in sorted(directory.rglob('*')):
            if not src.is_file() or excluded(src) or src.suffix.lower() not in CODE_SUFFIXES:
                continue
            copy_file(src, artifact_root / 'code' / src.relative_to(project_root), project_root, copied)
            found += 1
    if found == 0:
        raise RuntimeError('No code found under phase5_validation/, scripts/, or src/.')


def copy_results(project_root: Path, artifact_root: Path, copied: list[dict[str, Any]], include_derived: bool, max_mb: float) -> list[str]:
    warnings: list[str] = []
    for name in RESULT_DIRS:
        source_dir = locate_result_dir(project_root, name)
        if source_dir is None:
            warnings.append(f'Result directory not found: {name}')
            continue
        for src in sorted(source_dir.rglob('*')):
            if not src.is_file() or excluded(src):
                continue
            suffix = src.suffix.lower()
            allowed = suffix in RESULT_SUFFIXES or (include_derived and suffix in {'.npz', '.npy', '.parquet'})
            if not allowed:
                continue
            size_mb = src.stat().st_size / (1024 * 1024)
            if size_mb > max_mb:
                warnings.append(f'Skipped large file ({size_mb:.1f} MB): {src.relative_to(project_root)}')
                continue
            rel = src.relative_to(project_root / 'results')
            copy_file(src, artifact_root / 'results' / rel, project_root, copied)
    return warnings


def copy_paper(project_root: Path, artifact_root: Path, copied: list[dict[str, Any]]) -> None:
    for directory_name in ('paper', 'figures', 'tables', 'tex'):
        directory = project_root / directory_name
        if not directory.exists():
            continue
        for src in sorted(directory.rglob('*')):
            if not src.is_file() or excluded(src):
                continue
            if src.suffix.lower() not in RESULT_SUFFIXES | {'.bib'}:
                continue
            copy_file(src, artifact_root / 'paper' / src.relative_to(project_root), project_root, copied)


def first_column(frame: pd.DataFrame, names: list[str]) -> str:
    for name in names:
        if name in frame.columns:
            return name
    raise KeyError(f'Expected one of {names}; found {list(frame.columns)}')


def build_tables(artifact_root: Path) -> dict[str, Any]:
    out = artifact_root / 'tables'
    out.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {}

    support_path = artifact_root / 'results/phase5f_d109_support_runtime/support_sensitivity_summary.csv'
    if support_path.exists():
        df = pd.read_csv(support_path)
        floor = first_column(df, ['min_current_support', 'floor', 'support'])
        severe = first_column(df, ['severe_edges_q10', 'severe_edges'])
        budget = first_column(df, ['full_recall_budget_fraction', 'full_recall_budget', 'full_R_budget', 'minimum_budget_for_full_recall'])
        cols = [floor, severe, 'auprc', 'auroc', budget, 'active_vertices', 'max_degree']
        table = df[cols].copy()
        table.columns = ['Minimum support', 'Severe edges', 'AUPRC', 'AUROC', 'Full-recall budget', 'Active columns', 'Max degree']
        table.to_csv(out / 'support_spectrum_d109.csv', index=False)
        (out / 'support_spectrum_d109.tex').write_text(table.to_latex(index=False, escape=True, float_format=lambda x: f'{x:.3f}'), encoding='utf-8')
        report['support_spectrum_rows'] = len(table)

    for source, target in [
        ('results/phase5f_d109_support_runtime/runtime_summary.csv', 'planner_runtime_d109.csv'),
        ('results/phase5f_d109_support_runtime/end2end_summary.csv', 'proactive_end_to_end_d109.csv'),
        ('results/phase5g_query_feedback/final_strategy_table.csv', 'proactive_vs_feedback.csv'),
        ('results/phase5c_frontier_audit/exact_frontier_audit.csv', 'frontier_exact_audit.csv'),
    ]:
        path = artifact_root / source
        if path.exists():
            df = pd.read_csv(path)
            df.to_csv(out / target, index=False)
            report[target] = len(df)
    return report


def add_claim(claims: list[dict[str, Any]], claim_id: str, statement: str, source: str, selector: str, value: Any) -> None:
    claims.append({'claim_id': claim_id, 'statement': statement, 'source_file': source, 'selector': selector, 'value': value})


def build_claims(artifact_root: Path) -> dict[str, Any]:
    claims: list[dict[str, Any]] = []
    root = artifact_root / 'results'

    path = root / 'phase5c_frontier_audit/runtime_summary.csv'
    if path.exists():
        df = pd.read_csv(path)
        best = df.loc[df['seconds_median'].idxmin()]
        full = df[df['strategy'] == 'full'].iloc[0]
        add_claim(claims, 'P5C_FASTEST', 'Fastest tested d=50 refresh plan.', str(path.relative_to(artifact_root)), f"strategy={best['strategy']}", float(best['seconds_median']))
        add_claim(claims, 'P5C_SPEEDUP', 'd=50 speedup over full refresh.', str(path.relative_to(artifact_root)), 'full/best', float(full['seconds_median'] / best['seconds_median']))

    path = root / 'phase5f_d109_support_runtime/support_sensitivity_summary.csv'
    if path.exists():
        df = pd.read_csv(path)
        floor = first_column(df, ['min_current_support', 'floor', 'support'])
        severe = first_column(df, ['severe_edges_q10', 'severe_edges'])
        for m in (10, 20, 100):
            row = df[df[floor] == m]
            if len(row) == 1:
                add_claim(claims, f'P5F_SUPPORT_{m}', f'd=109 severe edges at support floor {m}.', str(path.relative_to(artifact_root)), f'{floor}={m}', int(row.iloc[0][severe]))

    path = root / 'phase5f_d109_support_runtime/end2end_summary.csv'
    if path.exists():
        df = pd.read_csv(path)
        floor = first_column(df, ['floor', 'support'])
        time_col = first_column(df, ['end2end_seconds_median', 'end_to_end_seconds_median'])
        speed_col = first_column(df, ['speedup_vs_full', 'speedup'])
        for m in (10, 20):
            row = df[df[floor] == m]
            if len(row) == 1:
                add_claim(claims, f'P5F_E2E_{m}', f'd=109 proactive end-to-end seconds at m={m}.', str(path.relative_to(artifact_root)), f'{floor}={m}', float(row.iloc[0][time_col]))
                add_claim(claims, f'P5F_SPEEDUP_{m}', f'd=109 proactive speedup at m={m}.', str(path.relative_to(artifact_root)), f'{floor}={m}', float(row.iloc[0][speed_col]))

    path = root / 'phase5g_query_feedback/feedback_summary.csv'
    if path.exists():
        df = pd.read_csv(path)
        metrics = ['maintenance_seconds_median', 'harmful_queries_median', 'support_coverage_end_median', 'verified_qerror_geomean_median']
        for _, row in df.iterrows():
            for metric in metrics:
                if metric in df.columns:
                    key = f"P5G_{row['workload']}_{row['policy']}_{metric}".upper()
                    add_claim(claims, key, f"{row['workload']} {row['policy']} {metric}.", str(path.relative_to(artifact_root)), f"workload={row['workload']},policy={row['policy']}", float(row[metric]))

    pd.DataFrame(claims).to_csv(artifact_root / 'CLAIMS_PROVENANCE.csv', index=False)
    return {'claims': len(claims)}


def collect_environment(project_root: Path, artifact_root: Path) -> dict[str, Any]:
    env = artifact_root / 'environment'
    env.mkdir(parents=True, exist_ok=True)
    info = {
        'python_version': sys.version,
        'python_executable': sys.executable,
        'platform': platform.platform(),
        'machine': platform.machine(),
    }
    (env / 'python_platform.json').write_text(json.dumps(info, indent=2), encoding='utf-8')
    commands = {
        'pip_freeze': [sys.executable, '-m', 'pip', 'freeze'],
        'git_commit': ['git', 'rev-parse', 'HEAD'],
        'git_status': ['git', 'status', '--short'],
        'postgres_version': ['psql', '--version'],
    }
    results = {}
    for name, command in commands.items():
        result = run(command, project_root)
        results[name] = result
        text = result['stdout']
        if result['stderr']:
            text += '\nSTDERR:\n' + result['stderr']
        (env / f'{name}.txt').write_text(text, encoding='utf-8')
    return {'platform': info, 'commands': results}


def create_runtime_files(artifact_root: Path, include_derived: bool) -> None:
    readme = f'''# EvoStats Artifact\n\nThis artifact contains frozen experiment code, result files, generated paper tables, environment metadata, and claim-level provenance.\n\n## Quick validation\n\n```powershell\npython validate_artifact.py\npython reproduce_tables.py\n```\n\n## Full reproduction\n\nFinal experiment runners are under `code/phase5_validation/`. The most important scripts are Phase 5C, 5D, 5F, and 5G. Full reproduction requires PostgreSQL and public ACS PUMS files.\n\n## Data policy\n\nRaw ACS files, caches, credentials, PostgreSQL storage, and virtual environments are excluded. Derived encoded arrays included: **{include_derived}**.\n\n## Canonical result selection\n\nThe artifact packages the frozen result directories below:\n\n```text\nphase0_unified                 catalog-blindness audit\npg_relabel_figure1             controlled relabeling witness\nphase1_statistic               diagnostic statistic evaluation\nphase2_v2_theory_aligned       final theory-aligned discovery run\nphase3_pg_end_to_end_v2        final PostgreSQL hub witness\nphase5b_detection_audit        negative residual-selector audit\nphase5b_qratio_audit           protocol-fixed max-ratio audit\nphase5c_frontier_audit         exact/greedy frontier audit\nphase5d_support_sensitivity    d=50 support-floor sensitivity\nphase5f_d109_support_runtime   final d=109 system evaluation\nphase5g_query_feedback         oracle feedback baseline\n```\n\nSuperseded runs such as `phase2_sparse_localization` and\n`phase3_pg_end_to_end` are intentionally excluded.\n\n## Provenance\n\n- `CLAIMS_PROVENANCE.csv`: paper claim to exact CSV row.\n- `MANIFEST.json`: packaged file inventory.\n- `checksums.sha256`: byte-level verification.\n\n## Claim boundaries\n\n- Exact optimum is claimed only for enumerated small graphs.\n- The 1.286 greedy gap is empirical, not a universal guarantee.\n- Max-ratio ranks candidates; PostgreSQL Q-error verifies them.\n- Support floor is a workload axis.\n- Query feedback receives exact Q-error and exact pair attribution.\n- Absolute times from different phases must not be mixed.\n'''
    (artifact_root / 'README.md').write_text(readme, encoding='utf-8')

    validator = '''#!/usr/bin/env python3\nfrom pathlib import Path\nimport hashlib, json, sys\nroot=Path(__file__).resolve().parent\nfail=[]\ndef h(path):\n    x=hashlib.sha256()\n    with path.open('rb') as f:\n        for c in iter(lambda:f.read(1024*1024),b''): x.update(c)\n    return x.hexdigest()\nfor line in (root/'checksums.sha256').read_text(encoding='utf-8').splitlines():\n    if not line.strip(): continue\n    expected,rel=line.split('  ',1)\n    p=root/rel\n    if not p.exists(): fail.append('missing '+rel)\n    elif h(p)!=expected: fail.append('checksum '+rel)\nprint('Manifest files:',len(json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))['files']))\nif fail:\n    print('FAIL'); [print(' -',x) for x in fail]; sys.exit(1)\nprint('PASS: all checksums match.')\n'''
    (artifact_root / 'validate_artifact.py').write_text(validator, encoding='utf-8')

    reproducer = r'''#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import sys

root = Path(__file__).resolve().parent
required = [
    'support_spectrum_d109.csv',
    'planner_runtime_d109.csv',
    'proactive_end_to_end_d109.csv',
    'proactive_vs_feedback.csv',
    'frontier_exact_audit.csv',
]
missing = []

for name in required:
    path = root / 'tables' / name
    if not path.exists():
        print(f'[missing] {name}')
        missing.append(name)
        continue
    frame = pd.read_csv(path)
    print()
    print(f'{name} ({len(frame)} rows)')
    print(frame.to_string(index=False))

if missing:
    print()
    print('FAIL: missing frozen tables: ' + ', '.join(missing))
    sys.exit(1)

print()
print('PASS: frozen tables loaded.')
'''
    (artifact_root / 'reproduce_tables.py').write_text(reproducer, encoding='utf-8')


def write_checksums(artifact_root: Path) -> list[dict[str, Any]]:
    files = sorted(p for p in artifact_root.rglob('*') if p.is_file() and p.name not in {'checksums.sha256', 'MANIFEST.json'})
    rows = []
    lines = []
    for path in files:
        rel = str(path.relative_to(artifact_root)).replace('\\', '/')
        digest = sha256(path)
        rows.append({'path': rel, 'bytes': path.stat().st_size, 'sha256': digest})
        lines.append(f'{digest}  {rel}')
    (artifact_root / 'checksums.sha256').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--include-derived-data', action='store_true')
    parser.add_argument('--max-file-mb', type=float, default=250.0)
    parser.add_argument('--zip', action='store_true')
    args = parser.parse_args()

    project_root = args.project_root.resolve()
    output_dir = args.output_dir.resolve()
    artifact_root = output_dir / 'evostats_artifact'
    if artifact_root.exists():
        shutil.rmtree(artifact_root)
    artifact_root.mkdir(parents=True)

    copied: list[dict[str, Any]] = []
    copy_code(project_root, artifact_root, copied)
    warnings = copy_results(project_root, artifact_root, copied, args.include_derived_data, args.max_file_mb)
    copy_paper(project_root, artifact_root, copied)

    required_status = []
    for rel in REQUIRED:
        present = (artifact_root / rel).exists()
        required_status.append({'path': rel, 'present': present})
        if not present:
            warnings.append('Required frozen file missing: ' + rel)

    environment = collect_environment(project_root, artifact_root)
    table_report = build_tables(artifact_root)
    claims_report = build_claims(artifact_root)
    create_runtime_files(artifact_root, args.include_derived_data)

    files = write_checksums(artifact_root)
    manifest = {
        'artifact_name': 'EvoStats',
        'created_unix': time.time(),
        'include_derived_data': args.include_derived_data,
        'files': files,
        'required_files': required_status,
        'warnings': warnings,
        'environment': environment,
        'table_report': table_report,
        'claims_report': claims_report,
    }
    (artifact_root / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    files = write_checksums(artifact_root)
    manifest['files'] = files
    (artifact_root / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    write_checksums(artifact_root)

    result = run([sys.executable, str(artifact_root / 'validate_artifact.py')], artifact_root)
    if result['returncode'] != 0:
        raise RuntimeError(result['stdout'] + '\n' + result['stderr'])

    report = [
        'EVOSTATS ARTIFACT PACKAGING REPORT',
        '=' * 78,
        f'Project root       : {project_root}',
        f'Artifact directory : {artifact_root}',
        f'Packaged files     : {len(files)}',
        f'Claims mapped      : {claims_report["claims"]}',
        f'Warnings           : {len(warnings)}',
        '',
        'REQUIRED FILES',
    ]
    report.extend(f"  {'PASS' if item['present'] else 'MISS'}  {item['path']}" for item in required_status)
    if warnings:
        report += ['', 'WARNINGS'] + ['  - ' + warning for warning in warnings]
    report += ['', 'VALIDATION', '  PASS: SHA-256 verification completed.', '', 'NEXT', '  Inspect README.md, CLAIMS_PROVENANCE.csv, PACKAGING_REPORT.txt, and environment/git_status.txt.']
    text = '\n'.join(report)
    (artifact_root / 'PACKAGING_REPORT.txt').write_text(text, encoding='utf-8')
    print(text)

    if args.zip:
        zip_path = output_dir / 'evostats_artifact.zip'
        if zip_path.exists():
            zip_path.unlink()
        shutil.make_archive(str(zip_path.with_suffix('')), 'zip', root_dir=artifact_root.parent, base_dir=artifact_root.name)
        print('\nZIP:', zip_path)


if __name__ == '__main__':
    main()
