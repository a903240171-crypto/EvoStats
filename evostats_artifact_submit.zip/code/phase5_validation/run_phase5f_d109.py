#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import importlib.util
import itertools
import json
import math
import random
import re
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def qtile(values: list[float], q: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=float), q)) if values else float('nan')


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot import {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def reconstruct_names(qframe: pd.DataFrame) -> list[str]:
    d = 1 + int(max(qframe['i'].max(), qframe['j'].max()))
    names: list[str | None] = [None] * d
    for row in qframe.itertuples(index=False):
        for idx, value in ((int(row.i), str(row.variable_i)), (int(row.j), str(row.variable_j))):
            if names[idx] is not None and names[idx] != value:
                raise RuntimeError(f'Variable mismatch at index {idx}')
            names[idx] = value
    if any(value is None for value in names):
        raise RuntimeError('Incomplete variable order in qerrors_d109.csv')
    return [str(value) for value in names]



def reconstruct_exact_phase4g(args, qframe: pd.DataFrame):
    """
    Re-run the exact Phase 4G data pipeline.

    Phase 4G did NOT use pandas.DataFrame.sample().  It used a streaming
    random-key sampler, selected Person/Housing variables on those exact
    samples, joined only the housing rows matching sampled SERIALNO values,
    normalized with '<NA>', and encoded categories with Python lexical sort.
    Every one of those details affects worst-cell category codes.
    """
    pg4g = load_module(args.phase4g_helper, 'phase4g_exact_helper')

    p19 = pg4g.find_person_csv(args.person_cache, 2019)
    p21 = pg4g.find_person_csv(args.person_cache, 2021)

    hpaths = {}
    for year in (2019, 2021):
        zip_path = args.data_dir / f'acs_{year}_hca.zip'
        if not pg4g.valid_zip(zip_path):
            raise FileNotFoundError(
                f'Missing exact Phase 4G housing cache: {zip_path}. '
                'Run Phase 4G once or restore its data directory.'
            )
        hpaths[year] = pg4g.extract_csv(
            zip_path, args.data_dir, year, 'housing'
        )

    pa = pg4g.uniform_sample_csv(p19, args.rows, 2019)
    pb = pg4g.uniform_sample_csv(p21, args.rows, 2021)
    ha = pg4g.load_matching_housing(
        hpaths[2019], set(pa['SERIALNO'].astype(str))
    )
    hb = pg4g.load_matching_housing(
        hpaths[2021], set(pb['SERIALNO'].astype(str))
    )

    pvars, _ = pg4g.select_vars(
        pa, pb, 'P', 50, 24, 0.2
    )
    hvars, _ = pg4g.select_vars(
        ha, hb, 'H', 80, 24, 0.3
    )
    ja, jb, names = pg4g.build_join(
        pa, pb, ha, hb, pvars, hvars
    )
    A, B, cards = pg4g.encode(ja, jb, names)

    stored_names = reconstruct_names(qframe)
    if names != stored_names:
        mismatch = [
            (index, expected, actual)
            for index, (expected, actual)
            in enumerate(zip(stored_names, names))
            if expected != actual
        ]
        raise RuntimeError(
            'Exact Phase 4G variable order does not match qerrors_d109.csv: '
            f'd={len(names)}, first mismatches={mismatch[:10]}'
        )

    metadata = {
        'pipeline': 'exact_phase4g_import',
        'person_2019': str(p19),
        'person_2021': str(p21),
        'housing_2019': str(hpaths[2019]),
        'housing_2021': str(hpaths[2021]),
        'rows_reference': len(A),
        'rows_current': len(B),
        'person_variables': len(pvars),
        'housing_variables': len(hvars),
        'd': len(names),
        'sampling': (
            'Phase4G uniform_sample_csv streaming random-key reservoir, '
            'seed=year; sample Person first; load matching Housing by SERIALNO'
        ),
        'normalization': "Phase4G norm(): '<NA>' and lexical category sort",
        'stale_transition': 'TRUNCATE + COPY after reference ANALYZE',
    }
    return pg4g, A, B, cards, names, metadata


def pair_counts(A, B, i, j, ci, cj):
    c0 = np.bincount(A[:, i].astype(np.int64) * cj + A[:, j].astype(np.int64), minlength=ci*cj).reshape(ci, cj)
    c1 = np.bincount(B[:, i].astype(np.int64) * cj + B[:, j].astype(np.int64), minlength=ci*cj).reshape(ci, cj)
    return c0, c1


def select_cell(c0, c1, n0, n1, floor):
    eligible = c1 >= floor
    if not np.any(eligible):
        return {'eligible': 0, 'qhat': 1.0, 'value_i': -1, 'value_j': -1, 'old_count': 0, 'current_count': 0}
    p0 = np.maximum(c0 / n0, 1.0 / n0)
    p1 = c1 / n1
    ratio = np.ones_like(p1, dtype=float)
    ratio[eligible] = np.maximum(p0[eligible] / p1[eligible], p1[eligible] / p0[eligible])
    flat = int(np.argmax(ratio))
    vi, vj = np.unravel_index(flat, ratio.shape)
    return {'eligible': 1, 'qhat': float(ratio[vi, vj]), 'value_i': int(vi), 'value_j': int(vj), 'old_count': int(c0[vi, vj]), 'current_count': int(c1[vi, vj])}


def template_match(A, B, qframe):
    cards = [int(max(A[:, c].max(), B[:, c].max())) + 1 for c in range(A.shape[1])]
    matches = 0
    for row in qframe.itertuples(index=False):
        c0, c1 = pair_counts(A, B, int(row.i), int(row.j), cards[int(row.i)], cards[int(row.j)])
        cell = select_cell(c0, c1, len(A), len(B), 1)
        matches += int(cell['value_i'] == int(row.worst_i) and cell['value_j'] == int(row.worst_j))
    return matches / len(qframe)


def establish_stale(pg4g, conn, schema, A, B, target):
    # Exact Phase 4G protocol: reference reset -> ANALYZE -> current TRUNCATE.
    pg4g.replace_rows(conn, schema, A)
    pg4g.analyze_all(conn, schema, target)
    pg4g.replace_rows(conn, schema, B)


def bounded_greedy(edges: set[tuple[int, int]], width: int):
    degree = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1
    ordered = sorted(edges, key=lambda e: (-(degree[e[0]] + degree[e[1]]), e))
    groups: list[set[int]] = []
    for edge in ordered:
        best = None
        best_inc = None
        for idx, group in enumerate(groups):
            merged = group | set(edge)
            if len(merged) > width:
                continue
            inc = choose2(len(merged)) - choose2(len(group))
            if best_inc is None or inc < best_inc:
                best, best_inc = idx, inc
        if best is None:
            groups.append(set(edge))
        else:
            groups[best].update(edge)
    return groups


def plan_metrics(groups):
    return {'calls': len(groups), 'object_ops': sum(choose2(len(g)) for g in groups), 'max_width': max((len(g) for g in groups), default=0)}


def build_plans(d, edges):
    active = {v for e in edges for v in e}
    plans = {'one_closure': [active], 'per_edge': [set(e) for e in sorted(edges)]}
    for width in (4, 6, 8, 12, 16):
        plans[f'B{width}'] = bounded_greedy(edges, width)
    return plans


def run_plan(pg4g, conn, schema, name, groups, target):
    start = time.perf_counter()
    if name == 'full':
        pg4g.analyze_all(conn, schema, target)
    else:
        for group in groups:
            pg4g.analyze_group(conn, schema, group, target)
    return time.perf_counter() - start


def verify_repair(pg4g, conn, schema, rows, severe):
    lookup = {(int(row['i']), int(row['j'])): row for row in rows}
    qvalues = []
    for edge in sorted(severe):
        row = lookup[edge]
        qerror, _, _ = pg4g.explain_q(
            conn,
            schema,
            edge[0],
            edge[1],
            int(row['value_i']),
            int(row['value_j']),
        )
        qvalues.append(float(qerror))
    if not qvalues:
        return {'repair': 1.0, 'fresh_qgeo': 1.0}
    return {
        'repair': sum(q <= 2.0 for q in qvalues) / len(qvalues),
        'fresh_qgeo': statistics.geometric_mean(qvalues),
    }


def graph_geometry(d, edges):
    active = {v for e in edges for v in e}
    degree = {v: 0 for v in active}
    for u, v in edges:
        degree[u] += 1
        degree[v] += 1
    return {'active_vertices': len(active), 'active_fraction': len(active)/d, 'max_degree': max(degree.values(), default=0), 'top1_edge_fraction': max(degree.values(), default=0)/max(len(edges), 1)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project-root', type=Path, required=True)
    ap.add_argument('--phase4g-result', type=Path, required=True)
    ap.add_argument('--phase4g-helper', type=Path, required=True)
    ap.add_argument('--person-cache', type=Path, required=True)
    ap.add_argument('--data-dir', type=Path, required=True)
    ap.add_argument('--qerrors', type=Path, required=True)
    ap.add_argument('--dsn', required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--schema', default='evostats_phase5f_d109')
    ap.add_argument('--rows', type=int, default=40000)
    ap.add_argument('--statistics-target', type=int, default=500)
    ap.add_argument('--q-threshold', type=float, default=10.0)
    ap.add_argument('--support-thresholds', default='1,5,10,20,50,100')
    ap.add_argument('--runtime-supports', default='10,20')
    ap.add_argument('--repeats', type=int, default=10)
    ap.add_argument('--min-runtime-edges', type=int, default=10)
    ap.add_argument('--force-runtime', action='store_true')
    ap.add_argument('--audit-only', action='store_true')
    ap.add_argument('--seed', type=int, default=20260718)
    args = ap.parse_args()

    floors = sorted({int(x) for x in args.support_thresholds.split(',')})
    runtime_floors = sorted({int(x) for x in args.runtime_supports.split(',')})
    out = args.out.resolve(); out.mkdir(parents=True, exist_ok=True)
    qframe = pd.read_csv(args.qerrors)
    names = reconstruct_names(qframe)
    d = len(names); M = choose2(d)
    if d != 109 or len(qframe) != 5886:
        raise RuntimeError(f'Expected d=109/M=5886, got d={d}/rows={len(qframe)}')

    pg4g, A, B, cards, exact_names, metadata = reconstruct_exact_phase4g(
        args, qframe
    )
    names = exact_names
    match = template_match(A, B, qframe)
    metadata['worst_template_match'] = match
    (out/'reconstruction_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    if match < 0.999999:
        raise RuntimeError(f'Phase 4G sample reconstruction failed: worst-template match={match:.6f}, expected 1.0')
    np.savez_compressed(out/'joined_d109_encoded.npz', A=A, B=B, variables=np.asarray(names, dtype=object))

    pairs = list(itertools.combinations(range(d), 2))
    counts = {}
    for idx, (i, j) in enumerate(pairs, 1):
        counts[(i, j)] = pair_counts(A, B, i, j, cards[i], cards[j])
        if idx % 1000 == 0 or idx == M:
            print(f'[counts] {idx}/{M}', flush=True)

    screens = {}
    score_times = {floor: [] for floor in floors}
    for rep in range(args.repeats):
        for floor in floors:
            start = time.perf_counter(); rows = []
            for i, j in pairs:
                cell = select_cell(*counts[(i, j)], len(A), len(B), floor)
                rows.append({'floor': floor, 'i': i, 'j': j, 'variable_i': names[i], 'variable_j': names[j], **cell})
            score_times[floor].append(time.perf_counter() - start)
            if rep == 0:
                screens[floor] = rows
        print(f'[screen] {rep+1}/{args.repeats}', flush=True)

    conn = pg4g.connect(args.dsn)
    query_cache = {}
    try:
        pg4g.create_schema(conn, args.schema, d)
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, d)
        establish_stale(pg4g, conn, args.schema, A, B, args.statistics_target)
        templates = sorted({(int(row['i']), int(row['j']), int(row['value_i']), int(row['value_j'])) for floor in floors if floor != 1 for row in screens[floor] if row['eligible']})
        print(f'[pg] unique new templates={len(templates)}', flush=True)
        for idx, template in enumerate(templates, 1):
            i, j, vi, vj = template
            start = time.perf_counter()
            qerror, estimated_rows, actual_rows = pg4g.explain_q(
                conn, args.schema, i, j, vi, vj
            )
            query_cache[template] = {
                'q_error': qerror,
                'estimated_rows': estimated_rows,
                'actual_rows': actual_rows,
                'seconds': time.perf_counter()-start,
            }
            if idx % 1000 == 0 or idx == len(templates):
                print(f'[pg-query] {idx}/{len(templates)}', flush=True)
    finally:
        conn.close()

    stored_m1 = {(int(row.i), int(row.j)) for row in qframe.itertuples(index=False) if float(row.stale_qerror) >= args.q_threshold}
    severe_sets = {1: stored_m1}
    summaries = []
    pair_rows = []
    orders = {}
    for floor in floors:
        rows = screens[floor]; labels = []; scores = []
        severe = set()
        stored_lookup = {(int(row.i), int(row.j)): row for row in qframe.itertuples(index=False)} if floor == 1 else None
        for row in rows:
            edge = (int(row['i']), int(row['j']))
            if floor == 1:
                src = stored_lookup[edge]
                qerror = float(src.stale_qerror); actual = float(getattr(src, 'actual_rows', row['current_count']))
            elif row['eligible']:
                result = query_cache[(edge[0], edge[1], int(row['value_i']), int(row['value_j']))]
                qerror = float(result['q_error']); actual = float(result['actual_rows'])
            else:
                qerror = 1.0; actual = 0.0
            label = int(qerror >= args.q_threshold)
            if label: severe.add(edge)
            labels.append(label); scores.append(float(row['qhat']))
            pair_rows.append({**row, 'pg_qerror': qerror, 'pg_actual_rows': actual, 'pg_severe': label})
        severe_sets[floor] = severe
        y = np.asarray(labels); s = np.log10(np.maximum(np.asarray(scores), 1.0))
        auroc = float(roc_auc_score(y, s)) if len(set(labels)) == 2 else float('nan')
        auprc = float(average_precision_score(y, s)) if any(labels) else float('nan')
        order = sorted(range(M), key=lambda index: scores[index], reverse=True); orders[floor] = order
        found = 0; full_count = 0
        for count, index in enumerate(order, 1):
            found += labels[index]
            if found == len(severe): full_count = count; break
        geometry = graph_geometry(d, severe)
        summaries.append({'floor': floor, 'severe_edges': len(severe), 'base_rate': len(severe)/M, 'auroc': auroc, 'auprc': auprc, 'full_recall_candidates': full_count, 'full_recall_budget': full_count/M if severe else float('nan'), 'score_seconds_median': statistics.median(score_times[floor]), 'm1_retained': len(severe & stored_m1)/len(stored_m1), **geometry})

    write_csv(out/'support_pairs.csv', pair_rows)
    write_csv(out/'support_summary.csv', summaries)

    runtime_floors = [floor for floor in runtime_floors if floor in severe_sets and severe_sets[floor]]
    run_runtime = not args.audit_only and (args.force_runtime or any(len(severe_sets[floor]) >= args.min_runtime_edges for floor in runtime_floors))
    runtime_trials = []; runtime_summary = []; e2e_trials = []; e2e_summary = []

    if run_runtime:
        plans = {floor: build_plans(d, severe_sets[floor]) for floor in runtime_floors}
        strategies = ['full'] + [f'm{floor}_{name}' for floor in runtime_floors for name in plans[floor]]
        conn = pg4g.connect(args.dsn); rng = random.Random(args.seed)
        try:
            # Reuse the schema and 5,886 statistics created by the support audit.
            # Recreating them for every stage changes no result and wastes time.
            for rep in range(1, args.repeats+1):
                order_names = strategies.copy(); rng.shuffle(order_names)
                for order_index, strategy in enumerate(order_names, 1):
                    if strategy == 'full':
                        floor = runtime_floors[0]; name = 'full'; groups = [set(range(d))]
                    else:
                        match_obj = re.match(r'^m(\d+)_(.+)$', strategy); floor = int(match_obj.group(1)); name = match_obj.group(2); groups = plans[floor][name]
                    metrics = plan_metrics(groups)
                    print(f'[runtime] rep={rep}/{args.repeats} strategy={strategy} s={len(severe_sets[floor])} calls={metrics["calls"]} obj={metrics["object_ops"]}', flush=True)
                    establish_stale(pg4g, conn, args.schema, A, B, args.statistics_target)
                    seconds = run_plan(pg4g, conn, args.schema, name, groups, args.statistics_target)
                    repair = verify_repair(pg4g, conn, args.schema, screens[floor], severe_sets[floor])
                    runtime_trials.append({'repeat': rep, 'order': order_index, 'strategy': strategy, 'floor': floor, 'severe_edges': len(severe_sets[floor]), **metrics, 'seconds': seconds, **repair})
        finally:
            conn.close()
        for strategy in strategies:
            rows = [row for row in runtime_trials if row['strategy'] == strategy]; values = [row['seconds'] for row in rows]; first = rows[0]
            runtime_summary.append({'strategy': strategy, 'floor': first['floor'], 'severe_edges': first['severe_edges'], 'calls': first['calls'], 'object_ops': first['object_ops'], 'seconds_median': statistics.median(values), 'seconds_iqr': qtile(values,.75)-qtile(values,.25), 'repair_median': statistics.median(row['repair'] for row in rows)})
        full_time = next(row['seconds_median'] for row in runtime_summary if row['strategy']=='full')
        for row in runtime_summary: row['speedup_vs_full'] = full_time/row['seconds_median']
        runtime_summary.sort(key=lambda row: row['seconds_median'])
        write_csv(out/'runtime_trials.csv', runtime_trials); write_csv(out/'runtime_summary.csv', runtime_summary)

        best_by_floor = {}
        for floor in runtime_floors:
            best = min([row for row in runtime_summary if row['strategy'].startswith(f'm{floor}_')], key=lambda row: row['seconds_median'])
            best_by_floor[floor] = best['strategy'].split('_',1)[1]

        conn = pg4g.connect(args.dsn)
        try:
            # Reuse the same persistent schema/statistics for end-to-end trials.
            for floor in runtime_floors:
                severe = severe_sets[floor]; row_lookup = {(int(row['i']),int(row['j'])): row for row in screens[floor]}
                candidate_count = next(int(row['full_recall_candidates']) for row in summaries if row['floor']==floor)
                candidates = [pairs[index] for index in orders[floor][:candidate_count]]
                best_name = best_by_floor[floor]
                for rep in range(1,args.repeats+1):
                    establish_stale(pg4g, conn, args.schema, A, B, args.statistics_target)
                    verified = set(); start = time.perf_counter()
                    for edge in candidates:
                        row = row_lookup[edge]
                        qerror, _, _ = pg4g.explain_q(
                            conn,
                            args.schema,
                            edge[0],
                            edge[1],
                            int(row['value_i']),
                            int(row['value_j']),
                        )
                        if float(qerror) >= args.q_threshold:
                            verified.add(edge)
                    verify_seconds = time.perf_counter()-start
                    if verified != severe: raise RuntimeError(f'Verification mismatch at m={floor}: {len(verified)} vs {len(severe)}')
                    if best_name == 'per_edge': groups = [set(edge) for edge in sorted(verified)]
                    elif best_name == 'one_closure': groups = [{v for edge in verified for v in edge}]
                    else: groups = bounded_greedy(verified, int(best_name.replace('B','')))
                    refresh_seconds = run_plan(pg4g, conn, args.schema, best_name, groups, args.statistics_target)
                    repair = verify_repair(pg4g, conn, args.schema, screens[floor], severe)
                    score_seconds = score_times[floor][rep-1]
                    e2e_trials.append({'repeat':rep,'floor':floor,'severe_edges':len(severe),'candidate_count':candidate_count,'candidate_fraction':candidate_count/M,'best_plan':best_name,'score_seconds':score_seconds,'verify_seconds':verify_seconds,'refresh_seconds':refresh_seconds,'end2end_seconds':score_seconds+verify_seconds+refresh_seconds,**repair})
        finally:
            conn.close()
        for floor in runtime_floors:
            rows=[row for row in e2e_trials if row['floor']==floor]; values=[row['end2end_seconds'] for row in rows]
            e2e_summary.append({'floor':floor,'severe_edges':rows[0]['severe_edges'],'candidate_count':rows[0]['candidate_count'],'candidate_fraction':rows[0]['candidate_fraction'],'best_plan':rows[0]['best_plan'],'score_seconds_median':statistics.median(row['score_seconds'] for row in rows),'verify_seconds_median':statistics.median(row['verify_seconds'] for row in rows),'refresh_seconds_median':statistics.median(row['refresh_seconds'] for row in rows),'end2end_seconds_median':statistics.median(values),'end2end_seconds_iqr':qtile(values,.75)-qtile(values,.25),'full_seconds_median':full_time,'speedup_vs_full':full_time/statistics.median(values),'repair_median':statistics.median(row['repair'] for row in rows)})
        write_csv(out/'end2end_trials.csv', e2e_trials); write_csv(out/'end2end_summary.csv', e2e_summary)

    m10 = len(severe_sets.get(10,set()))
    theme = 'BIG_THEME_SUPPORTED' if m10 >= 20 else ('MIXED_THEME' if m10 >= 10 else 'SMALL_THEME_ONLY')
    report = {'d':d,'M':M,'m1_severe':len(stored_m1),'template_match':match,'support_summary':summaries,'runtime_executed':run_runtime,'runtime_summary':runtime_summary,'end2end_summary':e2e_summary,'theme_decision':theme}
    (out/'gate_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    lines=['EVOSTATS PHASE 5F - d=109 SUPPORT FLOOR + RANDOMIZED RUNTIME','='*78,f'd / M: {d} / {M}',f'm=1 severe: {len(stored_m1)}',f'Phase 4G worst-template reconstruction: {match:.4f}','', 'SUPPORT SPECTRUM']
    for row in summaries:
        lines.append(f"  m={row['floor']:3d} severe={row['severe_edges']:4d} AUPRC={row['auprc']:.3f} AUROC={row['auroc']:.3f} full_R_budget={row['full_recall_budget']:.3f} active={row['active_vertices']:3d} Delta={row['max_degree']:3d} m1_retained={row['m1_retained']:.3f}")
    lines += ['',f'THEME DECISION: {theme}']
    if run_runtime:
        lines += ['', 'RANDOMIZED RUNTIME']
        for row in runtime_summary:
            lines.append(f"  {row['strategy']:18s} s={row['severe_edges']:4d} calls={row['calls']:4d} obj={row['object_ops']:5d} time={row['seconds_median']:.3f}s IQR={row['seconds_iqr']:.3f}s speedup={row['speedup_vs_full']:.2f}x repair={row['repair_median']:.3f}")
        lines += ['', 'END-TO-END PROACTIVE']
        for row in e2e_summary:
            lines.append(f"  m={row['floor']:3d} s={row['severe_edges']:4d} candidates={row['candidate_count']:4d} frac={row['candidate_fraction']:.3f} plan={row['best_plan']} end2end={row['end2end_seconds_median']:.3f}s full={row['full_seconds_median']:.3f}s speedup={row['speedup_vs_full']:.2f}x repair={row['repair_median']:.3f}")
    else:
        lines += ['', 'RUNTIME SKIPPED: m=10/m=20 did not retain the configured minimum edge count, or --audit-only was used.']
    lines += ['', 'PROGRESS', 'Phase 5A cost calibration          PASS', 'Phase 5B proactive/reactive         PASS', 'Phase 5C frontier optimality         PASS', 'Phase 5D d=50 support audit          PASS', 'Phase 5F d=109 decisive audit        PASS', '', 'NEXT: freeze framing; then one unified final table and artifact packaging.']
    text='\n'.join(lines); (out/'gate_report.txt').write_text(text,encoding='utf-8'); print('\n'+text)


if __name__ == '__main__':
    main()
