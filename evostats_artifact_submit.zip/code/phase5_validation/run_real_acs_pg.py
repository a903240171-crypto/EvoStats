#!/usr/bin/env python3
"""
EvoStats Phase 4C — Real ACS PostgreSQL Staleness Audit
=======================================================

Purpose
-------
Eliminate the last approximation in Phase 4B.

Instead of mapping residual D to Q-error using one synthetic cardinality, this
experiment measures stale PostgreSQL Q-error directly on the real ACS pairs.

Protocol
--------
1. Load 2019 and 2021 ACS PUMS samples.
2. Exclude allocation/imputation flags (F*P).
3. Select 50 shared categorical variables.
4. Encode both years with one fixed category map.
5. Create one PostgreSQL table with all 50 columns.
6. Load 2019, create all C(50,2)=1,225 extended statistics, ANALYZE.
7. Replace table contents with 2021 without ANALYZE; autovacuum is disabled.
8. For every candidate pair:
   - find the empirically worst changed cell;
   - run EXPLAIN ANALYZE on that real cell;
   - record stale Q-error.
9. Characterize operational support at Q>=2,5,10,25.
10. Refresh only the Q>=10 active columns and compare selective/full ANALYZE.

This directly measures real operational staleness. No synthetic D-to-Q transfer
is used for the final claim.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import statistics
import time
import zipfile
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import psycopg
from psycopg import sql


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def find_cached_csv(data_dir: Path, year: int) -> Path:
    csvs = sorted(data_dir.glob(f"*{year}*.csv"))
    if csvs:
        return csvs[0]

    zips = sorted(data_dir.glob(f"*{year}*.zip"))
    if not zips:
        raise FileNotFoundError(f"No cached {year} PUMS file in {data_dir}")

    with zipfile.ZipFile(zips[0]) as zf:
        members = [
            n for n in zf.namelist()
            if n.lower().endswith(".csv") and "psam_p" in n.lower()
        ]
        if not members:
            members = [n for n in zf.namelist() if n.lower().endswith(".csv")]
        member = sorted(members, key=len)[0]
        target = data_dir / f"{year}_{Path(member).name}"
        if not target.exists():
            with zf.open(member) as src, target.open("wb") as dst:
                dst.write(src.read())
        return target


def uniform_sample_csv(path: Path, n: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    frames: list[pd.DataFrame] = []
    keys: list[np.ndarray] = []

    for chunk in pd.read_csv(
        path, dtype=str, chunksize=50_000, low_memory=False
    ):
        k = rng.random(len(chunk))
        if len(chunk) > n:
            idx = np.argpartition(k, n - 1)[:n]
            chunk = chunk.iloc[idx].copy()
            k = k[idx]
        frames.append(chunk)
        keys.append(k)

        if sum(len(x) for x in frames) > 3 * n:
            frame = pd.concat(frames, ignore_index=True)
            all_keys = np.concatenate(keys)
            idx = np.argpartition(all_keys, n - 1)[:n]
            frames = [frame.iloc[idx].copy()]
            keys = [all_keys[idx]]

    frame = pd.concat(frames, ignore_index=True)
    all_keys = np.concatenate(keys)
    if len(frame) > n:
        idx = np.argpartition(all_keys, n - 1)[:n]
        frame = frame.iloc[idx]
    return frame.reset_index(drop=True)


def norm_series(s: pd.Series) -> pd.Series:
    return (
        s.astype("string")
        .fillna("<NA>")
        .str.strip()
        .replace({"": "<NA>", "nan": "<NA>", "None": "<NA>"})
    )


def allocation_flag(name: str) -> bool:
    u = name.upper()
    return u.startswith("F") and u.endswith("P")


def select_variables(
    a: pd.DataFrame,
    b: pd.DataFrame,
    max_vars: int,
    max_cardinality: int,
) -> tuple[list[str], list[dict[str, Any]]]:
    excluded_prefixes = (
        "PWGTP", "WGTP", "SERIALNO", "SPORDER", "ADJINC", "ADJHSG"
    )
    rows = []

    for col in sorted(set(a.columns) & set(b.columns)):
        if col.upper().startswith(excluded_prefixes) or allocation_flag(col):
            continue

        sa = norm_series(a[col])
        sb = norm_series(b[col])
        card = len(set(sa.unique()) | set(sb.unique()))
        missing = max(
            float((sa == "<NA>").mean()),
            float((sb == "<NA>").mean()),
        )
        eligible = 2 <= card <= max_cardinality and missing <= 0.20
        score = math.log1p(card) - 5.0 * missing

        rows.append({
            "variable": col,
            "cardinality": card,
            "missing": missing,
            "eligible": int(eligible),
            "selection_score": score,
        })

    eligible_rows = sorted(
        [r for r in rows if r["eligible"]],
        key=lambda r: (-r["selection_score"], r["variable"]),
    )[:max_vars]
    selected = [r["variable"] for r in eligible_rows]
    selected_set = set(selected)

    for row in rows:
        row["selected"] = int(row["variable"] in selected_set)

    if len(selected) < 20:
        raise RuntimeError(f"Only {len(selected)} variables selected")
    return selected, rows


def encode_frames(
    a: pd.DataFrame,
    b: pd.DataFrame,
    variables: list[str],
) -> tuple[np.ndarray, np.ndarray, list[list[str]]]:
    A = np.empty((len(a), len(variables)), dtype=np.int16)
    B = np.empty((len(b), len(variables)), dtype=np.int16)
    categories: list[list[str]] = []

    for j, col in enumerate(variables):
        sa = norm_series(a[col])
        sb = norm_series(b[col])
        cats = sorted(set(sa.unique()) | set(sb.unique()))
        mapping = {v: i for i, v in enumerate(cats)}
        A[:, j] = sa.map(mapping).astype(np.int16).to_numpy()
        B[:, j] = sb.map(mapping).astype(np.int16).to_numpy()
        categories.append(cats)

    return A, B, categories


def pair_empirical_metrics(
    A: np.ndarray,
    B: np.ndarray,
    i: int,
    j: int,
    ci: int,
    cj: int,
) -> dict[str, Any]:
    def joint(X: np.ndarray) -> np.ndarray:
        counts = np.bincount(
            X[:, i].astype(np.int64) * cj
            + X[:, j].astype(np.int64),
            minlength=ci * cj,
        ).reshape(ci, cj).astype(np.float64)
        return counts / len(X)

    p0 = joint(A)
    p1 = joint(B)

    def residual(p: np.ndarray) -> np.ndarray:
        return p - p.sum(1, keepdims=True) @ p.sum(0, keepdims=True)

    D = 0.25 * float(np.abs(residual(p1) - residual(p0)).sum())

    # Prefer a non-empty 2021 cell so Q-error does not depend on clamping.
    mask = p1 > 0
    ratio = np.zeros_like(p1)
    ratio[mask] = np.maximum(
        np.maximum(p0[mask], 1.0 / len(A)) / p1[mask],
        p1[mask] / np.maximum(p0[mask], 1.0 / len(A)),
    )
    worst = np.unravel_index(int(np.argmax(ratio)), ratio.shape)

    return {
        "residual_D": D,
        "worst_i": int(worst[0]),
        "worst_j": int(worst[1]),
        "old_prob": float(p0[worst]),
        "new_prob": float(p1[worst]),
        "empirical_probability_ratio": float(ratio[worst]),
    }


def connect(dsn: str):
    conn = psycopg.connect(dsn, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET jit=off")
        cur.execute("SET max_parallel_workers_per_gather=0")
        cur.execute("SET track_io_timing=on")
        cur.execute("SET statement_timeout=0")
    return conn


def create_schema_and_table(
    conn,
    schema: str,
    d: int,
) -> None:
    s = qi(schema)
    columns = ", ".join(f"c{i} integer NOT NULL" for i in range(d))

    with conn.cursor() as cur:
        cur.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        cur.execute(f"CREATE SCHEMA {s}")
        cur.execute(
            f"""
            CREATE TABLE {s}.fact(
                id bigint PRIMARY KEY,
                {columns}
            )
            """
        )
        cur.execute(
            f"""
            ALTER TABLE {s}.fact SET (
                autovacuum_enabled=false,
                toast.autovacuum_enabled=false
            )
            """
        )


def load_array(
    conn,
    schema: str,
    X: np.ndarray,
) -> float:
    s = qi(schema)
    d = X.shape[1]
    cols = ["id"] + [f"c{i}" for i in range(d)]

    start = time.perf_counter()
    with conn.cursor() as cur:
        with cur.copy(
            sql.SQL("COPY {}.fact ({}) FROM STDIN").format(
                sql.Identifier(schema),
                sql.SQL(",").join(sql.Identifier(c) for c in cols),
            )
        ) as cp:
            for idx, row in enumerate(X):
                cp.write_row([idx] + [int(v) for v in row])
    return time.perf_counter() - start


def create_all_statistics(
    conn,
    schema: str,
    d: int,
) -> None:
    s = qi(schema)
    with conn.cursor() as cur:
        for i, j in itertools.combinations(range(d), 2):
            cur.execute(
                f"""
                CREATE STATISTICS {s}.{qi(f'evs_{i}_{j}')}
                    (dependencies,mcv)
                ON c{i},c{j}
                FROM {s}.fact
                """
            )


def analyze_all(conn, schema: str, target: int) -> float:
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target={target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {qi(schema)}.fact")
        return time.perf_counter() - start


def analyze_columns(
    conn,
    schema: str,
    columns: list[int],
    target: int,
) -> float:
    names = ",".join(f"c{i}" for i in sorted(set(columns)))
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target={target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {qi(schema)}.fact ({names})")
        return time.perf_counter() - start


def replace_with_current(
    conn,
    schema: str,
    X: np.ndarray,
) -> tuple[float, float]:
    with conn.cursor() as cur:
        start = time.perf_counter()
        cur.execute(f"DELETE FROM {qi(schema)}.fact")
        delete_seconds = time.perf_counter() - start

    insert_seconds = load_array(conn, schema, X)
    return delete_seconds, insert_seconds


def find_fact_scan(plan: dict[str, Any]) -> dict[str, Any] | None:
    if plan.get("Relation Name") == "fact":
        return plan
    for child in plan.get("Plans", []) or []:
        found = find_fact_scan(child)
        if found is not None:
            return found
    return None


def explain_pair(
    conn,
    schema: str,
    i: int,
    j: int,
    vi: int,
    vj: int,
) -> dict[str, Any]:
    with conn.cursor() as cur:
        cur.execute(
            f"""
            EXPLAIN (ANALYZE,TIMING OFF,FORMAT JSON)
            SELECT COUNT(*)
            FROM {qi(schema)}.fact
            WHERE c{i}=%s AND c{j}=%s
            """,
            (vi, vj),
        )
        root = cur.fetchone()[0][0]["Plan"]
        scan = find_fact_scan(root)
        if scan is None:
            raise RuntimeError("fact scan not found")
        est = float(scan.get("Plan Rows", 0))
        act = float(scan.get("Actual Rows", 0))
        q = max(
            max(est, 1.0) / max(act, 1.0),
            max(act, 1.0) / max(est, 1.0),
        )
        return {
            "estimated_rows": est,
            "actual_rows": act,
            "q_error": q,
            "scan_node": str(scan.get("Node Type", "?")),
        }


def geometry(
    d: int,
    edges: set[tuple[int, int]],
    variables: list[str],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    deg = [0] * d
    for u, v in edges:
        deg[u] += 1
        deg[v] += 1

    order = sorted(range(d), key=lambda n: deg[n], reverse=True)
    covered: set[tuple[int, int]] = set()
    rows = []

    for rank, node in enumerate(order, start=1):
        covered |= {edge for edge in edges if node in edge}
        rows.append({
            "rank": rank,
            "node": node,
            "variable": variables[node],
            "degree": deg[node],
            "covered_edges": len(covered),
            "covered_fraction": len(covered) / max(len(edges), 1),
        })

    active = {node for edge in edges for node in edge}
    return rows, {
        "support_edges": len(edges),
        "support_density": len(edges) / choose2(d),
        "active_nodes": len(active),
        "max_degree": max(deg) if deg else 0,
        "top1_edge_cover": rows[0]["covered_fraction"] if rows else 0.0,
        "top5_edge_cover": (
            rows[min(4, len(rows)-1)]["covered_fraction"]
            if rows else 0.0
        ),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--cache-dir", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_acs_real_pg")
    ap.add_argument("--rows", type=int, default=40_000)
    ap.add_argument("--max-vars", type=int, default=50)
    ap.add_argument("--max-cardinality", type=int, default=24)
    ap.add_argument("--statistics-target", type=int, default=500)
    args = ap.parse_args()

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    path_2019 = find_cached_csv(args.cache_dir, 2019)
    path_2021 = find_cached_csv(args.cache_dir, 2021)
    Araw = uniform_sample_csv(path_2019, args.rows, 2019)
    Braw = uniform_sample_csv(path_2021, args.rows, 2021)

    variables, selection_rows = select_variables(
        Araw, Braw, args.max_vars, args.max_cardinality
    )
    write_csv(out / "variable_selection.csv", selection_rows)

    A, B, categories = encode_frames(Araw, Braw, variables)
    d = len(variables)
    M = choose2(d)

    print(f"[setup] real ACS d={d}, M={M}, rows={args.rows}", flush=True)

    empirical_rows = []
    for idx, (i, j) in enumerate(itertools.combinations(range(d), 2), start=1):
        metrics = pair_empirical_metrics(
            A, B, i, j, len(categories[i]), len(categories[j])
        )
        empirical_rows.append({
            "i": i,
            "j": j,
            "variable_i": variables[i],
            "variable_j": variables[j],
            **metrics,
        })
        if idx % 250 == 0 or idx == M:
            print(f"[empirical] {idx}/{M}", flush=True)

    conn = connect(args.dsn)
    try:
        create_schema_and_table(conn, args.schema, d)
        print("[pg] loading 2019", flush=True)
        load_2019_seconds = load_array(conn, args.schema, A)
        print("[pg] creating all statistics", flush=True)
        create_all_statistics(conn, args.schema, d)
        full_2019_analyze = analyze_all(
            conn, args.schema, args.statistics_target
        )

        print("[pg] replacing with 2021 without ANALYZE", flush=True)
        delete_seconds, load_2021_seconds = replace_with_current(
            conn, args.schema, B
        )

        # Verify stale state remains un-analyzed.
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT last_autoanalyze,n_mod_since_analyze
                FROM pg_stat_all_tables
                WHERE schemaname=%s AND relname='fact'
                """,
                (args.schema,),
            )
            last_auto, nmod = cur.fetchone()
            if last_auto is not None:
                raise RuntimeError("auto-ANALYZE occurred")

        print("[pg] measuring all real pair Q-errors", flush=True)
        for idx, row in enumerate(empirical_rows, start=1):
            q = explain_pair(
                conn,
                args.schema,
                int(row["i"]),
                int(row["j"]),
                int(row["worst_i"]),
                int(row["worst_j"]),
            )
            row.update({
                "stale_estimated_rows": q["estimated_rows"],
                "stale_actual_rows": q["actual_rows"],
                "stale_qerror": q["q_error"],
                "scan_node": q["scan_node"],
            })
            if idx % 250 == 0 or idx == M:
                print(f"[pg-query] {idx}/{M}", flush=True)

        write_csv(out / "real_pair_qerrors.csv", empirical_rows)

        summaries = []
        selected_q10: set[tuple[int, int]] = set()
        for tau in (2.0, 5.0, 10.0, 25.0):
            edges = {
                (int(r["i"]), int(r["j"]))
                for r in empirical_rows
                if float(r["stale_qerror"]) >= tau
            }
            degree_rows, geo = geometry(d, edges, variables)
            summaries.append({
                "qerror_threshold": tau,
                **geo,
            })
            if tau == 10.0:
                selected_q10 = edges
                write_csv(out / "degree_q10.csv", degree_rows)

        write_csv(out / "support_by_real_qerror.csv", summaries)

        active_columns = sorted({
            node for edge in selected_q10 for node in edge
        })
        closure = choose2(len(active_columns))

        print(
            f"[pg] selective refresh columns={len(active_columns)}, "
            f"closure={closure}/{M}",
            flush=True,
        )
        selective_seconds = (
            analyze_columns(
                conn,
                args.schema,
                active_columns,
                args.statistics_target,
            )
            if active_columns else 0.0
        )

        fresh_q10_rows = []
        for row in empirical_rows:
            edge = (int(row["i"]), int(row["j"]))
            if edge not in selected_q10:
                continue
            q = explain_pair(
                conn,
                args.schema,
                int(row["i"]),
                int(row["j"]),
                int(row["worst_i"]),
                int(row["worst_j"]),
            )
            fresh_q10_rows.append({
                "i": row["i"],
                "j": row["j"],
                "variable_i": row["variable_i"],
                "variable_j": row["variable_j"],
                "stale_qerror": row["stale_qerror"],
                "fresh_qerror": q["q_error"],
            })
        write_csv(out / "q10_refresh_results.csv", fresh_q10_rows)

        print("[pg] full ANALYZE cost comparison", flush=True)
        full_seconds = analyze_all(
            conn, args.schema, args.statistics_target
        )

    finally:
        conn.close()

    q10_summary = next(
        s for s in summaries if s["qerror_threshold"] == 10.0
    )
    stale_q10_gmean = (
        statistics.geometric_mean(
            float(r["stale_qerror"]) for r in fresh_q10_rows
        )
        if fresh_q10_rows else 1.0
    )
    fresh_q10_gmean = (
        statistics.geometric_mean(
            float(r["fresh_qerror"]) for r in fresh_q10_rows
        )
        if fresh_q10_rows else 1.0
    )

    decision = {
        "d": d,
        "M": M,
        "rows_per_year": args.rows,
        "support_by_real_qerror": summaries,
        "q10_active_columns": len(active_columns),
        "q10_closure_objects": closure,
        "q10_closure_fraction": closure / M,
        "q10_stale_geomean_qerror": stale_q10_gmean,
        "q10_fresh_geomean_qerror": fresh_q10_gmean,
        "selective_analyze_seconds": selective_seconds,
        "full_analyze_seconds": full_seconds,
        "selective_full_ratio": (
            selective_seconds / full_seconds if full_seconds else 0.0
        ),
        "load_2019_seconds": load_2019_seconds,
        "initial_full_analyze_seconds": full_2019_analyze,
        "delete_seconds": delete_seconds,
        "load_2021_seconds": load_2021_seconds,
        "real_operational_support_sparse_at_q10":
            q10_summary["support_density"] <= 0.05,
        "real_selective_refresh_repairs_q10":
            fresh_q10_gmean <= 2.0,
    }
    decision["phase4c_go"] = (
        decision["real_operational_support_sparse_at_q10"]
        and decision["real_selective_refresh_repairs_q10"]
    )
    decision["decision"] = (
        "GO: real ACS operational support is sparse and selectively repairable"
        if decision["phase4c_go"]
        else "LIMITED: revise real-data claim"
    )

    (out / "gate_report.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    lines = [
        "EVOSTATS PHASE 4C REAL ACS POSTGRESQL REPORT",
        "=" * 78,
        f"d / M                     : {d} / {M}",
        f"rows per year             : {args.rows}",
        "",
        "REAL STALE SUPPORT",
    ]
    for row in summaries:
        lines.append(
            f"Q>={row['qerror_threshold']:>4.0f}: "
            f"edges={row['support_edges']:4d} "
            f"density={row['support_density']:.4f} "
            f"active={row['active_nodes']:2d} "
            f"top1={row['top1_edge_cover']:.3f} "
            f"top5={row['top5_edge_cover']:.3f}"
        )

    lines += [
        "",
        "Q>=10 SELECTIVE REFRESH",
        f"active columns             : {len(active_columns)}",
        f"closure                    : {closure}/{M} "
        f"({closure/M:.4f})",
        f"stale Q geomean            : {stale_q10_gmean:.3f}",
        f"fresh Q geomean            : {fresh_q10_gmean:.3f}",
        f"selective ANALYZE          : {selective_seconds:.3f}s",
        f"full ANALYZE               : {full_seconds:.3f}s",
        f"selective/full             : "
        f"{selective_seconds/full_seconds:.4f}",
        "",
        "DECISION",
        json.dumps(decision, indent=2),
    ]
    report = "\n".join(lines)
    (out / "gate_report.txt").write_text(report, encoding="utf-8")
    print("\n" + report)


if __name__ == "__main__":
    main()
