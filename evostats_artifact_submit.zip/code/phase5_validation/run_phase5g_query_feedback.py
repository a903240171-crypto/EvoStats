#!/usr/bin/env python3
"""
EvoStats Phase 5G — Exact Query-Feedback Baseline
=================================================

Final missing baseline for the d=109 ACS Person+Housing experiment.

The proactive and full-refresh references are imported from the exact Phase 5F
randomized protocol. This script adds a deliberately strong query-feedback
baseline on the same encoded data, PostgreSQL statistics, operational support,
and ANALYZE target.

Feedback baseline
-----------------
After each normal workload query, the baseline receives:
  1. exact estimated-versus-actual Q-error;
  2. exact attribution to the queried column pair.

This is stronger than a deployable LEO-style attribution mechanism and should
be described as an oracle query-feedback upper bound.

Policies:
  * reactive_immediate:
      refresh the newly exposed severe pair immediately;
  * reactive_window50_B8:
      accumulate exposed severe pairs for 50 queries, then batch with B=8;
  * reactive_window200_B8:
      accumulate exposed severe pairs for 200 queries, then batch with B=8.

Workloads:
  * uniform over all M candidate pairs;
  * Zipf(1) over a seed-randomized pair ranking.

The workload-query execution time is common to every strategy and is excluded.
Reported reactive time is additional statistics-maintenance time. Harm counts
are measured before repair. Windowed policies may harm the same edge more than
once before the window closes.

The primary operating point is m=20:
  * each audit predicate has at least 20 current tuples;
  * Phase 5F found 141 real PG Q>=10 edges;
  * max-ratio screening achieved perfect ranking on this scoped workload;
  * proactive end-to-end maintenance was 4.49x faster than full refresh.

This script does not rerun full/proactive. It imports their ten-repeat Phase 5F
summaries and measures only the missing feedback baseline under the same exact
Phase 4G reconstruction.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import itertools
import json
import math
import random
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                fields.append(key)
                seen.add(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def covered_edges(
    groups: list[set[int]],
    severe: set[tuple[int, int]],
) -> set[tuple[int, int]]:
    covered: set[tuple[int, int]] = set()
    for group in groups:
        vertices = set(group)
        for edge in severe:
            if edge[0] in vertices and edge[1] in vertices:
                covered.add(edge)
    return covered


def generate_workload(
    M: int,
    length: int,
    distribution: str,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    if distribution == "uniform":
        return rng.integers(0, M, size=length, dtype=np.int64)
    if distribution == "zipf":
        # Randomize which physical pair receives each popularity rank so that
        # the result is not an artifact of lexicographic pair ordering.
        permutation = rng.permutation(M)
        ranks = np.arange(1, M + 1, dtype=np.float64)
        probabilities = 1.0 / ranks
        probabilities /= probabilities.sum()
        rank_draws = rng.choice(M, size=length, p=probabilities)
        return permutation[rank_draws].astype(np.int64)
    raise ValueError(distribution)


def simulate_policy(
    pairs: list[tuple[int, int]],
    severe: set[tuple[int, int]],
    sequence: np.ndarray,
    policy: str,
    window: int,
    batch_width: int,
    bounded_greedy,
) -> dict[str, Any]:
    repaired: set[tuple[int, int]] = set()
    pending: set[tuple[int, int]] = set()
    groups: list[set[int]] = []
    harmful_queries = 0
    harmful_distinct: set[tuple[int, int]] = set()
    severe_queries = 0

    def flush() -> None:
        nonlocal pending, repaired, groups
        if not pending:
            return
        if policy == "reactive_immediate":
            new_groups = [set(edge) for edge in sorted(pending)]
        else:
            new_groups = bounded_greedy(set(pending), batch_width)
        groups.extend(new_groups)
        repaired |= covered_edges(new_groups, severe)
        pending = set()

    for position, pair_index in enumerate(sequence, start=1):
        edge = pairs[int(pair_index)]
        if edge in severe:
            severe_queries += 1
            if edge not in repaired:
                harmful_queries += 1
                harmful_distinct.add(edge)
                pending.add(edge)
                if policy == "reactive_immediate":
                    flush()

        if (
            policy != "reactive_immediate"
            and position % window == 0
        ):
            flush()

    flush()

    return {
        "groups": groups,
        "harmful_queries": harmful_queries,
        "harmful_distinct_edges": len(harmful_distinct),
        "severe_queries": severe_queries,
        "repaired_edges_end": len(repaired),
        "support_coverage_end": len(repaired) / max(len(severe), 1),
        "unrepaired_edges_end": len(severe - repaired),
        "calls": len(groups),
        "object_ops": sum(choose2(len(group)) for group in groups),
        "max_width": max((len(group) for group in groups), default=0),
    }


def establish_stale(
    phase5f,
    pg4g,
    conn,
    schema: str,
    A: np.ndarray,
    B: np.ndarray,
    target: int,
) -> None:
    phase5f.establish_stale(
        pg4g, conn, schema, A, B, target
    )


def replay_groups(
    pg4g,
    conn,
    schema: str,
    groups: list[set[int]],
    target: int,
) -> float:
    start = time.perf_counter()
    for group in groups:
        pg4g.analyze_group(conn, schema, group, target)
    return time.perf_counter() - start


def verify_support_state(
    pg4g,
    conn,
    schema: str,
    rows: list[dict[str, Any]],
    severe: set[tuple[int, int]],
) -> dict[str, float]:
    lookup = {
        (int(row["i"]), int(row["j"])): row
        for row in rows
    }
    repaired = 0
    qerrors: list[float] = []
    for edge in sorted(severe):
        row = lookup[edge]
        qerror, _, _ = pg4g.explain_q(
            conn,
            schema,
            edge[0],
            edge[1],
            int(row["value_i"]),
            int(row["value_j"]),
        )
        qerror = float(qerror)
        qerrors.append(qerror)
        repaired += int(qerror <= 2.0)
    return {
        "verified_repair_fraction": repaired / max(len(severe), 1),
        "verified_qerror_geomean": (
            statistics.geometric_mean(qerrors)
            if qerrors else 1.0
        ),
        "verified_qerror_max": max(qerrors) if qerrors else 1.0,
    }


def import_phase5f_references(
    phase5f_dir: Path,
    floor: int,
) -> dict[str, dict[str, Any]]:
    runtime = pd.read_csv(phase5f_dir / "runtime_summary.csv")
    end2end = pd.read_csv(phase5f_dir / "end2end_summary.csv")

    full = runtime[runtime["strategy"] == "full"]
    if len(full) != 1:
        raise RuntimeError("Expected exactly one full row in Phase 5F")
    proactive = end2end[end2end["floor"] == floor]
    if len(proactive) != 1:
        raise RuntimeError(
            f"Expected exactly one Phase 5F end-to-end row for m={floor}"
        )

    full_row = full.iloc[0]
    proactive_row = proactive.iloc[0]
    return {
        "full_pre": {
            "maintenance_seconds_median":
                float(full_row["seconds_median"]),
            "maintenance_seconds_iqr":
                float(full_row["seconds_iqr"]),
            "harmful_queries_median": 0.0,
            "support_coverage_end_median": 1.0,
            "repair_fraction_median":
                float(full_row["repair_median"]),
            "source": "Phase5F exact randomized runtime",
        },
        "proactive_screen_verify_refresh": {
            "maintenance_seconds_median":
                float(proactive_row["end2end_seconds_median"]),
            "maintenance_seconds_iqr":
                float(proactive_row.get("end2end_seconds_iqr", 0.0)),
            "harmful_queries_median": 0.0,
            "support_coverage_end_median": 1.0,
            "repair_fraction_median":
                float(proactive_row["repair_median"]),
            "candidate_count":
                int(proactive_row["candidate_count"]),
            "candidate_fraction":
                float(proactive_row["candidate_fraction"]),
            "refresh_plan": str(proactive_row["best_plan"]),
            "source": "Phase5F exact end-to-end",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--phase5f-dir", type=Path, required=True)
    parser.add_argument("--phase5f-script", type=Path, required=True)
    parser.add_argument("--phase4g-helper", type=Path, required=True)
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--schema", default="evostats_phase5g_feedback")
    parser.add_argument("--floor", type=int, default=20)
    parser.add_argument("--statistics-target", type=int, default=500)
    parser.add_argument("--workload-length", type=int, default=5000)
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--batch-width", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20260719)
    args = parser.parse_args()

    if args.repeats < 10:
        raise ValueError("Final feedback baseline requires repeats >= 10")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(args.phase5f_script, "phase5f_exact")
    pg4g = load_module(args.phase4g_helper, "phase4g_exact")

    encoded = np.load(
        args.phase5f_dir / "joined_d109_encoded.npz",
        allow_pickle=True,
    )
    A = np.asarray(encoded["A"], dtype=np.int32)
    B = np.asarray(encoded["B"], dtype=np.int32)
    variable_names = [
        str(value) for value in encoded["variables"].tolist()
    ]
    d = A.shape[1]
    M = choose2(d)
    if d != 109 or B.shape[1] != d:
        raise RuntimeError(
            f"Expected d=109 arrays, found A={A.shape}, B={B.shape}"
        )

    pair_frame = pd.read_csv(args.phase5f_dir / "support_pairs.csv")
    floor_frame = pair_frame[pair_frame["floor"] == args.floor].copy()
    if len(floor_frame) != M:
        raise RuntimeError(
            f"Expected {M} support rows at m={args.floor}, "
            f"found {len(floor_frame)}"
        )

    severe = {
        (int(row.i), int(row.j))
        for row in floor_frame.itertuples(index=False)
        if int(row.pg_severe) == 1
    }
    if not severe:
        raise RuntimeError(f"No severe support at m={args.floor}")

    pairs = list(itertools.combinations(range(d), 2))
    expected_pairs = {
        (int(row.i), int(row.j))
        for row in floor_frame.itertuples(index=False)
    }
    if set(pairs) != expected_pairs:
        raise RuntimeError("Pair ordering/support table mismatch")

    support_rows = floor_frame.to_dict("records")
    references = import_phase5f_references(
        args.phase5f_dir, args.floor
    )

    policies = [
        ("reactive_immediate", 1),
        ("reactive_window50_B8", 50),
        ("reactive_window200_B8", 200),
    ]
    distributions = ["uniform", "zipf"]

    simulations: dict[tuple[int, str, str], dict[str, Any]] = {}
    for repeat in range(1, args.repeats + 1):
        for distribution in distributions:
            workload_seed = (
                args.seed
                + repeat * 10_000
                + (0 if distribution == "uniform" else 1_000_000)
            )
            sequence = generate_workload(
                M,
                args.workload_length,
                distribution,
                workload_seed,
            )
            for policy, window in policies:
                simulation = simulate_policy(
                    pairs,
                    severe,
                    sequence,
                    policy,
                    window,
                    args.batch_width,
                    phase5f.bounded_greedy,
                )
                simulations[(repeat, distribution, policy)] = simulation

    conn = pg4g.connect(args.dsn)
    trials: list[dict[str, Any]] = []
    randomizer = random.Random(args.seed)
    try:
        pg4g.create_schema(conn, args.schema, d)
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, d)

        strategy_keys = [
            (distribution, policy, window)
            for distribution in distributions
            for policy, window in policies
        ]

        for repeat in range(1, args.repeats + 1):
            order = strategy_keys.copy()
            randomizer.shuffle(order)
            for order_index, (distribution, policy, window) in enumerate(
                order, start=1
            ):
                simulation = simulations[
                    (repeat, distribution, policy)
                ]
                groups = simulation["groups"]

                print(
                    f"[feedback] rep={repeat}/{args.repeats} "
                    f"order={order_index}/{len(order)} "
                    f"workload={distribution} "
                    f"policy={policy} "
                    f"calls={simulation['calls']} "
                    f"objects={simulation['object_ops']} "
                    f"harm={simulation['harmful_queries']}",
                    flush=True,
                )

                establish_stale(
                    phase5f,
                    pg4g,
                    conn,
                    args.schema,
                    A,
                    B,
                    args.statistics_target,
                )
                maintenance_seconds = replay_groups(
                    pg4g,
                    conn,
                    args.schema,
                    groups,
                    args.statistics_target,
                )
                verified = verify_support_state(
                    pg4g,
                    conn,
                    args.schema,
                    support_rows,
                    severe,
                )

                # The replay must match the graph-level simulation.
                expected_coverage = simulation["support_coverage_end"]
                if abs(
                    verified["verified_repair_fraction"]
                    - expected_coverage
                ) > 1e-9:
                    raise RuntimeError(
                        "Reactive replay mismatch: "
                        f"simulated coverage={expected_coverage:.6f}, "
                        f"verified={verified['verified_repair_fraction']:.6f}"
                    )

                trials.append({
                    "repeat": repeat,
                    "randomized_order": order_index,
                    "floor": args.floor,
                    "d": d,
                    "M": M,
                    "severe_edges": len(severe),
                    "workload": distribution,
                    "workload_length": args.workload_length,
                    "policy": policy,
                    "window": window,
                    "batch_width": (
                        2 if policy == "reactive_immediate"
                        else args.batch_width
                    ),
                    "maintenance_seconds": maintenance_seconds,
                    **{
                        key: value
                        for key, value in simulation.items()
                        if key != "groups"
                    },
                    **verified,
                })
    finally:
        conn.close()

    write_csv(out / "feedback_trials.csv", trials)

    summary: list[dict[str, Any]] = []
    for distribution in distributions:
        for policy, window in policies:
            rows = [
                row for row in trials
                if row["workload"] == distribution
                and row["policy"] == policy
            ]
            times = [
                float(row["maintenance_seconds"]) for row in rows
            ]
            harms = [
                int(row["harmful_queries"]) for row in rows
            ]
            coverages = [
                float(row["support_coverage_end"]) for row in rows
            ]
            summary.append({
                "floor": args.floor,
                "severe_edges": len(severe),
                "workload": distribution,
                "workload_length": args.workload_length,
                "policy": policy,
                "window": window,
                "maintenance_seconds_median":
                    statistics.median(times),
                "maintenance_seconds_iqr":
                    qtile(times, 0.75) - qtile(times, 0.25),
                "harmful_queries_median":
                    statistics.median(harms),
                "harmful_queries_q25": qtile(harms, 0.25),
                "harmful_queries_q75": qtile(harms, 0.75),
                "harmful_distinct_edges_median":
                    statistics.median(
                        int(row["harmful_distinct_edges"])
                        for row in rows
                    ),
                "support_coverage_end_median":
                    statistics.median(coverages),
                "support_coverage_end_q25":
                    qtile(coverages, 0.25),
                "support_coverage_end_q75":
                    qtile(coverages, 0.75),
                "calls_median":
                    statistics.median(
                        int(row["calls"]) for row in rows
                    ),
                "object_ops_median":
                    statistics.median(
                        int(row["object_ops"]) for row in rows
                    ),
                "verified_qerror_geomean_median":
                    statistics.median(
                        float(row["verified_qerror_geomean"])
                        for row in rows
                    ),
            })

    write_csv(out / "feedback_summary.csv", summary)

    final_table: list[dict[str, Any]] = []
    for strategy, row in references.items():
        final_table.append({
            "strategy": strategy,
            "workload": "pre-workload",
            "floor": args.floor,
            "severe_edges": len(severe),
            **row,
        })
    for row in summary:
        final_table.append({
            "strategy": row["policy"],
            "workload": row["workload"],
            "floor": args.floor,
            "severe_edges": len(severe),
            "maintenance_seconds_median":
                row["maintenance_seconds_median"],
            "maintenance_seconds_iqr":
                row["maintenance_seconds_iqr"],
            "harmful_queries_median":
                row["harmful_queries_median"],
            "support_coverage_end_median":
                row["support_coverage_end_median"],
            "calls_median": row["calls_median"],
            "object_ops_median": row["object_ops_median"],
            "source": "Phase5G exact query-feedback replay",
        })
    write_csv(out / "final_strategy_table.csv", final_table)

    uniform_expectation = len(severe) * (
        1.0 - (1.0 - 1.0 / M) ** args.workload_length
    )

    report = {
        "floor": args.floor,
        "d": d,
        "M": M,
        "severe_edges": len(severe),
        "workload_length": args.workload_length,
        "uniform_first_victim_expectation": uniform_expectation,
        "phase5f_references": references,
        "feedback_summary": summary,
        "baseline_strength": (
            "Oracle feedback: exact Q-error and exact pair attribution "
            "after each normal query."
        ),
        "timing_scope": (
            "Reactive values measure additional statistics-maintenance "
            "time; normal workload-query execution is excluded as common."
        ),
        "mandatory_interpretation": [
            "Reactive feedback cannot prevent the first harmful query.",
            "Zipf workloads may leave cold severe pairs undiscovered.",
            "Windowed batching can reduce maintenance time but may allow "
            "repeated harm before a window closes.",
            "H_RMSP is a substantive housing attribute, but this experiment "
            "does not establish a causal COVID explanation.",
        ],
    }
    (out / "gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5G - EXACT QUERY-FEEDBACK BASELINE",
        "=" * 78,
        f"d / M                         : {d} / {M}",
        f"support floor                 : {args.floor}",
        f"real PG Q>=10 edges           : {len(severe)}",
        f"workload length               : {args.workload_length}",
        (
            "uniform first-victim E[H]  : "
            f"{uniform_expectation:.2f}"
        ),
        "",
        "PRE-WORKLOAD REFERENCES (PHASE 5F)",
        (
            "  full_pre                  "
            f"time={references['full_pre']['maintenance_seconds_median']:.3f}s "
            "harm=0 coverage=1.000"
        ),
        (
            "  proactive                 "
            f"time={references['proactive_screen_verify_refresh']['maintenance_seconds_median']:.3f}s "
            "harm=0 coverage=1.000 "
            f"plan={references['proactive_screen_verify_refresh']['refresh_plan']}"
        ),
        "",
        "ORACLE QUERY-FEEDBACK",
    ]
    for row in summary:
        lines.append(
            f"  {row['workload']:7s} "
            f"{row['policy']:24s} "
            f"time={row['maintenance_seconds_median']:.3f}s "
            f"IQR={row['maintenance_seconds_iqr']:.3f}s "
            f"harm={row['harmful_queries_median']:.1f} "
            f"coverage={row['support_coverage_end_median']:.3f} "
            f"calls={row['calls_median']:.1f}"
        )

    lines += [
        "",
        "MANDATORY INTERPRETATION",
        (
            "The feedback baseline is intentionally optimistic: it receives "
            "exact Q-error and exact pair attribution after each query."
        ),
        (
            "Proactive maintenance pays before the workload to obtain zero "
            "harm and complete cold-edge coverage."
        ),
        "",
        "PROGRESS",
        "Phase 5A cost calibration               PASS",
        "Phase 5B d=50 feedback prototype        PASS",
        "Phase 5C frontier optimality             PASS",
        "Phase 5D d=50 support spectrum           PASS",
        "Phase 5F d=109 support/runtime           PASS",
        "Phase 5G exact feedback baseline         PASS",
        "",
        "NEXT: artifact packaging and code freeze. No new experiment.",
    ]
    text = "\n".join(lines)
    (out / "gate_report.txt").write_text(text, encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
