#!/usr/bin/env python3
"""
EvoStats Phase 5B.2 — End-to-End Proactive Detection Audit
===========================================================

Purpose
-------
The original Phase 5B "proactive" row is an oracle maintenance upper bound:
it starts from the 48 real PostgreSQL Q>=10 edges and times only their refresh.
This audit separates that oracle row from two deployable proactive variants:

1. residual_all
   - score every pair with the residual-shape statistic;
   - select the existing BH-FDR shape-drift support;
   - refresh every selected pair.

2. residual_verify
   - score every pair with the residual-shape statistic;
   - select the BH-FDR shape-drift support;
   - proactively execute exact PostgreSQL probes only for those candidates;
   - retain candidates with real PostgreSQL Q-error >= threshold;
   - batch-refresh the verified support.

The script reports detection, verification, and refresh costs separately.
It never adds residual-compute time to the 48-edge oracle support and calls that
an end-to-end method.

Important scope
---------------
The residual-compute timing starts after the two fixed-size snapshot samples
have been materialized and encoded. Sample acquisition is reported as outside
this timing because the current experiments obtain samples from cached PUMS
CSV files rather than through a production DBMS sampling path.

The existing Phase 4B null calibration is treated as reference-time/offline
calibration. Online residual timing measures all-pair scoring over the current
snapshot and reference snapshot.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import itertools
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def qtile(values: list[float], q: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=np.float64), q))


def summarize(values: list[float]) -> dict[str, float]:
    return {
        "median": statistics.median(values),
        "q25": qtile(values, 0.25),
        "q75": qtile(values, 0.75),
        "iqr": qtile(values, 0.75) - qtile(values, 0.25),
    }


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def residual_score(
    X0: np.ndarray,
    X1: np.ndarray,
    i: int,
    j: int,
    ci: int,
    cj: int,
) -> float:
    def residual(X: np.ndarray) -> np.ndarray:
        joint = np.bincount(
            X[:, i].astype(np.int64) * cj
            + X[:, j].astype(np.int64),
            minlength=ci * cj,
        ).reshape(ci, cj).astype(np.float64)
        joint /= len(X)
        return (
            joint
            - joint.sum(axis=1, keepdims=True)
            @ joint.sum(axis=0, keepdims=True)
        )

    return 0.25 * float(np.abs(residual(X1) - residual(X0)).sum())


def establish_stale(
    conn,
    helper,
    schema: str,
    A: np.ndarray,
    B: np.ndarray,
    target: int,
) -> None:
    with conn.cursor() as cur:
        cur.execute(f'TRUNCATE TABLE "{schema}".fact')
    helper.load_array(conn, schema, A)
    helper.analyze_all(conn, schema, target)
    with conn.cursor() as cur:
        cur.execute(f'TRUNCATE TABLE "{schema}".fact')
    helper.load_array(conn, schema, B)


def close_groups(
    groups: list[set[int]],
) -> set[tuple[int, int]]:
    result: set[tuple[int, int]] = set()
    for group in groups:
        result.update(itertools.combinations(sorted(group), 2))
    return result


def verify_candidates(
    conn,
    helper,
    schema: str,
    candidates: list[dict[str, Any]],
    q_threshold: float,
) -> tuple[set[tuple[int, int]], list[dict[str, Any]], float]:
    verified: set[tuple[int, int]] = set()
    rows: list[dict[str, Any]] = []
    start = time.perf_counter()

    for candidate in candidates:
        result = helper.explain_pair(
            conn,
            schema,
            int(candidate["i"]),
            int(candidate["j"]),
            int(candidate["worst_i"]),
            int(candidate["worst_j"]),
        )
        q_error = float(result["q_error"])
        edge = (int(candidate["i"]), int(candidate["j"]))
        if q_error >= q_threshold:
            verified.add(edge)
        rows.append({
            "i": edge[0],
            "j": edge[1],
            "variable_i": candidate["variable_i"],
            "variable_j": candidate["variable_j"],
            "worst_i": int(candidate["worst_i"]),
            "worst_j": int(candidate["worst_j"]),
            "verified_pg_qerror": q_error,
            "verified_severe": int(q_error >= q_threshold),
        })

    return verified, rows, time.perf_counter() - start


def run_refresh(
    conn,
    helper,
    schema: str,
    groups: list[set[int]],
    target: int,
) -> float:
    start = time.perf_counter()
    for group in groups:
        helper.analyze_columns(
            conn, schema, sorted(group), target
        )
    return time.perf_counter() - start


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--cache-dir", type=Path, required=True)
    ap.add_argument("--phase4b-scores", type=Path, required=True)
    ap.add_argument("--phase4c-dir", type=Path, required=True)
    ap.add_argument("--phase5b-dir", type=Path, required=True)
    ap.add_argument("--helper", type=Path, required=True)
    ap.add_argument("--feedback-helper", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_feedback_detection")
    ap.add_argument("--rows", type=int, default=40_000)
    ap.add_argument("--max-vars", type=int, default=50)
    ap.add_argument("--max-cardinality", type=int, default=24)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--q-threshold", type=float, default=10.0)
    ap.add_argument("--batch-width", type=int, default=4)
    ap.add_argument("--repeats", type=int, default=10)
    args = ap.parse_args()

    if args.repeats < 10:
        raise ValueError("Final audit requires at least 10 repetitions")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    helper = load_module(args.helper, "phase4c_helper")
    feedback = load_module(args.feedback_helper, "phase5b_helper")

    qframe = pd.read_csv(args.phase4c_dir / "real_pair_qerrors.csv")
    severe_frame = qframe[qframe["stale_qerror"] >= args.q_threshold]
    severe_edges = {
        (int(row.i), int(row.j))
        for row in severe_frame.itertuples(index=False)
    }

    path_a = helper.find_cached_csv(args.cache_dir, 2019)
    path_b = helper.find_cached_csv(args.cache_dir, 2021)

    sample_start = time.perf_counter()
    raw_a = helper.uniform_sample_csv(path_a, args.rows, 2019)
    raw_b = helper.uniform_sample_csv(path_b, args.rows, 2021)
    sample_seconds = time.perf_counter() - sample_start

    variables, _ = helper.select_variables(
        raw_a, raw_b, args.max_vars, args.max_cardinality
    )
    encode_start = time.perf_counter()
    A, B, categories = helper.encode_frames(
        raw_a, raw_b, variables
    )
    encode_seconds = time.perf_counter() - encode_start
    cards = [len(values) for values in categories]
    d = len(variables)
    M = choose2(d)

    # Validate the direct-PG template order.
    for row in qframe.itertuples(index=False):
        i, j = int(row.i), int(row.j)
        if variables[i] != row.variable_i or variables[j] != row.variable_j:
            raise RuntimeError(
                f"Phase 4C variable mismatch at {(i, j)}"
            )

    shape = pd.read_csv(args.phase4b_scores)
    shape = shape[shape["significant_fdr"] == 1].copy()

    name_to_index = {name: index for index, name in enumerate(variables)}
    candidate_rows: list[dict[str, Any]] = []
    for row in shape.itertuples(index=False):
        if row.variable_i not in name_to_index or row.variable_j not in name_to_index:
            raise RuntimeError(
                "Phase 4B and Phase 4C variable sets do not match: "
                f"{row.variable_i}, {row.variable_j}"
            )
        i = name_to_index[row.variable_i]
        j = name_to_index[row.variable_j]
        if i > j:
            i, j = j, i
        candidate_rows.append({
            "i": i,
            "j": j,
            "variable_i": variables[i],
            "variable_j": variables[j],
            "worst_i": int(row.worst_i),
            "worst_j": int(row.worst_j),
            "residual_D": float(row.residual_D),
            "bh_qvalue": float(row.bh_qvalue),
        })

    residual_edges = {
        (int(row["i"]), int(row["j"]))
        for row in candidate_rows
    }
    residual_groups = feedback.bounded_greedy(
        residual_edges, args.batch_width
    )
    residual_closure = close_groups(residual_groups)

    severe_recall = (
        len(severe_edges & residual_edges) / len(severe_edges)
    )
    severe_covered_recall = (
        len(severe_edges & residual_closure) / len(severe_edges)
    )
    severe_precision = (
        len(severe_edges & residual_edges) / len(residual_edges)
    )

    # Time all-pair online residual scoring after samples are available.
    pairs = list(itertools.combinations(range(d), 2))
    _ = [
        residual_score(A, B, i, j, cards[i], cards[j])
        for i, j in pairs
    ]  # warm-up

    detector_times: list[float] = []
    detector_checksums: list[float] = []
    for repeat in range(args.repeats):
        start = time.perf_counter()
        scores = [
            residual_score(A, B, i, j, cards[i], cards[j])
            for i, j in pairs
        ]
        detector_times.append(time.perf_counter() - start)
        detector_checksums.append(float(sum(scores)))

    if max(detector_checksums) - min(detector_checksums) > 1e-10:
        raise RuntimeError("Residual detector checksum changed across repetitions")

    conn = helper.connect(args.dsn)
    all_live_rows: list[dict[str, Any]] = []
    verification_rows_first: list[dict[str, Any]] = []
    try:
        helper.create_schema_and_table(conn, args.schema, d)
        helper.load_array(conn, args.schema, A)
        helper.create_all_statistics(conn, args.schema, d)

        for repeat in range(1, args.repeats + 1):
            # Deployable conservative variant: refresh all detected shape edges.
            establish_stale(
                conn, helper, args.schema, A, B,
                args.statistics_target
            )
            residual_refresh_seconds = run_refresh(
                conn, helper, args.schema, residual_groups,
                args.statistics_target
            )
            all_live_rows.append({
                "repeat": repeat,
                "strategy": "residual_all",
                "detected_edges": len(residual_edges),
                "verified_edges": "",
                "severe_edge_recall_before_closure": severe_recall,
                "severe_edge_recall_after_closure": severe_covered_recall,
                "calls": len(residual_groups),
                "object_ops": sum(
                    choose2(len(group))
                    for group in residual_groups
                ),
                "verification_seconds": 0.0,
                "refresh_seconds": residual_refresh_seconds,
            })

            # Deployable two-stage variant: residual screen + exact PG probes.
            establish_stale(
                conn, helper, args.schema, A, B,
                args.statistics_target
            )
            verified_edges, verification_rows, verify_seconds = (
                verify_candidates(
                    conn,
                    helper,
                    args.schema,
                    candidate_rows,
                    args.q_threshold,
                )
            )
            verified_groups = feedback.bounded_greedy(
                verified_edges, args.batch_width
            )
            verify_refresh_seconds = run_refresh(
                conn, helper, args.schema, verified_groups,
                args.statistics_target
            )
            verified_closure = close_groups(verified_groups)
            verified_recall = (
                len(severe_edges & verified_closure)
                / len(severe_edges)
            )
            all_live_rows.append({
                "repeat": repeat,
                "strategy": "residual_verify",
                "detected_edges": len(residual_edges),
                "verified_edges": len(verified_edges),
                "severe_edge_recall_before_closure": (
                    len(severe_edges & verified_edges)
                    / len(severe_edges)
                ),
                "severe_edge_recall_after_closure": verified_recall,
                "calls": len(verified_groups),
                "object_ops": sum(
                    choose2(len(group))
                    for group in verified_groups
                ),
                "verification_seconds": verify_seconds,
                "refresh_seconds": verify_refresh_seconds,
            })
            if repeat == 1:
                verification_rows_first = verification_rows
    finally:
        conn.close()

    write_csv(out / "detection_refresh_trials.csv", all_live_rows)
    write_csv(out / "candidate_verification_first_repeat.csv",
              verification_rows_first)

    detector_summary = summarize(detector_times)
    strategy_summary: list[dict[str, Any]] = []

    for strategy in ("residual_all", "residual_verify"):
        rows = [
            row for row in all_live_rows
            if row["strategy"] == strategy
        ]
        verify_values = [
            float(row["verification_seconds"])
            for row in rows
        ]
        refresh_values = [
            float(row["refresh_seconds"])
            for row in rows
        ]
        total_values = [
            detector_times[index]
            + verify_values[index]
            + refresh_values[index]
            for index in range(args.repeats)
        ]
        strategy_summary.append({
            "strategy": strategy,
            "repeats": args.repeats,
            "detected_edges": int(rows[0]["detected_edges"]),
            "verified_edges_median": (
                statistics.median(
                    [float(row["verified_edges"]) for row in rows]
                )
                if strategy == "residual_verify" else ""
            ),
            "severe_recall_before_closure_median": statistics.median(
                [float(row["severe_edge_recall_before_closure"])
                 for row in rows]
            ),
            "severe_recall_after_closure_median": statistics.median(
                [float(row["severe_edge_recall_after_closure"])
                 for row in rows]
            ),
            "calls_median": statistics.median(
                [float(row["calls"]) for row in rows]
            ),
            "object_ops_median": statistics.median(
                [float(row["object_ops"]) for row in rows]
            ),
            "detector_seconds_median": detector_summary["median"],
            "detector_seconds_iqr": detector_summary["iqr"],
            "verification_seconds_median": summarize(verify_values)["median"],
            "verification_seconds_iqr": summarize(verify_values)["iqr"],
            "refresh_seconds_median": summarize(refresh_values)["median"],
            "refresh_seconds_iqr": summarize(refresh_values)["iqr"],
            "compute_plus_refresh_seconds_median": summarize(total_values)["median"],
            "compute_plus_refresh_seconds_iqr": summarize(total_values)["iqr"],
        })

    write_csv(out / "detection_refresh_summary.csv", strategy_summary)

    # Read the original Phase 5B baselines for side-by-side comparison.
    baseline_path = args.phase5b_dir / "feedback_live_summary.csv"
    baseline_rows = (
        pd.read_csv(baseline_path).to_dict("records")
        if baseline_path.exists() else []
    )

    T = 5000
    expected_uniform_first_victims = (
        len(severe_edges)
        * (1.0 - (1.0 - 1.0 / M) ** T)
    )

    report = {
        "d": d,
        "M": M,
        "severe_edges": len(severe_edges),
        "residual_selected_edges": len(residual_edges),
        "residual_severe_precision": severe_precision,
        "residual_severe_recall": severe_recall,
        "residual_closure_severe_recall": severe_covered_recall,
        "batch_width": args.batch_width,
        "sample_materialization_seconds_single_run": sample_seconds,
        "encoding_seconds_single_run": encode_seconds,
        "online_residual_compute": detector_summary,
        "deployable_strategies": strategy_summary,
        "original_phase5b_live_rows": baseline_rows,
        "uniform_reactive_immediate_expectation": {
            "workload_length": T,
            "expected_distinct_first_victims":
                expected_uniform_first_victims,
            "identity": (
                "For exact immediate feedback, harmful queries equal the "
                "number of distinct severe edges queried at least once, "
                "unless collateral batch refresh repairs an edge first."
            ),
        },
        "interpretation": {
            "oracle_row": (
                "The original proactive row remains an oracle refresh-only "
                "upper bound and must not be presented as end-to-end."
            ),
            "residual_all": (
                "A deployable conservative strategy that avoids D-to-Q "
                "calibration by refreshing every statistically significant "
                "shape-drift edge."
            ),
            "residual_verify": (
                "A deployable two-stage strategy that screens by residual "
                "shape drift and then proactively verifies only candidates "
                "with exact PostgreSQL probes before refresh."
            ),
            "sample_cost_scope": (
                "Online residual-compute timing excludes obtaining the fixed "
                "snapshot samples. CSV materialization time is reported "
                "separately and is not added to DBMS wall-clock comparisons."
            ),
        },
    }

    (out / "gate_report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )

    lines = [
        "EVOSTATS PHASE 5B.2 - END-TO-END PROACTIVE DETECTION AUDIT",
        "=" * 78,
        f"d / M                         : {d} / {M}",
        f"real PG severe edges         : {len(severe_edges)}",
        f"residual BH-FDR candidates   : {len(residual_edges)}",
        f"candidate precision          : {severe_precision:.3f}",
        f"severe recall before closure : {severe_recall:.3f}",
        f"severe recall after closure  : {severe_covered_recall:.3f}",
        f"batch width                  : {args.batch_width}",
        "",
        "ONLINE RESIDUAL COMPUTE (samples already available)",
        (
            f"median={detector_summary['median']:.3f}s "
            f"IQR={detector_summary['iqr']:.3f}s"
        ),
        "",
        "DEPLOYABLE PROACTIVE STRATEGIES",
    ]
    for row in strategy_summary:
        lines.append(
            f"  {row['strategy']:18s} "
            f"selected={row['detected_edges']} "
            f"verified={row['verified_edges_median']} "
            f"recall={row['severe_recall_after_closure_median']:.3f} "
            f"calls={row['calls_median']:.1f} "
            f"objects={row['object_ops_median']:.1f} "
            f"verify={row['verification_seconds_median']:.3f}s "
            f"refresh={row['refresh_seconds_median']:.3f}s "
            f"compute+verify+refresh="
            f"{row['compute_plus_refresh_seconds_median']:.3f}s"
        )

    lines += [
        "",
        "REACTIVE FIRST-VICTIM CHECK",
        (
            f"uniform expectation at T={T}: "
            f"{expected_uniform_first_victims:.2f} distinct first victims"
        ),
        "",
        "MANDATORY INTERPRETATION",
        (
            "The original 48-edge proactive timing is an oracle "
            "refresh-only upper bound."
        ),
        (
            "Do not add residual runtime to the oracle 48-edge support: "
            "the residual detector does not output that support exactly."
        ),
        (
            "Use residual_all or residual_verify for end-to-end proactive "
            "comparisons."
        ),
    ]

    text = "\n".join(lines)
    (out / "gate_report.txt").write_text(text, encoding="utf-8")
    print("\n" + text)


if __name__ == "__main__":
    main()
