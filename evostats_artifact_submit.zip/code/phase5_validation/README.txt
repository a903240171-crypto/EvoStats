﻿Replace the existing runner in:

D:\ICDE-SignedSketch\vldb 升级版\phase5_validation

Preferred command:

powershell -ExecutionPolicy Bypass -File `
  "D:\ICDE-SignedSketch\vldb 升级版\phase5_validation\run_phase5b_feedback.ps1" `
  -PgPassword "123456"

Parser-proof fallback:

"D:\ICDE-SignedSketch\vldb 升级版\phase5_validation\run_phase5b_feedback.cmd" 123456
