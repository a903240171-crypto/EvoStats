import sys, importlib.util as u
from pathlib import Path
import pandas as pd, math

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_no_hub_geometry_ablation as m6a   # 只借 graph_stats

def load(p, n):
    s = u.spec_from_file_location(n, str(p)); m = u.module_from_spec(s)
    s.loader.exec_module(m); return m
p5f = load(ROOT / "code" / "phase5_validation" / "run_phase5f_d109.py", "p5f")

HUB_IDX = 52          # H_RMSP 的列索引，若不对请改
FLOOR, WIDTHS = 20, [3, 4, 6, 8, 12, 16]
OUT = ROOT / "results" / "phase6a_no_hub_ablation_p5fplanner"
OUT.mkdir(parents=True, exist_ok=True)

sp = pd.read_csv(ROOT / "results" / "phase5f_d109_support_runtime" / "support_pairs.csv")
fz = sp[(sp.floor == FLOOR) & (sp.pg_severe == 1)]
full_i = {tuple(sorted((int(a), int(b)))) for a, b in zip(fz.i, fz.j)}
assert len(full_i) == len(fz), "duplicate edges in frozen set"
hub_name = fz[(fz.i == HUB_IDX) | (fz.j == HUB_IDX)].variable_i.tolist()[:1]
print(f"frozen={len(full_i)}  hub_idx={HUB_IDX}  hub_incident={sum(HUB_IDX in e for e in full_i)}")
nohub_i = {e for e in full_i if HUB_IDX not in e}
print(f"no_hub edges={len(nohub_i)}")

def name_edges(E): return {m6a.canonical_edge(f"c{a}", f"c{b}") for a, b in E}
conds_i = {"full": full_i, "no_hub": nohub_i}

srows, prows = [], []
for cond, Ei in conds_i.items():
    st = m6a.graph_stats(cond, name_edges(Ei), f"c{HUB_IDX}")
    srows.append(st)
    for w in WIDTHS:
        g = p5f.bounded_greedy(Ei, w)
        slots = sum(len(x)*(len(x)-1)//2 for x in g)
        cap = math.ceil(len(Ei) / (w*(w-1)//2))
        mlb = math.ceil(st["matching_size"] / max(1, w//2))
        dlb = math.ceil(st["max_degree"] / (w - 1)) if w > 1 else st["max_degree"]
        lb  = max(cap, mlb, dlb, 1)
        prows.append(dict(condition=cond, width=w, calls=len(g), slots=slots,
                          widths=str(sorted((len(x) for x in g), reverse=True)[:4]),
                          capacity_lb=cap, matching_lb=mlb, degree_lb=dlb,
                          lower_bound=lb, call_gap=len(g)/lb))
sdf, pdf = pd.DataFrame(srows), pd.DataFrame(prows)
sdf.to_csv(OUT / "graph_geometry_summary.csv", index=False)
pdf.to_csv(OUT / "planner_summary.csv", index=False)
print("=" * 96)
print(sdf[["condition","edges","active_vertices","components","max_degree",
           "degree_gini","hub_degree","hub_edge_fraction","matching_size"]].to_string(index=False))
print()
print(pdf.to_string(index=False))
print("\n[write]", OUT)
