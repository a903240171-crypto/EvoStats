#!/usr/bin/env python3
"""
Phase 6A: leave-one-hub-out geometry ablation for EvoStats (clean rewrite).

Run from project root:
    python phase6_review\\run_no_hub_geometry_ablation.py

Reads results/phase4g_ambient_width/qerrors_d109.csv (no resampling).
Builds the severe stale-support graph (actual_rows >= support-floor,
stale_qerror >= qerror-threshold), then compares:
    (a) full graph
    (b) graph with all H_RMSP-incident edges removed
Reports geometry + deterministic bounded-width planner for several B.

Column names are fixed to this CSV's schema:
    variable_i, variable_j, actual_rows, stale_qerror
"""
from __future__ import annotations
import argparse
import json
import math
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Dict, List, Set, Tuple

import matplotlib.pyplot as plt
import pandas as pd

Edge = Tuple[str, str]


def canonical_edge(a, b) -> Edge:
    x, y = str(a).strip(), str(b).strip()
    return (x, y) if x <= y else (y, x)


def build_adjacency(edges) -> Dict[str, Set[str]]:
    adj: Dict[str, Set[str]] = defaultdict(set)
    for u, v in edges:
        if u == v:
            continue
        adj[u].add(v)
        adj[v].add(u)
    return dict(adj)


def connected_components(adj: Dict[str, Set[str]]) -> List[Set[str]]:
    unseen = set(adj)
    comps: List[Set[str]] = []
    while unseen:
        root = min(unseen)
        q = deque([root])
        unseen.remove(root)
        comp = {root}
        while q:
            u = q.popleft()
            for w in sorted(adj.get(u, ())):
                if w in unseen:
                    unseen.remove(w)
                    comp.add(w)
                    q.append(w)
        comps.append(comp)
    return sorted(comps, key=lambda c: (-len(c), sorted(c)))


def greedy_maximal_matching(edges: Set[Edge]) -> Set[Edge]:
    """Deterministic maximal matching: sorted-edge sweep, take if both free.
    Verified against manual count (no_hub 32 edges -> 7)."""
    used: Set[str] = set()
    matching: Set[Edge] = set()
    for u, v in sorted(edges):
        if u == v:
            continue
        if u not in used and v not in used:
            matching.add((u, v))
            used.add(u)
            used.add(v)
    return matching


def gini(values) -> float:
    vals = sorted(float(v) for v in values if v >= 0)
    if not vals or sum(vals) == 0:
        return 0.0
    n = len(vals)
    weighted = sum((i + 1) * x for i, x in enumerate(vals))
    return (2.0 * weighted) / (n * sum(vals)) - (n + 1.0) / n


def graph_stats(condition: str, edges: Set[Edge], hub: str) -> dict:
    adj = build_adjacency(edges)
    degrees = [len(v) for v in adj.values()]
    comps = connected_components(adj)
    matching = greedy_maximal_matching(edges)
    active = len(adj)
    hub_degree = len(adj.get(hub, set()))
    med = float(pd.Series(degrees).median()) if degrees else 0.0
    return dict(
        condition=condition,
        hub=hub,
        active_vertices=active,
        edges=len(edges),
        components=len(comps),
        largest_component=max((len(c) for c in comps), default=0),
        max_degree=max(degrees, default=0),
        mean_degree=(sum(degrees) / len(degrees)) if degrees else 0.0,
        median_degree=med,
        degree_gini=gini(degrees),
        hub_degree=hub_degree,
        hub_edge_fraction=(hub_degree / len(edges)) if edges else 0.0,
        matching_size=len(matching),
        edge_cover_vertex_lb=max(0, active - len(matching)),
    )


def induced_slots(group) -> int:
    n = len(group)
    return n * (n - 1) // 2


def covered_edges(group: Set[str], uncovered: Set[Edge]) -> Set[Edge]:
    return {e for e in uncovered if e[0] in group and e[1] in group}


def greedy_bounded_groups(edges: Set[Edge], width: int) -> List[List[str]]:
    if width < 2:
        raise ValueError("width must be >= 2")
    uncovered = set(edges)
    groups: List[List[str]] = []
    while uncovered:
        degree = Counter()
        nbrs: Dict[str, Set[str]] = defaultdict(set)
        for u, v in uncovered:
            degree[u] += 1
            degree[v] += 1
            nbrs[u].add(v)
            nbrs[v].add(u)
        seed = min(degree, key=lambda x: (-degree[x], x))
        group: Set[str] = {seed}
        while len(group) < width:
            cands = set()
            for u in group:
                cands.update(nbrs.get(u, set()))
            cands.difference_update(group)
            if not cands:
                break
            def gain(v):
                cg = set(group)
                cg.add(v)
                return (len(covered_edges(cg, uncovered)),
                        sum(canonical_edge(v, u) in uncovered for u in group), v)
            best = sorted(cands, key=lambda v: (-gain(v)[0], -gain(v)[1], v))[0]
            if gain(best)[0] <= len(covered_edges(group, uncovered)):
                break
            group.add(best)
        hit = covered_edges(group, uncovered)
        if not hit:
            u, v = min(uncovered)
            group = {u, v}
            hit = {(u, v)}
        groups.append(sorted(group))
        uncovered.difference_update(hit)
    return groups


def plan_summary(condition, edges, width, groups, matching_size) -> dict:
    slots = sum(induced_slots(g) for g in groups)
    calls = len(groups)
    useful = len(edges)
    capacity = width * (width - 1) // 2
    capacity_lb = math.ceil(useful / capacity) if useful else 0
    matching_lb = math.ceil(matching_size / max(1, width // 2)) if useful else 0
    lb = max(capacity_lb, matching_lb, 1) if useful else 0
    return dict(
        condition=condition,
        width=width,
        calls=calls,
        total_pair_slots=slots,
        useful_edges=useful,
        closure_overhead=slots - useful,
        useful_fraction=(useful / slots) if slots else 1.0,
        avg_group_width=(sum(len(g) for g in groups) / calls) if calls else 0.0,
        max_group_width=max((len(g) for g in groups), default=0),
        capacity_call_lb=capacity_lb,
        matching_call_lb=matching_lb,
        lower_bound_calls=lb,
        call_gap=(calls / lb) if lb else 1.0,
    )


def make_figure(stats_df, plans_df, out_path):
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.6))
    x = range(len(stats_df))
    axes[0].bar(x, stats_df["edges"])
    axes[0].set_xticks(list(x), stats_df["condition"])
    axes[0].set_ylabel("Severe edges")
    axes[0].set_title("Graph size after hub removal")
    for i, row in stats_df.reset_index(drop=True).iterrows():
        axes[0].text(i, row["edges"], f"{int(row['edges'])}", ha="center", va="bottom")
    for cond, part in plans_df.groupby("condition", sort=False):
        axes[1].plot(part["width"], part["total_pair_slots"], marker="o", label=cond)
    axes[1].set_xlabel("Maximum ANALYZE width B")
    axes[1].set_ylabel("Induced pair slots")
    axes[1].set_title("Same planner, different geometry")
    axes[1].legend()
    fig.tight_layout()
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path,
                    default=Path("results/phase4g_ambient_width/qerrors_d109.csv"))
    ap.add_argument("--output-dir", type=Path,
                    default=Path("results/phase6a_no_hub_ablation"))
    ap.add_argument("--hub", default="H_RMSP")
    ap.add_argument("--support-floor", type=float, default=20.0)
    ap.add_argument("--qerror-threshold", type=float, default=10.0)
    ap.add_argument("--widths", nargs="+", type=int, default=[3, 4, 6, 8, 12, 16])
    args = ap.parse_args()

    src = args.input.resolve()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(src)
    print(f"[load] {src}  rows={len(df)} cols={list(df.columns)}")

    # fixed column names for this CSV
    L, R, SUP, QE = "variable_i", "variable_j", "actual_rows", "stale_qerror"
    for c in (L, R, SUP, QE):
        if c not in df.columns:
            raise KeyError(f"expected column {c!r} not in {list(df.columns)}")

    sup = pd.to_numeric(df[SUP], errors="coerce")
    qe = pd.to_numeric(df[QE], errors="coerce")
    li = df[L].map(lambda x: str(x).strip())
    ri = df[R].map(lambda x: str(x).strip())
    mask = (sup >= args.support_floor) & (qe >= args.qerror_threshold) & li.ne("") & ri.ne("") & li.ne(ri)
    severe = df[mask].copy()
    edges_list = [canonical_edge(a, b) for a, b in zip(li[mask], ri[mask])]
    full_edges = set(edges_list)
    no_hub_edges = {e for e in full_edges if args.hub not in e}

    if not full_edges:
        raise RuntimeError("no severe edges selected; check thresholds")
    if not any(args.hub in e for e in full_edges):
        raise RuntimeError(f"hub {args.hub!r} not in graph")

    conditions = {"full": full_edges, "no_hub": no_hub_edges}
    stats = [graph_stats(n, e, args.hub) for n, e in conditions.items()]
    stats_df = pd.DataFrame(stats)
    by_cond = {s["condition"]: s for s in stats}

    plan_rows = []
    for cond, edges in conditions.items():
        for w in sorted(set(args.widths)):
            groups = greedy_bounded_groups(edges, w)
            plan_rows.append(plan_summary(cond, edges, w, groups, by_cond[cond]["matching_size"]))
    plans_df = pd.DataFrame(plan_rows)

    stats_df.to_csv(out / "graph_geometry_summary.csv", index=False)
    plans_df.to_csv(out / "planner_summary.csv", index=False)
    (out / "run_manifest.json").write_text(json.dumps({
        "input": str(src), "hub": args.hub,
        "support_floor": args.support_floor, "qerror_threshold": args.qerror_threshold,
        "full_edges": len(full_edges), "no_hub_edges": len(no_hub_edges),
    }, indent=2), encoding="utf-8")
    make_figure(stats_df, plans_df, out / "no_hub_geometry_ablation.pdf")

    print("=" * 88)
    print("PHASE 6A COMPLETE")
    print("=" * 88)
    print(stats_df.to_string(index=False))
    print()
    print(plans_df.to_string(index=False))
    print()
    print(f"[write] {out}")


if __name__ == "__main__":
    main()
