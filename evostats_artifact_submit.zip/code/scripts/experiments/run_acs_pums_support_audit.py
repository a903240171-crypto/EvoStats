#!/usr/bin/env python3
"""
EvoStats Phase 4A — ACS PUMS Real-Wide-Table Support Audit
==========================================================

Purpose
-------
Test the final unverified assumption behind the sublinear localization claim:

    On a real wide table, is dependency drift sparse and structurally
    concentrated (hub/block), or is it diffuse/dense?

This audit downloads two official ACS 1-year Person PUMS files from the U.S.
Census Bureau, selects a shared set of categorical variables, computes
contingency-residual drift for every candidate pair, calibrates a null envelope
using within-year split halves, and characterizes the support geometry.

This is NOT used to prove that bijective relabeling is common. It tests whether
the real drift support falls into the sparse/structured regime where
Theta(M/s + d) localization is useful.

Default
-------
State: California
Years: 2022 vs 2024
Variables: up to 80 shared categorical columns
Rows per year: up to 80,000 sampled records
Cardinality: 2..24 categories
Null calibration: repeated within-year split halves
Pair universe: up to C(80,2)=3,160

Outputs
-------
variable_selection.csv
pair_drift_scores.csv
null_calibration.csv
support_summary.csv
degree_summary.csv
gate_report.json
gate_report.txt
config.json
"""

from __future__ import annotations

import argparse
import csv
import io
import itertools
import json
import math
import random
import statistics
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


CENSUS_BASE = (
    "https://www2.census.gov/programs-surveys/acs/data/pums/"
    "{year}/1-Year/csv_p{state}.zip"
)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

def choose2(n: int) -> int:
    return n * (n - 1) // 2



def download(
    url: str,
    path: Path,
    retries: int = 6,
    chunk_size: int = 1024 * 1024,
) -> None:
    """
    Robust resumable download.

    - writes to `<name>.part`;
    - resumes with HTTP Range when possible;
    - retries incomplete transfers with exponential backoff;
    - validates ZIP integrity before atomic rename;
    - discards a corrupt partial file and restarts cleanly.
    """
    import http.client
    import time as _time

    def valid_zip(p: Path) -> bool:
        if not p.exists() or p.stat().st_size == 0:
            return False
        try:
            with zipfile.ZipFile(p) as zf:
                return zf.testzip() is None
        except zipfile.BadZipFile:
            return False

    if valid_zip(path):
        print(f"[download] cached {path.name}", flush=True)
        return

    part = path.with_suffix(path.suffix + ".part")

    # A previous failed version may have written a truncated file directly to
    # the final path. Move it to the resumable .part location.
    if path.exists() and not valid_zip(path):
        if part.exists():
            path.unlink()
        else:
            path.replace(part)

    for attempt in range(1, retries + 1):
        offset = part.stat().st_size if part.exists() else 0
        headers = {"User-Agent": "EvoStats-Research/1.0"}
        if offset > 0:
            headers["Range"] = f"bytes={offset}-"

        print(
            f"[download] attempt={attempt}/{retries} "
            f"resume_from={offset:,} {url}",
            flush=True,
        )

        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=300) as response:
                status = getattr(response, "status", response.getcode())

                # If the server ignores Range and returns the full file, restart
                # the partial file rather than appending duplicate bytes.
                append = offset > 0 and status == 206
                mode = "ab" if append else "wb"
                if offset > 0 and not append:
                    print(
                        "[download] server ignored Range; restarting file",
                        flush=True,
                    )

                with part.open(mode) as fh:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        fh.write(chunk)

            if valid_zip(part):
                part.replace(path)
                print(
                    f"[download] completed {path.name} "
                    f"size={path.stat().st_size:,}",
                    flush=True,
                )
                return

            print(
                f"[download] transfer ended but ZIP is incomplete "
                f"size={part.stat().st_size:,}",
                flush=True,
            )

        except (
            urllib.error.URLError,
            TimeoutError,
            ConnectionError,
            http.client.IncompleteRead,
            OSError,
        ) as exc:
            print(
                f"[download] interrupted: {type(exc).__name__}: {exc}",
                flush=True,
            )

        if attempt < retries:
            delay = min(30, 2 ** attempt)
            print(f"[download] retrying in {delay}s", flush=True)
            _time.sleep(delay)

    raise RuntimeError(
        f"Download failed after {retries} attempts: {url}. "
        f"Partial file retained at {part} for the next run."
    )


def extract_person_csv(zip_path: Path, out_dir: Path) -> Path:
    with zipfile.ZipFile(zip_path) as zf:
        members = [
            name for name in zf.namelist()
            if name.lower().endswith(".csv")
            and (
                "psam_p" in name.lower()
                or name.lower().startswith("psam_p")
            )
        ]
        if not members:
            members = [
                name for name in zf.namelist()
                if name.lower().endswith(".csv")
            ]
        if not members:
            raise RuntimeError(f"No CSV found in {zip_path}")

        member = sorted(members, key=len)[0]
        target = out_dir / Path(member).name
        if not target.exists():
            print(f"[extract] {zip_path.name} -> {target.name}", flush=True)
            with zf.open(member) as src, target.open("wb") as dst:
                dst.write(src.read())
        return target


def load_uniform_sample(
    csv_path: Path,
    sample_rows: int,
    seed: int,
) -> pd.DataFrame:
    """
    Uniform sample over the full CSV using random priorities per row.

    For each chunk, assign IID U(0,1) priorities, retain the globally smallest
    `sample_rows` priorities, and discard the rest. This avoids taking only the
    first few chunks of a potentially ordered PUMS file.
    """
    rng = np.random.default_rng(seed)
    kept_frames: list[pd.DataFrame] = []
    kept_keys: list[np.ndarray] = []

    for chunk in pd.read_csv(
        csv_path,
        dtype=str,
        chunksize=50_000,
        low_memory=False,
    ):
        if len(chunk) == 0:
            continue
        keys = rng.random(len(chunk))
        if len(chunk) > sample_rows:
            idx = np.argpartition(keys, sample_rows - 1)[:sample_rows]
            chunk = chunk.iloc[idx].copy()
            keys = keys[idx]
        kept_frames.append(chunk)
        kept_keys.append(keys)

        total = sum(len(x) for x in kept_frames)
        if total > sample_rows * 3:
            frame = pd.concat(kept_frames, ignore_index=True)
            all_keys = np.concatenate(kept_keys)
            idx = np.argpartition(all_keys, sample_rows - 1)[:sample_rows]
            kept_frames = [frame.iloc[idx].copy()]
            kept_keys = [all_keys[idx]]

    frame = pd.concat(kept_frames, ignore_index=True)
    all_keys = np.concatenate(kept_keys)
    if len(frame) > sample_rows:
        idx = np.argpartition(all_keys, sample_rows - 1)[:sample_rows]
        frame = frame.iloc[idx]
    return frame.reset_index(drop=True)


def matched_null_partitions(
    pool: pd.DataFrame,
    n_each: int,
    repeats: int,
    seed: int,
) -> list[tuple[pd.DataFrame, pd.DataFrame]]:
    """
    Repeated matched-size null comparisons.

    Every repeat partitions the same 2*n pool into two non-overlapping n-row
    halves. Thus the null and the real year-to-year comparison use identical
    per-snapshot sample sizes.
    """
    if len(pool) < 2 * n_each:
        raise ValueError(
            f"Need at least {2*n_each} rows for matched null; got {len(pool)}"
        )

    rng = np.random.default_rng(seed)
    out = []
    base = np.arange(len(pool))
    for _ in range(repeats):
        order = rng.permutation(base)
        left = pool.iloc[order[:n_each]].reset_index(drop=True)
        right = pool.iloc[order[n_each:2*n_each]].reset_index(drop=True)
        out.append((left, right))
    return out


def normalized_series(s: pd.Series) -> pd.Series:
    x = s.astype("string").fillna("<NA>").str.strip()
    x = x.replace({"": "<NA>", "nan": "<NA>", "None": "<NA>"})
    return x


def select_variables(
    a: pd.DataFrame,
    b: pd.DataFrame,
    max_vars: int,
    min_cardinality: int,
    max_cardinality: int,
    max_missing: float,
) -> tuple[list[str], list[dict[str, Any]]]:
    exclude_prefixes = (
        "PWGTP", "WGTP", "SERIALNO", "SPORDER",
        "ADJINC", "ADJHSG",
    )
    common = sorted(set(a.columns) & set(b.columns))

    rows = []
    for col in common:
        if col.upper().startswith(exclude_prefixes):
            continue

        sa = normalized_series(a[col])
        sb = normalized_series(b[col])
        miss_a = float((sa == "<NA>").mean())
        miss_b = float((sb == "<NA>").mean())
        ca = int(sa.nunique(dropna=False))
        cb = int(sb.nunique(dropna=False))
        union_card = int(pd.concat([sa, sb]).nunique(dropna=False))

        eligible = (
            miss_a <= max_missing
            and miss_b <= max_missing
            and min_cardinality <= union_card <= max_cardinality
            and ca >= min_cardinality
            and cb >= min_cardinality
        )

        # Prefer stable cardinality, low missingness, and nontrivial variables.
        score = (
            -abs(ca - cb)
            - 5.0 * (miss_a + miss_b)
            + math.log1p(union_card)
        )

        rows.append({
            "variable": col,
            "cardinality_year_a": ca,
            "cardinality_year_b": cb,
            "union_cardinality": union_card,
            "missing_year_a": miss_a,
            "missing_year_b": miss_b,
            "eligible": int(eligible),
            "selection_score": score,
        })

    eligible_rows = [r for r in rows if r["eligible"] == 1]
    eligible_rows.sort(
        key=lambda r: (
            -r["selection_score"],
            r["union_cardinality"],
            r["variable"],
        )
    )
    selected = [r["variable"] for r in eligible_rows[:max_vars]]
    selected_set = set(selected)
    for row in rows:
        row["selected"] = int(row["variable"] in selected_set)

    if len(selected) < 20:
        raise RuntimeError(
            f"Only {len(selected)} variables selected; relax filters"
        )
    return selected, rows


def build_category_maps(
    frames: list[pd.DataFrame],
    variables: list[str],
) -> dict[str, list[str]]:
    """
    Freeze one category universe per variable across every real and null frame.

    This prevents a pair from using a different contingency-table shape in the
    real comparison and in the null comparisons.
    """
    maps: dict[str, list[str]] = {}
    for col in variables:
        values: set[str] = set()
        for frame in frames:
            values.update(normalized_series(frame[col]).unique().tolist())
        maps[col] = sorted(values)
    return maps


def encode_joint(
    a: pd.Series,
    b: pd.Series,
    categories_a: list[str],
    categories_b: list[str],
) -> np.ndarray:
    amap = {v: i for i, v in enumerate(categories_a)}
    bmap = {v: i for i, v in enumerate(categories_b)}
    ai = normalized_series(a).map(amap).fillna(-1).astype(np.int32).to_numpy()
    bi = normalized_series(b).map(bmap).fillna(-1).astype(np.int32).to_numpy()
    valid = (ai >= 0) & (bi >= 0)
    joint = np.bincount(
        ai[valid].astype(np.int64) * len(categories_b)
        + bi[valid].astype(np.int64),
        minlength=len(categories_a) * len(categories_b),
    ).reshape(len(categories_a), len(categories_b)).astype(np.float64)
    if joint.sum() == 0:
        return joint
    return joint / joint.sum()


def residual_from_joint(joint: np.ndarray) -> np.ndarray:
    if joint.sum() == 0:
        return joint
    return joint - joint.sum(1, keepdims=True) @ joint.sum(0, keepdims=True)


def residual_distance_fixed(
    a1: pd.Series,
    b1: pd.Series,
    a2: pd.Series,
    b2: pd.Series,
    categories_a: list[str],
    categories_b: list[str],
) -> float:
    j1 = encode_joint(a1, b1, categories_a, categories_b)
    j2 = encode_joint(a2, b2, categories_a, categories_b)
    return 0.25 * float(
        np.abs(residual_from_joint(j2) - residual_from_joint(j1)).sum()
    )


def prepare(frame: pd.DataFrame, variables: list[str]) -> pd.DataFrame:
    out = pd.DataFrame(index=frame.index)
    for col in variables:
        out[col] = normalized_series(frame[col])
    return out


def benjamini_hochberg(pvalues: np.ndarray) -> np.ndarray:
    """Return BH-adjusted q-values."""
    m = len(pvalues)
    order = np.argsort(pvalues)
    ranked = pvalues[order]
    adjusted = ranked * m / np.arange(1, m + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0.0, 1.0)
    out = np.empty(m, dtype=np.float64)
    out[order] = adjusted
    return out


def pairwise_real_and_null(
    A: pd.DataFrame,
    B: pd.DataFrame,
    null_partitions: list[tuple[pd.DataFrame, pd.DataFrame]],
    variables: list[str],
    category_maps: dict[str, list[str]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """
    Pair-specific matched-null calibration.

    Each pair receives its own null distribution using the same sample size and
    the same frozen contingency-table dimensions as the real comparison.
    """
    rows: list[dict[str, Any]] = []
    null_long: list[dict[str, Any]] = []
    total = choose2(len(variables))
    done = 0

    for i, j in itertools.combinations(range(len(variables)), 2):
        x, y = variables[i], variables[j]
        cats_x = category_maps[x]
        cats_y = category_maps[y]

        real = residual_distance_fixed(
            A[x], A[y], B[x], B[y], cats_x, cats_y
        )
        null_values = []
        for rep, (left, right) in enumerate(null_partitions, start=1):
            score = residual_distance_fixed(
                left[x], left[y], right[x], right[y], cats_x, cats_y
            )
            null_values.append(score)
            null_long.append({
                "repeat": rep,
                "i": i,
                "j": j,
                "variable_i": x,
                "variable_j": y,
                "null_score": score,
                "cells": len(cats_x) * len(cats_y),
            })

        null_arr = np.asarray(null_values, dtype=np.float64)
        null_mean = float(null_arr.mean())
        null_std = float(null_arr.std(ddof=1)) if len(null_arr) > 1 else 0.0

        # One-sided empirical p-value with finite-sample correction.
        p_emp = (1.0 + float(np.sum(null_arr >= real))) / (len(null_arr) + 1.0)

        # Studentized excess is diagnostic only; BH uses empirical p-values.
        z = (
            (real - null_mean) / null_std
            if null_std > 0 else (
                float("inf") if real > null_mean else 0.0
            )
        )

        rows.append({
            "i": i,
            "j": j,
            "variable_i": x,
            "variable_j": y,
            "cells": len(cats_x) * len(cats_y),
            "residual_drift": real,
            "null_mean": null_mean,
            "null_std": null_std,
            "null_p95": float(np.quantile(null_arr, 0.95)),
            "null_p99": float(np.quantile(null_arr, 0.99)),
            "excess_over_null": real - null_mean,
            "z_score": z,
            "empirical_p": p_emp,
        })

        done += 1
        if done % 500 == 0 or done == total:
            print(f"[pairs] {done}/{total}", flush=True)

    pvalues = np.asarray([r["empirical_p"] for r in rows], dtype=np.float64)
    qvalues = benjamini_hochberg(pvalues)
    for row, qv in zip(rows, qvalues):
        row["bh_qvalue"] = float(qv)

    return rows, null_long



def connected_components(
    d: int,
    edges: set[tuple[int, int]],
) -> list[set[int]]:
    adj = [set() for _ in range(d)]
    for u, v in edges:
        adj[u].add(v)
        adj[v].add(u)

    seen = set()
    comps = []
    for node in range(d):
        if node in seen or not adj[node]:
            continue
        stack = [node]
        comp = set()
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            comp.add(x)
            stack.extend(adj[x] - seen)
        comps.append(comp)
    return sorted(comps, key=len, reverse=True)


def support_analysis(
    d: int,
    score_rows: list[dict[str, Any]],
    threshold: float,
    variables: list[str],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    support = {
        (int(r["i"]), int(r["j"]))
        for r in score_rows
        if (
            int(r.get("selected_bh_fdr", 0)) == 1
            if "selected_bh_fdr" in r
            else float(r["residual_drift"]) > threshold
        )
    }
    M = choose2(d)
    s = len(support)

    degrees = [0] * d
    for u, v in support:
        degrees[u] += 1
        degrees[v] += 1

    ranked = sorted(range(d), key=lambda x: degrees[x], reverse=True)
    edge_cover = []
    covered = set()
    for rank, node in enumerate(ranked, start=1):
        for edge in support:
            if node in edge:
                covered.add(edge)
        edge_cover.append({
            "rank": rank,
            "node": node,
            "variable": variables[node],
            "degree": degrees[node],
            "covered_edges": len(covered),
            "covered_fraction": len(covered) / max(s, 1),
        })

    comps = connected_components(d, support)
    active_nodes = {v for edge in support for v in edge}
    top1_cover = edge_cover[0]["covered_fraction"] if edge_cover else 0.0
    top5_cover = (
        edge_cover[min(4, len(edge_cover)-1)]["covered_fraction"]
        if edge_cover else 0.0
    )
    top10_cover = (
        edge_cover[min(9, len(edge_cover)-1)]["covered_fraction"]
        if edge_cover else 0.0
    )

    # Geometry labels are descriptive, not assumed.
    sparse = s / M <= 0.05
    hub_like = top1_cover >= 0.30 or top5_cover >= 0.70
    block_like = (
        len(comps) > 0
        and max(len(c) for c in comps) <= max(12, int(0.25*d))
        and top10_cover >= 0.70
    )

    summary = {
        "d": d,
        "M": M,
        "support_edges": s,
        "support_density": s / M,
        "active_nodes": len(active_nodes),
        "active_node_fraction": len(active_nodes) / d,
        "max_degree": max(degrees) if degrees else 0,
        "mean_active_degree": (
            statistics.mean(degrees[v] for v in active_nodes)
            if active_nodes else 0.0
        ),
        "top1_edge_cover": top1_cover,
        "top5_edge_cover": top5_cover,
        "top10_edge_cover": top10_cover,
        "components": len(comps),
        "largest_component_nodes": len(comps[0]) if comps else 0,
        "sparse_regime": sparse,
        "hub_like": hub_like,
        "block_like": block_like,
        "structured_regime": hub_like or block_like,
    }
    return edge_cover, summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--state", default="ca")
    ap.add_argument("--year-a", type=int, default=2019)
    ap.add_argument("--year-b", type=int, default=2021)
    ap.add_argument("--max-rows", type=int, default=80_000)
    ap.add_argument("--max-vars", type=int, default=80)
    ap.add_argument("--min-cardinality", type=int, default=2)
    ap.add_argument("--max-cardinality", type=int, default=24)
    ap.add_argument("--max-missing", type=float, default=0.20)
    ap.add_argument("--null-repeats", type=int, default=39)
    ap.add_argument("--null-quantile", type=float, default=0.995)
    ap.add_argument("--fdr", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    data_dir = out / "data"
    data_dir.mkdir(exist_ok=True)

    config = {**vars(args), "out": str(out)}
    (out / "config.json").write_text(
        json.dumps(config, indent=2, default=str),
        encoding="utf-8",
    )

    print(
        "EvoStats Phase 4A v5 - ACS PUMS Pair-Specific Null Audit\n"
        "================================================================\n"
        f"state={args.state}, years={args.year_a}->{args.year_b}, "
        f"max_rows={args.max_rows}, max_vars={args.max_vars}\n"
        "Question: is real dependency drift sparse and structured?\n"
        "Overall progress: [#########-] 90%\n",
        flush=True,
    )

    frames = {}
    csv_paths = {}
    for year in (args.year_a, args.year_b):
        url = CENSUS_BASE.format(year=year, state=args.state.lower())
        zip_path = data_dir / f"acs_{year}_p{args.state.lower()}.zip"
        download(url, zip_path)
        csv_path = extract_person_csv(zip_path, data_dir)
        csv_paths[year] = csv_path
        print(f"[load] year={year} file={csv_path.name}", flush=True)

    # Year A supplies both the real snapshot and a separate matched-size null
    # pool. Year B supplies one real snapshot.
    year_a_pool = load_uniform_sample(
        csv_paths[args.year_a],
        sample_rows=2 * args.max_rows,
        seed=args.seed + args.year_a,
    )
    frames[args.year_a] = year_a_pool.iloc[:args.max_rows].reset_index(drop=True)
    frames[args.year_b] = load_uniform_sample(
        csv_paths[args.year_b],
        sample_rows=args.max_rows,
        seed=args.seed + args.year_b,
    )

    print(
        f"[load] year={args.year_a} pool_rows={len(year_a_pool):,} "
        f"real_rows={len(frames[args.year_a]):,} "
        f"columns={len(frames[args.year_a].columns)}",
        flush=True,
    )
    print(
        f"[load] year={args.year_b} real_rows={len(frames[args.year_b]):,} "
        f"columns={len(frames[args.year_b].columns)}",
        flush=True,
    )

    selected, selection_rows = select_variables(
        frames[args.year_a],
        frames[args.year_b],
        max_vars=args.max_vars,
        min_cardinality=args.min_cardinality,
        max_cardinality=args.max_cardinality,
        max_missing=args.max_missing,
    )
    write_csv(out / "variable_selection.csv", selection_rows)
    print(
        f"[variables] selected={len(selected)} "
        f"M={choose2(len(selected)):,}",
        flush=True,
    )

    # Split raw rows first, then prepare each 80K snapshot separately.
    raw_partitions = matched_null_partitions(
        year_a_pool,
        n_each=args.max_rows,
        repeats=args.null_repeats,
        seed=args.seed,
    )

    A = prepare(frames[args.year_a], selected)
    B = prepare(frames[args.year_b], selected)
    prepared_partitions = [
        (prepare(left, selected), prepare(right, selected))
        for left, right in raw_partitions
    ]

    # Freeze category support across real and every null snapshot.
    category_maps = build_category_maps(
        [A, B]
        + [left for left, _ in prepared_partitions]
        + [right for _, right in prepared_partitions],
        selected,
    )

    scores, null_long = pairwise_real_and_null(
        A=A,
        B=B,
        null_partitions=prepared_partitions,
        variables=selected,
        category_maps=category_maps,
    )
    write_csv(out / "pair_null_scores.csv", null_long)

    for row in scores:
        row["selected_bh_fdr"] = int(row["bh_qvalue"] <= args.fdr)

    scores.sort(key=lambda r: float(r["residual_drift"]), reverse=True)
    write_csv(out / "pair_drift_scores.csv", scores)

    # Compact null diagnostics by repeat.
    null_rows = []
    for rep in range(1, args.null_repeats + 1):
        vals = [
            float(r["null_score"])
            for r in null_long
            if int(r["repeat"]) == rep
        ]
        null_rows.append({
            "repeat": rep,
            "rows_left": args.max_rows,
            "rows_right": args.max_rows,
            "mean": statistics.mean(vals),
            "p95": float(np.quantile(vals, 0.95)),
            "p99": float(np.quantile(vals, 0.99)),
            "p995": float(np.quantile(vals, 0.995)),
            "max": max(vals),
        })
    write_csv(out / "null_calibration.csv", null_rows)

    # Support is defined by pair-specific BH-FDR, not a pooled global cutoff.
    support_edges = {
        (int(r["i"]), int(r["j"]))
        for r in scores
        if int(r["selected_bh_fdr"]) == 1
    }

    support_scores = []
    for row in scores:
        copied = dict(row)
        copied["above_null_threshold"] = copied["selected_bh_fdr"]
        support_scores.append(copied)

    degree_rows, support = support_analysis(
        len(selected),
        support_scores,
        threshold=float("inf"),
        variables=selected,
    )

    sensitivity_rows = []
    for alpha in (0.01, 0.05, 0.10):
        detected = sum(float(r["bh_qvalue"]) <= alpha for r in scores)
        sensitivity_rows.append({
            "fdr": alpha,
            "detected_pairs": detected,
            "detected_density": detected / choose2(len(selected)),
        })
    write_csv(out / "threshold_sensitivity.csv", sensitivity_rows)

    # Pair-specific diagnostics.
    real_mean = statistics.mean(float(r["residual_drift"]) for r in scores)
    null_mean = statistics.mean(float(r["null_mean"]) for r in scores)
    write_csv(out / "degree_summary.csv", degree_rows)
    write_csv(out / "support_summary.csv", [support])

    # Decision is descriptive: either outcome is scientifically useful.
    localization_applicable = (
        support["sparse_regime"]
        and support["structured_regime"]
    )

    decision = {
        **support,
        "state": args.state,
        "year_a": args.year_a,
        "year_b": args.year_b,
        "rows_year_a": len(A),
        "rows_year_b": len(B),
        "fdr": args.fdr,
        "pair_specific_null_repeats": args.null_repeats,
        "mean_real_pair_score": real_mean,
        "mean_pair_specific_null_score": null_mean,
        "real_to_null_mean_ratio": real_mean / max(null_mean, 1e-15),
        "threshold_sensitivity": sensitivity_rows,
        "localization_applicable": localization_applicable,
        "decision": (
            "STRUCTURED-SPARSE: Theta(M/s+d) has a real-data applicability regime"
            if localization_applicable
            else (
                "SPARSE-BUT-DIFFUSE: residual monitoring remains useful, "
                "but exact sublinear localization needs a different structure model"
                if support["sparse_regime"]
                else (
                    "DENSE: retain shape-monitoring contribution; "
                    "do not headline sublinear localization as universal"
                )
            )
        ),
    }
    (out / "gate_report.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    top_pairs = scores[:20]
    lines = [
        "EVOSTATS PHASE 4A ACS PUMS SUPPORT REPORT",
        "=" * 78,
        "",
        f"State / years             : {args.state.upper()} "
        f"{args.year_a}->{args.year_b}",
        f"Rows                      : {len(A):,} / {len(B):,}",
        f"Selected variables        : {len(selected)}",
        f"Candidate pairs M         : {choose2(len(selected)):,}",
        f"Pair-specific null repeats: {args.null_repeats}",
        f"BH FDR                    : {args.fdr:.3f}",
        f"Mean real / null score    : {real_mean:.6f} / {null_mean:.6f}",
        f"Real/null mean ratio      : {real_mean / max(null_mean, 1e-15):.3f}",
        f"Detected support s        : {support['support_edges']}",
        f"Support density           : {support['support_density']:.4f}",
        f"Active nodes              : {support['active_nodes']}",
        f"Top-1 / Top-5 edge cover  : "
        f"{support['top1_edge_cover']:.3f} / "
        f"{support['top5_edge_cover']:.3f}",
        f"Components                : {support['components']}",
        f"Largest component nodes   : {support['largest_component_nodes']}",
        "",
        "TOP 20 PAIR DRIFTS",
    ]
    for row in top_pairs:
        lines.append(
            f"{row['variable_i']:16s} - {row['variable_j']:16s} "
            f"D={float(row['residual_drift']):.5f} "
            f"selected={row['selected_bh_fdr']} q={row['bh_qvalue']:.4f}"
        )

    lines += [
        "",
        "DECISION",
        json.dumps(decision, indent=2),
        "",
        decision["decision"],
        "",
        "Interpretation:",
        "- This audit tests support sparsity/geometry, not whether relabeling",
        "  itself is common.",
        "- A dense result does not invalidate shape monitoring; it limits only",
        "  the universal scope of the sublinear localization headline.",
    ]

    report = "\n".join(lines)
    (out / "gate_report.txt").write_text(report, encoding="utf-8")
    print("\n" + report)


if __name__ == "__main__":
    main()
