#!/usr/bin/env python3
"""
EvoStats Phase 0.5 v3 — Shared-Column Candidate-Graph Audit.

This is the corrected Phase 0.5 harness.

Corrections
-----------
1. Autovacuum/auto-ANALYZE is disabled on every fact table.
2. Staleness is checked explicitly before Q-error measurement.
3. d ordinary columns are shared across M=C(d,2) candidate pairs.
4. D0 is exactly pairwise independent using a finite-field construction.
5. D1 changes a sparse matching of s pairs while preserving every univariate
   marginal exactly.
6. ANALYZE timings are repeated five times and summarized by medians.
7. PostgreSQL refresh granularity is reported honestly:
   ANALYZE accepts columns, not individual extended-statistics objects.
   Selecting s disjoint changed edges touches 2s columns and refreshes the
   induced closure C(2s,2), not only s objects.

Default grid
------------
d = 20, 30, 40, 50
M = 190, 435, 780, 1225
s = 8 disjoint changed edges (or floor(d/2) if d<16)
domain = 61 (prime)
rows = 61^2 * 100 = 372,100
timing repeats = 5

Outputs
-------
scaling_detail.csv
scaling_summary.csv
candidate_profile.csv
gate_report.json
gate_report.txt
config.json
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import random
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import psycopg


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def parse_ints(text: str) -> list[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def qerror(est: float, act: float) -> float:
    e = max(float(est), 1.0)
    a = max(float(act), 1.0)
    return max(e / a, a / e)


def geomean(values: list[float]) -> float:
    return math.exp(sum(math.log(max(x, 1e-12)) for x in values) / len(values))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def connect(dsn: str):
    conn = psycopg.connect(dsn, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET jit = off")
        cur.execute("SET max_parallel_workers_per_gather = 0")
        cur.execute("SET track_io_timing = on")
        cur.execute("SET statement_timeout = 0")
    return conn


def all_pairs(d: int) -> list[tuple[int, int]]:
    return list(itertools.combinations(range(1, d + 1), 2))


def changed_matching(d: int, s: int, seed: int) -> list[tuple[int, int]]:
    if 2 * s > d:
        raise ValueError(f"Need d >= 2s; got d={d}, s={s}")
    rng = random.Random(seed + d)
    cols = list(range(1, d + 1))
    rng.shuffle(cols)
    chosen = sorted(cols[: 2 * s])
    return sorted(
        (min(chosen[2*k], chosen[2*k+1]), max(chosen[2*k], chosen[2*k+1]))
        for k in range(s)
    )


def setup_schema(
    conn,
    schema: str,
    d: int,
    domain: int,
    repeat_factor: int,
    statistics_target: int,
) -> int:
    rows = domain * domain * repeat_factor
    s = qi(schema)
    cols = ["id bigint PRIMARY KEY"] + [
        f"z{j} integer NOT NULL" for j in range(1, d + 1)
    ]

    with conn.cursor() as cur:
        print(f"\n[setup d={d}] drop/create schema", flush=True)
        cur.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        cur.execute(f"CREATE SCHEMA {s}")
        cur.execute(f"CREATE TABLE {s}.fact ({', '.join(cols)})")
        cur.execute(
            f"""
            ALTER TABLE {s}.fact SET (
                autovacuum_enabled = false,
                toast.autovacuum_enabled = false
            )
            """
        )

        # D0 finite-field construction:
        # z_j = a + (j-1)b mod q.
        # For prime q and distinct j,k<q, every (z_j,z_k) pair is exactly uniform.
        exprs = ["g::bigint AS id"]
        for j in range(1, d + 1):
            exprs.append(
                f"mod("
                f"mod(g::bigint, {domain}) "
                f"+ {(j-1)} * mod((g::bigint / {domain}), {domain}), "
                f"{domain})::integer AS z{j}"
            )

        print(
            f"[setup d={d}] loading rows={rows:,}, M={choose2(d):,}",
            flush=True,
        )
        cur.execute(
            f"""
            INSERT INTO {s}.fact
            SELECT {", ".join(exprs)}
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (rows,),
        )

        print(
            f"[setup d={d}] creating all {choose2(d):,} statistics objects",
            flush=True,
        )
        for i, j in all_pairs(d):
            cur.execute(
                f"""
                CREATE STATISTICS {s}.{qi(f'evs_{i}_{j}')}
                    (dependencies, mcv)
                ON z{i}, z{j}
                FROM {s}.fact
                """
            )

        cur.execute(f"SET default_statistics_target = {statistics_target}")
        cur.execute(f"VACUUM (ANALYZE) {s}.fact")

    return rows


def count_statistics_objects(conn, schema: str) -> int:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT COUNT(*)
            FROM pg_statistic_ext e
            JOIN pg_namespace n ON n.oid=e.stxnamespace
            WHERE n.nspname=%s
            """,
            (schema,),
        )
        return int(cur.fetchone()[0])


def count_statistics_payloads(conn, schema: str) -> int:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT COUNT(*)
            FROM pg_statistic_ext e
            JOIN pg_namespace n ON n.oid=e.stxnamespace
            JOIN pg_statistic_ext_data d ON d.stxoid=e.oid
            WHERE n.nspname=%s
            """,
            (schema,),
        )
        return int(cur.fetchone()[0])


def get_analyze_state(conn, schema: str) -> dict[str, Any]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT last_analyze, last_autoanalyze, n_mod_since_analyze
            FROM pg_stat_all_tables
            WHERE schemaname=%s AND relname='fact'
            """,
            (schema,),
        )
        row = cur.fetchone()
        return {
            "last_analyze": str(row[0]) if row and row[0] else None,
            "last_autoanalyze": str(row[1]) if row and row[1] else None,
            "n_mod_since_analyze": int(row[2]) if row else -1,
        }


def reset_d0(
    conn,
    schema: str,
    d: int,
    domain: int,
) -> None:
    s = qi(schema)
    assignments = []
    for j in range(1, d + 1):
        assignments.append(
            f"z{j}=mod("
            f"mod(id::bigint, {domain}) "
            f"+ {(j-1)} * mod((id::bigint / {domain}), {domain}), "
            f"{domain})::integer"
        )
    with conn.cursor() as cur:
        cur.execute(f"UPDATE {s}.fact SET {', '.join(assignments)}")


def apply_matching_drift(
    conn,
    schema: str,
    changed: list[tuple[int, int]],
) -> None:
    s = qi(schema)
    # For each disjoint pair (i,j), set z_j=z_i.
    # Because D0 is pairwise independent and the changed edges are disjoint,
    # cross-pair marginals remain pairwise independent.
    assignments = [f"z{j}=z{i}" for i, j in changed]
    with conn.cursor() as cur:
        cur.execute(f"UPDATE {s}.fact SET {', '.join(assignments)}")


def analyze_all_once(
    conn,
    schema: str,
    statistics_target: int,
) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact")
        return time.perf_counter() - start


def analyze_columns_once(
    conn,
    schema: str,
    columns: list[int],
    statistics_target: int,
) -> float:
    s = qi(schema)
    names = ", ".join(f"z{j}" for j in sorted(set(columns)))
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact ({names})")
        return time.perf_counter() - start


def repeat_timing(fn, repeats: int) -> tuple[list[float], float]:
    values = [float(fn()) for _ in range(repeats)]
    return values, float(statistics.median(values))


def verify_exact_marginals(
    conn,
    schema: str,
    d: int,
    domain: int,
    rows: int,
) -> bool:
    expected = rows // domain
    s = qi(schema)
    with conn.cursor() as cur:
        for j in range(1, d + 1):
            cur.execute(
                f"""
                SELECT COUNT(DISTINCT z{j}), MIN(c), MAX(c)
                FROM (
                    SELECT z{j}, COUNT(*) AS c
                    FROM {s}.fact
                    GROUP BY z{j}
                ) q
                """
            )
            distinct_n, min_c, max_c = [int(x) for x in cur.fetchone()]
            if not (
                distinct_n == domain
                and min_c == expected
                and max_c == expected
            ):
                return False
    return True


def profile_all_pairs(
    conn,
    schema: str,
    d: int,
    sample_mod: int,
) -> list[dict[str, Any]]:
    s = qi(schema)
    cols = ", ".join(f"z{j}" for j in range(1, d + 1))
    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT {cols}
            FROM {s}.fact
            WHERE mod(id, %s)=0
            ORDER BY id
            """,
            (sample_mod,),
        )
        data = np.asarray(cur.fetchall(), dtype=np.int16)

    rows = []
    n = data.shape[0]
    for i, j in all_pairs(d):
        equality = float(np.mean(data[:, i-1] == data[:, j-1]))
        # Independent baseline is 1/q. Equality drift gives score near 1.
        rows.append(
            {
                "i": i,
                "j": j,
                "sample_rows": n,
                "equality_rate": equality,
                "score": equality,
            }
        )
    return rows


def scan_node(plan: dict[str, Any]) -> dict[str, Any] | None:
    if plan.get("Relation Name") == "fact":
        return plan
    for child in plan.get("Plans", []) or []:
        found = scan_node(child)
        if found is not None:
            return found
    return None


def pair_qerror(
    conn,
    schema: str,
    edge: tuple[int, int],
    value: int,
) -> float:
    i, j = edge
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(
            f"""
            EXPLAIN (ANALYZE, TIMING OFF, FORMAT JSON)
            SELECT COUNT(*)
            FROM {s}.fact
            WHERE z{i}=%s AND z{j}=%s
            """,
            (value, value),
        )
        root = cur.fetchone()[0][0]["Plan"]
        scan = scan_node(root)
        if scan is None:
            raise RuntimeError(f"No fact scan found for edge {(i,j)}")
        return qerror(
            float(scan.get("Plan Rows", 0)),
            float(scan.get("Actual Rows", 0)),
        )


def run_one_d(
    conn,
    d: int,
    changed_count: int,
    domain: int,
    repeat_factor: int,
    timing_repeats: int,
    statistics_target: int,
    sample_mod: int,
    query_value: int,
    seed: int,
) -> tuple[list[dict[str, Any]], dict[str, Any], list[dict[str, Any]]]:
    M = choose2(d)
    s_count = min(changed_count, d // 2)
    changed = changed_matching(d, s_count, seed)
    changed_set = set(changed)
    selected_columns = sorted({v for edge in changed for v in edge})
    closure_objects = choose2(len(selected_columns))
    schema = f"evostats_shared_d{d}"

    rows = setup_schema(
        conn,
        schema,
        d,
        domain,
        repeat_factor,
        statistics_target,
    )

    defined = count_statistics_objects(conn, schema)
    if defined != M:
        raise RuntimeError(
            f"d={d}: only {defined}/{M} statistics objects were created"
        )

    # Canonical stale state: D0 stats -> D1 drift, with autoanalyze disabled.
    reset_d0(conn, schema, d, domain)
    analyze_all_once(conn, schema, statistics_target)
    apply_matching_drift(conn, schema, changed)

    state = get_analyze_state(conn, schema)
    if state["last_autoanalyze"] is not None:
        raise RuntimeError(
            f"d={d}: last_autoanalyze is not NULL despite autovacuum disabled: "
            f"{state['last_autoanalyze']}"
        )
    if state["n_mod_since_analyze"] <= 0:
        raise RuntimeError(
            f"d={d}: expected stale modifications, got "
            f"n_mod_since_analyze={state['n_mod_since_analyze']}"
        )
    if not verify_exact_marginals(conn, schema, d, domain, rows):
        raise RuntimeError(f"d={d}: exact marginal audit failed")

    profile = profile_all_pairs(conn, schema, d, sample_mod)
    ranked = sorted(profile, key=lambda r: r["score"], reverse=True)
    proposed = sorted(
        (min(int(r["i"]), int(r["j"])), max(int(r["i"]), int(r["j"])))
        for r in ranked[:s_count]
    )
    proposed_set = set(proposed)

    precision = len(changed_set & proposed_set) / len(proposed_set)
    recall = len(changed_set & proposed_set) / len(changed_set)

    stale_q = geomean(
        [pair_qerror(conn, schema, edge, query_value) for edge in changed]
    )

    # Full refresh timings: reset to identical stale state once, then repeat.
    reset_d0(conn, schema, d, domain)
    analyze_all_once(conn, schema, statistics_target)
    apply_matching_drift(conn, schema, changed)
    full_times, full_median = repeat_timing(
        lambda: analyze_all_once(conn, schema, statistics_target),
        timing_repeats,
    )
    full_q = geomean(
        [pair_qerror(conn, schema, edge, query_value) for edge in changed]
    )

    # Selective refresh via selected columns. This refreshes the induced closure.
    reset_d0(conn, schema, d, domain)
    analyze_all_once(conn, schema, statistics_target)
    apply_matching_drift(conn, schema, changed)
    selective_times, selective_median = repeat_timing(
        lambda: analyze_columns_once(
            conn,
            schema,
            selected_columns,
            statistics_target,
        ),
        timing_repeats,
    )
    selective_q = geomean(
        [pair_qerror(conn, schema, edge, query_value) for edge in changed]
    )

    benefit = (
        (stale_q - selective_q)
        / max(stale_q - full_q, 1e-12)
    )
    ratio = selective_median / max(full_median, 1e-12)

    detail = []
    for method, values in [
        ("full_refresh", full_times),
        ("selective_column_closure", selective_times),
    ]:
        for idx, seconds in enumerate(values, 1):
            detail.append(
                {
                    "d": d,
                    "M": M,
                    "s": s_count,
                    "method": method,
                    "repeat": idx,
                    "seconds": seconds,
                }
            )

    profile_rows = []
    for row in profile:
        edge = (int(row["i"]), int(row["j"]))
        profile_rows.append(
            {
                "d": d,
                "M": M,
                **row,
                "changed": int(edge in changed_set),
                "selected": int(edge in proposed_set),
            }
        )

    summary = {
        "d": d,
        "M": M,
        "s": s_count,
        "rows": rows,
        "defined_statistics": defined,
        "payload_statistics_after_selective": count_statistics_payloads(
            conn, schema
        ),
        "changed_edges": json.dumps(changed),
        "proposed_edges": json.dumps(proposed),
        "selected_columns": len(selected_columns),
        "closure_objects": closure_objects,
        "closure_fraction": closure_objects / M,
        "precision": precision,
        "recall": recall,
        "stale_qerror": stale_q,
        "full_qerror": full_q,
        "selective_qerror": selective_q,
        "benefit_recovery": benefit,
        "full_refresh_median_s": full_median,
        "selective_refresh_median_s": selective_median,
        "total_cost_ratio": ratio,
        "last_autoanalyze": state["last_autoanalyze"],
        "n_mod_since_analyze_before_measurement": state[
            "n_mod_since_analyze"
        ],
    }

    print(
        f"[d={d}, M={M}] P/R={precision:.2f}/{recall:.2f} "
        f"Q={stale_q:.2f}->{selective_q:.2f} "
        f"benefit={benefit:.3f} "
        f"full/sel={full_median:.3f}/{selective_median:.3f}s "
        f"ratio={ratio:.3f} closure={closure_objects}/{M}",
        flush=True,
    )

    return detail, summary, profile_rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dsn",
        default="postgresql://postgres:123456@localhost:5432/postgres",
    )
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--d-values", default="20,30,40,50")
    ap.add_argument("--changed-count", type=int, default=8)
    ap.add_argument("--domain", type=int, default=61)
    ap.add_argument("--repeat-factor", type=int, default=100)
    ap.add_argument("--timing-repeats", type=int, default=5)
    ap.add_argument("--statistics-target", type=int, default=200)
    ap.add_argument("--sample-mod", type=int, default=20)
    ap.add_argument("--query-value", type=int, default=7)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    d_values = parse_ints(args.d_values)
    if max(d_values) >= args.domain:
        raise ValueError(
            "Finite-field construction requires max(d) < prime domain"
        )

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "config.json").write_text(
        json.dumps(
            {
                **vars(args),
                "out": str(out),
                "d_values": d_values,
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    print(
        "EvoStats Phase 0.5 v3 — Shared-Column Scaling Audit\n"
        "==============================================================\n"
        "Goal: M=C(d,2), exact D0, sparse matching drift, autovacuum off\n"
        "Overall progress: [####------] 40%\n",
        flush=True,
    )

    conn = connect(args.dsn)
    detail_rows = []
    summaries = []
    profile_rows = []
    try:
        for d in d_values:
            detail, summary, profile = run_one_d(
                conn,
                d,
                args.changed_count,
                args.domain,
                args.repeat_factor,
                args.timing_repeats,
                args.statistics_target,
                args.sample_mod,
                args.query_value,
                args.seed,
            )
            detail_rows.extend(detail)
            summaries.append(summary)
            profile_rows.extend(profile)
    finally:
        conn.close()

    write_csv(out / "scaling_detail.csv", detail_rows)
    write_csv(out / "scaling_summary.csv", summaries)
    write_csv(out / "candidate_profile.csv", profile_rows)

    quality_pass = all(
        row["precision"] >= 0.9
        and row["recall"] >= 0.9
        and row["stale_qerror"] >= 10
        and row["full_qerror"] <= 2
        and row["selective_qerror"] <= 2
        and row["benefit_recovery"] >= 0.9
        for row in summaries
    )
    largest = summaries[-1]
    scaling_pass = largest["total_cost_ratio"] <= 0.25
    autovacuum_pass = all(
        row["last_autoanalyze"] is None for row in summaries
    )
    object_pass = all(
        row["defined_statistics"] == row["M"] for row in summaries
    )
    go = quality_pass and scaling_pass and autovacuum_pass and object_pass

    decision = {
        "quality_pass_all_d": quality_pass,
        "largest_d_cost_scaling_pass": scaling_pass,
        "autovacuum_isolation_pass": autovacuum_pass,
        "all_statistics_objects_created": object_pass,
        "phase05_go": go,
        "largest_d": largest["d"],
        "largest_M": largest["M"],
        "largest_total_cost_ratio": largest["total_cost_ratio"],
        "largest_closure_fraction": largest["closure_fraction"],
        "decision": (
            "GO: proceed to Phase 1 contingency-residual statistic"
            if go
            else "REDESIGN: inspect failed gate before Phase 1"
        ),
    }
    (out / "gate_report.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    lines = [
        "EVOSTATS PHASE 0.5 v3 SHARED-COLUMN REPORT",
        "=" * 78,
        "",
        "SUMMARY",
    ]
    for row in summaries:
        lines.append(
            f"d={row['d']:2d} M={row['M']:4d} s={row['s']:2d} "
            f"P/R={row['precision']:.2f}/{row['recall']:.2f} "
            f"Q={row['stale_qerror']:.2f}->{row['selective_qerror']:.2f} "
            f"benefit={row['benefit_recovery']:.3f} "
            f"full/sel={row['full_refresh_median_s']:.3f}/"
            f"{row['selective_refresh_median_s']:.3f}s "
            f"ratio={row['total_cost_ratio']:.3f} "
            f"closure={row['closure_objects']}/{row['M']}"
        )
    lines += [
        "",
        "DECISION",
        json.dumps(decision, indent=2),
        "",
        decision["decision"],
        "",
        "Important:",
        "- PostgreSQL refreshes statistics through ANALYZE(column list).",
        "- Selective cost therefore follows the selected-column closure, not",
        "  an idealized per-edge refresh API.",
        "- Hub drift needs a separate incident-expansion experiment; this",
        "  scaling gate uses sparse disjoint changed edges to keep D1 clean.",
    ]
    report = "\n".join(lines)
    (out / "gate_report.txt").write_text(report, encoding="utf-8")
    print("\n" + report)


if __name__ == "__main__":
    main()
