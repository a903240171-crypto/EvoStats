#!/usr/bin/env python3
"""
EvoStats Phase 2 — Unified Sparse-Localization Audit
====================================================

Research question
-----------------
Can EvoStats localize a sparse set of stale pairwise statistics without
probing all M = C(d,2) candidate pairs?

This is the algorithmic gate after Phase 1 established the pairwise residual
statistic. It evaluates localization over three support geometries:

1. matching: s disjoint stale edges;
2. hub:      s stale edges incident to one node;
3. blocks:   stale edges concentrated in small local blocks.

The pair probe is a noisy estimate of the Phase-1 residual score. The harness
does NOT reveal the support to the algorithms. All methods consume the same
pre-generated probe table, so comparisons are exactly paired.

Algorithms
----------
- full_scan:
    probes all M edges; upper bound on recall and cost.
- uniform:
    random edge probing without replacement.
- workload:
    probes edges by an independent Zipf workload prior; not aligned with truth.
- node_first:
    samples a small number of incident edges per node, ranks nodes by observed
    node mass, then expands the highest-ranked nodes.
- evostats:
    multi-stage exploration:
      pilot random edge probes
      -> node evidence aggregation
      -> uncertainty-aware node ranking
      -> incident expansion
      -> independent verification of candidate edges
    It never receives the support geometry label.

Metrics
-------
- candidate recall before verification
- verified edge recall / precision / F1
- pair probes
- verification probes
- total probes
- probe fraction of M
- refresh closure size C(|V_selected|,2)
- Q-error benefit recovery proxy
- exact-recovery rate

Default grid
------------
d = 50, 100, 200
M = 1,225 to 19,900
s = 8, 16
structures = matching, hub, blocks
5 seeds
budgets = 0.02M, 0.05M, 0.10M, 0.20M

Outputs
-------
localization_detail.csv
localization_summary.csv
scaling_summary.csv
gate_report.json
gate_report.txt
config.json
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import random
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


# =============================================================================
# Utilities
# =============================================================================

def parse_ints(text: str) -> list[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def parse_floats(text: str) -> list[float]:
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def all_edges(d: int) -> list[tuple[int, int]]:
    return list(itertools.combinations(range(d), 2))


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def mean_std(values: list[float]) -> tuple[float, float]:
    return statistics.mean(values), statistics.pstdev(values)


# =============================================================================
# Support generation
# =============================================================================

def support_matching(d: int, s: int, rng: random.Random) -> set[tuple[int, int]]:
    if 2 * s > d:
        raise ValueError(f"matching requires d >= 2s; got d={d}, s={s}")
    nodes = list(range(d))
    rng.shuffle(nodes)
    chosen = nodes[: 2 * s]
    return {
        (min(chosen[2*k], chosen[2*k+1]),
         max(chosen[2*k], chosen[2*k+1]))
        for k in range(s)
    }


def support_hub(d: int, s: int, rng: random.Random) -> set[tuple[int, int]]:
    if s >= d:
        raise ValueError("hub requires s < d")
    hub = rng.randrange(d)
    spokes = rng.sample([x for x in range(d) if x != hub], s)
    return {(min(hub, v), max(hub, v)) for v in spokes}


def support_blocks(d: int, s: int, rng: random.Random) -> set[tuple[int, int]]:
    """
    Concentrate stale edges in several small blocks without requiring every
    within-block edge to be stale.
    """
    edges: set[tuple[int, int]] = set()
    available = list(range(d))
    rng.shuffle(available)
    cursor = 0

    while len(edges) < s:
        remaining = s - len(edges)
        block_size = min(
            max(3, int(math.ceil(math.sqrt(2 * remaining))) + 1),
            8,
            d - cursor,
        )
        if block_size < 3:
            # Fall back to random unused edges.
            candidates = [
                e for e in all_edges(d) if e not in edges
            ]
            edges.update(rng.sample(candidates, remaining))
            break

        block = available[cursor:cursor + block_size]
        cursor += block_size
        candidates = list(itertools.combinations(sorted(block), 2))
        rng.shuffle(candidates)
        take = min(remaining, max(2, len(candidates) // 2))
        edges.update(candidates[:take])

        if cursor + 3 > d and len(edges) < s:
            candidates = [
                e for e in all_edges(d) if e not in edges
            ]
            edges.update(rng.sample(candidates, s - len(edges)))
            break

    return set(sorted(edges)[:s])


def make_support(
    structure: str,
    d: int,
    s: int,
    seed: int,
) -> set[tuple[int, int]]:
    rng = random.Random(seed * 10007 + d * 101 + s)
    if structure == "matching":
        return support_matching(d, s, rng)
    if structure == "hub":
        return support_hub(d, s, rng)
    if structure == "blocks":
        return support_blocks(d, s, rng)
    raise ValueError(structure)


# =============================================================================
# Paired probe world
# =============================================================================

@dataclass
class ProbeWorld:
    d: int
    edges: list[tuple[int, int]]
    edge_to_idx: dict[tuple[int, int], int]
    truth: set[tuple[int, int]]
    discovery_scores: np.ndarray
    verification_scores: np.ndarray
    threshold: float
    workload_priority: np.ndarray

    @property
    def M(self) -> int:
        return len(self.edges)

    def score(self, edge_idx: int) -> float:
        return float(self.discovery_scores[edge_idx])

    def verify(self, edge_idx: int) -> float:
        return float(self.verification_scores[edge_idx])


def make_world(
    d: int,
    truth: set[tuple[int, int]],
    seed: int,
    signal_mean: float,
    signal_std: float,
    null_std: float,
    threshold: float,
) -> ProbeWorld:
    edges = all_edges(d)
    edge_to_idx = {e: k for k, e in enumerate(edges)}
    rng = np.random.default_rng(seed * 99991 + d * 17 + len(truth))

    discovery = rng.normal(0.0, null_std, size=len(edges))
    verification = rng.normal(0.0, null_std / math.sqrt(2), size=len(edges))

    for edge in truth:
        idx = edge_to_idx[edge]
        latent = max(
            threshold * 1.25,
            float(rng.normal(signal_mean, signal_std)),
        )
        discovery[idx] += latent
        verification[idx] += latent

    # Workload prior is independent of truth by construction.
    order = rng.permutation(len(edges))
    ranks = np.empty(len(edges), dtype=np.int64)
    ranks[order] = np.arange(1, len(edges) + 1)
    workload_priority = 1.0 / np.power(ranks.astype(np.float64), 0.8)

    return ProbeWorld(
        d=d,
        edges=edges,
        edge_to_idx=edge_to_idx,
        truth=truth,
        discovery_scores=discovery,
        verification_scores=verification,
        threshold=threshold,
        workload_priority=workload_priority,
    )


# =============================================================================
# Algorithms
# =============================================================================

@dataclass
class Result:
    algorithm: str
    probed: set[int]
    candidates: set[int]
    verified: set[int]
    verification_probes: int


def top_candidates_from_probes(
    world: ProbeWorld,
    probed: set[int],
    max_candidates: int,
) -> set[int]:
    positive = [
        idx for idx in probed
        if world.score(idx) > world.threshold
    ]
    positive.sort(key=world.score, reverse=True)
    return set(positive[:max_candidates])


def verify_candidates(
    world: ProbeWorld,
    candidates: set[int],
    verify_threshold: float,
) -> set[int]:
    return {
        idx for idx in candidates
        if world.verify(idx) > verify_threshold
    }


def run_full_scan(
    world: ProbeWorld,
    truth_size: int,
    verify_threshold: float,
) -> Result:
    probed = set(range(world.M))
    candidates = top_candidates_from_probes(
        world, probed, max_candidates=max(4 * truth_size, truth_size)
    )
    verified = verify_candidates(world, candidates, verify_threshold)
    return Result("full_scan", probed, candidates, verified, len(candidates))


def run_uniform(
    world: ProbeWorld,
    budget: int,
    truth_size: int,
    verify_threshold: float,
    seed: int,
) -> Result:
    rng = random.Random(seed * 31337 + budget)
    probed = set(rng.sample(range(world.M), min(budget, world.M)))
    candidates = top_candidates_from_probes(
        world, probed, max_candidates=max(4 * truth_size, truth_size)
    )
    verified = verify_candidates(world, candidates, verify_threshold)
    return Result("uniform", probed, candidates, verified, len(candidates))


def run_workload(
    world: ProbeWorld,
    budget: int,
    truth_size: int,
    verify_threshold: float,
) -> Result:
    order = np.argsort(-world.workload_priority)
    probed = set(int(x) for x in order[:min(budget, world.M)])
    candidates = top_candidates_from_probes(
        world, probed, max_candidates=max(4 * truth_size, truth_size)
    )
    verified = verify_candidates(world, candidates, verify_threshold)
    return Result("workload", probed, candidates, verified, len(candidates))


def incident_edge_indices(world: ProbeWorld) -> list[list[int]]:
    incident = [[] for _ in range(world.d)]
    for idx, (u, v) in enumerate(world.edges):
        incident[u].append(idx)
        incident[v].append(idx)
    return incident


def run_node_first(
    world: ProbeWorld,
    budget: int,
    truth_size: int,
    verify_threshold: float,
    seed: int,
) -> Result:
    rng = random.Random(seed * 17011 + budget)
    incident = incident_edge_indices(world)
    probed: set[int] = set()

    # One small, equal-cost pilot per node where possible.
    pilot_per_node = max(1, min(3, budget // max(world.d, 1)))
    node_mass = np.zeros(world.d, dtype=np.float64)
    node_count = np.zeros(world.d, dtype=np.int64)

    for node in range(world.d):
        choices = incident[node][:]
        rng.shuffle(choices)
        for idx in choices[:pilot_per_node]:
            if len(probed) >= budget:
                break
            if idx not in probed:
                probed.add(idx)
                score = max(world.score(idx) - world.threshold, 0.0)
                u, v = world.edges[idx]
                node_mass[u] += score
                node_mass[v] += score
                node_count[u] += 1
                node_count[v] += 1

    avg_mass = node_mass / np.maximum(node_count, 1)
    node_order = list(np.argsort(-avg_mass))

    for node in node_order:
        if len(probed) >= budget:
            break
        choices = incident[int(node)][:]
        choices.sort(
            key=lambda idx: world.score(idx),
            reverse=True,
        )
        for idx in choices:
            if len(probed) >= budget:
                break
            probed.add(idx)

    candidates = top_candidates_from_probes(
        world, probed, max_candidates=max(4 * truth_size, truth_size)
    )
    verified = verify_candidates(world, candidates, verify_threshold)
    return Result("node_first", probed, candidates, verified, len(candidates))


def run_evostats(
    world: ProbeWorld,
    budget: int,
    truth_size: int,
    verify_threshold: float,
    seed: int,
) -> Result:
    """
    Structure-agnostic adaptive exploration.

    Budget allocation:
      25% random pilot;
      15% uncertainty-aware node sampling;
      60% incident expansion.

    It does not know whether the truth is matching, hub, or block structured.
    """
    rng = random.Random(seed * 65537 + budget)
    incident = incident_edge_indices(world)
    probed: set[int] = set()

    pilot_budget = max(world.d, int(0.25 * budget))
    pilot_budget = min(pilot_budget, budget, world.M)

    # Stratified edge pilot: ensure broad node coverage, then fill randomly.
    node_order = list(range(world.d))
    rng.shuffle(node_order)
    for node in node_order:
        if len(probed) >= pilot_budget:
            break
        choices = incident[node][:]
        rng.shuffle(choices)
        for idx in choices:
            if idx not in probed:
                probed.add(idx)
                break

    remaining = [
        idx for idx in range(world.M) if idx not in probed
    ]
    if len(probed) < pilot_budget:
        probed.update(
            rng.sample(
                remaining,
                min(pilot_budget - len(probed), len(remaining)),
            )
        )

    def node_stats() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        mass = np.zeros(world.d, dtype=np.float64)
        count = np.zeros(world.d, dtype=np.int64)
        max_score = np.zeros(world.d, dtype=np.float64)
        for idx in probed:
            excess = max(world.score(idx) - world.threshold, 0.0)
            u, v = world.edges[idx]
            mass[u] += excess
            mass[v] += excess
            count[u] += 1
            count[v] += 1
            max_score[u] = max(max_score[u], world.score(idx))
            max_score[v] = max(max_score[v], world.score(idx))
        return mass, count, max_score

    # Uncertainty-aware node sampling:
    # high upper-confidence node mass receives extra random incident probes.
    refine_target = min(budget, pilot_budget + int(0.15 * budget))
    while len(probed) < refine_target:
        mass, count, max_score = node_stats()
        avg = mass / np.maximum(count, 1)
        uncertainty = 1.0 / np.sqrt(np.maximum(count, 1))
        ucb = avg + 0.35 * uncertainty + 0.25 * np.maximum(
            max_score - world.threshold, 0.0
        )
        nodes = list(np.argsort(-ucb))
        added = False
        for node in nodes:
            choices = [
                idx for idx in incident[int(node)]
                if idx not in probed
            ]
            if not choices:
                continue
            idx = rng.choice(choices)
            probed.add(idx)
            added = True
            break
        if not added:
            break

    # Incident expansion from evidence-bearing nodes.
    mass, count, max_score = node_stats()
    positive_hits = np.zeros(world.d, dtype=np.int64)
    for idx in probed:
        if world.score(idx) > world.threshold:
            u, v = world.edges[idx]
            positive_hits[u] += 1
            positive_hits[v] += 1

    avg = mass / np.maximum(count, 1)
    priority = (
        2.0 * positive_hits
        + avg
        + 0.5 * np.maximum(max_score - world.threshold, 0.0)
    )
    node_order = list(np.argsort(-priority))

    # Alternate expansion across top nodes so matching support is not starved.
    active_nodes = [
        int(n) for n in node_order
        if priority[int(n)] > 0
    ]
    if not active_nodes:
        active_nodes = [int(n) for n in node_order[:max(4, truth_size)]]

    cursor = {node: 0 for node in active_nodes}
    sorted_incident = {}
    for node in active_nodes:
        choices = incident[node][:]
        # Ranking uses a cheap discovery proxy already available only after a
        # pair is probed; unseen edges are shuffled, not oracle-ranked.
        rng.shuffle(choices)
        sorted_incident[node] = choices

    while len(probed) < budget:
        added = False
        for node in active_nodes:
            choices = sorted_incident[node]
            while cursor[node] < len(choices):
                idx = choices[cursor[node]]
                cursor[node] += 1
                if idx not in probed:
                    probed.add(idx)
                    added = True
                    break
            if len(probed) >= budget:
                break

        # New evidence can activate additional nodes.
        if len(probed) % max(10, world.d // 2) == 0:
            mass, count, max_score = node_stats()
            positive_hits = np.zeros(world.d, dtype=np.int64)
            for idx in probed:
                if world.score(idx) > world.threshold:
                    u, v = world.edges[idx]
                    positive_hits[u] += 1
                    positive_hits[v] += 1
            avg = mass / np.maximum(count, 1)
            priority = (
                2.0 * positive_hits
                + avg
                + 0.5 * np.maximum(max_score - world.threshold, 0.0)
            )
            newly_ranked = list(np.argsort(-priority))
            for n in newly_ranked:
                node = int(n)
                if priority[node] <= 0:
                    continue
                if node not in active_nodes:
                    active_nodes.append(node)
                    choices = incident[node][:]
                    rng.shuffle(choices)
                    sorted_incident[node] = choices
                    cursor[node] = 0

        if not added:
            remaining = [
                idx for idx in range(world.M) if idx not in probed
            ]
            if not remaining:
                break
            probed.add(rng.choice(remaining))

    candidates = top_candidates_from_probes(
        world,
        probed,
        max_candidates=max(3 * truth_size, truth_size),
    )
    verified = verify_candidates(world, candidates, verify_threshold)
    return Result("evostats", probed, candidates, verified, len(candidates))


# =============================================================================
# Metrics
# =============================================================================

def evaluate(
    world: ProbeWorld,
    result: Result,
    truth_size: int,
    budget_fraction: float,
    structure: str,
    seed: int,
) -> dict[str, Any]:
    truth_idx = {world.edge_to_idx[e] for e in world.truth}
    candidate_tp = len(result.candidates & truth_idx)
    verified_tp = len(result.verified & truth_idx)

    candidate_recall = candidate_tp / truth_size
    recall = verified_tp / truth_size
    precision = (
        verified_tp / len(result.verified)
        if result.verified else 0.0
    )
    f1 = (
        2 * precision * recall / (precision + recall)
        if precision + recall > 0 else 0.0
    )

    selected_edges = [world.edges[idx] for idx in result.verified]
    selected_nodes = {
        node for edge in selected_edges for node in edge
    }
    closure_size = choose2(len(selected_nodes))

    # Each true stale edge contributes equal Q-error benefit in this gate.
    benefit_recovery = recall

    total_probes = len(result.probed) + result.verification_probes
    return {
        "d": world.d,
        "M": world.M,
        "s": truth_size,
        "structure": structure,
        "seed": seed,
        "budget_fraction": budget_fraction,
        "budget_edges": len(result.probed),
        "algorithm": result.algorithm,
        "candidate_recall": candidate_recall,
        "verified_precision": precision,
        "verified_recall": recall,
        "verified_f1": f1,
        "exact_recovery": int(
            result.verified == truth_idx
        ),
        "discovery_probes": len(result.probed),
        "verification_probes": result.verification_probes,
        "total_probes": total_probes,
        "probe_fraction_M": total_probes / world.M,
        "verified_edges": len(result.verified),
        "selected_nodes": len(selected_nodes),
        "refresh_closure_size": closure_size,
        "refresh_closure_fraction": closure_size / world.M,
        "qerror_benefit_recovery": benefit_recovery,
    }


def aggregate(
    rows: list[dict[str, Any]],
    keys: list[str],
) -> list[dict[str, Any]]:
    groups: dict[tuple, list[dict[str, Any]]] = {}
    for row in rows:
        key = tuple(row[k] for k in keys)
        groups.setdefault(key, []).append(row)

    metrics = [
        "candidate_recall",
        "verified_precision",
        "verified_recall",
        "verified_f1",
        "exact_recovery",
        "discovery_probes",
        "verification_probes",
        "total_probes",
        "probe_fraction_M",
        "selected_nodes",
        "refresh_closure_size",
        "refresh_closure_fraction",
        "qerror_benefit_recovery",
    ]
    out = []
    for key, items in groups.items():
        record = {k: v for k, v in zip(keys, key)}
        record["runs"] = len(items)
        for metric in metrics:
            values = [float(x[metric]) for x in items]
            mean, std = mean_std(values)
            record[f"{metric}_mean"] = mean
            record[f"{metric}_std"] = std
        out.append(record)
    return sorted(out, key=lambda r: tuple(r[k] for k in keys))


# =============================================================================
# Main
# =============================================================================

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--d-values", default="50,100,200")
    ap.add_argument("--s-values", default="8,16")
    ap.add_argument("--budget-fractions", default="0.02,0.05,0.10,0.20")
    ap.add_argument("--seeds", default="1,2,3,4,5")
    ap.add_argument("--signal-mean", type=float, default=0.22)
    ap.add_argument("--signal-std", type=float, default=0.035)
    ap.add_argument("--null-std", type=float, default=0.025)
    ap.add_argument("--threshold", type=float, default=0.065)
    ap.add_argument("--verify-threshold", type=float, default=0.055)
    args = ap.parse_args()

    d_values = parse_ints(args.d_values)
    s_values = parse_ints(args.s_values)
    budget_fractions = parse_floats(args.budget_fractions)
    seeds = parse_ints(args.seeds)
    structures = ["matching", "hub", "blocks"]

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "config.json").write_text(
        json.dumps(
            {
                **vars(args),
                "out": str(out),
                "d_values": d_values,
                "s_values": s_values,
                "budget_fractions": budget_fractions,
                "seeds": seeds,
                "structures": structures,
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    print(
        "EvoStats Phase 2 - Unified Sparse-Localization Audit\n"
        "================================================================\n"
        f"d={d_values}, s={s_values}, budgets={budget_fractions}\n"
        f"structures={structures}, seeds={seeds}\n"
        "Overall progress: [########--] 80%\n",
        flush=True,
    )

    detail_rows: list[dict[str, Any]] = []

    for d in d_values:
        M = choose2(d)
        for s in s_values:
            if 2 * s > d:
                continue
            for structure in structures:
                for seed in seeds:
                    truth = make_support(structure, d, s, seed)
                    world = make_world(
                        d=d,
                        truth=truth,
                        seed=seed + 1000 * s + 100000 * structures.index(structure),
                        signal_mean=args.signal_mean,
                        signal_std=args.signal_std,
                        null_std=args.null_std,
                        threshold=args.threshold,
                    )

                    full = run_full_scan(
                        world, s, args.verify_threshold
                    )
                    detail_rows.append(
                        evaluate(
                            world, full, s, 1.0, structure, seed
                        )
                    )

                    for frac in budget_fractions:
                        budget = max(d, int(round(frac * M)))
                        budget = min(budget, M)

                        methods = [
                            run_uniform(
                                world, budget, s,
                                args.verify_threshold, seed
                            ),
                            run_workload(
                                world, budget, s,
                                args.verify_threshold
                            ),
                            run_node_first(
                                world, budget, s,
                                args.verify_threshold, seed
                            ),
                            run_evostats(
                                world, budget, s,
                                args.verify_threshold, seed
                            ),
                        ]
                        for result in methods:
                            detail_rows.append(
                                evaluate(
                                    world, result, s, frac,
                                    structure, seed
                                )
                            )

                # Progress line at the 10% budget.
                subset = [
                    r for r in detail_rows
                    if r["d"] == d
                    and r["s"] == s
                    and r["structure"] == structure
                    and r["algorithm"] == "evostats"
                    and abs(r["budget_fraction"] - 0.10) < 1e-9
                ]
                if subset:
                    print(
                        f"d={d:3d} M={M:5d} s={s:2d} "
                        f"{structure:8s} EvoStats@10% "
                        f"R={statistics.mean(r['verified_recall'] for r in subset):.3f} "
                        f"P={statistics.mean(r['verified_precision'] for r in subset):.3f} "
                        f"probe={statistics.mean(r['probe_fraction_M'] for r in subset):.3f}",
                        flush=True,
                    )

    write_csv(out / "localization_detail.csv", detail_rows)

    summary = aggregate(
        detail_rows,
        [
            "d", "M", "s", "structure",
            "budget_fraction", "algorithm",
        ],
    )
    write_csv(out / "localization_summary.csv", summary)

    # Scaling summary: best EvoStats budget achieving >=0.9 recall.
    scaling_rows = []
    for d in d_values:
        for s in s_values:
            if 2 * s > d:
                continue
            for structure in structures:
                candidates = [
                    r for r in summary
                    if r["d"] == d
                    and r["s"] == s
                    and r["structure"] == structure
                    and r["algorithm"] == "evostats"
                ]
                feasible = [
                    r for r in candidates
                    if r["verified_recall_mean"] >= 0.90
                    and r["verified_precision_mean"] >= 0.90
                ]
                if feasible:
                    best = min(
                        feasible,
                        key=lambda r: r["total_probes_mean"],
                    )
                    scaling_rows.append(
                        {
                            "d": d,
                            "M": choose2(d),
                            "s": s,
                            "structure": structure,
                            "best_budget_fraction": best["budget_fraction"],
                            "total_probes_mean": best["total_probes_mean"],
                            "probe_fraction_M": best["probe_fraction_M_mean"],
                            "recall": best["verified_recall_mean"],
                            "precision": best["verified_precision_mean"],
                            "closure_fraction": best[
                                "refresh_closure_fraction_mean"
                            ],
                        }
                    )
                else:
                    scaling_rows.append(
                        {
                            "d": d,
                            "M": choose2(d),
                            "s": s,
                            "structure": structure,
                            "best_budget_fraction": float("nan"),
                            "total_probes_mean": float("nan"),
                            "probe_fraction_M": float("nan"),
                            "recall": 0.0,
                            "precision": 0.0,
                            "closure_fraction": float("nan"),
                        }
                    )

    write_csv(out / "scaling_summary.csv", scaling_rows)

    # Gates are evaluated at the largest d and 10% budget.
    largest_d = max(d_values)
    gate_rows = [
        r for r in summary
        if r["d"] == largest_d
        and abs(float(r["budget_fraction"]) - 0.10) < 1e-9
    ]

    evo_rows = [r for r in gate_rows if r["algorithm"] == "evostats"]
    uniform_rows = [r for r in gate_rows if r["algorithm"] == "uniform"]
    node_rows = [r for r in gate_rows if r["algorithm"] == "node_first"]

    quality_pass = all(
        r["verified_recall_mean"] >= 0.90
        and r["verified_precision_mean"] >= 0.90
        for r in evo_rows
    )

    # Structure gain: hub should be easier than matching for EvoStats.
    hub_evo = [
        r for r in evo_rows if r["structure"] == "hub"
    ]
    matching_evo = [
        r for r in evo_rows if r["structure"] == "matching"
    ]
    structure_gain = (
        statistics.mean(r["verified_recall_mean"] for r in hub_evo)
        >= statistics.mean(r["verified_recall_mean"] for r in matching_evo)
    )

    # Baseline gain: EvoStats should dominate uniform at equal discovery budget.
    baseline_gain = all(
        evo["verified_recall_mean"]
        >= uni["verified_recall_mean"] + 0.15
        for evo in evo_rows
        for uni in uniform_rows
        if evo["s"] == uni["s"]
        and evo["structure"] == uni["structure"]
    )

    # Subquadratic empirical gate at largest d.
    probe_pass = all(
        r["probe_fraction_M_mean"] <= 0.15
        for r in evo_rows
    )

    exact_recovery_pass = all(
        r["exact_recovery_mean"] >= 0.60
        for r in evo_rows
    )

    go = (
        quality_pass
        and structure_gain
        and baseline_gain
        and probe_pass
        and exact_recovery_pass
    )

    decision = {
        "largest_d": largest_d,
        "evostats_quality_pass_at_10pct": quality_pass,
        "hub_not_harder_than_matching": structure_gain,
        "evostats_beats_uniform_by_15_recall_points": baseline_gain,
        "total_probe_fraction_pass": probe_pass,
        "exact_recovery_pass": exact_recovery_pass,
        "phase2_go": go,
        "decision": (
            "GO: integrate sparse localization with PostgreSQL maintenance"
            if go
            else "REDESIGN: inspect failed Phase 2 localization gate"
        ),
    }
    (out / "gate_report.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    lines = [
        "EVOSTATS PHASE 2 SPARSE-LOCALIZATION REPORT",
        "=" * 78,
        "",
        "LARGEST-D RESULTS AT 10% DISCOVERY BUDGET",
    ]
    for row in sorted(
        gate_rows,
        key=lambda r: (
            r["s"], r["structure"], r["algorithm"]
        ),
    ):
        lines.append(
            f"d={row['d']:3d} s={row['s']:2d} "
            f"{row['structure']:8s} {row['algorithm']:10s} "
            f"P={row['verified_precision_mean']:.3f} "
            f"R={row['verified_recall_mean']:.3f} "
            f"F1={row['verified_f1_mean']:.3f} "
            f"exact={row['exact_recovery_mean']:.3f} "
            f"probe/M={row['probe_fraction_M_mean']:.3f} "
            f"closure/M={row['refresh_closure_fraction_mean']:.3f}"
        )

    lines += [
        "",
        "DECISION",
        json.dumps(decision, indent=2),
        "",
        decision["decision"],
        "",
        "Interpretation:",
        "- Phase 1 established the pairwise residual score.",
        "- Phase 2 tests whether support can be found without full pair scan.",
        "- The harness is synthetic and algorithmic; PostgreSQL integration",
        "  follows only after this gate passes.",
    ]
    report = "\n".join(lines)
    (out / "gate_report.txt").write_text(report, encoding="utf-8")
    print("\n" + report)


if __name__ == "__main__":
    main()
