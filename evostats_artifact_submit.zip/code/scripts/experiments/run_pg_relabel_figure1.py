#!/usr/bin/env python3
"""
EvoStats PostgreSQL Figure 1 Audit
=================================

Purpose
-------
Move the Phase-1 "bijection relabeling" result into a real PostgreSQL catalog.

D0:
    75% y=x plus 25% independent noise.

D1:
    75% y=x+1 (mod q) plus the same 25% independent noise.

D0 and D1 have:
- exactly identical one-column marginals;
- exactly identical chi-square and Cramer's V;
- the same functional-dependency strength up to PostgreSQL's estimator;
- different dependence shape / MCV cells.

Protocol
--------
1. Build D0 and collect PostgreSQL extended statistics (dependencies + MCV).
2. Apply D1 without ANALYZE; autovacuum is disabled.
3. Measure:
   - chi-square invariance;
   - dependency-degree invariance;
   - residual-shape drift;
   - stale-MCV Q-error on old-hot and new-hot cells.
4. Refresh x,y statistics and remeasure Q-error.

Expected result
---------------
- chi-square change ~= 0;
- dependency-degree change ~= 0;
- residual L1 > 0;
- stale MCV causes roughly 25x Q-error;
- refreshed MCV returns Q-error near 1.

Outputs
-------
figure1_report.txt
figure1_report.json
query_results.csv
catalog_audit.csv
contingency_d0.csv
contingency_d1.csv
config.json
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import time
from pathlib import Path
from typing import Any

import numpy as np
import psycopg


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def qerror(est: float, act: float) -> float:
    e = max(float(est), 1.0)
    a = max(float(act), 1.0)
    return max(e / a, a / e)


def connect(dsn: str):
    conn = psycopg.connect(dsn, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET jit = off")
        cur.execute("SET max_parallel_workers_per_gather = 0")
        cur.execute("SET track_io_timing = on")
        cur.execute("SET statement_timeout = 0")
    return conn


def setup_d0(
    conn,
    schema: str,
    q: int,
    rows: int,
    rho_num: int,
    rho_den: int,
    statistics_target: int,
) -> None:
    if rows % (q * q * rho_den) != 0:
        raise ValueError(
            f"rows must be divisible by q^2*rho_den={q*q*rho_den}"
        )

    s = qi(schema)
    dep_rows = rows * rho_num // rho_den
    ind_rows = rows - dep_rows

    if dep_rows % q != 0 or ind_rows % (q*q) != 0:
        raise ValueError("Exact component sizes are not integral")

    with conn.cursor() as cur:
        print("[setup] drop/create schema", flush=True)
        cur.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        cur.execute(f"CREATE SCHEMA {s}")
        cur.execute(
            f"""
            CREATE TABLE {s}.fact (
                id bigint PRIMARY KEY,
                is_dep boolean NOT NULL,
                x integer NOT NULL,
                y integer NOT NULL,
                pad text NOT NULL
            )
            """
        )
        cur.execute(
            f"""
            ALTER TABLE {s}.fact SET (
                autovacuum_enabled = false,
                toast.autovacuum_enabled = false
            )
            """
        )

        print(
            f"[setup] D0 rows={rows:,}, dep={dep_rows:,}, independent={ind_rows:,}",
            flush=True,
        )

        # Exact dependent component: each x appears equally often and y=x.
        cur.execute(
            f"""
            INSERT INTO {s}.fact(id, is_dep, x, y, pad)
            SELECT
                g::bigint,
                true,
                mod(g::bigint, %s)::integer,
                mod(g::bigint, %s)::integer,
                repeat(md5(g::text), 2)
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (q, q, dep_rows),
        )

        # Exact independent component: every cell has identical count.
        cur.execute(
            f"""
            INSERT INTO {s}.fact(id, is_dep, x, y, pad)
            SELECT
                (%s + g)::bigint,
                false,
                mod(g::bigint, %s)::integer,
                mod((g::bigint / %s), %s)::integer,
                repeat(md5((%s + g)::text), 2)
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (dep_rows, q, q, q, dep_rows, ind_rows),
        )

        cur.execute(f"CREATE INDEX fact_xy_idx ON {s}.fact(x,y)")
        cur.execute(
            f"""
            CREATE STATISTICS {s}.evs_xy (dependencies, mcv)
            ON x, y
            FROM {s}.fact
            """
        )
        cur.execute(f"SET default_statistics_target = {statistics_target}")
        cur.execute(f"VACUUM (ANALYZE) {s}.fact")


def apply_relabel_drift(conn, schema: str, q: int) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        start = time.perf_counter()
        cur.execute(
            f"""
            UPDATE {s}.fact
            SET y = mod(x + 1, %s)
            WHERE is_dep
            """,
            (q,),
        )
        return time.perf_counter() - start


def analyze_xy(conn, schema: str, statistics_target: int) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact (x,y)")
        return time.perf_counter() - start


def analyze_state(conn, schema: str) -> dict[str, Any]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT last_analyze, last_autoanalyze, n_mod_since_analyze
            FROM pg_stat_all_tables
            WHERE schemaname=%s AND relname='fact'
            """,
            (schema,),
        )
        row = cur.fetchone()
        if not row:
            raise RuntimeError("fact table not found in pg_stat_all_tables")
        return {
            "last_analyze": str(row[0]) if row[0] else None,
            "last_autoanalyze": str(row[1]) if row[1] else None,
            "n_mod_since_analyze": int(row[2]),
        }


def contingency(conn, schema: str, q: int) -> np.ndarray:
    s = qi(schema)
    table = np.zeros((q, q), dtype=np.int64)
    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT x, y, COUNT(*)::bigint
            FROM {s}.fact
            GROUP BY x,y
            ORDER BY x,y
            """
        )
        for x, y, count in cur.fetchall():
            table[int(x), int(y)] = int(count)
    return table


def table_rows(table: np.ndarray, snapshot: str) -> list[dict[str, Any]]:
    rows = []
    for x in range(table.shape[0]):
        for y in range(table.shape[1]):
            rows.append(
                {
                    "snapshot": snapshot,
                    "x": x,
                    "y": y,
                    "count": int(table[x, y]),
                }
            )
    return rows


def marginal_audit(table: np.ndarray) -> dict[str, Any]:
    rx = table.sum(axis=1)
    cy = table.sum(axis=0)
    return {
        "x_min": int(rx.min()),
        "x_max": int(rx.max()),
        "y_min": int(cy.min()),
        "y_max": int(cy.max()),
        "exact_uniform": bool(
            np.all(rx == rx[0]) and np.all(cy == cy[0])
        ),
    }


def shape_metrics(table: np.ndarray) -> dict[str, float]:
    n = float(table.sum())
    p = table.astype(np.float64) / n
    px = p.sum(axis=1, keepdims=True)
    py = p.sum(axis=0, keepdims=True)
    expected = px @ py
    residual = p - expected

    mask = p > 0
    mi = float(np.sum(p[mask] * np.log(p[mask] / expected[mask])))
    chi2 = float(
        n * np.sum((p - expected) ** 2 / np.maximum(expected, 1e-15))
    )
    q = table.shape[0]
    cramers_v = math.sqrt(chi2 / (n * max(q - 1, 1)))

    return {
        "mi": mi,
        "chi_square": chi2,
        "cramers_v": cramers_v,
        "equality_rate": float(np.trace(p)),
        "residual": residual,
    }


def residual_distance(a: np.ndarray, b: np.ndarray) -> float:
    ma = shape_metrics(a)
    mb = shape_metrics(b)
    return 0.25 * float(np.abs(ma["residual"] - mb["residual"]).sum())


def dependency_payload(conn, schema: str) -> str:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT d.stxddependencies::text
            FROM pg_statistic_ext e
            JOIN pg_namespace n ON n.oid=e.stxnamespace
            JOIN pg_statistic_ext_data d ON d.stxoid=e.oid
            WHERE n.nspname=%s AND e.stxname='evs_xy'
            """,
            (schema,),
        )
        row = cur.fetchone()
        return row[0] if row and row[0] is not None else ""


def dependency_degrees(payload: str) -> list[float]:
    # pg_dependencies textual form contains numeric degree values.
    vals = [
        float(x)
        for x in re.findall(r'(?::\s*|=>\s*)(0(?:\.\d+)?|1(?:\.0+)?)', payload)
    ]
    if vals:
        return vals

    # Fallback: collect decimal probabilities, excluding attribute identifiers.
    vals = [
        float(x)
        for x in re.findall(r'\b(?:0\.\d+|1\.0+)\b', payload)
    ]
    return vals


def mcv_rows(conn, schema: str, label: str) -> list[dict[str, Any]]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT
                m.index,
                m.values::text,
                m.frequency,
                m.base_frequency
            FROM pg_statistic_ext e
            JOIN pg_namespace n ON n.oid=e.stxnamespace
            JOIN pg_statistic_ext_data d ON d.stxoid=e.oid
            CROSS JOIN LATERAL pg_mcv_list_items(d.stxdmcv) AS m
            WHERE n.nspname=%s AND e.stxname='evs_xy'
            ORDER BY m.frequency DESC, m.index
            """,
            (schema,),
        )
        return [
            {
                "stage": label,
                "index": int(idx),
                "values": values,
                "frequency": float(freq),
                "base_frequency": float(base),
            }
            for idx, values, freq, base in cur.fetchall()
        ]


def find_fact_scan(plan: dict[str, Any]) -> dict[str, Any] | None:
    if plan.get("Relation Name") == "fact":
        return plan
    for child in plan.get("Plans", []) or []:
        found = find_fact_scan(child)
        if found is not None:
            return found
    return None


def explain_cell(
    conn,
    schema: str,
    stage: str,
    label: str,
    x: int,
    y: int,
    repeats: int,
) -> dict[str, Any]:
    s = qi(schema)
    query = f"""
        SELECT SUM(length(pad))
        FROM {s}.fact
        WHERE x=%s AND y=%s
    """
    records = []
    with conn.cursor() as cur:
        # warmup
        cur.execute(
            "EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) " + query,
            (x, y),
        )
        cur.fetchone()

        for _ in range(repeats):
            cur.execute(
                "EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) " + query,
                (x, y),
            )
            doc = cur.fetchone()[0][0]
            scan = find_fact_scan(doc["Plan"])
            if scan is None:
                raise RuntimeError("fact scan not found")
            records.append(
                {
                    "est": float(scan.get("Plan Rows", 0)),
                    "act": float(scan.get("Actual Rows", 0)),
                    "ms": float(doc.get("Execution Time", 0)),
                    "node": str(scan.get("Node Type", "?")),
                }
            )

    ests = sorted(r["est"] for r in records)
    acts = sorted(r["act"] for r in records)
    times = sorted(r["ms"] for r in records)
    mid = len(records) // 2

    est = ests[mid]
    act = acts[mid]
    return {
        "stage": stage,
        "query": label,
        "x": x,
        "y": y,
        "estimated_rows": est,
        "actual_rows": act,
        "q_error": qerror(est, act),
        "execution_ms": times[mid],
        "scan_node": records[mid]["node"],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dsn",
        default="postgresql://postgres:123456@localhost:5432/postgres",
    )
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_relabel_fig1")
    ap.add_argument("--q", type=int, default=8)
    ap.add_argument("--rows", type=int, default=819_200)
    ap.add_argument("--rho-num", type=int, default=3)
    ap.add_argument("--rho-den", type=int, default=4)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--repeats", type=int, default=5)
    args = ap.parse_args()

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "config.json").write_text(
        json.dumps({**vars(args), "out": str(out)}, indent=2, default=str),
        encoding="utf-8",
    )

    print(
        "EvoStats PostgreSQL Figure 1 - Relabeling Drift Audit\n"
        "================================================================\n"
        "D0: 0.75*(y=x)   + 0.25*independent\n"
        "D1: 0.75*(y=x+1) + 0.25*independent\n"
        "Goal: chi-square/dependency strength unchanged, MCV stale, Q-error high\n",
        flush=True,
    )

    conn = connect(args.dsn)
    query_rows: list[dict[str, Any]] = []
    catalog_rows: list[dict[str, Any]] = []

    try:
        setup_d0(
            conn,
            args.schema,
            args.q,
            args.rows,
            args.rho_num,
            args.rho_den,
            args.statistics_target,
        )

        d0 = contingency(conn, args.schema, args.q)
        d0_metrics = shape_metrics(d0)
        d0_dep_payload = dependency_payload(conn, args.schema)
        d0_dep_degrees = dependency_degrees(d0_dep_payload)
        d0_mcv = mcv_rows(conn, args.schema, "D0_fresh")

        query_rows.append(
            explain_cell(
                conn, args.schema, "D0_fresh",
                "old_hot_cell", 0, 0, args.repeats
            )
        )
        query_rows.append(
            explain_cell(
                conn, args.schema, "D0_fresh",
                "future_hot_cell", 0, 1, args.repeats
            )
        )

        print("[drift] applying y=x+1 relabeling without ANALYZE", flush=True)
        drift_seconds = apply_relabel_drift(conn, args.schema, args.q)
        state_stale = analyze_state(conn, args.schema)

        if state_stale["last_autoanalyze"] is not None:
            raise RuntimeError(
                "auto-ANALYZE occurred; stale-statistics experiment invalid"
            )
        if state_stale["n_mod_since_analyze"] <= 0:
            raise RuntimeError("expected stale modifications before measurement")

        d1 = contingency(conn, args.schema, args.q)
        d1_metrics = shape_metrics(d1)

        query_rows.append(
            explain_cell(
                conn, args.schema, "D1_stale",
                "old_hot_cell", 0, 0, args.repeats
            )
        )
        query_rows.append(
            explain_cell(
                conn, args.schema, "D1_stale",
                "new_hot_cell", 0, 1, args.repeats
            )
        )

        print("[refresh] ANALYZE fact(x,y)", flush=True)
        refresh_seconds = analyze_xy(
            conn, args.schema, args.statistics_target
        )

        d1_dep_payload = dependency_payload(conn, args.schema)
        d1_dep_degrees = dependency_degrees(d1_dep_payload)
        d1_mcv = mcv_rows(conn, args.schema, "D1_refreshed")

        query_rows.append(
            explain_cell(
                conn, args.schema, "D1_refreshed",
                "old_hot_cell", 0, 0, args.repeats
            )
        )
        query_rows.append(
            explain_cell(
                conn, args.schema, "D1_refreshed",
                "new_hot_cell", 0, 1, args.repeats
            )
        )

        write_csv(out / "query_results.csv", query_rows)
        write_csv(
            out / "contingency_d0.csv",
            table_rows(d0, "D0"),
        )
        write_csv(
            out / "contingency_d1.csv",
            table_rows(d1, "D1"),
        )
        write_csv(
            out / "catalog_audit.csv",
            d0_mcv + d1_mcv,
        )

        d0_marg = marginal_audit(d0)
        d1_marg = marginal_audit(d1)

        chi_rel = abs(
            d1_metrics["chi_square"] - d0_metrics["chi_square"]
        ) / max(abs(d0_metrics["chi_square"]), 1e-12)
        mi_abs = abs(d1_metrics["mi"] - d0_metrics["mi"])
        v_abs = abs(d1_metrics["cramers_v"] - d0_metrics["cramers_v"])
        residual = residual_distance(d0, d1)

        if d0_dep_degrees and d1_dep_degrees:
            dep_degree_delta = max(
                abs(a - b)
                for a, b in zip(d0_dep_degrees, d1_dep_degrees)
            )
        else:
            dep_degree_delta = float("nan")

        stale_old = next(
            r for r in query_rows
            if r["stage"] == "D1_stale" and r["query"] == "old_hot_cell"
        )
        stale_new = next(
            r for r in query_rows
            if r["stage"] == "D1_stale" and r["query"] == "new_hot_cell"
        )
        fresh_old = next(
            r for r in query_rows
            if r["stage"] == "D1_refreshed" and r["query"] == "old_hot_cell"
        )
        fresh_new = next(
            r for r in query_rows
            if r["stage"] == "D1_refreshed" and r["query"] == "new_hot_cell"
        )

        marginals_pass = (
            d0_marg["exact_uniform"]
            and d1_marg["exact_uniform"]
            and d0_marg == d1_marg
        )
        strength_invariance_pass = (
            chi_rel <= 1e-12
            and mi_abs <= 1e-12
            and v_abs <= 1e-12
        )
        dependency_degree_pass = (
            math.isfinite(dep_degree_delta)
            and dep_degree_delta <= 0.02
        )
        residual_pass = residual >= 0.20
        stale_qerror_pass = (
            stale_old["q_error"] >= 10
            and stale_new["q_error"] >= 10
        )
        refresh_pass = (
            fresh_old["q_error"] <= 2
            and fresh_new["q_error"] <= 2
        )

        go = (
            marginals_pass
            and strength_invariance_pass
            and dependency_degree_pass
            and residual_pass
            and stale_qerror_pass
            and refresh_pass
        )

        report = {
            "marginals_exact_and_unchanged": marginals_pass,
            "chi_square_relative_change": chi_rel,
            "mi_absolute_change": mi_abs,
            "cramers_v_absolute_change": v_abs,
            "strength_invariance_pass": strength_invariance_pass,
            "dependency_degrees_d0": d0_dep_degrees,
            "dependency_degrees_d1": d1_dep_degrees,
            "dependency_degree_max_delta": dep_degree_delta,
            "dependency_degree_invariance_pass": dependency_degree_pass,
            "residual_l1_quarter": residual,
            "residual_shape_change_pass": residual_pass,
            "stale_old_hot_qerror": stale_old["q_error"],
            "stale_new_hot_qerror": stale_new["q_error"],
            "stale_mcv_qerror_pass": stale_qerror_pass,
            "refreshed_old_hot_qerror": fresh_old["q_error"],
            "refreshed_new_hot_qerror": fresh_new["q_error"],
            "refresh_repairs_qerror_pass": refresh_pass,
            "drift_seconds": drift_seconds,
            "refresh_seconds": refresh_seconds,
            "last_autoanalyze_before_stale_measurement":
                state_stale["last_autoanalyze"],
            "n_mod_since_analyze_before_stale_measurement":
                state_stale["n_mod_since_analyze"],
            "figure1_go": go,
            "decision": (
                "GO: use as PostgreSQL Figure 1 / motivating experiment"
                if go
                else "REDESIGN: inspect failed Figure 1 gate"
            ),
        }

        (out / "figure1_report.json").write_text(
            json.dumps(report, indent=2),
            encoding="utf-8",
        )

        lines = [
            "EVOSTATS POSTGRESQL FIGURE 1 - RELABELING DRIFT",
            "=" * 78,
            "",
            "WHY THIS EXPERIMENT EXISTS",
            "A strength-only detector can report no change even while the",
            "catalog's MCV shape becomes stale and query estimates fail.",
            "",
            "POPULATION / CATALOG INVARIANCE",
            f"marginals exact and unchanged : {marginals_pass}",
            f"chi-square relative change    : {chi_rel:.12g}",
            f"MI absolute change            : {mi_abs:.12g}",
            f"Cramers V absolute change     : {v_abs:.12g}",
            f"dependency degree D0          : {d0_dep_degrees}",
            f"dependency degree D1          : {d1_dep_degrees}",
            f"dependency max delta          : {dep_degree_delta:.6g}",
            f"residual shape distance       : {residual:.6f}",
            "",
            "QUERY CONSEQUENCE",
            (
                f"D1 stale old-hot  Q={stale_old['q_error']:.2f} "
                f"est={stale_old['estimated_rows']:.0f} "
                f"act={stale_old['actual_rows']:.0f}"
            ),
            (
                f"D1 stale new-hot  Q={stale_new['q_error']:.2f} "
                f"est={stale_new['estimated_rows']:.0f} "
                f"act={stale_new['actual_rows']:.0f}"
            ),
            (
                f"D1 fresh old-hot  Q={fresh_old['q_error']:.2f} "
                f"est={fresh_old['estimated_rows']:.0f} "
                f"act={fresh_old['actual_rows']:.0f}"
            ),
            (
                f"D1 fresh new-hot  Q={fresh_new['q_error']:.2f} "
                f"est={fresh_new['estimated_rows']:.0f} "
                f"act={fresh_new['actual_rows']:.0f}"
            ),
            "",
            "DECISION",
            json.dumps(report, indent=2),
            "",
            report["decision"],
        ]
        text = "\n".join(lines)
        (out / "figure1_report.txt").write_text(
            text, encoding="utf-8"
        )
        print("\n" + text)

    finally:
        conn.close()


if __name__ == "__main__":
    main()
