#!/usr/bin/env python3
"""
EvoStats Phase 0 Unified PostgreSQL Audit.

Runs one consistent end-to-end experiment:

A. Catalog blindness / stale-statistics consequence
   D0: every (x_k,y_k) pair is independent.
   D1: a sparse subset becomes y_k=x_k.
   Every single-column marginal remains exactly uniform.

B. Budgeted proactive localization
   A sample-based dependence profiler ranks all candidate pairs.
   Compare full refresh, selective refresh, frequency, and random selection.

C. Plan/runtime consequence
   Run the same filtered join workload under stale, full, and selective stats.

The script owns the complete lifecycle. Every scenario is rebuilt from the same D0
state, so results are directly comparable.

Default scale:
  rows=360,000
  candidate_pairs=48
  changed_pairs=8
  domain=60
  changed query actual rows=6,000
  stale estimate approximately 100
  expected Q-error approximately 60

Outputs:
  marginal_audit.csv
  candidate_profile.csv
  scenario_selection.json
  query_detail.csv
  scenario_summary.csv
  gate_report.json
  gate_report.txt
  config.json
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import statistics
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

import psycopg


# =============================================================================
# Utilities
# =============================================================================

def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def qerror(est: float, act: float) -> float:
    e = max(float(est), 1.0)
    a = max(float(act), 1.0)
    return max(e / a, a / e)


def geomean(values: list[float]) -> float:
    if not values:
        return float("nan")
    return math.exp(sum(math.log(max(v, 1e-12)) for v in values) / len(values))


def weighted_geomean(values: list[float], weights: list[float]) -> float:
    if not values or not weights or sum(weights) <= 0:
        return float("nan")
    return math.exp(
        sum(w * math.log(max(v, 1e-12)) for v, w in zip(values, weights))
        / sum(weights)
    )


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            cooked = {
                k: json.dumps(v, ensure_ascii=False)
                if isinstance(v, (list, dict))
                else v
                for k, v in row.items()
            }
            writer.writerow(cooked)


def connect(dsn: str):
    conn = psycopg.connect(dsn, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET jit = off")
        cur.execute("SET max_parallel_workers_per_gather = 0")
        cur.execute("SET track_io_timing = on")
        cur.execute("SET statement_timeout = 0")
    return conn


# =============================================================================
# Data / statistics lifecycle
# =============================================================================

def setup_schema(
    conn,
    schema: str,
    rows: int,
    pairs: int,
    domain: int,
    lookup_rows: int,
    detail_fanout: int,
    indexed_pairs: list[int],
) -> None:
    if rows % (domain * domain) != 0:
        raise ValueError(
            f"--rows must be divisible by domain^2={domain*domain}; got {rows}"
        )

    s = qi(schema)
    columns = []
    for k in range(1, pairs + 1):
        columns += [f"x{k} integer NOT NULL", f"y{k} integer NOT NULL"]

    with conn.cursor() as cur:
        print("[setup] dropping old schema", flush=True)
        cur.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        cur.execute(f"CREATE SCHEMA {s}")

        cur.execute(
            f"""
            CREATE TABLE {s}.fact (
                id bigint PRIMARY KEY,
                payload_id integer NOT NULL,
                {", ".join(columns)}
            )
            """
        )
        cur.execute(
            f"""
            CREATE TABLE {s}.lookup (
                id integer PRIMARY KEY,
                cost integer NOT NULL,
                pad text NOT NULL
            )
            """
        )
        cur.execute(
            f"""
            CREATE TABLE {s}.detail (
                lookup_id integer NOT NULL,
                slot integer NOT NULL,
                measure integer NOT NULL,
                PRIMARY KEY (lookup_id, slot)
            )
            """
        )

        print(f"[setup] loading lookup rows={lookup_rows:,}", flush=True)
        cur.execute(
            f"""
            INSERT INTO {s}.lookup(id, cost, pad)
            SELECT g::integer,
                   (mod(g::bigint * 17, 1000)::integer + 1),
                   repeat(md5(g::text), 2)
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (lookup_rows,),
        )

        print(
            f"[setup] loading detail rows={lookup_rows * detail_fanout:,}",
            flush=True,
        )
        cur.execute(
            f"""
            INSERT INTO {s}.detail(lookup_id, slot, measure)
            SELECT l.id,
                   slot,
                   mod(l.id::bigint * 31 + slot, 1000)::integer
            FROM {s}.lookup l
            CROSS JOIN generate_series(1, %s) AS g(slot)
            """,
            (detail_fanout,),
        )

        select_exprs = [
            "g::bigint AS id",
            f"mod(g::bigint * 7919, {lookup_rows})::integer AS payload_id",
        ]
        for k in range(1, pairs + 1):
            x = f"mod(g::bigint, {domain})::integer"
            y = (
                f"mod((g::bigint / {domain}) + {13*k}, "
                f"{domain})::integer"
            )
            select_exprs += [f"{x} AS x{k}", f"{y} AS y{k}"]

        print(
            f"[setup] loading D0 fact rows={rows:,}, candidate_pairs={pairs}",
            flush=True,
        )
        cur.execute(
            f"""
            INSERT INTO {s}.fact
            SELECT {", ".join(select_exprs)}
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (rows,),
        )

        print("[setup] creating workload indexes", flush=True)
        cur.execute(f"CREATE INDEX fact_payload_idx ON {s}.fact(payload_id)")
        cur.execute(f"CREATE INDEX detail_lookup_idx ON {s}.detail(lookup_id)")
        for k in sorted(set(indexed_pairs)):
            cur.execute(
                f"CREATE INDEX fact_pair_{k}_idx "
                f"ON {s}.fact(x{k}, y{k})"
            )

        cur.execute(f"VACUUM (ANALYZE) {s}.fact")
        cur.execute(f"VACUUM (ANALYZE) {s}.lookup")
        cur.execute(f"VACUUM (ANALYZE) {s}.detail")


def create_all_statistics_definitions(
    conn,
    schema: str,
    pairs: int,
) -> None:
    s = qi(schema)
    with conn.cursor() as cur:
        for k in range(1, pairs + 1):
            cur.execute(
                f"""
                CREATE STATISTICS {s}.{qi(f'evs_pair_{k}')}
                    (dependencies, mcv)
                ON x{k}, y{k}
                FROM {s}.fact
                """
            )


def analyze_all(conn, schema: str, statistics_target: int) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {int(statistics_target)}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact")
        return time.perf_counter() - start


def analyze_selected(
    conn,
    schema: str,
    pair_ids: Iterable[int],
    statistics_target: int,
) -> float:
    """
    PostgreSQL ANALYZE with an explicit column list. Extended statistics whose
    referenced columns are all included are refreshed; unrelated groups are not.
    """
    selected = sorted(set(int(x) for x in pair_ids))
    if not selected:
        return 0.0

    s = qi(schema)
    columns = []
    for k in selected:
        columns += [f"x{k}", f"y{k}"]

    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {int(statistics_target)}")
        start = time.perf_counter()
        cur.execute(
            f"ANALYZE {s}.fact ({', '.join(columns)})"
        )
        return time.perf_counter() - start


def reset_to_d0(conn, schema: str, pairs: int, domain: int) -> float:
    s = qi(schema)
    assignments = [
        (
            f"y{k}=mod((id::bigint / {domain}) + {13*k}, "
            f"{domain})::integer"
        )
        for k in range(1, pairs + 1)
    ]
    with conn.cursor() as cur:
        start = time.perf_counter()
        cur.execute(
            f"UPDATE {s}.fact SET {', '.join(assignments)}"
        )
        return time.perf_counter() - start


def apply_drift(
    conn,
    schema: str,
    changed_pairs: Iterable[int],
) -> float:
    s = qi(schema)
    assignments = [f"y{k}=x{k}" for k in sorted(set(changed_pairs))]
    with conn.cursor() as cur:
        start = time.perf_counter()
        cur.execute(
            f"UPDATE {s}.fact SET {', '.join(assignments)}"
        )
        return time.perf_counter() - start


def verify_single_column_marginals(
    conn,
    schema: str,
    pairs: int,
    domain: int,
    rows: int,
) -> list[dict[str, Any]]:
    s = qi(schema)
    expected = rows // domain
    records = []

    with conn.cursor() as cur:
        for k in range(1, pairs + 1):
            cur.execute(
                f"""
                SELECT
                    COUNT(DISTINCT x{k}),
                    COUNT(DISTINCT y{k}),
                    MIN(cx), MAX(cx), MIN(cy), MAX(cy)
                FROM (
                    SELECT x{k}, y{k},
                           COUNT(*) OVER (PARTITION BY x{k}) AS cx,
                           COUNT(*) OVER (PARTITION BY y{k}) AS cy
                    FROM {s}.fact
                ) q
                """
            )
            dx, dy, minx, maxx, miny, maxy = cur.fetchone()
            exact = (
                int(dx) == domain
                and int(dy) == domain
                and int(minx) == expected
                and int(maxx) == expected
                and int(miny) == expected
                and int(maxy) == expected
            )
            records.append(
                {
                    "pair_id": k,
                    "distinct_x": int(dx),
                    "distinct_y": int(dy),
                    "min_freq_x": int(minx),
                    "max_freq_x": int(maxx),
                    "min_freq_y": int(miny),
                    "max_freq_y": int(maxy),
                    "expected_frequency": expected,
                    "exact_uniform": int(exact),
                }
            )
    return records


# =============================================================================
# Candidate profiler
# =============================================================================

def profile_candidates(
    conn,
    schema: str,
    pairs: int,
    sample_mod: int,
    workload_weights: dict[int, float],
) -> list[dict[str, Any]]:
    s = qi(schema)
    rows = []

    with conn.cursor() as cur:
        for k in range(1, pairs + 1):
            cur.execute(
                f"""
                WITH sample AS (
                    SELECT x{k} AS x, y{k} AS y
                    FROM {s}.fact
                    WHERE mod(id, %s) = 0
                )
                SELECT
                    COUNT(*)::bigint,
                    COUNT(DISTINCT x)::bigint,
                    COUNT(DISTINCT y)::bigint,
                    COUNT(DISTINCT (x,y))::bigint
                FROM sample
                """,
                (sample_mod,),
            )
            n, dx, dy, dxy = [int(x) for x in cur.fetchone()]
            inflation = (dx * dy) / max(dxy, 1)
            dependence_score = max(0.0, math.log(max(inflation, 1.0)))
            weight = float(workload_weights[k])
            impact = dependence_score * weight
            rows.append(
                {
                    "pair_id": k,
                    "sample_rows": n,
                    "distinct_x": dx,
                    "distinct_y": dy,
                    "distinct_xy": dxy,
                    "inflation_proxy": inflation,
                    "dependence_score": dependence_score,
                    "workload_weight": weight,
                    "impact_score": impact,
                }
            )
    return rows


def choose_scenarios(
    profile: list[dict[str, Any]],
    changed_pairs: list[int],
    pairs: int,
    budget: int,
    seed: int,
) -> dict[str, list[int]]:
    all_ids = list(range(1, pairs + 1))
    proposed = [
        int(row["pair_id"])
        for row in sorted(
            profile,
            key=lambda r: r["impact_score"],
            reverse=True,
        )[:budget]
    ]
    frequency = [
        int(row["pair_id"])
        for row in sorted(
            profile,
            key=lambda r: r["workload_weight"],
            reverse=True,
        )[:budget]
    ]
    rng = random.Random(seed)
    random_ids = sorted(rng.sample(all_ids, k=budget))

    return {
        "stale": [],
        "full_refresh": all_ids,
        "oracle_selective": sorted(changed_pairs),
        "proposed_selective": proposed,
        "frequency_selective": frequency,
        "random_selective": random_ids,
    }


# =============================================================================
# EXPLAIN / workload
# =============================================================================

@dataclass
class QueryRecord:
    scenario: str
    pair_id: int
    changed: bool
    workload_weight: float
    estimated_rows: float
    actual_rows: float
    q_error: float
    execution_ms: float
    plan_signature: str
    fact_scan_node: str


def find_fact_scan(plan: dict[str, Any]) -> dict[str, Any] | None:
    if plan.get("Relation Name") == "fact":
        return plan
    for child in plan.get("Plans", []) or []:
        found = find_fact_scan(child)
        if found is not None:
            return found
    return None


def signature(plan: dict[str, Any]) -> str:
    node = str(plan.get("Node Type", "?"))
    relation = plan.get("Relation Name")
    index = plan.get("Index Name")
    if relation:
        node += f"[{relation}]"
    if index:
        node += f"<{index}>"
    children = plan.get("Plans", []) or []
    if children:
        node += "(" + ",".join(signature(x) for x in children) + ")"
    return node


def explain_query(
    conn,
    schema: str,
    pair_id: int,
    value: int,
    repeats: int,
    scenario: str,
    changed: bool,
    weight: float,
) -> QueryRecord:
    s = qi(schema)
    query = f"""
        SELECT SUM(d.measure + l.cost)
        FROM {s}.fact f
        JOIN {s}.lookup l ON l.id = f.payload_id
        JOIN {s}.detail d ON d.lookup_id = l.id
        WHERE f.x{pair_id} = %s
          AND f.y{pair_id} = %s
    """

    records = []
    with conn.cursor() as cur:
        # Warm-up.
        cur.execute(
            "EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) " + query,
            (value, value),
        )
        cur.fetchone()

        for _ in range(repeats):
            cur.execute(
                "EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) " + query,
                (value, value),
            )
            doc = cur.fetchone()[0][0]
            root = doc["Plan"]
            scan = find_fact_scan(root)
            if scan is None:
                raise RuntimeError("fact scan not found")

            records.append(
                {
                    "estimated_rows": float(scan.get("Plan Rows", 0)),
                    "actual_rows": float(scan.get("Actual Rows", 0)),
                    "execution_ms": float(doc.get("Execution Time", 0)),
                    "plan_signature": signature(root),
                    "fact_scan_node": str(scan.get("Node Type", "?")),
                }
            )

    def median_numeric(key: str) -> float:
        return float(statistics.median([r[key] for r in records]))

    def mode_text(key: str) -> str:
        values = [r[key] for r in records]
        return max(set(values), key=values.count)

    est = median_numeric("estimated_rows")
    act = median_numeric("actual_rows")

    return QueryRecord(
        scenario=scenario,
        pair_id=pair_id,
        changed=changed,
        workload_weight=weight,
        estimated_rows=est,
        actual_rows=act,
        q_error=qerror(est, act),
        execution_ms=median_numeric("execution_ms"),
        plan_signature=mode_text("plan_signature"),
        fact_scan_node=mode_text("fact_scan_node"),
    )


# =============================================================================
# Unified experiment
# =============================================================================

def run_scenario(
    conn,
    schema: str,
    pairs: int,
    domain: int,
    changed_pairs: list[int],
    selected_pairs: list[int],
    scenario: str,
    statistics_target: int,
    query_pairs: list[int],
    query_value: int,
    repeats: int,
    workload_weights: dict[int, float],
) -> tuple[list[QueryRecord], dict[str, Any]]:
    # Identical starting state for every scenario:
    # D0 -> full D0 ANALYZE -> D1 -> scenario-specific refresh.
    reset_seconds = reset_to_d0(conn, schema, pairs, domain)
    baseline_analyze_seconds = analyze_all(
        conn,
        schema,
        statistics_target,
    )
    drift_seconds = apply_drift(conn, schema, changed_pairs)

    if scenario == "stale":
        refresh_seconds = 0.0
    elif scenario == "full_refresh":
        refresh_seconds = analyze_all(
            conn,
            schema,
            statistics_target,
        )
    else:
        refresh_seconds = analyze_selected(
            conn,
            schema,
            selected_pairs,
            statistics_target,
        )

    results = []
    for pair_id in query_pairs:
        rec = explain_query(
            conn,
            schema,
            pair_id,
            query_value,
            repeats,
            scenario,
            pair_id in set(changed_pairs),
            workload_weights[pair_id],
        )
        results.append(rec)
        print(
            f"  pair={pair_id:02d} changed={int(rec.changed)} "
            f"est={rec.estimated_rows:.0f} "
            f"act={rec.actual_rows:.0f} "
            f"Q={rec.q_error:.2f} "
            f"time={rec.execution_ms:.2f}ms "
            f"scan={rec.fact_scan_node}",
            flush=True,
        )

    changed_results = [r for r in results if r.changed]
    control_results = [r for r in results if not r.changed]

    summary = {
        "scenario": scenario,
        "selected_pairs": selected_pairs,
        "selected_count": len(selected_pairs),
        "reset_seconds": reset_seconds,
        "baseline_analyze_seconds": baseline_analyze_seconds,
        "drift_seconds": drift_seconds,
        "refresh_seconds": refresh_seconds,
        "changed_geomean_qerror": geomean(
            [r.q_error for r in changed_results]
        ),
        "control_geomean_qerror": geomean(
            [r.q_error for r in control_results]
        ),
        "weighted_geomean_qerror": weighted_geomean(
            [r.q_error for r in results],
            [r.workload_weight for r in results],
        ),
        "changed_mean_runtime_ms": statistics.mean(
            [r.execution_ms for r in changed_results]
        ),
        "control_mean_runtime_ms": statistics.mean(
            [r.execution_ms for r in control_results]
        ),
        "weighted_mean_runtime_ms": (
            sum(r.execution_ms * r.workload_weight for r in results)
            / sum(r.workload_weight for r in results)
        ),
        "plan_signatures": sorted(
            set(r.plan_signature for r in results)
        ),
    }
    return results, summary


def make_decision(
    summaries: dict[str, dict[str, Any]],
    records: list[QueryRecord],
    selections: dict[str, list[int]],
    changed_pairs: list[int],
    pairs: int,
) -> dict[str, Any]:
    stale = summaries["stale"]
    full = summaries["full_refresh"]
    proposed = summaries["proposed_selective"]
    oracle = summaries["oracle_selective"]
    freq = summaries["frequency_selective"]
    random_s = summaries["random_selective"]

    changed = set(changed_pairs)
    proposed_selected = set(selections["proposed_selective"])
    precision = (
        len(proposed_selected & changed) / len(proposed_selected)
        if proposed_selected else 0.0
    )
    recall = len(proposed_selected & changed) / len(changed)

    stale_q = stale["changed_geomean_qerror"]
    full_q = full["changed_geomean_qerror"]
    proposed_q = proposed["changed_geomean_qerror"]
    denominator = max(stale_q - full_q, 1e-12)
    benefit_recovery = (stale_q - proposed_q) / denominator

    full_cost = full["refresh_seconds"]
    proposed_cost = proposed["refresh_seconds"]
    cost_fraction = (
        proposed_cost / full_cost if full_cost > 0 else float("nan")
    )

    by_key = {
        (r.scenario, r.pair_id): r
        for r in records
    }
    plan_changes = 0
    runtime_improvements = []
    for pair_id in changed_pairs:
        a = by_key[("stale", pair_id)]
        b = by_key[("full_refresh", pair_id)]
        if a.plan_signature != b.plan_signature:
            plan_changes += 1
        runtime_improvements.append(
            (a.execution_ms - b.execution_ms)
            / max(a.execution_ms, 1e-12)
        )
    median_runtime_improvement = statistics.median(
        runtime_improvements
    )

    gate_a = (
        stale_q >= 10.0
        and full_q <= 2.0
    )
    gate_b = (
        precision >= 0.8
        and recall >= 0.8
        and benefit_recovery >= 0.8
    )
    gate_c = (
        cost_fraction <= 0.35
        and len(selections["proposed_selective"]) / pairs <= 0.25
    )
    gate_d = (
        plan_changes >= 1
        and median_runtime_improvement >= 0.10
    )

    # Runtime is a separate bonus gate. The core research direction proceeds
    # when A+B+C pass; D determines whether runtime can be a headline.
    core_go = gate_a and gate_b and gate_c
    runtime_headline = gate_d

    return {
        "gate_A_catalog_blindness_pass": gate_a,
        "gate_B_selector_quality_pass": gate_b,
        "gate_C_maintenance_cost_pass": gate_c,
        "gate_D_positive_runtime_pass": gate_d,
        "core_direction_go": core_go,
        "runtime_headline_ready": runtime_headline,
        "proposed_precision": precision,
        "proposed_recall": recall,
        "proposed_qerror_benefit_recovery": benefit_recovery,
        "proposed_refresh_cost_fraction": cost_fraction,
        "changed_plan_changes_stale_to_full": plan_changes,
        "changed_median_runtime_improvement": (
            median_runtime_improvement
        ),
        "frequency_changed_qerror": freq["changed_geomean_qerror"],
        "random_changed_qerror": random_s["changed_geomean_qerror"],
        "oracle_changed_qerror": oracle["changed_geomean_qerror"],
        "decision": (
            "GO: implement Phase 1 dependency-drift statistic"
            if core_go
            else "NO-GO: stop or redesign before Phase 1"
        ),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dsn",
        default="postgresql://postgres:123456@localhost:5432/postgres",
    )
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_phase0_unified")
    ap.add_argument("--rows", type=int, default=360_000)
    ap.add_argument("--pairs", type=int, default=48)
    ap.add_argument("--domain", type=int, default=60)
    ap.add_argument(
        "--changed-pairs",
        default="3,8,14,21,29,35,42,47",
    )
    ap.add_argument("--budget", type=int, default=8)
    ap.add_argument("--lookup-rows", type=int, default=100_000)
    ap.add_argument("--detail-fanout", type=int, default=5)
    ap.add_argument("--sample-mod", type=int, default=30)
    ap.add_argument("--statistics-target", type=int, default=200)
    ap.add_argument("--query-controls", default="1,2,4,5")
    ap.add_argument("--query-value", type=int, default=7)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--random-seed", type=int, default=42)
    args = ap.parse_args()

    changed_pairs = sorted(
        int(x.strip())
        for x in args.changed_pairs.split(",")
        if x.strip()
    )
    controls = sorted(
        int(x.strip())
        for x in args.query_controls.split(",")
        if x.strip()
    )

    if max(changed_pairs + controls) > args.pairs:
        raise ValueError("pair id exceeds --pairs")
    if args.budget < len(changed_pairs):
        raise ValueError("--budget must be >= number of changed pairs")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    # Highest frequencies are intentionally not aligned with all changed pairs.
    workload_weights = {
        k: float(max(1, args.pairs + 1 - k))
        for k in range(1, args.pairs + 1)
    }

    config = {
        **vars(args),
        "out": str(out),
        "changed_pairs": changed_pairs,
        "query_controls": controls,
        "workload_weights": workload_weights,
    }
    (out / "config.json").write_text(
        json.dumps(config, indent=2, default=str),
        encoding="utf-8",
    )

    query_pairs = changed_pairs + controls
    indexed_pairs = query_pairs

    conn = connect(args.dsn)
    try:
        print(
            "EvoStats Phase 0 Unified Audit\n"
            "==============================================================\n"
            "Goal: catalog blindness + sparse localization + selective "
            "maintenance + plan/runtime\n"
            "Progress: [###-------] 30% overall\n",
            flush=True,
        )

        setup_schema(
            conn,
            args.schema,
            args.rows,
            args.pairs,
            args.domain,
            args.lookup_rows,
            args.detail_fanout,
            indexed_pairs,
        )

        print("[setup] creating all extended-statistics definitions", flush=True)
        create_all_statistics_definitions(
            conn,
            args.schema,
            args.pairs,
        )

        print("[audit] D0 marginal audit", flush=True)
        d0_audit = verify_single_column_marginals(
            conn,
            args.schema,
            args.pairs,
            args.domain,
            args.rows,
        )
        if not all(x["exact_uniform"] == 1 for x in d0_audit):
            raise RuntimeError("D0 marginal audit failed")

        print("[baseline] collecting D0 statistics", flush=True)
        analyze_all(
            conn,
            args.schema,
            args.statistics_target,
        )

        print("[drift] applying D1 sparse dependency drift", flush=True)
        apply_drift(
            conn,
            args.schema,
            changed_pairs,
        )

        print("[audit] D1 marginal audit", flush=True)
        d1_audit = verify_single_column_marginals(
            conn,
            args.schema,
            args.pairs,
            args.domain,
            args.rows,
        )
        if not all(x["exact_uniform"] == 1 for x in d1_audit):
            raise RuntimeError("D1 marginal audit failed")

        marginal_rows = []
        for a, b in zip(d0_audit, d1_audit):
            row = {
                "pair_id": a["pair_id"],
                "changed_pair": int(a["pair_id"] in set(changed_pairs)),
            }
            for key, value in a.items():
                if key != "pair_id":
                    row[f"d0_{key}"] = value
            for key, value in b.items():
                if key != "pair_id":
                    row[f"d1_{key}"] = value
            marginal_rows.append(row)
        write_csv(out / "marginal_audit.csv", marginal_rows)

        print("[profile] ranking all candidate pairs on D1", flush=True)
        profile = profile_candidates(
            conn,
            args.schema,
            args.pairs,
            args.sample_mod,
            workload_weights,
        )
        for row in profile:
            row["changed_pair"] = int(
                row["pair_id"] in set(changed_pairs)
            )
        write_csv(out / "candidate_profile.csv", profile)

        selections = choose_scenarios(
            profile,
            changed_pairs,
            args.pairs,
            args.budget,
            args.random_seed,
        )
        (out / "scenario_selection.json").write_text(
            json.dumps(selections, indent=2),
            encoding="utf-8",
        )
        print(
            "[selection] " + json.dumps(selections),
            flush=True,
        )

        scenario_order = [
            "stale",
            "full_refresh",
            "oracle_selective",
            "proposed_selective",
            "frequency_selective",
            "random_selective",
        ]

        all_records: list[QueryRecord] = []
        summaries: dict[str, dict[str, Any]] = {}

        for scenario in scenario_order:
            print(
                f"\n[scenario] {scenario}: "
                f"selected={selections[scenario]}",
                flush=True,
            )
            records, summary = run_scenario(
                conn,
                args.schema,
                args.pairs,
                args.domain,
                changed_pairs,
                selections[scenario],
                scenario,
                args.statistics_target,
                query_pairs,
                args.query_value,
                args.repeats,
                workload_weights,
            )
            all_records.extend(records)
            summaries[scenario] = summary

        detail_rows = [asdict(x) for x in all_records]
        summary_rows = [
            summaries[name] for name in scenario_order
        ]
        write_csv(out / "query_detail.csv", detail_rows)
        write_csv(out / "scenario_summary.csv", summary_rows)

        decision = make_decision(
            summaries,
            all_records,
            selections,
            changed_pairs,
            args.pairs,
        )
        (out / "gate_report.json").write_text(
            json.dumps(decision, indent=2),
            encoding="utf-8",
        )

        report_lines = [
            "EVOSTATS PHASE 0 UNIFIED GO/NO-GO",
            "=" * 78,
            "",
            f"Rows: {args.rows:,}",
            f"Candidate pairs: {args.pairs}",
            f"Changed pairs: {changed_pairs}",
            f"Budget: {args.budget}",
            "",
            "SCENARIO SUMMARY",
        ]
        for row in summary_rows:
            report_lines.append(
                f"{row['scenario']:22s} "
                f"selected={row['selected_count']:2d} "
                f"Q_changed={row['changed_geomean_qerror']:.3f} "
                f"Q_control={row['control_geomean_qerror']:.3f} "
                f"time_changed={row['changed_mean_runtime_ms']:.2f}ms "
                f"refresh={row['refresh_seconds']:.3f}s"
            )

        report_lines += [
            "",
            "DECISION",
            json.dumps(decision, indent=2),
            "",
            decision["decision"],
            "",
            "Interpretation:",
            "- Gates A+B+C decide whether EvoStats proceeds.",
            "- Gate D only decides whether runtime can be a headline.",
            "- A runtime failure does not erase a strong Q-error and "
            "maintenance-cost result.",
        ]
        report = "\n".join(report_lines)
        (out / "gate_report.txt").write_text(
            report,
            encoding="utf-8",
        )
        print("\n" + report)

    finally:
        conn.close()


if __name__ == "__main__":
    main()
