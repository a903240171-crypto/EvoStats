#!/usr/bin/env python3
"""
EvoStats Phase 0.5 — Unified Maintenance Scaling Audit.

Purpose
-------
Fix the two unresolved issues from Phase 0:

1. ANALYZE timing noise:
   Every timing is repeated R times and summarized by the median.

2. Candidate universe too small:
   Sweep M candidate multivariate-statistics objects while keeping the same
   sparse changed set size s.

Important model note
--------------------
In this controlled prototype, one candidate statistics object is represented by
one disjoint column pair (x_k, y_k). Therefore M is the number of candidate
statistics objects directly; it is not C(d,2) for one d-column table.

This is deliberate for Phase 0.5: the goal is to isolate PostgreSQL maintenance
cost as a function of the number of statistics objects. Phase 2 will later move
to a shared candidate graph over ordinary wide-table columns.

Default grid
------------
M in {48, 96, 192, 384}
s = 8
rows = 72,000
domain = 60
timing repeats = 5

Outputs
-------
scaling_detail.csv
scaling_summary.csv
gate_report.json
gate_report.txt
config.json
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import statistics
import time
from pathlib import Path
from typing import Any, Iterable

import psycopg


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def qerror(est: float, act: float) -> float:
    e = max(float(est), 1.0)
    a = max(float(act), 1.0)
    return max(e / a, a / e)


def geomean(values: list[float]) -> float:
    if not values:
        return float("nan")
    return math.exp(sum(math.log(max(v, 1e-12)) for v in values) / len(values))


def parse_ints(text: str) -> list[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def connect(dsn: str):
    conn = psycopg.connect(dsn, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET jit = off")
        cur.execute("SET max_parallel_workers_per_gather = 0")
        cur.execute("SET track_io_timing = on")
        cur.execute("SET statement_timeout = 0")
    return conn


def setup_schema(
    conn,
    schema: str,
    rows: int,
    candidates: int,
    domain: int,
    changed_pairs: list[int],
) -> None:
    if rows % (domain * domain) != 0:
        raise ValueError(
            f"--rows must be divisible by domain^2={domain * domain}; got {rows}"
        )
    if 2 * candidates + 2 >= 1600:
        raise ValueError(
            f"M={candidates} requires {2*candidates+2} table columns, "
            "too close to PostgreSQL's column limit. Use M<=700."
        )

    s = qi(schema)
    cols = ["id bigint PRIMARY KEY", "payload integer NOT NULL"]
    for k in range(1, candidates + 1):
        cols += [f"x{k} integer NOT NULL", f"y{k} integer NOT NULL"]

    with conn.cursor() as cur:
        print(f"\n[setup M={candidates}] drop/create schema", flush=True)
        cur.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        cur.execute(f"CREATE SCHEMA {s}")
        cur.execute(f"CREATE TABLE {s}.fact ({', '.join(cols)})")

        exprs = [
            "g::bigint AS id",
            "mod(g::bigint * 7919, 100000)::integer AS payload",
        ]
        for k in range(1, candidates + 1):
            x = f"mod(g::bigint, {domain})::integer"
            y = (
                f"mod((g::bigint / {domain}) + {13*k}, "
                f"{domain})::integer"
            )
            exprs += [f"{x} AS x{k}", f"{y} AS y{k}"]

        print(
            f"[setup M={candidates}] loading rows={rows:,}, "
            f"physical_columns={2*candidates+2}",
            flush=True,
        )
        cur.execute(
            f"""
            INSERT INTO {s}.fact
            SELECT {", ".join(exprs)}
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (rows,),
        )

        # Index only changed pairs used for Q-error audit.
        for k in changed_pairs:
            cur.execute(
                f"CREATE INDEX fact_pair_{k}_idx "
                f"ON {s}.fact(x{k}, y{k})"
            )

        print(f"[setup M={candidates}] creating {candidates} stats objects", flush=True)
        for k in range(1, candidates + 1):
            cur.execute(
                f"""
                CREATE STATISTICS {s}.{qi(f'evs_pair_{k}')}
                    (dependencies, mcv)
                ON x{k}, y{k}
                FROM {s}.fact
                """
            )

        cur.execute(f"VACUUM (ANALYZE) {s}.fact")


def reset_d0(conn, schema: str, candidates: int, domain: int) -> None:
    s = qi(schema)
    assignments = [
        (
            f"y{k}=mod((id::bigint / {domain}) + {13*k}, "
            f"{domain})::integer"
        )
        for k in range(1, candidates + 1)
    ]
    with conn.cursor() as cur:
        cur.execute(f"UPDATE {s}.fact SET {', '.join(assignments)}")


def apply_drift(conn, schema: str, changed_pairs: list[int]) -> None:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(
            f"UPDATE {s}.fact SET "
            + ", ".join(f"y{k}=x{k}" for k in changed_pairs)
        )


def analyze_all_once(
    conn,
    schema: str,
    statistics_target: int,
) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact")
        return time.perf_counter() - start


def analyze_selected_once(
    conn,
    schema: str,
    selected: Iterable[int],
    statistics_target: int,
) -> float:
    selected = sorted(set(int(x) for x in selected))
    if not selected:
        return 0.0
    s = qi(schema)
    columns = []
    for k in selected:
        columns += [f"x{k}", f"y{k}"]
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact ({', '.join(columns)})")
        return time.perf_counter() - start


def analyze_base_once(
    conn,
    schema: str,
    statistics_target: int,
) -> float:
    """
    Fixed scan/startup proxy: analyze only payload, which is not part of any
    extended statistics object.
    """
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target = {statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact (payload)")
        return time.perf_counter() - start


def repeat_timing(fn, repeats: int) -> tuple[list[float], float]:
    values = []
    for _ in range(repeats):
        values.append(float(fn()))
    return values, float(statistics.median(values))


def verify_marginals(
    conn,
    schema: str,
    changed_pairs: list[int],
    domain: int,
    rows: int,
) -> bool:
    s = qi(schema)
    expected = rows // domain
    with conn.cursor() as cur:
        for k in changed_pairs:
            cur.execute(
                f"""
                SELECT
                    COUNT(DISTINCT x{k}),
                    COUNT(DISTINCT y{k}),
                    MIN(cx), MAX(cx), MIN(cy), MAX(cy)
                FROM (
                    SELECT x{k}, y{k},
                           COUNT(*) OVER (PARTITION BY x{k}) AS cx,
                           COUNT(*) OVER (PARTITION BY y{k}) AS cy
                    FROM {s}.fact
                ) q
                """
            )
            dx, dy, minx, maxx, miny, maxy = cur.fetchone()
            if not (
                int(dx) == domain
                and int(dy) == domain
                and int(minx) == expected
                and int(maxx) == expected
                and int(miny) == expected
                and int(maxy) == expected
            ):
                return False
    return True


def profile_candidates(
    conn,
    schema: str,
    candidates: int,
    sample_mod: int,
) -> list[dict[str, Any]]:
    s = qi(schema)
    out = []
    with conn.cursor() as cur:
        for k in range(1, candidates + 1):
            cur.execute(
                f"""
                WITH sample AS (
                    SELECT x{k} AS x, y{k} AS y
                    FROM {s}.fact
                    WHERE mod(id, %s) = 0
                )
                SELECT
                    COUNT(*)::bigint,
                    COUNT(DISTINCT x)::bigint,
                    COUNT(DISTINCT y)::bigint,
                    COUNT(DISTINCT (x,y))::bigint
                FROM sample
                """,
                (sample_mod,),
            )
            n, dx, dy, dxy = [int(v) for v in cur.fetchone()]
            inflation = (dx * dy) / max(dxy, 1)
            score = max(0.0, math.log(max(inflation, 1.0)))
            out.append(
                {
                    "pair_id": k,
                    "sample_rows": n,
                    "distinct_x": dx,
                    "distinct_y": dy,
                    "distinct_xy": dxy,
                    "score": score,
                }
            )
    return out


def explain_qerror(
    conn,
    schema: str,
    pair_id: int,
    value: int,
) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(
            f"""
            EXPLAIN (ANALYZE, TIMING OFF, FORMAT JSON)
            SELECT COUNT(*)
            FROM {s}.fact
            WHERE x{pair_id}=%s AND y{pair_id}=%s
            """,
            (value, value),
        )
        doc = cur.fetchone()[0][0]
        plan = doc["Plan"]
        est = float(plan.get("Plan Rows", 0))
        act = float(plan.get("Actual Rows", 0))
        return qerror(est, act)


def run_one_M(
    conn,
    out: Path,
    M: int,
    rows: int,
    domain: int,
    changed_count: int,
    repeats: int,
    sample_mod: int,
    statistics_target: int,
    query_value: int,
    seed: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if changed_count >= M:
        raise ValueError("changed_count must be < M")

    rng = random.Random(seed + M)
    changed_pairs = sorted(rng.sample(range(1, M + 1), k=changed_count))
    schema = f"evostats_scale_{M}"

    setup_schema(
        conn,
        schema,
        rows,
        M,
        domain,
        changed_pairs,
    )

    # D0 statistics become stale after D1 drift.
    reset_d0(conn, schema, M, domain)
    analyze_all_once(conn, schema, statistics_target)
    apply_drift(conn, schema, changed_pairs)

    if not verify_marginals(
        conn,
        schema,
        changed_pairs,
        domain,
        rows,
    ):
        raise RuntimeError(f"M={M}: marginal audit failed")

    profile = profile_candidates(
        conn,
        schema,
        M,
        sample_mod,
    )
    proposed = [
        int(r["pair_id"])
        for r in sorted(profile, key=lambda x: x["score"], reverse=True)[
            :changed_count
        ]
    ]

    truth = set(changed_pairs)
    pred = set(proposed)
    precision = len(truth & pred) / len(pred) if pred else 0.0
    recall = len(truth & pred) / len(truth)

    stale_q = geomean(
        [
            explain_qerror(conn, schema, k, query_value)
            for k in changed_pairs
        ]
    )

    # Each scenario is reset to the same D0 -> D1 state.
    reset_d0(conn, schema, M, domain)
    analyze_all_once(conn, schema, statistics_target)
    apply_drift(conn, schema, changed_pairs)
    full_times, full_median = repeat_timing(
        lambda: analyze_all_once(conn, schema, statistics_target),
        repeats,
    )
    full_q = geomean(
        [
            explain_qerror(conn, schema, k, query_value)
            for k in changed_pairs
        ]
    )

    reset_d0(conn, schema, M, domain)
    analyze_all_once(conn, schema, statistics_target)
    apply_drift(conn, schema, changed_pairs)
    selective_times, selective_median = repeat_timing(
        lambda: analyze_selected_once(
            conn,
            schema,
            proposed,
            statistics_target,
        ),
        repeats,
    )
    selective_q = geomean(
        [
            explain_qerror(conn, schema, k, query_value)
            for k in changed_pairs
        ]
    )

    # Measure fixed scan/startup proxy after the same D1 state.
    base_times, base_median = repeat_timing(
        lambda: analyze_base_once(
            conn,
            schema,
            statistics_target,
        ),
        repeats,
    )

    benefit_recovery = (
        (stale_q - selective_q)
        / max(stale_q - full_q, 1e-12)
    )

    total_ratio = selective_median / max(full_median, 1e-12)
    full_incremental = max(full_median - base_median, 0.0)
    selective_incremental = max(selective_median - base_median, 0.0)
    incremental_ratio = (
        selective_incremental / full_incremental
        if full_incremental > 0
        else float("nan")
    )

    detail_rows = []
    for method, values in [
        ("full_refresh", full_times),
        ("selective_refresh", selective_times),
        ("base_analyze", base_times),
    ]:
        for repeat_idx, value in enumerate(values, start=1):
            detail_rows.append(
                {
                    "M": M,
                    "s": changed_count,
                    "method": method,
                    "repeat": repeat_idx,
                    "seconds": value,
                }
            )

    summary = {
        "M": M,
        "s": changed_count,
        "physical_columns": 2 * M + 2,
        "changed_pairs": json.dumps(changed_pairs),
        "proposed_pairs": json.dumps(proposed),
        "precision": precision,
        "recall": recall,
        "stale_qerror": stale_q,
        "full_qerror": full_q,
        "selective_qerror": selective_q,
        "benefit_recovery": benefit_recovery,
        "base_analyze_median_s": base_median,
        "full_refresh_median_s": full_median,
        "selective_refresh_median_s": selective_median,
        "total_cost_ratio": total_ratio,
        "full_incremental_s": full_incremental,
        "selective_incremental_s": selective_incremental,
        "incremental_cost_ratio": incremental_ratio,
        "object_fraction": changed_count / M,
    }

    print(
        f"[M={M}] precision={precision:.3f} recall={recall:.3f} "
        f"Q stale/full/sel={stale_q:.2f}/{full_q:.2f}/{selective_q:.2f} "
        f"time base/full/sel={base_median:.3f}/{full_median:.3f}/"
        f"{selective_median:.3f}s ratio={total_ratio:.3f}",
        flush=True,
    )

    return detail_rows, summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dsn",
        default="postgresql://postgres:123456@localhost:5432/postgres",
    )
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--M-values", default="48,96,192,384")
    ap.add_argument("--rows", type=int, default=72_000)
    ap.add_argument("--domain", type=int, default=60)
    ap.add_argument("--changed-count", type=int, default=8)
    ap.add_argument("--timing-repeats", type=int, default=5)
    ap.add_argument("--sample-mod", type=int, default=12)
    ap.add_argument("--statistics-target", type=int, default=200)
    ap.add_argument("--query-value", type=int, default=7)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    M_values = parse_ints(args.M_values)
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    config = {
        **vars(args),
        "out": str(out),
        "M_values": M_values,
    }
    (out / "config.json").write_text(
        json.dumps(config, indent=2, default=str),
        encoding="utf-8",
    )

    print(
        "EvoStats Phase 0.5 — Maintenance Scaling Audit\n"
        "==============================================================\n"
        "Goal: repeat timing + scale candidate statistics universe\n"
        "Overall progress: [####------] 40%\n",
        flush=True,
    )

    conn = connect(args.dsn)
    all_detail = []
    summaries = []
    try:
        for M in M_values:
            detail, summary = run_one_M(
                conn,
                out,
                M,
                args.rows,
                args.domain,
                args.changed_count,
                args.timing_repeats,
                args.sample_mod,
                args.statistics_target,
                args.query_value,
                args.seed,
            )
            all_detail.extend(detail)
            summaries.append(summary)
    finally:
        conn.close()

    write_csv(out / "scaling_detail.csv", all_detail)
    write_csv(out / "scaling_summary.csv", summaries)

    largest = summaries[-1]
    quality_pass = all(
        row["precision"] >= 0.9
        and row["recall"] >= 0.9
        and row["benefit_recovery"] >= 0.9
        for row in summaries
    )
    scaling_pass = (
        largest["total_cost_ratio"] <= 0.25
        or (
            math.isfinite(largest["incremental_cost_ratio"])
            and largest["incremental_cost_ratio"] <= 0.25
        )
    )
    monotone_pass = (
        summaries[-1]["total_cost_ratio"]
        < summaries[0]["total_cost_ratio"]
    )
    go = quality_pass and scaling_pass and monotone_pass

    decision = {
        "quality_pass_all_M": quality_pass,
        "largest_M_cost_scaling_pass": scaling_pass,
        "cost_ratio_decreases_with_M": monotone_pass,
        "phase05_go": go,
        "largest_M": largest["M"],
        "largest_M_total_cost_ratio": largest["total_cost_ratio"],
        "largest_M_incremental_cost_ratio": largest[
            "incremental_cost_ratio"
        ],
        "decision": (
            "GO: proceed to Phase 1 contingency-residual statistic"
            if go
            else "NO-GO/REDESIGN: maintenance scaling not yet established"
        ),
    }
    (out / "gate_report.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    lines = [
        "EVOSTATS PHASE 0.5 MAINTENANCE SCALING REPORT",
        "=" * 78,
        "",
        "SUMMARY",
    ]
    for row in summaries:
        lines.append(
            f"M={row['M']:3d} s={row['s']:2d} "
            f"P/R={row['precision']:.2f}/{row['recall']:.2f} "
            f"Q={row['stale_qerror']:.2f}->{row['selective_qerror']:.2f} "
            f"benefit={row['benefit_recovery']:.3f} "
            f"base/full/sel={row['base_analyze_median_s']:.3f}/"
            f"{row['full_refresh_median_s']:.3f}/"
            f"{row['selective_refresh_median_s']:.3f}s "
            f"total_ratio={row['total_cost_ratio']:.3f} "
            f"incremental_ratio={row['incremental_cost_ratio']:.3f}"
        )
    lines += [
        "",
        "DECISION",
        json.dumps(decision, indent=2),
        "",
        decision["decision"],
    ]
    report = "\n".join(lines)
    (out / "gate_report.txt").write_text(
        report,
        encoding="utf-8",
    )
    print("\n" + report)


if __name__ == "__main__":
    main()
