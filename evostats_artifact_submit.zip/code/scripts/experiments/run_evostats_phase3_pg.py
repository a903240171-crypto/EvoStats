#!/usr/bin/env python3
"""
EvoStats Phase 3 — PostgreSQL End-to-End Hub Audit
==================================================

This experiment connects every validated component:

1. strength-preserving relabeling drift;
2. residual-shape probes;
3. node-first hit-and-expand localization;
4. PostgreSQL selected-column ANALYZE;
5. Q-error recovery and closure-cost savings.

Construction
------------
Columns:
- h: one 8-bit categorical hub, domain 0..255;
- y1..y8: spoke bits;
- remaining columns: stable decoys driven by an independent latent variable.

D0:
    y_k = bit_k(h)

D1:
    y_k = 1 - bit_k(h)

Thus:
- each h -> y_k remains a perfect functional dependency;
- dependency degree remains 1;
- all one-column marginals remain unchanged;
- spoke-spoke pairs remain independent;
- only the eight hub-spoke dependence shapes change.

The candidate universe is the complete graph over d=50 columns:
    M = C(50,2) = 1225.

Localization:
    random pair probes until the first verified residual hit,
    then expand both endpoints and independently verify candidates.

Expected:
- exact support recovery in Theta(M/s + 2d) probes;
- stale new-hot Q-error >= 10;
- selective ANALYZE on 9 columns refreshes closure C(9,2)=36;
- selective/full maintenance ratio near 36/1225;
- refreshed Q-error <= 2.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import random
import re
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import psycopg


def qi(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def all_edges(d: int) -> list[tuple[int, int]]:
    return list(itertools.combinations(range(d), 2))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def qerror(est: float, act: float) -> float:
    e = max(float(est), 1.0)
    a = max(float(act), 1.0)
    return max(e / a, a / e)


def connect(dsn: str):
    conn = psycopg.connect(dsn, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET jit = off")
        cur.execute("SET max_parallel_workers_per_gather = 0")
        cur.execute("SET track_io_timing = on")
        cur.execute("SET statement_timeout = 0")
    return conn


def column_names(spokes: int, decoys: int) -> list[str]:
    return (
        ["h"]
        + [f"y{k}" for k in range(1, spokes + 1)]
        + [f"z{k}" for k in range(1, decoys + 1)]
    )


def setup(
    conn,
    schema: str,
    spokes: int,
    decoys: int,
    repeat_factor: int,
    statistics_target: int,
) -> tuple[int, list[str]]:
    names = column_names(spokes, decoys)
    d = len(names)
    rows = 256 * 257 * repeat_factor
    s = qi(schema)

    cols = ["id bigint PRIMARY KEY"]
    cols += ["h integer NOT NULL"]
    cols += [f"y{k} integer NOT NULL" for k in range(1, spokes + 1)]
    cols += [f"z{k} integer NOT NULL" for k in range(1, decoys + 1)]

    with conn.cursor() as cur:
        print("[setup] drop/create schema", flush=True)
        cur.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        cur.execute(f"CREATE SCHEMA {s}")
        cur.execute(f"CREATE TABLE {s}.ref ({', '.join(cols)})")
        cur.execute(f"CREATE TABLE {s}.fact ({', '.join(cols)})")

        for table in ("ref", "fact"):
            cur.execute(
                f"""
                ALTER TABLE {s}.{table} SET (
                    autovacuum_enabled = false,
                    toast.autovacuum_enabled = false
                )
                """
            )

        exprs = [
            "g::bigint AS id",
            "mod(g::bigint, 256)::integer AS h",
        ]
        for k in range(spokes):
            exprs.append(
                f"((mod(g::bigint,256)::integer >> {k}) & 1) AS y{k+1}"
            )

        # u is independent of h because rows enumerate the full h x u grid.
        for k in range(1, decoys + 1):
            coeff = k + 1
            offset = 17 * k
            exprs.append(
                f"mod("
                f"(mod((g::bigint / 256),257) * {coeff}) + {offset},"
                f"257)::integer AS z{k}"
            )

        print(
            f"[setup] loading rows={rows:,}, d={d}, M={choose2(d):,}",
            flush=True,
        )
        cur.execute(
            f"""
            INSERT INTO {s}.ref
            SELECT {', '.join(exprs)}
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (rows,),
        )
        cur.execute(f"INSERT INTO {s}.fact SELECT * FROM {s}.ref")

        # Query indexes for the eight hub-spoke predicates.
        for k in range(1, spokes + 1):
            cur.execute(
                f"CREATE INDEX fact_h_y{k}_idx ON {s}.fact(h,y{k})"
            )

        print(
            f"[setup] creating all {choose2(d):,} extended-statistics objects",
            flush=True,
        )
        for i, j in itertools.combinations(range(d), 2):
            a, b = names[i], names[j]
            cur.execute(
                f"""
                CREATE STATISTICS {s}.{qi(f'evs_{i}_{j}')}
                    (dependencies, mcv)
                ON {a}, {b}
                FROM {s}.fact
                """
            )

        cur.execute(f"SET default_statistics_target={statistics_target}")
        cur.execute(f"VACUUM (ANALYZE) {s}.fact")

    return rows, names


def apply_drift(conn, schema: str, spokes: int) -> float:
    s = qi(schema)
    assignments = [f"y{k}=1-y{k}" for k in range(1, spokes + 1)]
    with conn.cursor() as cur:
        start = time.perf_counter()
        cur.execute(f"UPDATE {s}.fact SET {', '.join(assignments)}")
        return time.perf_counter() - start


def analyze_columns(
    conn,
    schema: str,
    columns: list[str],
    statistics_target: int,
) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target={statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact ({', '.join(columns)})")
        return time.perf_counter() - start


def analyze_all(conn, schema: str, statistics_target: int) -> float:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(f"SET default_statistics_target={statistics_target}")
        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact")
        return time.perf_counter() - start


def analyze_state(conn, schema: str) -> dict[str, Any]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT last_analyze,last_autoanalyze,n_mod_since_analyze
            FROM pg_stat_all_tables
            WHERE schemaname=%s AND relname='fact'
            """,
            (schema,),
        )
        row = cur.fetchone()
        return {
            "last_analyze": str(row[0]) if row and row[0] else None,
            "last_autoanalyze": str(row[1]) if row and row[1] else None,
            "n_mod_since_analyze": int(row[2]) if row else -1,
        }


def fetch_sample(
    conn,
    schema: str,
    table: str,
    names: list[str],
    modulus: int,
    residue: int,
    limit: int,
) -> np.ndarray:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT {', '.join(names)}
            FROM {s}.{table}
            WHERE mod(id,%s)=%s
            ORDER BY id
            LIMIT %s
            """,
            (modulus, residue, limit),
        )
        return np.asarray(cur.fetchall(), dtype=np.int32)


def residual_score(
    X0: np.ndarray,
    X1: np.ndarray,
    i: int,
    j: int,
) -> float:
    a0 = X0[:, i]
    b0 = X0[:, j]
    a1 = X1[:, i]
    b1 = X1[:, j]

    va = np.unique(np.concatenate([a0, a1]))
    vb = np.unique(np.concatenate([b0, b1]))
    amap = {int(v): k for k, v in enumerate(va)}
    bmap = {int(v): k for k, v in enumerate(vb)}

    def residual(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        ai = np.fromiter((amap[int(v)] for v in a), dtype=np.int32)
        bi = np.fromiter((bmap[int(v)] for v in b), dtype=np.int32)
        joint = np.bincount(
            ai.astype(np.int64) * len(vb) + bi.astype(np.int64),
            minlength=len(va) * len(vb),
        ).reshape(len(va), len(vb)).astype(np.float64)
        joint /= len(a)
        return joint - joint.sum(1, keepdims=True) @ joint.sum(0, keepdims=True)

    return 0.25 * float(np.abs(residual(a1, b1) - residual(a0, b0)).sum())


def localize(
    X0_disc: np.ndarray,
    X1_disc: np.ndarray,
    X0_ver: np.ndarray,
    X1_ver: np.ndarray,
    d: int,
    threshold: float,
    verify_threshold: float,
    seed: int,
) -> dict[str, Any]:
    edges = all_edges(d)
    edge_to_idx = {e: idx for idx, e in enumerate(edges)}
    incident = [[] for _ in range(d)]
    for idx, (u, v) in enumerate(edges):
        incident[u].append(idx)
        incident[v].append(idx)

    disc_cache: dict[int, float] = {}
    ver_cache: dict[int, float] = {}

    def disc(idx: int) -> float:
        if idx not in disc_cache:
            i, j = edges[idx]
            disc_cache[idx] = residual_score(X0_disc, X1_disc, i, j)
        return disc_cache[idx]

    def ver(idx: int) -> float:
        if idx not in ver_cache:
            i, j = edges[idx]
            ver_cache[idx] = residual_score(X0_ver, X1_ver, i, j)
        return ver_cache[idx]

    order = list(range(len(edges)))
    random.Random(seed).shuffle(order)

    first_hit_rank = None
    hit_idx = None
    for rank, idx in enumerate(order, start=1):
        if disc(idx) > threshold:
            first_hit_rank = rank
            hit_idx = idx
            break
    if hit_idx is None:
        raise RuntimeError("No residual hit found")

    u, v = edges[hit_idx]
    probed = set(order[:first_hit_rank])
    for node in (u, v):
        for idx in incident[node]:
            probed.add(idx)
            disc(idx)

    candidates = {
        idx for idx in probed if disc(idx) > threshold
    }
    verified = {
        idx for idx in candidates if ver(idx) > verify_threshold
    }

    return {
        "edges": edges,
        "first_hit_rank": first_hit_rank,
        "hit_edge": edges[hit_idx],
        "discovery_probes": len(disc_cache),
        "verification_probes": len(ver_cache),
        "total_probes": len(disc_cache) + len(ver_cache),
        "verified_indices": sorted(verified),
        "verified_edges": [edges[idx] for idx in sorted(verified)],
        "discovery_scores": {
            str(edges[idx]): disc_cache[idx] for idx in sorted(disc_cache)
        },
        "verification_scores": {
            str(edges[idx]): ver_cache[idx] for idx in sorted(ver_cache)
        },
    }


def dependency_degree_for_edge(
    conn,
    schema: str,
    edge_name: str,
) -> list[float]:
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT d.stxddependencies::text
            FROM pg_statistic_ext e
            JOIN pg_namespace n ON n.oid=e.stxnamespace
            JOIN pg_statistic_ext_data d ON d.stxoid=e.oid
            WHERE n.nspname=%s AND e.stxname=%s
            """,
            (schema, edge_name),
        )
        row = cur.fetchone()
        payload = row[0] if row and row[0] else ""
    return [
        float(x)
        for x in re.findall(r'\b(?:0\.\d+|1(?:\.0+)?)\b', payload)
    ]


def find_fact_scan(plan: dict[str, Any]) -> dict[str, Any] | None:
    if plan.get("Relation Name") == "fact":
        return plan
    for child in plan.get("Plans", []) or []:
        found = find_fact_scan(child)
        if found is not None:
            return found
    return None


def query_qerror(
    conn,
    schema: str,
    stage: str,
    spoke: int,
    h_value: int,
    y_value: int,
) -> dict[str, Any]:
    s = qi(schema)
    with conn.cursor() as cur:
        cur.execute(
            f"""
            EXPLAIN (ANALYZE,TIMING OFF,FORMAT JSON)
            SELECT COUNT(*)
            FROM {s}.fact
            WHERE h=%s AND y{spoke}=%s
            """,
            (h_value, y_value),
        )
        root = cur.fetchone()[0][0]["Plan"]
        scan = find_fact_scan(root)
        if scan is None:
            raise RuntimeError("fact scan not found")
        est = float(scan.get("Plan Rows", 0))
        act = float(scan.get("Actual Rows", 0))
        return {
            "stage": stage,
            "spoke": spoke,
            "h": h_value,
            "y": y_value,
            "estimated_rows": est,
            "actual_rows": act,
            "q_error": qerror(est, act),
            "scan_node": str(scan.get("Node Type", "?")),
        }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dsn",
        default="postgresql://postgres:123456@localhost:5432/postgres",
    )
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_phase3_hub")
    ap.add_argument("--spokes", type=int, default=8)
    ap.add_argument("--decoys", type=int, default=41)
    ap.add_argument("--repeat-factor", type=int, default=4)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--sample-limit", type=int, default=16384)
    ap.add_argument("--threshold", type=float, default=0.10)
    ap.add_argument("--verify-threshold", type=float, default=0.10)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "config.json").write_text(
        json.dumps({**vars(args), "out": str(out)}, indent=2, default=str),
        encoding="utf-8",
    )

    print(
        "EvoStats Phase 3 - PostgreSQL End-to-End Hub Audit\n"
        "================================================================\n"
        "Goal: relabeling drift -> residual localization -> selective ANALYZE\n"
        "Overall progress: [#########-] 90%\n",
        flush=True,
    )

    conn = connect(args.dsn)
    query_rows: list[dict[str, Any]] = []
    degree_rows: list[dict[str, Any]] = []

    try:
        rows, names = setup(
            conn,
            args.schema,
            args.spokes,
            args.decoys,
            args.repeat_factor,
            args.statistics_target,
        )
        d = len(names)
        M = choose2(d)
        truth = {(0, k) for k in range(1, args.spokes + 1)}

        # Dependency-degree witness before drift.
        for k in range(1, args.spokes + 1):
            degree_rows.append({
                "stage": "D0",
                "spoke": k,
                "degrees": json.dumps(
                    dependency_degree_for_edge(
                        conn, args.schema, f"evs_0_{k}"
                    )
                ),
            })

        print("[drift] flipping all hub-spoke mappings", flush=True)
        drift_seconds = apply_drift(conn, args.schema, args.spokes)
        state = analyze_state(conn, args.schema)
        if state["last_autoanalyze"] is not None:
            raise RuntimeError("auto-ANALYZE occurred")
        if state["n_mod_since_analyze"] <= 0:
            raise RuntimeError("stale state not established")

        # Independent discovery and verification samples.
        X0_disc = fetch_sample(
            conn, args.schema, "ref", names, 17, 0, args.sample_limit
        )
        X1_disc = fetch_sample(
            conn, args.schema, "fact", names, 17, 0, args.sample_limit
        )
        X0_ver = fetch_sample(
            conn, args.schema, "ref", names, 19, 1, args.sample_limit
        )
        X1_ver = fetch_sample(
            conn, args.schema, "fact", names, 19, 1, args.sample_limit
        )

        print("[localize] node-first hit-and-expand", flush=True)
        loc = localize(
            X0_disc, X1_disc, X0_ver, X1_ver,
            d, args.threshold, args.verify_threshold, args.seed
        )
        verified = set(tuple(e) for e in loc["verified_edges"])

        # Stale Q-error on the new-hot cell h=0,y=1 for every spoke.
        for k in range(1, args.spokes + 1):
            query_rows.append(
                query_qerror(
                    conn, args.schema, "D1_stale", k, 0, 1
                )
            )

        selected_nodes = sorted(
            {node for edge in verified for node in edge}
        )
        selected_columns = [names[node] for node in selected_nodes]
        closure = choose2(len(selected_nodes))

        print(
            f"[refresh] selective columns={selected_columns}, "
            f"closure={closure}/{M}",
            flush=True,
        )
        selective_seconds = analyze_columns(
            conn, args.schema, selected_columns, args.statistics_target
        )

        for k in range(1, args.spokes + 1):
            degree_rows.append({
                "stage": "D1_selective",
                "spoke": k,
                "degrees": json.dumps(
                    dependency_degree_for_edge(
                        conn, args.schema, f"evs_0_{k}"
                    )
                ),
            })
            query_rows.append(
                query_qerror(
                    conn, args.schema, "D1_selective", k, 0, 1
                )
            )

        print("[refresh] full ANALYZE for cost comparison", flush=True)
        full_seconds = analyze_all(
            conn, args.schema, args.statistics_target
        )

        write_csv(out / "query_results.csv", query_rows)
        write_csv(out / "dependency_degrees.csv", degree_rows)

        stale_q = statistics.geometric_mean(
            r["q_error"] for r in query_rows
            if r["stage"] == "D1_stale"
        )
        fresh_q = statistics.geometric_mean(
            r["q_error"] for r in query_rows
            if r["stage"] == "D1_selective"
        )

        precision = len(verified & truth) / max(len(verified), 1)
        recall = len(verified & truth) / len(truth)
        exact = verified == truth

        # Parse D0/D1 degrees conservatively.
        d0_vals = []
        d1_vals = []
        for row in degree_rows:
            vals = json.loads(row["degrees"])
            if row["stage"] == "D0":
                d0_vals.extend(vals)
            else:
                d1_vals.extend(vals)
        degree_delta = (
            max(abs(a-b) for a,b in zip(d0_vals,d1_vals))
            if d0_vals and d1_vals and len(d0_vals) == len(d1_vals)
            else float("nan")
        )

        theory_cost = M / args.spokes + 2 * d
        probe_pass = loc["total_probes"] <= 1.5 * theory_cost
        localization_pass = precision == 1.0 and recall == 1.0 and exact
        stale_pass = stale_q >= 10.0
        refresh_pass = fresh_q <= 2.0
        closure_pass = closure == choose2(args.spokes + 1)
        maintenance_pass = selective_seconds / full_seconds <= 0.10
        degree_pass = math.isfinite(degree_delta) and degree_delta <= 0.01

        go = all([
            probe_pass,
            localization_pass,
            stale_pass,
            refresh_pass,
            closure_pass,
            maintenance_pass,
            degree_pass,
        ])

        report = {
            "rows": rows,
            "d": d,
            "M": M,
            "s": args.spokes,
            "truth_edges": sorted(truth),
            "verified_edges": sorted(verified),
            "precision": precision,
            "recall": recall,
            "exact_recovery": exact,
            "first_hit_rank": loc["first_hit_rank"],
            "hit_edge": loc["hit_edge"],
            "discovery_probes": loc["discovery_probes"],
            "verification_probes": loc["verification_probes"],
            "total_probes": loc["total_probes"],
            "theory_M_over_s_plus_2d": theory_cost,
            "probe_bound_pass": probe_pass,
            "selected_nodes": selected_nodes,
            "selected_columns": selected_columns,
            "closure_objects": closure,
            "closure_fraction": closure / M,
            "closure_exact_pass": closure_pass,
            "stale_qerror_geomean": stale_q,
            "selective_qerror_geomean": fresh_q,
            "stale_qerror_pass": stale_pass,
            "refresh_qerror_pass": refresh_pass,
            "selective_analyze_seconds": selective_seconds,
            "full_analyze_seconds": full_seconds,
            "selective_full_time_ratio": selective_seconds / full_seconds,
            "maintenance_ratio_pass": maintenance_pass,
            "dependency_degree_values_d0": d0_vals,
            "dependency_degree_values_d1": d1_vals,
            "dependency_degree_max_delta": degree_delta,
            "dependency_degree_invariance_pass": degree_pass,
            "last_autoanalyze": state["last_autoanalyze"],
            "n_mod_since_analyze": state["n_mod_since_analyze"],
            "drift_seconds": drift_seconds,
            "phase3_go": go,
            "decision": (
                "GO: end-to-end EvoStats PostgreSQL pipeline validated"
                if go
                else "REDESIGN: inspect failed Phase 3 integration gate"
            ),
        }

        (out / "localization.json").write_text(
            json.dumps(loc, indent=2, default=str),
            encoding="utf-8",
        )
        (out / "gate_report.json").write_text(
            json.dumps(report, indent=2, default=str),
            encoding="utf-8",
        )

        lines = [
            "EVOSTATS PHASE 3 POSTGRESQL END-TO-END REPORT",
            "=" * 78,
            "",
            "LOCALIZATION",
            f"d={d}, M={M}, s={args.spokes}",
            f"first hit rank            : {loc['first_hit_rank']}",
            f"total probes              : {loc['total_probes']}",
            f"theory M/s+2d             : {theory_cost:.1f}",
            f"precision / recall        : {precision:.3f} / {recall:.3f}",
            f"exact recovery            : {exact}",
            "",
            "MAINTENANCE",
            f"selected columns          : {selected_columns}",
            f"closure                   : {closure}/{M} ({closure/M:.4f})",
            f"selective ANALYZE         : {selective_seconds:.3f}s",
            f"full ANALYZE              : {full_seconds:.3f}s",
            f"selective/full            : {selective_seconds/full_seconds:.4f}",
            "",
            "QUERY QUALITY",
            f"stale Q-error geomean     : {stale_q:.3f}",
            f"selective Q-error geomean : {fresh_q:.3f}",
            "",
            "DEPENDENCY DEGREE",
            f"D0 values                 : {d0_vals}",
            f"D1 values                 : {d1_vals}",
            f"max delta                 : {degree_delta}",
            "",
            "DECISION",
            json.dumps(report, indent=2, default=str),
            "",
            report["decision"],
        ]
        text = "\n".join(lines)
        (out / "gate_report.txt").write_text(text, encoding="utf-8")
        print("\n" + text)

    finally:
        conn.close()


if __name__ == "__main__":
    main()
