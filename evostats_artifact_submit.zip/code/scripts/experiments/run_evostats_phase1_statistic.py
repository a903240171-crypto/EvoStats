#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, itertools, json, math, random, statistics
from pathlib import Path
from typing import Any
import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score

SCORES = ["residual_l1", "mi_delta", "cramers_v_delta", "equality_delta"]
MECHANISMS = [
    "equality_on", "noisy_permutation_on", "modular_on",
    "diffuse_two_permutations_on", "weakening", "disappearance",
    "permutation_switch_diag_to_offdiag",
    "permutation_switch_offdiag",
]

def parse_ints(s: str) -> list[int]:
    return [int(x) for x in s.split(',') if x.strip()]

def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text('', encoding='utf-8'); return
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def pairs(d: int): return list(itertools.combinations(range(d), 2))

def matching(d: int, s: int, seed: int):
    if 2*s > d: raise ValueError('Need d >= 2s')
    cols = list(range(d)); random.Random(seed).shuffle(cols)
    return sorted((min(cols[2*k], cols[2*k+1]), max(cols[2*k], cols[2*k+1])) for k in range(s))

def balanced_col(n, q, rng):
    x = np.tile(np.arange(q, dtype=np.int16), n//q); rng.shuffle(x); return x

def independent_pair(n, q, rng):
    reps = n//(q*q)
    x = np.tile(np.repeat(np.arange(q, dtype=np.int16), q), reps)
    y = np.tile(np.tile(np.arange(q, dtype=np.int16), q), reps)
    o = rng.permutation(n); return x[o], y[o]

def perm_component(n, q, perm, rng):
    x = np.tile(np.arange(q, dtype=np.int16), n//q); y = perm[x]
    o = rng.permutation(n); return x[o], y[o]

def mixture_pair(n, q, rho, perms, rng):
    if rho == 0: return independent_pair(n, q, rng)
    dep = int(round(n*rho)); block = q*len(perms); dep = (dep//block)*block
    ind = n-dep
    rem = ind%(q*q)
    if rem: dep -= (q*q-rem); ind = n-dep
    xs=[]; ys=[]
    if ind:
        x,y = independent_pair(ind,q,rng); xs.append(x); ys.append(y)
    each = dep//len(perms)
    for p in perms:
        x,y = perm_component(each,q,p,rng); xs.append(x); ys.append(y)
    x=np.concatenate(xs); y=np.concatenate(ys); o=rng.permutation(n); return x[o], y[o]

def mech_pair(name, snap, n, q, rng):
    ident=np.arange(q,dtype=np.int16); shift1=np.roll(ident,-1); shift2=np.roll(ident,-2); rev=ident[::-1].copy()
    cfg={
      'equality_on': ((0,[ident]),(.75,[ident])),
      'noisy_permutation_on': ((0,[ident]),(.50,[rev])),
      'modular_on': ((0,[ident]),(.75,[shift1])),
      'diffuse_two_permutations_on': ((0,[ident]),(.75,[shift1,shift2])),
      'weakening': ((.75,[rev]),(.25,[rev])),
      'disappearance': ((.75,[shift1]),(0,[shift1])),
      # Strength-preserving relabeling. Equality rate changes here.
      'permutation_switch_diag_to_offdiag': ((.75,[ident]),(.75,[shift1])),
      # Strongest stress test: strength and equality rate are both preserved.
      'permutation_switch_offdiag': ((.75,[shift1]),(.75,[shift2])),
    }[name]
    rho, perms = cfg[0 if snap=='ref' else 1]
    return mixture_pair(n,q,rho,perms,rng)

def snapshots(n,d,q,changed,name,seed):
    r0=np.random.default_rng(seed*1009+17); r1=np.random.default_rng(seed*1009+31)
    X0=np.column_stack([balanced_col(n,q,r0) for _ in range(d)])
    X1=np.column_stack([balanced_col(n,q,r1) for _ in range(d)])
    for i,j in changed:
        X0[:,i],X0[:,j]=mech_pair(name,'ref',n,q,r0)
        X1[:,i],X1[:,j]=mech_pair(name,'cur',n,q,r1)
    target=n//q
    for X in (X0,X1):
        for j in range(d):
            if not np.all(np.bincount(X[:,j], minlength=q)==target):
                raise RuntimeError(f'marginal audit failed col={j}')
    return X0,X1

def features(x,y,q):
    n=len(x); joint=np.bincount(x.astype(np.int64)*q+y.astype(np.int64), minlength=q*q).reshape(q,q).astype(float)/n
    px=joint.sum(1,keepdims=True); py=joint.sum(0,keepdims=True); exp=px@py; res=joint-exp
    mask=joint>0; mi=float(np.sum(joint[mask]*np.log(joint[mask]/exp[mask])))
    chi=float(np.sum((joint-exp)**2/np.maximum(exp,1e-15))); v=math.sqrt(max(chi/max(q-1,1),0))
    return res,mi,v,float(np.trace(joint))

def score_pairs(X0,X1,q):
    out=[]
    for i,j in pairs(X0.shape[1]):
        r0,mi0,v0,e0=features(X0[:,i],X0[:,j],q); r1,mi1,v1,e1=features(X1[:,i],X1[:,j],q)
        out.append({'i':i,'j':j,'residual_l1':.25*float(np.abs(r1-r0).sum()),'mi_delta':abs(mi1-mi0),'cramers_v_delta':abs(v1-v0),'equality_delta':abs(e1-e0)})
    return out

def calibrate(n,d,q,seeds,quant):
    pool={k:[] for k in SCORES}; rows=[]
    for seed in seeds:
        X0,X1=snapshots(n,d,q,[],'equality_on',seed+70000); ss=score_pairs(X0,X1,q)
        for k in SCORES:
            vals=[r[k] for r in ss]; pool[k]+=vals
            rows.append({'n':n,'d':d,'seed':seed,'score':k,'mean':statistics.mean(vals),'p95':float(np.quantile(vals,.95)),'max':max(vals)})
    return {k:float(np.quantile(v,quant)) for k,v in pool.items()}, rows

def eval_score(rows, changed, name, budget, threshold):
    y=np.array([int((r['i'],r['j']) in changed) for r in rows]); s=np.array([r[name] for r in rows])
    order=np.argsort(-s)[:budget]; tp=int(y[order].sum()); null=y==0
    return {'auroc':float(roc_auc_score(y,s)),'auprc':float(average_precision_score(y,s)),'precision_at_budget':tp/budget,'recall_at_budget':tp/max(int(y.sum()),1),'null_fpr':float(np.mean(s[null]>threshold))}

def run_setting(n,d,q,s,name,seeds,thresholds,save_pairs):
    metrics=[]; dump=[]
    for seed in seeds:
        ch=matching(d,s,seed+991); chs=set(ch); X0,X1=snapshots(n,d,q,ch,name,seed); rows=score_pairs(X0,X1,q)
        for r in rows: r['changed']=int((r['i'],r['j']) in chs)
        for score in SCORES:
            metrics.append({'n':n,'d':d,'M':d*(d-1)//2,'s':s,'mechanism':name,'seed':seed,'score':score,**eval_score(rows,chs,score,s,thresholds[score])})
        if save_pairs:
            dump += [{'n':n,'d':d,'mechanism':name,'seed':seed,**r} for r in rows]
    return metrics,dump

def aggregate(rows, keys):
    groups={}
    for r in rows: groups.setdefault(tuple(r[k] for k in keys),[]).append(r)
    out=[]
    for key,items in groups.items():
        rec={k:v for k,v in zip(keys,key)}; rec['seeds']=len(items)
        for m in ['auroc','auprc','precision_at_budget','recall_at_budget','null_fpr']:
            vals=[x[m] for x in items]; rec[m+'_mean']=statistics.mean(vals); rec[m+'_std']=statistics.pstdev(vals)
        out.append(rec)
    return sorted(out,key=lambda r:tuple(r[k] for k in keys))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,required=True); ap.add_argument('--d',type=int,default=30); ap.add_argument('--q',type=int,default=8); ap.add_argument('--s',type=int,default=6); ap.add_argument('--main-n',type=int,default=8192); ap.add_argument('--n-values',default='2048,4096,8192,16384'); ap.add_argument('--seeds',default='1,2,3,4,5'); ap.add_argument('--null-quantile',type=float,default=.95); a=ap.parse_args()
    ns=parse_ints(a.n_values); seeds=parse_ints(a.seeds)
    for n in set(ns+[a.main_n]):
        if n%(a.q*a.q): raise ValueError('all n must be divisible by q^2')
    out=a.out.resolve(); out.mkdir(parents=True,exist_ok=True); (out/'config.json').write_text(json.dumps({**vars(a),'out':str(out),'n_values':ns,'seeds':seeds,'mechanisms':MECHANISMS},indent=2,default=str),encoding='utf-8')
    print(f'EvoStats Phase 1 Unified Audit\nd={a.d}, M={a.d*(a.d-1)//2}, s={a.s}, q={a.q}, main_n={a.main_n}\nOverall [#####-----] 50%')
    thresholds,null_rows=calibrate(a.main_n,a.d,a.q,seeds,a.null_quantile); print('[null]',thresholds)
    all_rows=[]; pair_dump=[]
    for mech in MECHANISMS:
        rows,dump=run_setting(a.main_n,a.d,a.q,a.s,mech,seeds,thresholds,True); all_rows+=rows; pair_dump+=dump
        rr=[r for r in rows if r['score']=='residual_l1']; print(f"{mech:30s} AUROC={statistics.mean(x['auroc'] for x in rr):.3f} AUPRC={statistics.mean(x['auprc'] for x in rr):.3f} R@B={statistics.mean(x['recall_at_budget'] for x in rr):.3f}")
    mech_res=aggregate(all_rows,['mechanism','score','n','d','M','s']); write_csv(out/'mechanism_results.csv',mech_res); write_csv(out/'pair_scores.csv',pair_dump); write_csv(out/'null_calibration.csv',null_rows)
    sc=[]
    for n in ns:
        th,_=calibrate(n,a.d,a.q,seeds,a.null_quantile)
        for mech in MECHANISMS:
            rows,_=run_setting(n,a.d,a.q,a.s,mech,seeds,th,False); sc += [r for r in rows if r['score']=='residual_l1']
    sc_res=aggregate(sc,['n','mechanism','score','d','M','s']); write_csv(out/'sample_complexity.csv',sc_res)
    main_res=[r for r in mech_res if r['score']=='residual_l1' and r['n']==a.main_n]
    get=lambda mech,score: next(r for r in mech_res if r['mechanism']==mech and r['score']==score and r['n']==a.main_n)
    diag_res=get('permutation_switch_diag_to_offdiag','residual_l1')
    diag_mi=get('permutation_switch_diag_to_offdiag','mi_delta')
    diag_v=get('permutation_switch_diag_to_offdiag','cramers_v_delta')
    diag_eq=get('permutation_switch_diag_to_offdiag','equality_delta')

    off_res=get('permutation_switch_offdiag','residual_l1')
    off_mi=get('permutation_switch_offdiag','mi_delta')
    off_v=get('permutation_switch_offdiag','cramers_v_delta')
    off_eq=get('permutation_switch_offdiag','equality_delta')

    quality=all(r['auroc_mean']>=.95 and r['auprc_mean']>=.90 and r['recall_at_budget_mean']>=.90 for r in main_res)
    null_ok=all(r['null_fpr_mean']<=.08 for r in main_res)

    # MI and Cramer's V are invariant to a bijective relabeling of one variable.
    strength_invariance=(
        diag_res['auroc_mean']>=.95
        and diag_mi['auroc_mean']<=.70
        and diag_v['auroc_mean']<=.70
    )

    # Off-diagonal switch preserves equality rate as well:
    # y=x+1 (mod q) -> y=x+2 (mod q).
    all_proxy_blind_spot=(
        off_res['auroc_mean']>=.95
        and off_mi['auroc_mean']<=.70
        and off_v['auroc_mean']<=.70
        and off_eq['auroc_mean']<=.70
    )

    largest=[r for r in sc_res if r['n']==max(ns)]
    sample_ok=all(r['recall_at_budget_mean']>=.90 for r in largest)
    go=quality and null_ok and strength_invariance and all_proxy_blind_spot and sample_ok

    decision={
      'residual_quality_pass_all_mechanisms':quality,
      'null_fpr_pass':null_ok,
      'strength_invariance_blind_spot_pass':strength_invariance,
      'offdiag_all_proxy_blind_spot_pass':all_proxy_blind_spot,
      'sample_complexity_largest_n_pass':sample_ok,
      'phase1_go':go,
      'diag_to_offdiag_residual_auroc':diag_res['auroc_mean'],
      'diag_to_offdiag_mi_auroc':diag_mi['auroc_mean'],
      'diag_to_offdiag_cramers_v_auroc':diag_v['auroc_mean'],
      'diag_to_offdiag_equality_auroc':diag_eq['auroc_mean'],
      'offdiag_switch_residual_auroc':off_res['auroc_mean'],
      'offdiag_switch_mi_auroc':off_mi['auroc_mean'],
      'offdiag_switch_cramers_v_auroc':off_v['auroc_mean'],
      'offdiag_switch_equality_auroc':off_eq['auroc_mean'],
      'decision':'GO: proceed to Phase 2 sparse localization algorithm' if go else 'REDESIGN: inspect failed Phase 1 statistic gate'
    }
    (out/'gate_report.json').write_text(json.dumps(decision,indent=2),encoding='utf-8')
    lines=['EVOSTATS PHASE 1 DEPENDENCY-RESIDUAL REPORT','='*78,'','MAIN RESULTS — RESIDUAL L1']
    for r in main_res: lines.append(f"{r['mechanism']:30s} AUROC={r['auroc_mean']:.3f} AUPRC={r['auprc_mean']:.3f} P@B={r['precision_at_budget_mean']:.3f} R@B={r['recall_at_budget_mean']:.3f} nullFPR={r['null_fpr_mean']:.3f}")
    lines += [
      '',
      'KILLER TABLE — BIJECTIVE RELABELING',
      (
        'diag->offdiag: '
        f"Residual={diag_res['auroc_mean']:.3f}, "
        f"MI={diag_mi['auroc_mean']:.3f}, "
        f"CramersV={diag_v['auroc_mean']:.3f}, "
        f"Equality={diag_eq['auroc_mean']:.3f}"
      ),
      (
        'offdiag->offdiag: '
        f"Residual={off_res['auroc_mean']:.3f}, "
        f"MI={off_mi['auroc_mean']:.3f}, "
        f"CramersV={off_v['auroc_mean']:.3f}, "
        f"Equality={off_eq['auroc_mean']:.3f}"
      ),
      '',
      'DECISION',
      json.dumps(decision,indent=2),
      '',
      decision['decision'],
      '',
      'Interpretation:',
      '- MI and Cramers V preserve dependence strength under bijective relabeling.',
      '- Equality delta can detect diagonal-to-offdiagonal movement, but fails',
      '  when both couplings are off-diagonal and have equal trace.',
      '- Residual L1 compares the full dependence shape and detects both.'
    ]
    report='\n'.join(lines); (out/'gate_report.txt').write_text(report,encoding='utf-8'); print('\n'+report)
if __name__=='__main__': main()
