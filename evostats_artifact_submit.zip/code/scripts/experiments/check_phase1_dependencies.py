#!/usr/bin/env python3
try:
    import numpy
    import sklearn
except ImportError as exc:
    raise SystemExit(2) from exc

print(f"numpy {numpy.__version__} sklearn {sklearn.__version__}")
