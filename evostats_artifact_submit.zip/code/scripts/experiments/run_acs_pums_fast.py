#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, itertools, json, math, statistics, zipfile
from pathlib import Path
import numpy as np
import pandas as pd

def choose2(n): return n*(n-1)//2

def write_csv(path, rows):
    if not rows:
        path.write_text("", encoding="utf-8"); return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def find_cached_csv(data_dir, year):
    cs=sorted(data_dir.glob(f"*{year}*.csv"))
    if cs: return cs[0]
    zs=sorted(data_dir.glob(f"*{year}*.zip"))
    if not zs: raise FileNotFoundError(f"No cached {year} data in {data_dir}")
    z=zs[0]
    with zipfile.ZipFile(z) as zf:
        ms=[n for n in zf.namelist() if n.lower().endswith(".csv") and "psam_p" in n.lower()]
        if not ms: ms=[n for n in zf.namelist() if n.lower().endswith(".csv")]
        m=sorted(ms,key=len)[0]
        t=data_dir/f"{year}_{Path(m).name}"
        if not t.exists():
            with zf.open(m) as src, t.open("wb") as dst: dst.write(src.read())
        return t

def uniform_sample_csv(path,n,seed):
    rng=np.random.default_rng(seed); fs=[]; ks=[]
    for chunk in pd.read_csv(path,dtype=str,chunksize=50000,low_memory=False):
        key=rng.random(len(chunk))
        if len(chunk)>n:
            idx=np.argpartition(key,n-1)[:n]; chunk=chunk.iloc[idx].copy(); key=key[idx]
        fs.append(chunk); ks.append(key)
        if sum(map(len,fs))>3*n:
            frame=pd.concat(fs,ignore_index=True); key=np.concatenate(ks)
            idx=np.argpartition(key,n-1)[:n]
            fs=[frame.iloc[idx].copy()]; ks=[key[idx]]
    frame=pd.concat(fs,ignore_index=True); key=np.concatenate(ks)
    if len(frame)>n:
        idx=np.argpartition(key,n-1)[:n]; frame=frame.iloc[idx]
    return frame.reset_index(drop=True)

def norm_series(s):
    return s.astype("string").fillna("<NA>").str.strip().replace({"":"<NA>","nan":"<NA>","None":"<NA>"})

def select_variables(a,b,max_vars,max_card):
    ex=("PWGTP","WGTP","SERIALNO","SPORDER","ADJINC","ADJHSG")
    rows=[]
    for c in sorted(set(a.columns)&set(b.columns)):
        if c.upper().startswith(ex): continue
        sa,sb=norm_series(a[c]),norm_series(b[c])
        card=len(set(sa.unique())|set(sb.unique()))
        miss=max(float((sa=="<NA>").mean()),float((sb=="<NA>").mean()))
        ok=2<=card<=max_card and miss<=.2
        rows.append({"variable":c,"cardinality":card,"missing":miss,"eligible":int(ok),"score":math.log1p(card)-5*miss})
    elig=sorted([r for r in rows if r["eligible"]],key=lambda r:(-r["score"],r["variable"]))[:max_vars]
    sel=[r["variable"] for r in elig]; ss=set(sel)
    for r in rows:r["selected"]=int(r["variable"] in ss)
    return sel,rows

def encode_frames(frames,vars):
    arrs=[np.empty((len(f),len(vars)),dtype=np.int16) for f in frames]; cards=[]
    for j,c in enumerate(vars):
        vals=set(); ns=[]
        for f in frames:
            s=norm_series(f[c]); ns.append(s); vals.update(s.unique().tolist())
        cats=sorted(vals); mp={v:i for i,v in enumerate(cats)}; cards.append(len(cats))
        for a,s in zip(arrs,ns): a[:,j]=s.map(mp).astype(np.int16).to_numpy()
    return arrs,cards

def residual_score(X0,X1,i,j,ci,cj):
    def res(X):
        joint=np.bincount(X[:,i].astype(np.int64)*cj+X[:,j].astype(np.int64),minlength=ci*cj).reshape(ci,cj).astype(float)
        joint/=len(X)
        return joint-joint.sum(1,keepdims=True)@joint.sum(0,keepdims=True)
    return .25*float(np.abs(res(X1)-res(X0)).sum())

def bh(p):
    m=len(p); o=np.argsort(p); r=p[o]; q=r*m/np.arange(1,m+1); q=np.minimum.accumulate(q[::-1])[::-1]; q=np.clip(q,0,1)
    out=np.empty(m); out[o]=q; return out

def geometry(d,edges,vars):
    deg=[0]*d
    for u,v in edges: deg[u]+=1; deg[v]+=1
    order=sorted(range(d),key=lambda x:deg[x],reverse=True); cov=set(); rows=[]
    for rank,n in enumerate(order,1):
        cov|={e for e in edges if n in e}
        rows.append({"rank":rank,"node":n,"variable":vars[n],"degree":deg[n],"covered_edges":len(cov),"covered_fraction":len(cov)/max(len(edges),1)})
    active={v for e in edges for v in e}
    return rows,{"d":d,"M":choose2(d),"support_edges":len(edges),"support_density":len(edges)/choose2(d),"active_nodes":len(active),"max_degree":max(deg) if deg else 0,"top1_edge_cover":rows[0]["covered_fraction"] if rows else 0,"top5_edge_cover":rows[min(4,len(rows)-1)]["covered_fraction"] if rows else 0}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",type=Path,required=True); ap.add_argument("--cache-dir",type=Path,required=True)
    ap.add_argument("--year-a",type=int,default=2019); ap.add_argument("--year-b",type=int,default=2021)
    ap.add_argument("--rows",type=int,default=40000); ap.add_argument("--max-vars",type=int,default=80)
    ap.add_argument("--max-cardinality",type=int,default=24); ap.add_argument("--null-repeats",type=int,default=6)
    ap.add_argument("--fdr",type=float,default=.05); ap.add_argument("--seed",type=int,default=42)
    a=ap.parse_args(); out=a.out.resolve(); out.mkdir(parents=True,exist_ok=True)
    pa,pb=find_cached_csv(a.cache_dir,a.year_a),find_cached_csv(a.cache_dir,a.year_b)
    print("[load] sampling",flush=True)
    pool=uniform_sample_csv(pa,2*a.rows,a.seed+a.year_a); Araw=pool.iloc[:a.rows].reset_index(drop=True); Braw=uniform_sample_csv(pb,a.rows,a.seed+a.year_b)
    vars,selrows=select_variables(Araw,Braw,a.max_vars,a.max_cardinality); write_csv(out/"variable_selection.csv",selrows)
    d=len(vars); M=choose2(d); print(f"[variables] d={d} M={M}",flush=True)
    rng=np.random.default_rng(a.seed); base=np.arange(len(pool)); parts=[]
    for _ in range(a.null_repeats):
        o=rng.permutation(base); parts.append((pool.iloc[o[:a.rows]].reset_index(drop=True),pool.iloc[o[a.rows:2*a.rows]].reset_index(drop=True)))
    frames=[Araw,Braw]
    for l,r in parts: frames += [l,r]
    arrs,cards=encode_frames(frames,vars); A,B=arrs[0],arrs[1]; nulls=[(arrs[2+2*k],arrs[3+2*k]) for k in range(a.null_repeats)]
    pairs=list(itertools.combinations(range(d),2)); rows=[]; poolz=[]
    for idx,(i,j) in enumerate(pairs,1):
        real=residual_score(A,B,i,j,cards[i],cards[j])
        nv=np.array([residual_score(L,R,i,j,cards[i],cards[j]) for L,R in nulls],float)
        mu=float(nv.mean()); sd=float(nv.std(ddof=1)); z=(real-mu)/sd if sd>0 else (999 if real>mu else 0)
        for r in range(len(nv)):
            oth=np.delete(nv,r); om=float(oth.mean()); os=float(oth.std(ddof=1)); poolz.append((nv[r]-om)/os if os>0 else 0)
        rows.append({"i":i,"j":j,"variable_i":vars[i],"variable_j":vars[j],"cells":cards[i]*cards[j],"residual_drift":real,"null_mean":mu,"null_std":sd,"excess_over_null":real-mu,"z_score":z})
        if idx%500==0 or idx==M: print(f"[pairs] {idx}/{M}",flush=True)
    nz=np.sort(np.array(poolz,float))
    for r in rows:
        ge=len(nz)-int(np.searchsorted(nz,r["z_score"],side="left")); r["empirical_p"]=(1+ge)/(1+len(nz))
    q=bh(np.array([r["empirical_p"] for r in rows]))
    for r,v in zip(rows,q): r["bh_qvalue"]=float(v); r["selected_bh_fdr"]=int(v<=a.fdr)
    rows.sort(key=lambda r:r["residual_drift"],reverse=True); write_csv(out/"pair_drift_scores.csv",rows)
    edges={(int(r["i"]),int(r["j"])) for r in rows if r["selected_bh_fdr"]}
    degrows,sup=geometry(d,edges,vars); write_csv(out/"degree_summary.csv",degrows); write_csv(out/"support_summary.csv",[sup])
    rm=statistics.mean(r["residual_drift"] for r in rows); nm=statistics.mean(r["null_mean"] for r in rows)
    dec={**sup,"year_a":a.year_a,"year_b":a.year_b,"rows_per_snapshot":a.rows,"null_repeats":a.null_repeats,"fdr":a.fdr,"mean_real_score":rm,"mean_pair_null_score":nm,"real_null_ratio":rm/max(nm,1e-15)}
    dec["structured_sparse"]=sup["support_edges"]>=5 and sup["support_density"]<=.05 and (sup["top1_edge_cover"]>=.3 or sup["top5_edge_cover"]>=.7)
    dec["decision"]="STRUCTURED-SPARSE" if dec["structured_sparse"] else "NOT YET ESTABLISHED"
    (out/"gate_report.json").write_text(json.dumps(dec,indent=2),encoding="utf-8")
    lines=["EVOSTATS PHASE 4A v6 FAST ACS PUMS REPORT","="*78,f"d / M                    : {d} / {M}",f"rows per snapshot        : {a.rows}",f"null repeats             : {a.null_repeats}",f"BH FDR                   : {a.fdr}",f"mean real / pair-null    : {rm:.6f} / {nm:.6f}",f"real/null ratio          : {dec['real_null_ratio']:.3f}",f"detected support         : {sup['support_edges']}",f"support density          : {sup['support_density']:.5f}",f"max degree               : {sup['max_degree']}",f"top1 / top5 cover        : {sup['top1_edge_cover']:.3f} / {sup['top5_edge_cover']:.3f}","","TOP 20"]
    for r in rows[:20]: lines.append(f"{r['variable_i']:15s} - {r['variable_j']:15s} D={r['residual_drift']:.5f} z={r['z_score']:.2f} p={r['empirical_p']:.4g} q={r['bh_qvalue']:.4g} sel={r['selected_bh_fdr']}")
    lines += ["","DECISION",json.dumps(dec,indent=2)]
    rep="\n".join(lines); (out/"gate_report.txt").write_text(rep,encoding="utf-8"); print("\n"+rep)
if __name__=="__main__": main()
