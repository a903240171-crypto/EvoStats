#!/usr/bin/env python3
"""
PostgreSQL extended-statistics Go/No-Go (native-safe v2).

This is an end-to-end DBMS experiment, not a detector simulation.

It tests:
Gate 0 — Does missing multivariate statistics cause real PostgreSQL
         cardinality/plan/runtime regressions, and do correct statistics fix them?
Gate 1 — Can a small, automatically selected budget of statistics objects recover
         most of the benefit of creating all candidate objects?

The data construction preserves every single-column marginal exactly:
- x_k is uniform on {0,...,m-1}
- y_k is also uniform on {0,...,m-1}
- for ordinary pairs, x_k and y_k are independent
- for drifted pairs, y_k = x_k

Thus single-column statistics are unchanged, while conjunction selectivity changes
by a factor of m.

Requirements:
    pip install "psycopg[binary]>=3.2"

Example:
    python run_pg_extstats_gonogo.py ^
      --dsn "postgresql://postgres:postgres@localhost:55432/postgres" ^
      --out "D:/ICDE-SignedSketch/results/pg_extstats_gonogo"

Default scale:
    1,000,000 fact rows
    8 candidate column pairs
    3 truly drifted/dependent pairs
    budget = 3 statistics objects
"""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

try:
    import psycopg
    from psycopg import sql
except ImportError as exc:
    raise SystemExit(
        'Missing dependency. Run: pip install "psycopg[binary]>=3.2"'
    ) from exc


@dataclass
class QueryResult:
    scenario: str
    pair_id: int
    dependent: bool
    workload_weight: float
    estimated_rows: float
    actual_rows: float
    q_error: float
    execution_ms: float
    plan_signature: str
    scan_node: str
    shared_hit_blocks: int
    shared_read_blocks: int


def qerror(estimated: float, actual: float) -> float:
    e = max(float(estimated), 1.0)
    a = max(float(actual), 1.0)
    return max(e / a, a / e)


def quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def connect(dsn: str):
    conn = psycopg.connect(dsn, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET jit = off")
        cur.execute("SET max_parallel_workers_per_gather = 0")
        cur.execute("SET track_io_timing = on")
        cur.execute("SET statement_timeout = 0")
    return conn


def execute(cur, statement: str, params=None):
    cur.execute(statement, params)


def fetchone_value(cur, statement: str, params=None):
    cur.execute(statement, params)
    row = cur.fetchone()
    return row[0] if row else None


def create_schema_and_data(
    conn,
    schema: str,
    rows: int,
    pairs: int,
    domain: int,
    dependent_pairs: set[int],
    lookup_rows: int,
) -> None:
    if rows % (domain * domain) != 0:
        raise ValueError(
            f"--rows must be divisible by domain^2={domain*domain}; got {rows}"
        )

    s = quote_ident(schema)
    with conn.cursor() as cur:
        print("[setup] dropping old schema", flush=True)
        cur.execute(f"DROP SCHEMA IF EXISTS {s} CASCADE")
        cur.execute(f"CREATE SCHEMA {s}")

        pair_columns = []
        for k in range(1, pairs + 1):
            pair_columns += [f"x{k} integer NOT NULL", f"y{k} integer NOT NULL"]

        cur.execute(
            f"""
            CREATE TABLE {s}.fact (
                id bigint PRIMARY KEY,
                payload_id integer NOT NULL,
                {", ".join(pair_columns)}
            )
            """
        )
        cur.execute(
            f"""
            CREATE TABLE {s}.lookup (
                id integer PRIMARY KEY,
                cost integer NOT NULL,
                pad text NOT NULL
            )
            """
        )

        print(f"[setup] loading lookup rows={lookup_rows:,}", flush=True)
        cur.execute(
            f"""
            INSERT INTO {s}.lookup(id, cost, pad)
            SELECT g,
                   mod(g::bigint * 17, 1000)::integer + 1,
                   repeat(md5(g::text), 4)
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (lookup_rows,),
        )

        select_exprs = [
            "g::bigint AS id",
            f"mod(g::bigint * 7919, {lookup_rows})::integer AS payload_id",
        ]
        for k in range(1, pairs + 1):
            x = f"mod(g::bigint, {domain})::integer"
            if k in dependent_pairs:
                y = x
            else:
                # Exact independence over each domain^2 block.
                y = f"mod((g::bigint / {domain}) + {13*k}, {domain})::integer"
            select_exprs += [f"{x} AS x{k}", f"{y} AS y{k}"]

        print(
            f"[setup] loading fact rows={rows:,}, pairs={pairs}, "
            f"dependent={sorted(dependent_pairs)}",
            flush=True,
        )
        cur.execute(
            f"""
            INSERT INTO {s}.fact
            SELECT {", ".join(select_exprs)}
            FROM generate_series(0::bigint, (%s - 1)::bigint) AS t(g)
            """,
            (rows,),
        )

        print("[setup] creating single-column indexes", flush=True)
        for k in range(1, pairs + 1):
            cur.execute(f"CREATE INDEX fact_x{k}_idx ON {s}.fact (x{k})")
            cur.execute(f"CREATE INDEX fact_y{k}_idx ON {s}.fact (y{k})")

        cur.execute(f"VACUUM (ANALYZE) {s}.fact")
        cur.execute(f"VACUUM (ANALYZE) {s}.lookup")


def verify_exact_marginals(
    conn,
    schema: str,
    pairs: int,
    domain: int,
    rows: int,
) -> list[dict[str, Any]]:
    s = quote_ident(schema)
    expected_single = rows / domain
    records = []

    with conn.cursor() as cur:
        for k in range(1, pairs + 1):
            cur.execute(
                f"""
                SELECT
                    COUNT(DISTINCT x{k}),
                    COUNT(DISTINCT y{k}),
                    MIN(cx), MAX(cx), MIN(cy), MAX(cy)
                FROM (
                    SELECT x{k}, y{k},
                           COUNT(*) OVER (PARTITION BY x{k}) AS cx,
                           COUNT(*) OVER (PARTITION BY y{k}) AS cy
                    FROM {s}.fact
                ) z
                """
            )
            dx, dy, min_x, max_x, min_y, max_y = cur.fetchone()
            records.append(
                {
                    "pair_id": k,
                    "distinct_x": int(dx),
                    "distinct_y": int(dy),
                    "min_frequency_x": int(min_x),
                    "max_frequency_x": int(max_x),
                    "min_frequency_y": int(min_y),
                    "max_frequency_y": int(max_y),
                    "expected_frequency": float(expected_single),
                    "exact_uniform": bool(
                        dx == domain
                        and dy == domain
                        and min_x == max_x == expected_single
                        and min_y == max_y == expected_single
                    ),
                }
            )
    return records


def drop_statistics(conn, schema: str) -> None:
    s = quote_ident(schema)
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT stxname
            FROM pg_statistic_ext
            WHERE stxnamespace = %s::regnamespace
            """,
            (schema,),
        )
        names = [row[0] for row in cur.fetchall()]
        for name in names:
            cur.execute(f"DROP STATISTICS IF EXISTS {s}.{quote_ident(name)}")


def install_statistics(
    conn,
    schema: str,
    selected_pairs: Iterable[int],
    statistics_target: int,
) -> tuple[float, int]:
    selected = sorted(set(int(x) for x in selected_pairs))
    s = quote_ident(schema)
    drop_statistics(conn, schema)

    with conn.cursor() as cur:
        for k in selected:
            cur.execute(
                f"""
                CREATE STATISTICS {s}.{quote_ident(f'evs_pair_{k}')}
                    (dependencies, mcv)
                ON x{k}, y{k}
                FROM {s}.fact
                """
            )

        cur.execute(
            f"ALTER TABLE {s}.fact SET (autovacuum_enabled = false)"
        )
        cur.execute(f"SET default_statistics_target = {int(statistics_target)}")

        start = time.perf_counter()
        cur.execute(f"ANALYZE {s}.fact")
        analyze_seconds = time.perf_counter() - start

        if selected:
            cur.execute(
                """
                SELECT COALESCE(SUM(
                    COALESCE(pg_column_size(d.stxddependencies), 0) +
                    COALESCE(pg_column_size(d.stxdmcv), 0) +
                    COALESCE(pg_column_size(d.stxdndistinct), 0)
                ), 0)
                FROM pg_statistic_ext e
                JOIN pg_statistic_ext_data d ON d.stxoid = e.oid
                WHERE e.stxnamespace = %s::regnamespace
                """,
                (schema,),
            )
            storage_bytes = int(cur.fetchone()[0] or 0)
        else:
            storage_bytes = 0

    return analyze_seconds, storage_bytes


def find_fact_scan(plan: dict[str, Any]) -> dict[str, Any] | None:
    if plan.get("Relation Name") == "fact":
        return plan
    for child in plan.get("Plans", []) or []:
        found = find_fact_scan(child)
        if found is not None:
            return found
    return None


def plan_signature(plan: dict[str, Any]) -> str:
    parts = [str(plan.get("Node Type", "?"))]
    relation = plan.get("Relation Name")
    index = plan.get("Index Name")
    if relation:
        parts[-1] += f"[{relation}]"
    if index:
        parts[-1] += f"<{index}>"
    children = plan.get("Plans", []) or []
    if children:
        parts.append("(" + ",".join(plan_signature(c) for c in children) + ")")
    return "".join(parts)


def run_explain(
    conn,
    schema: str,
    pair_id: int,
    value: int,
    repeats: int,
    scenario: str,
    dependent: bool,
    workload_weight: float,
) -> QueryResult:
    s = quote_ident(schema)
    query = f"""
        SELECT SUM(l.cost)
        FROM {s}.fact f
        JOIN {s}.lookup l ON l.id = f.payload_id
        WHERE f.x{pair_id} = %s
          AND f.y{pair_id} = %s
    """

    records = []
    with conn.cursor() as cur:
        # Warm both data and plan paths.
        cur.execute(
            "EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) " + query,
            (value, value),
        )
        cur.fetchone()

        for _ in range(repeats):
            cur.execute(
                "EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) " + query,
                (value, value),
            )
            doc = cur.fetchone()[0]
            root_doc = doc[0]
            root_plan = root_doc["Plan"]
            scan = find_fact_scan(root_plan)
            if scan is None:
                raise RuntimeError("Could not find fact scan in EXPLAIN JSON")

            records.append(
                {
                    "estimated_rows": float(scan.get("Plan Rows", 0)),
                    "actual_rows": float(scan.get("Actual Rows", 0)),
                    "execution_ms": float(root_doc.get("Execution Time", 0)),
                    "plan_signature": plan_signature(root_plan),
                    "scan_node": str(scan.get("Node Type", "?")),
                    "shared_hit_blocks": int(scan.get("Shared Hit Blocks", 0)),
                    "shared_read_blocks": int(scan.get("Shared Read Blocks", 0)),
                }
            )

    median_record = {
        key: statistics.median([r[key] for r in records])
        if key not in {"plan_signature", "scan_node"}
        else max(
            set(r[key] for r in records),
            key=lambda x: sum(r[key] == x for r in records),
        )
        for key in records[0]
    }

    return QueryResult(
        scenario=scenario,
        pair_id=pair_id,
        dependent=dependent,
        workload_weight=workload_weight,
        estimated_rows=float(median_record["estimated_rows"]),
        actual_rows=float(median_record["actual_rows"]),
        q_error=qerror(
            median_record["estimated_rows"],
            median_record["actual_rows"],
        ),
        execution_ms=float(median_record["execution_ms"]),
        plan_signature=str(median_record["plan_signature"]),
        scan_node=str(median_record["scan_node"]),
        shared_hit_blocks=int(median_record["shared_hit_blocks"]),
        shared_read_blocks=int(median_record["shared_read_blocks"]),
    )


def profile_candidates(
    conn,
    schema: str,
    pairs: int,
    sample_mod: int,
    workload_weights: dict[int, float],
) -> list[dict[str, Any]]:
    s = quote_ident(schema)
    rows = []

    with conn.cursor() as cur:
        for k in range(1, pairs + 1):
            cur.execute(
                f"""
                WITH sample AS (
                    SELECT x{k} AS x, y{k} AS y
                    FROM {s}.fact
                    WHERE mod(id, %s) = 0
                )
                SELECT
                    COUNT(*)::bigint,
                    COUNT(DISTINCT x)::bigint,
                    COUNT(DISTINCT y)::bigint,
                    COUNT(DISTINCT (x, y))::bigint
                FROM sample
                """,
                (sample_mod,),
            )
            n, dx, dy, dxy = [int(x) for x in cur.fetchone()]
            inflation = (dx * dy) / max(dxy, 1)
            dependence_score = max(0.0, math.log(max(inflation, 1.0)))
            weight = float(workload_weights[k])
            impact_score = dependence_score * weight

            rows.append(
                {
                    "pair_id": k,
                    "sample_rows": n,
                    "distinct_x": dx,
                    "distinct_y": dy,
                    "distinct_xy": dxy,
                    "inflation_proxy": inflation,
                    "dependence_score": dependence_score,
                    "workload_weight": weight,
                    "impact_score": impact_score,
                }
            )
    return rows


def weighted_geomean(values: list[float], weights: list[float]) -> float:
    total = sum(weights)
    if total <= 0:
        return float("nan")
    return math.exp(
        sum(w * math.log(max(v, 1e-12)) for v, w in zip(values, weights))
        / total
    )


def summarize_scenario(
    scenario: str,
    query_results: list[QueryResult],
    analyze_seconds: float,
    storage_bytes: int,
    selected_pairs: list[int],
) -> dict[str, Any]:
    weights = [r.workload_weight for r in query_results]
    qerrors = [r.q_error for r in query_results]
    runtimes = [r.execution_ms for r in query_results]

    dep = [r for r in query_results if r.dependent]
    indep = [r for r in query_results if not r.dependent]

    return {
        "scenario": scenario,
        "selected_pairs": selected_pairs,
        "selected_count": len(selected_pairs),
        "analyze_seconds": analyze_seconds,
        "statistics_storage_bytes": storage_bytes,
        "weighted_geomean_qerror": weighted_geomean(qerrors, weights),
        "weighted_mean_runtime_ms": (
            sum(w * t for w, t in zip(weights, runtimes)) / sum(weights)
        ),
        "dependent_median_qerror": statistics.median(
            [r.q_error for r in dep]
        ) if dep else float("nan"),
        "independent_median_qerror": statistics.median(
            [r.q_error for r in indep]
        ) if indep else float("nan"),
        "dependent_mean_runtime_ms": statistics.mean(
            [r.execution_ms for r in dep]
        ) if dep else float("nan"),
        "plan_signatures": sorted(set(r.plan_signature for r in query_results)),
    }


def choose_scenarios(
    profile: list[dict[str, Any]],
    dependent_pairs: set[int],
    pairs: int,
    budget: int,
    random_seed: int,
) -> dict[str, list[int]]:
    all_pairs = list(range(1, pairs + 1))
    oracle = sorted(dependent_pairs)[:budget]
    proposed = [
        int(r["pair_id"])
        for r in sorted(profile, key=lambda x: x["impact_score"], reverse=True)[:budget]
    ]
    frequency = [
        int(r["pair_id"])
        for r in sorted(profile, key=lambda x: x["workload_weight"], reverse=True)[:budget]
    ]
    rng = random.Random(random_seed)
    random_choice = sorted(rng.sample(all_pairs, k=budget))

    return {
        "none": [],
        "all": all_pairs,
        "oracle_budget": oracle,
        "proposed_budget": proposed,
        "frequency_budget": frequency,
        "random_budget": random_choice,
    }


def compute_go_nogo(
    summaries: dict[str, dict[str, Any]],
    details: list[QueryResult],
    dependent_pairs: set[int],
) -> dict[str, Any]:
    none = summaries["none"]
    all_stats = summaries["all"]
    oracle = summaries["oracle_budget"]
    proposed = summaries["proposed_budget"]

    none_q = none["weighted_geomean_qerror"]
    all_q = all_stats["weighted_geomean_qerror"]
    proposed_q = proposed["weighted_geomean_qerror"]

    max_possible_q_gain = max(none_q - all_q, 1e-12)
    proposed_q_recovery = (none_q - proposed_q) / max_possible_q_gain

    none_t = none["weighted_mean_runtime_ms"]
    all_t = all_stats["weighted_mean_runtime_ms"]
    proposed_t = proposed["weighted_mean_runtime_ms"]
    max_possible_t_gain = max(none_t - all_t, 1e-12)
    proposed_t_recovery = (
        (none_t - proposed_t) / max_possible_t_gain
        if none_t > all_t
        else 0.0
    )

    detail_by = {}
    for r in details:
        detail_by[(r.scenario, r.pair_id)] = r

    plan_changes = 0
    runtime_improvements = []
    for pair_id in dependent_pairs:
        a = detail_by[("none", pair_id)]
        b = detail_by[("all", pair_id)]
        if a.plan_signature != b.plan_signature:
            plan_changes += 1
        if a.execution_ms > 0:
            runtime_improvements.append(
                (a.execution_ms - b.execution_ms) / a.execution_ms
            )

    median_runtime_improvement = (
        statistics.median(runtime_improvements)
        if runtime_improvements else 0.0
    )

    gate0_q = (
        none["dependent_median_qerror"] >= 10.0
        and all_stats["dependent_median_qerror"] <= 2.0
    )
    gate0_system = (
        plan_changes >= 1
        or median_runtime_improvement >= 0.20
    )
    gate0 = gate0_q and gate0_system

    gate1_selection = (
        set(proposed["selected_pairs"]) == set(oracle["selected_pairs"])
        or len(set(proposed["selected_pairs"]) & dependent_pairs)
        >= max(1, math.ceil(0.8 * len(dependent_pairs)))
    )
    gate1_benefit = proposed_q_recovery >= 0.80
    gate1_budget = (
        proposed["selected_count"] < all_stats["selected_count"]
        and proposed["statistics_storage_bytes"]
        <= max(1, 0.60 * all_stats["statistics_storage_bytes"])
    )
    gate1 = gate1_selection and gate1_benefit and gate1_budget

    real_system_value = gate0 and gate1

    return {
        "gate0_qerror_pass": gate0_q,
        "gate0_plan_or_runtime_pass": gate0_system,
        "gate0_pass": gate0,
        "gate1_selection_pass": gate1_selection,
        "gate1_benefit_pass": gate1_benefit,
        "gate1_budget_pass": gate1_budget,
        "gate1_pass": gate1,
        "real_system_value_go": real_system_value,
        "dependent_plan_changes_none_to_all": plan_changes,
        "dependent_median_runtime_improvement": median_runtime_improvement,
        "proposed_qerror_benefit_recovery": proposed_q_recovery,
        "proposed_runtime_benefit_recovery": proposed_t_recovery,
        "decision": (
            "GO: proceed to a real benchmark/workload"
            if real_system_value
            else "NO-GO: do not turn this into a paper yet"
        ),
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    import csv
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            cooked = {
                k: json.dumps(v, ensure_ascii=False)
                if isinstance(v, (list, dict))
                else v
                for k, v in row.items()
            }
            writer.writerow(cooked)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dsn",
        default="postgresql://postgres:postgres@localhost:55432/postgres",
    )
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_gonogo")
    ap.add_argument("--rows", type=int, default=1_000_000)
    ap.add_argument("--pairs", type=int, default=8)
    ap.add_argument("--domain", type=int, default=100)
    ap.add_argument("--dependent-pairs", default="2,5,8")
    ap.add_argument("--budget", type=int, default=3)
    ap.add_argument("--lookup-rows", type=int, default=200_000)
    ap.add_argument("--sample-mod", type=int, default=50)
    ap.add_argument("--statistics-target", type=int, default=200)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--query-value", type=int, default=7)
    ap.add_argument("--random-seed", type=int, default=42)
    args = ap.parse_args()

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    dependent_pairs = {
        int(x.strip())
        for x in args.dependent_pairs.split(",")
        if x.strip()
    }
    if not dependent_pairs:
        raise ValueError("Need at least one dependent pair")
    if max(dependent_pairs) > args.pairs:
        raise ValueError("dependent pair id exceeds --pairs")
    if args.budget < len(dependent_pairs):
        print(
            "[warning] budget is smaller than dependent-pair count; "
            "oracle budget will be truncated",
            flush=True,
        )

    # Deliberately put the highest workload frequencies on mostly non-dependent
    # pairs, so frequency-only is not an oracle.
    base_weights = [20, 18, 16, 14, 12, 10, 8, 6]
    if args.pairs > len(base_weights):
        base_weights += [
            max(1, 6 - i) for i in range(args.pairs - len(base_weights))
        ]
    workload_weights = {
        k: float(base_weights[k - 1])
        for k in range(1, args.pairs + 1)
    }

    config = {
        **vars(args),
        "out": str(out),
        "dependent_pairs": sorted(dependent_pairs),
        "workload_weights": workload_weights,
    }
    (out / "config.json").write_text(
        json.dumps(config, indent=2, default=str),
        encoding="utf-8",
    )

    conn = connect(args.dsn)
    try:
        create_schema_and_data(
            conn,
            args.schema,
            args.rows,
            args.pairs,
            args.domain,
            dependent_pairs,
            args.lookup_rows,
        )

        print("[audit] verifying exact single-column marginals", flush=True)
        marginals = verify_exact_marginals(
            conn,
            args.schema,
            args.pairs,
            args.domain,
            args.rows,
        )
        write_csv(out / "marginal_audit.csv", marginals)
        if not all(r["exact_uniform"] for r in marginals):
            raise RuntimeError("Marginal audit failed; stop")

        print("[profile] scoring candidate column pairs", flush=True)
        profile = profile_candidates(
            conn,
            args.schema,
            args.pairs,
            args.sample_mod,
            workload_weights,
        )
        for r in profile:
            r["truly_dependent"] = int(r["pair_id"] in dependent_pairs)
        write_csv(out / "candidate_profile.csv", profile)

        scenarios = choose_scenarios(
            profile,
            dependent_pairs,
            args.pairs,
            args.budget,
            args.random_seed,
        )
        (out / "scenario_selection.json").write_text(
            json.dumps(scenarios, indent=2),
            encoding="utf-8",
        )
        print(f"[selection] {json.dumps(scenarios)}", flush=True)

        all_details: list[QueryResult] = []
        summaries: dict[str, dict[str, Any]] = {}

        # Keep scenario order fixed but warm every query separately.
        for scenario, selected in scenarios.items():
            print(
                f"\n[scenario] {scenario}: selected={selected}",
                flush=True,
            )
            analyze_seconds, storage_bytes = install_statistics(
                conn,
                args.schema,
                selected,
                args.statistics_target,
            )

            scenario_results = []
            for k in range(1, args.pairs + 1):
                result = run_explain(
                    conn,
                    args.schema,
                    k,
                    args.query_value,
                    args.repeats,
                    scenario,
                    k in dependent_pairs,
                    workload_weights[k],
                )
                scenario_results.append(result)
                all_details.append(result)
                print(
                    f"  pair={k} dep={int(k in dependent_pairs)} "
                    f"est={result.estimated_rows:.0f} "
                    f"act={result.actual_rows:.0f} "
                    f"Q={result.q_error:.2f} "
                    f"time={result.execution_ms:.2f}ms "
                    f"scan={result.scan_node}",
                    flush=True,
                )

            summaries[scenario] = summarize_scenario(
                scenario,
                scenario_results,
                analyze_seconds,
                storage_bytes,
                selected,
            )

        detail_rows = [asdict(x) for x in all_details]
        summary_rows = [summaries[name] for name in scenarios]
        write_csv(out / "query_detail.csv", detail_rows)
        write_csv(out / "scenario_summary.csv", summary_rows)

        decision = compute_go_nogo(
            summaries,
            all_details,
            dependent_pairs,
        )
        (out / "go_nogo.json").write_text(
            json.dumps(decision, indent=2),
            encoding="utf-8",
        )

        report = [
            "POSTGRESQL EXTENDED-STATISTICS GO/NO-GO",
            "=" * 78,
            "",
            f"Rows: {args.rows:,}",
            f"Candidate pairs: {args.pairs}",
            f"True dependent pairs: {sorted(dependent_pairs)}",
            f"Budget: {args.budget}",
            "",
            "SCENARIO SUMMARY",
        ]
        for row in summary_rows:
            report += [
                (
                    f"{row['scenario']:18s} "
                    f"selected={str(row['selected_pairs']):12s} "
                    f"Q={row['weighted_geomean_qerror']:.3f} "
                    f"time={row['weighted_mean_runtime_ms']:.2f}ms "
                    f"ANALYZE={row['analyze_seconds']:.2f}s "
                    f"storage={row['statistics_storage_bytes']}B"
                )
            ]

        report += [
            "",
            "DECISION",
            json.dumps(decision, indent=2),
            "",
            decision["decision"],
        ]
        report_text = "\n".join(report)
        (out / "go_nogo_report.txt").write_text(
            report_text,
            encoding="utf-8",
        )
        print("\n" + report_text)

    finally:
        conn.close()


if __name__ == "__main__":
    main()
