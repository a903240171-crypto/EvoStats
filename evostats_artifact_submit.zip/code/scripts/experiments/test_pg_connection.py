#!/usr/bin/env python3
import os
import psycopg

with psycopg.connect(os.environ["EVOSTATS_DSN"]) as conn:
    with conn.cursor() as cur:
        cur.execute("select version()")
        print(cur.fetchone()[0])
