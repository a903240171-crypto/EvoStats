#!/usr/bin/env python3
"""
EvoStats Phase 2 v2 — Theory-Aligned Localization Audit

Corrects the Phase 2 v1 design:
- removes the failed adaptive explorer;
- uses node-first hit-and-expand as the method;
- evaluates exact-recovery cost, not impossible fixed-budget recall;
- scales s with d using s = ceil(alpha*d);
- separates matching and hub support.

Claims tested:
1. Random first hit needs Theta(M/s) probes.
2. Matching exact recovery needs Theta(M) probes.
3. Hub exact recovery with hit-and-expand needs Theta(M/s + d) probes.
4. The speedup over full scan grows with s when M/s dominates d.

The probe world is noiseless at the support level. This audit isolates search
complexity rather than re-testing the Phase 1 residual statistic.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import random
import statistics
from pathlib import Path
from typing import Any


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def all_edges(d: int) -> list[tuple[int, int]]:
    return list(itertools.combinations(range(d), 2))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def matching_support(d: int, s: int, rng: random.Random) -> set[tuple[int, int]]:
    if 2 * s > d:
        raise ValueError(f"matching requires 2s<=d, got d={d}, s={s}")
    nodes = list(range(d))
    rng.shuffle(nodes)
    return {
        tuple(sorted((nodes[2*k], nodes[2*k+1])))
        for k in range(s)
    }


def hub_support(d: int, s: int, rng: random.Random) -> set[tuple[int, int]]:
    hub = rng.randrange(d)
    spokes = rng.sample([v for v in range(d) if v != hub], s)
    return {tuple(sorted((hub, v))) for v in spokes}


def shuffled_edge_order(M: int, seed: int) -> list[int]:
    order = list(range(M))
    random.Random(seed).shuffle(order)
    return order


def first_hit_cost(order: list[int], truth_idx: set[int]) -> int:
    for rank, idx in enumerate(order, start=1):
        if idx in truth_idx:
            return rank
    return len(order)


def matching_exact_cost(order: list[int], truth_idx: set[int]) -> int:
    found = 0
    for rank, idx in enumerate(order, start=1):
        if idx in truth_idx:
            found += 1
            if found == len(truth_idx):
                return rank
    return len(order)


def hub_hit_expand_cost(
    d: int,
    edges: list[tuple[int, int]],
    edge_to_idx: dict[tuple[int, int], int],
    order: list[int],
    truth_idx: set[int],
) -> tuple[int, int]:
    """
    Probe random edges until first hit. Then expand both endpoints.

    One endpoint is the hub and reveals all stale spokes. Expanding both costs
    at most 2(d-1) incident probes, with duplicates removed.
    """
    first = first_hit_cost(order, truth_idx)
    hit_idx = order[first - 1]
    u, v = edges[hit_idx]

    probed = set(order[:first])
    for node in (u, v):
        for other in range(d):
            if other == node:
                continue
            e = tuple(sorted((node, other)))
            probed.add(edge_to_idx[e])

    recovered = len(probed & truth_idx)
    return len(probed), recovered


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    keys = ["d", "M", "s", "structure", "algorithm"]
    groups: dict[tuple, list[dict[str, Any]]] = {}
    for row in rows:
        key = tuple(row[k] for k in keys)
        groups.setdefault(key, []).append(row)

    out = []
    for key, items in groups.items():
        rec = {k: v for k, v in zip(keys, key)}
        for metric in [
            "probes",
            "probe_fraction",
            "speedup_vs_full",
            "first_hit_probes",
            "recovered_fraction",
            "exact_recovery",
        ]:
            vals = [float(x[metric]) for x in items]
            rec[f"{metric}_mean"] = statistics.mean(vals)
            rec[f"{metric}_std"] = statistics.pstdev(vals)
        rec["runs"] = len(items)
        out.append(rec)
    return sorted(out, key=lambda r: tuple(r[k] for k in keys))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--d-values", default="100,200,500,1000")
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--seeds", type=int, default=200)
    args = ap.parse_args()

    d_values = [int(x) for x in args.d_values.split(",") if x.strip()]
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    config = {
        "d_values": d_values,
        "alpha": args.alpha,
        "seeds": args.seeds,
    }
    (out / "config.json").write_text(
        json.dumps(config, indent=2),
        encoding="utf-8",
    )

    print(
        "EvoStats Phase 2 v2 — Theory-Aligned Localization\n"
        "==============================================================\n"
        f"d={d_values}, s=ceil({args.alpha}d), seeds={args.seeds}\n"
        "Methods: full_scan, random_matching_exact, node_first_hub\n"
        "Overall progress: [########--] 80%\n",
        flush=True,
    )

    detail: list[dict[str, Any]] = []

    for d in d_values:
        s = max(2, int(math.ceil(args.alpha * d)))
        if 2 * s > d:
            s = d // 2

        edges = all_edges(d)
        edge_to_idx = {e: i for i, e in enumerate(edges)}
        M = len(edges)

        for seed in range(1, args.seeds + 1):
            rng_m = random.Random(seed * 1009 + d)
            rng_h = random.Random(seed * 2017 + d)

            matching = matching_support(d, s, rng_m)
            hub = hub_support(d, s, rng_h)

            matching_idx = {edge_to_idx[e] for e in matching}
            hub_idx = {edge_to_idx[e] for e in hub}

            order_m = shuffled_edge_order(M, seed * 7919 + d)
            order_h = shuffled_edge_order(M, seed * 1543 + d)

            hit_m = first_hit_cost(order_m, matching_idx)
            exact_m = matching_exact_cost(order_m, matching_idx)

            hit_h = first_hit_cost(order_h, hub_idx)
            hub_cost, hub_recovered = hub_hit_expand_cost(
                d, edges, edge_to_idx, order_h, hub_idx
            )

            detail.append({
                "d": d,
                "M": M,
                "s": s,
                "structure": "matching",
                "algorithm": "random_exact",
                "seed": seed,
                "probes": exact_m,
                "probe_fraction": exact_m / M,
                "speedup_vs_full": M / exact_m,
                "first_hit_probes": hit_m,
                "recovered_fraction": 1.0,
                "exact_recovery": 1,
            })

            detail.append({
                "d": d,
                "M": M,
                "s": s,
                "structure": "hub",
                "algorithm": "node_first",
                "seed": seed,
                "probes": hub_cost,
                "probe_fraction": hub_cost / M,
                "speedup_vs_full": M / hub_cost,
                "first_hit_probes": hit_h,
                "recovered_fraction": hub_recovered / s,
                "exact_recovery": int(hub_recovered == s),
            })

            detail.append({
                "d": d,
                "M": M,
                "s": s,
                "structure": "all",
                "algorithm": "full_scan",
                "seed": seed,
                "probes": M,
                "probe_fraction": 1.0,
                "speedup_vs_full": 1.0,
                "first_hit_probes": 1.0,
                "recovered_fraction": 1.0,
                "exact_recovery": 1,
            })

        print(
            f"d={d:4d} M={M:7d} s={s:3d} "
            f"theory M/s={M/s:8.1f}, M/s+d={M/s+d:8.1f}",
            flush=True,
        )

    write_csv(out / "trial_detail.csv", detail)
    summary = summarize(detail)
    write_csv(out / "summary.csv", summary)

    gate_rows = [r for r in summary if r["algorithm"] != "full_scan"]

    matching_rows = [r for r in gate_rows if r["structure"] == "matching"]
    hub_rows = [r for r in gate_rows if r["structure"] == "hub"]

    # Theory checks.
    hit_tight = all(
        0.75 <= r["first_hit_probes_mean"] / (r["M"] / r["s"]) <= 1.35
        for r in matching_rows + hub_rows
    )

    matching_linear = all(
        r["probe_fraction_mean"] >= 0.75
        for r in matching_rows
    )

    hub_bound = all(
        r["probes_mean"] <= 1.5 * (r["M"] / r["s"] + 2 * r["d"])
        for r in hub_rows
    )

    hub_exact = all(
        r["exact_recovery_mean"] >= 0.99
        for r in hub_rows
    )

    speedup_grows = (
        hub_rows[-1]["speedup_vs_full_mean"]
        > hub_rows[0]["speedup_vs_full_mean"]
    )

    go = hit_tight and matching_linear and hub_bound and hub_exact and speedup_grows

    decision = {
        "first_hit_matches_M_over_s": hit_tight,
        "matching_exact_recovery_is_linear": matching_linear,
        "hub_cost_matches_M_over_s_plus_d": hub_bound,
        "hub_exact_recovery_pass": hub_exact,
        "hub_speedup_grows_with_s": speedup_grows,
        "phase2_go": go,
        "decision": (
            "GO: use node-first hit-and-expand as EvoStats localization core"
            if go
            else "REDESIGN: inspect failed theory-aligned localization gate"
        ),
    }

    (out / "gate_report.json").write_text(
        json.dumps(decision, indent=2),
        encoding="utf-8",
    )

    lines = [
        "EVOSTATS PHASE 2 v2 THEORY-ALIGNED REPORT",
        "=" * 78,
        "",
        "SUMMARY",
    ]
    for r in summary:
        if r["algorithm"] == "full_scan":
            continue
        lines.append(
            f"d={r['d']:4d} M={r['M']:7d} s={r['s']:3d} "
            f"{r['structure']:8s} {r['algorithm']:12s} "
            f"probes={r['probes_mean']:.1f} "
            f"probe/M={r['probe_fraction_mean']:.3f} "
            f"speedup={r['speedup_vs_full_mean']:.2f}x "
            f"first_hit={r['first_hit_probes_mean']:.1f} "
            f"exact={r['exact_recovery_mean']:.3f}"
        )

    lines += [
        "",
        "DECISION",
        json.dumps(decision, indent=2),
        "",
        decision["decision"],
        "",
        "Interpretation:",
        "- Matching exact recovery remains near-linear in M.",
        "- Hub localization pays first-hit cost Theta(M/s), then O(d) expansion.",
        "- The method is node-first hit-and-expand; the failed adaptive explorer",
        "  from Phase 2 v1 is removed.",
    ]

    report = "\n".join(lines)
    (out / "gate_report.txt").write_text(report, encoding="utf-8")
    print("\n" + report)


if __name__ == "__main__":
    main()
