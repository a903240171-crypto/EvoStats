#!/usr/bin/env python3
r"""
Phase 6B: multi-cell retirement safety audit for EvoStats.

Purpose
-------
The original retire-or-refresh classifier uses one verified pair-cell.
This audit tests whether that cell-level decision safely supports an
object-level retirement action.

For every operationally stale pair:
  1. Reproduce the original audited-cell decision.
  2. Select additional cells from three evidence strata:
       - top-K current-support cells;
       - top-K stale/reference-hot cells;
       - K deterministic random currently-supported cells.
  3. Compare:
       stale/reference-joint estimate,
       current lower-order (independence) estimate,
       refreshed/current-joint estimate.
  4. Report decision flips, unsafe retire objects, false-retire count,
     quantiles, and worst-case degradation.

This is a data-side counterfactual audit. It intentionally does not modify
PostgreSQL catalogs. The existing PostgreSQL experiment remains the source of
the exact audited-cell Q-errors. This script answers the reviewer's granularity
question: does lower-order adequacy persist across multiple supported cells of
the same object?

Default severe-pair input:
    results/phase4g_ambient_width/qerrors_d109.csv

Default output:
    results/phase6b_multicell_retire_audit/

Snapshot discovery
------------------
The script searches common repository paths for reference/current encoded
snapshots in CSV, Parquet, NPY, or NPZ form. For exact reproducibility, explicit
paths are preferred:

    python phase6_review/run_multicell_retire_safety.py ^
      --reference PATH_TO_2019_ENCODED ^
      --current PATH_TO_2021_ENCODED

Both snapshots must expose the qerrors variable names, e.g. H_RMSP.

Decision protocol
-----------------
- Original retire candidate:
      lower-order Q-error on (worst_i, worst_j) <= action threshold.
- Multi-cell safe retire:
      lower-order Q-error <= action threshold on every selected supported cell.
- False retire:
      original decision is retire, but at least one selected cell fails.
- Refreshed estimate is the current joint cell count and therefore Q-error 1
  in this empirical counterfactual audit.

Use the same support floor and Q-error boundary as the paper:
    support >= 20, action threshold Q <= 2.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


PAIR_LEFT = "variable_i"
PAIR_RIGHT = "variable_j"
WORST_LEFT = "worst_i"
WORST_RIGHT = "worst_j"
ACTUAL_ROWS = "actual_rows"
STALE_QERROR = "stale_qerror"


@dataclass
class ObjectSummary:
    variable_i: str
    variable_j: str
    audited_value_i: str
    audited_value_j: str
    audited_actual: int
    audited_stale_qerror_pg: float
    audited_lower_qerror: float
    original_action: str
    sampled_cells: int
    max_lower_qerror: float
    geo_lower_qerror: float
    p90_lower_qerror: float
    unsafe_cells: int
    multi_cell_action: str
    action_flip: bool
    worst_value_i: str
    worst_value_j: str
    worst_actual: int
    worst_lower_estimate: float
    worst_lower_qerror: float
    stale_better_cells: int
    lower_better_cells: int


def qerror(estimate: float, actual: float) -> float:
    e = max(float(estimate), 1.0)
    a = max(float(actual), 1.0)
    return max(e / a, a / e)


def geometric_mean(values: Sequence[float]) -> float:
    vals = np.asarray(values, dtype=float)
    vals = vals[np.isfinite(vals) & (vals > 0)]
    if vals.size == 0:
        return float("nan")
    return float(np.exp(np.mean(np.log(vals))))


def normalize_scalar(x: object) -> str:
    if pd.isna(x):
        return "__NA__"
    if isinstance(x, (np.integer, int)):
        return str(int(x))
    if isinstance(x, (np.floating, float)):
        if float(x).is_integer():
            return str(int(x))
        return format(float(x), ".17g")
    return str(x)


def coerce_value_for_series(raw: object, series: pd.Series) -> object:
    """
    Convert CSV cell labels such as '1' or '1.0' to the snapshot column dtype.
    Falls back to the raw normalized string for categorical/object columns.
    """
    if pd.api.types.is_integer_dtype(series.dtype):
        return int(float(raw))
    if pd.api.types.is_float_dtype(series.dtype):
        return float(raw)
    if pd.api.types.is_bool_dtype(series.dtype):
        text = str(raw).strip().lower()
        return text in {"1", "true", "t", "yes"}
    return normalize_scalar(raw)


def canonical_pair(a: str, b: str) -> Tuple[str, str]:
    return (a, b) if a <= b else (b, a)


def read_npz(path: Path) -> pd.DataFrame:
    with np.load(path, allow_pickle=True) as z:
        keys = list(z.keys())

        # Common representation: X plus columns/feature_names.
        x_key = next((k for k in ["X", "data", "encoded", "array"] if k in z), None)
        c_key = next(
            (k for k in ["columns", "feature_names", "variable_names", "names"] if k in z),
            None,
        )
        if x_key and c_key:
            x = np.asarray(z[x_key])
            cols = [normalize_scalar(v) for v in np.asarray(z[c_key]).tolist()]
            if x.ndim != 2 or x.shape[1] != len(cols):
                raise ValueError(f"Incompatible X/columns arrays in {path}")
            return pd.DataFrame(x, columns=cols)

        # Alternative: one 1-D array per variable.
        arrays = {}
        lengths = set()
        for k in keys:
            arr = np.asarray(z[k])
            if arr.ndim == 1:
                arrays[k] = arr
                lengths.add(len(arr))
        if arrays and len(lengths) == 1:
            return pd.DataFrame(arrays)

    raise ValueError(
        f"Could not infer a tabular snapshot from NPZ {path}. Keys: {keys}"
    )


def load_snapshot(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path, low_memory=False)
    if suffix in {".parquet", ".pq"}:
        return pd.read_parquet(path)
    if suffix == ".npz":
        return read_npz(path)
    if suffix == ".npy":
        arr = np.load(path, allow_pickle=True)
        if isinstance(arr, np.ndarray) and arr.dtype.names:
            return pd.DataFrame.from_records(arr)
        raise ValueError(
            f"NPY {path} lacks column names. Use NPZ with columns or explicit CSV."
        )
    raise ValueError(f"Unsupported snapshot format: {path}")


def score_snapshot_candidate(
    path: Path,
    required_columns: Sequence[str],
    role_tokens: Sequence[str],
) -> Tuple[int, int, int]:
    name = str(path).lower()
    token_score = sum(tok in name for tok in role_tokens)
    format_score = {
        ".parquet": 4,
        ".pq": 4,
        ".npz": 3,
        ".csv": 2,
        ".npy": 1,
    }.get(path.suffix.lower(), 0)

    column_score = 0
    try:
        if path.suffix.lower() == ".csv":
            cols = list(pd.read_csv(path, nrows=0).columns)
            column_score = sum(c in cols for c in required_columns)
        elif path.suffix.lower() in {".parquet", ".pq"}:
            cols = list(pd.read_parquet(path).columns)
            column_score = sum(c in cols for c in required_columns)
        elif path.suffix.lower() == ".npz":
            with np.load(path, allow_pickle=True) as z:
                keys = list(z.keys())
                if "columns" in keys:
                    cols = [normalize_scalar(v) for v in z["columns"].tolist()]
                    column_score = sum(c in cols for c in required_columns)
                else:
                    column_score = sum(c in keys for c in required_columns)
    except Exception:
        pass

    return (column_score, token_score, format_score)


def discover_snapshot(
    root: Path,
    required_columns: Sequence[str],
    role: str,
) -> Tuple[Optional[Path], List[Tuple[Path, Tuple[int, int, int]]]]:
    if role == "reference":
        tokens = ["2019", "reference", "ref", "old", "snapshot0", "t0"]
    else:
        tokens = ["2021", "current", "cur", "new", "snapshot1", "t1"]

    ignored_parts = {
        ".git", ".venv", "venv", "__pycache__", "site-packages",
        "phase6a_no_hub_ablation", "phase6b_multicell_retire_audit",
    }
    candidates = []
    for ext in ("*.parquet", "*.pq", "*.npz", "*.csv", "*.npy"):
        for path in root.rglob(ext):
            if any(part in ignored_parts for part in path.parts):
                continue
            if path.name == "qerrors_d109.csv":
                continue
            try:
                if path.stat().st_size < 1024:
                    continue
            except OSError:
                continue
            score = score_snapshot_candidate(path, required_columns, tokens)
            if score[0] > 0 or score[1] > 0:
                candidates.append((path, score))

    candidates.sort(key=lambda x: (x[1], -len(str(x[0]))), reverse=True)
    for path, score in candidates:
        if score[0] == len(required_columns):
            return path, candidates[:30]
    return None, candidates[:30]


def align_columns(
    reference: pd.DataFrame,
    current: pd.DataFrame,
    required: Sequence[str],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    missing_ref = sorted(set(required) - set(reference.columns))
    missing_cur = sorted(set(required) - set(current.columns))
    if missing_ref or missing_cur:
        raise KeyError(
            f"Snapshot columns do not match qerrors variables.\n"
            f"Missing from reference ({len(missing_ref)}): {missing_ref[:30]}\n"
            f"Missing from current ({len(missing_cur)}): {missing_cur[:30]}"
        )
    return reference[list(required)].copy(), current[list(required)].copy()


def pair_counts(df: pd.DataFrame, a: str, b: str) -> pd.DataFrame:
    work = pd.DataFrame(
        {
            a: df[a].map(normalize_scalar),
            b: df[b].map(normalize_scalar),
        }
    )
    counts = (
        work.groupby([a, b], dropna=False, sort=False)
        .size()
        .rename("count")
        .reset_index()
    )
    return counts


def marginal_counts(df: pd.DataFrame, col: str) -> Dict[str, int]:
    normalized = df[col].map(normalize_scalar)
    return normalized.value_counts(dropna=False).astype(int).to_dict()


def deterministic_random_cells(
    frame: pd.DataFrame,
    k: int,
    seed_text: str,
) -> pd.DataFrame:
    if frame.empty or k <= 0:
        return frame.iloc[0:0].copy()
    digest = hashlib.sha256(seed_text.encode("utf-8")).digest()
    seed = int.from_bytes(digest[:8], "little") % (2**32)
    rng = np.random.default_rng(seed)
    n = min(k, len(frame))
    idx = rng.choice(len(frame), size=n, replace=False)
    return frame.iloc[np.sort(idx)].copy()


def select_cells(
    ref_counts: pd.DataFrame,
    cur_counts: pd.DataFrame,
    a: str,
    b: str,
    support_floor: int,
    top_k: int,
    random_k: int,
    audited_cell: Tuple[str, str],
) -> pd.DataFrame:
    ref = ref_counts.rename(columns={"count": "reference_count"})
    cur = cur_counts.rename(columns={"count": "current_count"})
    merged = cur.merge(ref, on=[a, b], how="outer")
    merged["current_count"] = merged["current_count"].fillna(0).astype(int)
    merged["reference_count"] = merged["reference_count"].fillna(0).astype(int)

    supported = merged[merged["current_count"] >= support_floor].copy()
    if supported.empty:
        return supported

    selected = []

    top_current = supported.sort_values(
        ["current_count", "reference_count", a, b],
        ascending=[False, False, True, True],
    ).head(top_k).copy()
    top_current["source_top_current"] = True
    selected.append(top_current)

    top_stale = supported.sort_values(
        ["reference_count", "current_count", a, b],
        ascending=[False, False, True, True],
    ).head(top_k).copy()
    top_stale["source_top_stale"] = True
    selected.append(top_stale)

    random_part = deterministic_random_cells(
        supported,
        random_k,
        seed_text=f"{a}|{b}|multicell-retire",
    )
    random_part["source_random_supported"] = True
    selected.append(random_part)

    audited = supported[
        (supported[a] == audited_cell[0]) & (supported[b] == audited_cell[1])
    ].copy()
    if audited.empty:
        # Preserve the original cell even if serialization differs or support changed.
        audited = merged[
            (merged[a] == audited_cell[0]) & (merged[b] == audited_cell[1])
        ].copy()
    audited["source_original_audited"] = True
    selected.append(audited)

    out = pd.concat(selected, ignore_index=True, sort=False)
    source_cols = [
        "source_top_current",
        "source_top_stale",
        "source_random_supported",
        "source_original_audited",
    ]
    for col in source_cols:
        if col not in out:
            out[col] = False
        out[col] = out[col].fillna(False).astype(bool)

    out = (
        out.groupby([a, b], as_index=False, dropna=False)
        .agg(
            reference_count=("reference_count", "max"),
            current_count=("current_count", "max"),
            source_top_current=("source_top_current", "max"),
            source_top_stale=("source_top_stale", "max"),
            source_random_supported=("source_random_supported", "max"),
            source_original_audited=("source_original_audited", "max"),
        )
    )
    return out


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument(
        "--pairs",
        type=Path,
        default=Path("results/phase4g_ambient_width/qerrors_d109.csv"),
    )
    p.add_argument("--reference", type=Path)
    p.add_argument("--current", type=Path)
    p.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/phase6b_multicell_retire_audit"),
    )
    p.add_argument("--support-floor", type=int, default=20)
    p.add_argument("--severe-threshold", type=float, default=10.0)
    p.add_argument("--action-threshold", type=float, default=2.0)
    p.add_argument("--top-k", type=int, default=5)
    p.add_argument("--random-k", type=int, default=5)
    p.add_argument(
        "--max-pairs",
        type=int,
        default=0,
        help="Debug only. Zero means all severe pairs.",
    )
    return p.parse_args()


def main() -> int:
    args = parse_args()
    root = Path.cwd().resolve()
    pair_path = args.pairs.resolve()
    out_dir = args.output_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if not pair_path.exists():
        raise FileNotFoundError(f"Pair file not found: {pair_path}")

    pairs = pd.read_csv(pair_path)
    required_pair_cols = [
        PAIR_LEFT, PAIR_RIGHT, WORST_LEFT, WORST_RIGHT,
        ACTUAL_ROWS, STALE_QERROR,
    ]
    missing = [c for c in required_pair_cols if c not in pairs.columns]
    if missing:
        raise KeyError(
            f"qerrors CSV is missing columns {missing}. "
            f"Available: {list(pairs.columns)}"
        )

    pairs[STALE_QERROR] = pd.to_numeric(pairs[STALE_QERROR], errors="coerce")
    pairs[ACTUAL_ROWS] = pd.to_numeric(pairs[ACTUAL_ROWS], errors="coerce")
    severe = pairs[
        (pairs[STALE_QERROR] >= args.severe_threshold)
        & (pairs[ACTUAL_ROWS] >= args.support_floor)
    ].copy()
    severe = severe.drop_duplicates([PAIR_LEFT, PAIR_RIGHT])
    if args.max_pairs > 0:
        severe = severe.head(args.max_pairs).copy()

    required_vars = sorted(
        set(severe[PAIR_LEFT].astype(str)) | set(severe[PAIR_RIGHT].astype(str))
    )

    ref_path = args.reference.resolve() if args.reference else None
    cur_path = args.current.resolve() if args.current else None

    ref_candidates = []
    cur_candidates = []
    if ref_path is None:
        ref_path, ref_candidates = discover_snapshot(root, required_vars, "reference")
    if cur_path is None:
        cur_path, cur_candidates = discover_snapshot(root, required_vars, "current")

    if ref_path is None or cur_path is None:
        diagnostic = out_dir / "SNAPSHOT_DISCOVERY.txt"
        lines = [
            "Could not safely identify both encoded snapshots.",
            "",
            f"Required variables ({len(required_vars)}): {required_vars}",
            "",
            "Reference candidates:",
        ]
        lines.extend(f"  score={score}  {path}" for path, score in ref_candidates)
        lines.append("")
        lines.append("Current candidates:")
        lines.extend(f"  score={score}  {path}" for path, score in cur_candidates)
        lines.extend(
            [
                "",
                "Rerun with:",
                "  --reference <2019/reference encoded file>",
                "  --current <2021/current encoded file>",
            ]
        )
        diagnostic.write_text("\n".join(lines) + "\n", encoding="utf-8")
        raise FileNotFoundError(
            "Could not safely auto-discover both encoded snapshots. "
            f"See {diagnostic}"
        )

    print(f"[pairs]     {pair_path}")
    print(f"[reference] {ref_path}")
    print(f"[current]   {cur_path}")
    print(f"[severe]    {len(severe)} objects")

    reference = load_snapshot(ref_path)
    current = load_snapshot(cur_path)
    reference, current = align_columns(reference, current, required_vars)

    n_ref = len(reference)
    n_cur = len(current)
    if n_ref == 0 or n_cur == 0:
        raise ValueError("Reference/current snapshot must contain rows.")

    object_rows = []
    cell_rows = []

    for index, row in severe.reset_index(drop=True).iterrows():
        a = str(row[PAIR_LEFT])
        b = str(row[PAIR_RIGHT])
        audited_a = normalize_scalar(row[WORST_LEFT])
        audited_b = normalize_scalar(row[WORST_RIGHT])

        ref_joint = pair_counts(reference, a, b)
        cur_joint = pair_counts(current, a, b)
        ref_marg_a = marginal_counts(reference, a)
        ref_marg_b = marginal_counts(reference, b)
        cur_marg_a = marginal_counts(current, a)
        cur_marg_b = marginal_counts(current, b)

        selected = select_cells(
            ref_joint,
            cur_joint,
            a,
            b,
            args.support_floor,
            args.top_k,
            args.random_k,
            (audited_a, audited_b),
        )
        if selected.empty:
            print(f"[warn] no supported cells for {a},{b}")
            continue

        local_rows = []
        for _, cell in selected.iterrows():
            va = normalize_scalar(cell[a])
            vb = normalize_scalar(cell[b])
            actual = int(cell["current_count"])
            reference_count = int(cell["reference_count"])

            # Scale old/reference joint probability to the current row count.
            stale_est = n_cur * (reference_count / n_ref)
            lower_est = (
                float(cur_marg_a.get(va, 0))
                * float(cur_marg_b.get(vb, 0))
                / float(n_cur)
            )
            refreshed_est = float(actual)

            stale_q = qerror(stale_est, actual)
            lower_q = qerror(lower_est, actual)
            refreshed_q = qerror(refreshed_est, actual)

            source_names = []
            if cell["source_top_current"]:
                source_names.append("top_current")
            if cell["source_top_stale"]:
                source_names.append("top_stale")
            if cell["source_random_supported"]:
                source_names.append("random_supported")
            if cell["source_original_audited"]:
                source_names.append("original_audited")

            item = {
                "variable_i": a,
                "variable_j": b,
                "value_i": va,
                "value_j": vb,
                "sources": "|".join(source_names),
                "reference_count": reference_count,
                "current_count": actual,
                "stale_estimate_counterfactual": stale_est,
                "lower_order_estimate": lower_est,
                "refreshed_estimate": refreshed_est,
                "stale_qerror_counterfactual": stale_q,
                "lower_order_qerror": lower_q,
                "refreshed_qerror": refreshed_q,
                "lower_adequate": lower_q <= args.action_threshold,
                "stale_better_than_lower": stale_q < lower_q,
                "lower_better_than_stale": lower_q < stale_q,
            }
            local_rows.append(item)
            cell_rows.append(item)

        local = pd.DataFrame(local_rows)
        audited_match = local[
            local["sources"].str.contains("original_audited", regex=False)
        ]
        if audited_match.empty:
            # Serialization fallback: use the CSV's actual and current marginals.
            lower_est_audited = (
                float(cur_marg_a.get(audited_a, 0))
                * float(cur_marg_b.get(audited_b, 0))
                / float(n_cur)
            )
            audited_lower_q = qerror(
                lower_est_audited, float(row[ACTUAL_ROWS])
            )
        else:
            audited_lower_q = float(
                audited_match["lower_order_qerror"].iloc[0]
            )

        original_action = (
            "retire"
            if audited_lower_q <= args.action_threshold
            else "refresh"
        )
        max_lower_idx = local["lower_order_qerror"].idxmax()
        worst = local.loc[max_lower_idx]
        unsafe_cells = int(
            (local["lower_order_qerror"] > args.action_threshold).sum()
        )
        multi_action = "retire" if unsafe_cells == 0 else "refresh"

        object_rows.append(
            asdict(
                ObjectSummary(
                    variable_i=a,
                    variable_j=b,
                    audited_value_i=audited_a,
                    audited_value_j=audited_b,
                    audited_actual=int(row[ACTUAL_ROWS]),
                    audited_stale_qerror_pg=float(row[STALE_QERROR]),
                    audited_lower_qerror=audited_lower_q,
                    original_action=original_action,
                    sampled_cells=len(local),
                    max_lower_qerror=float(local["lower_order_qerror"].max()),
                    geo_lower_qerror=geometric_mean(
                        local["lower_order_qerror"].tolist()
                    ),
                    p90_lower_qerror=float(
                        local["lower_order_qerror"].quantile(0.90)
                    ),
                    unsafe_cells=unsafe_cells,
                    multi_cell_action=multi_action,
                    action_flip=original_action != multi_action,
                    worst_value_i=str(worst["value_i"]),
                    worst_value_j=str(worst["value_j"]),
                    worst_actual=int(worst["current_count"]),
                    worst_lower_estimate=float(worst["lower_order_estimate"]),
                    worst_lower_qerror=float(worst["lower_order_qerror"]),
                    stale_better_cells=int(local["stale_better_than_lower"].sum()),
                    lower_better_cells=int(local["lower_better_than_stale"].sum()),
                )
            )
        )

        if (index + 1) % 20 == 0 or index + 1 == len(severe):
            print(f"[audit] {index + 1}/{len(severe)}")

    objects = pd.DataFrame(object_rows)
    cells = pd.DataFrame(cell_rows)
    if objects.empty:
        raise RuntimeError("No objects were audited.")

    original_retire = objects[objects["original_action"] == "retire"]
    false_retire = original_retire[
        objects.loc[original_retire.index, "multi_cell_action"] == "refresh"
    ]
    original_refresh = objects[objects["original_action"] == "refresh"]
    conservative_refresh = original_refresh[
        objects.loc[original_refresh.index, "multi_cell_action"] == "retire"
    ]

    summary = {
        "input_pairs": str(pair_path),
        "reference_snapshot": str(ref_path),
        "current_snapshot": str(cur_path),
        "n_reference": n_ref,
        "n_current": n_cur,
        "support_floor": args.support_floor,
        "severe_threshold": args.severe_threshold,
        "action_threshold": args.action_threshold,
        "top_k": args.top_k,
        "random_k": args.random_k,
        "objects_audited": int(len(objects)),
        "cells_audited": int(len(cells)),
        "original_retire": int(len(original_retire)),
        "original_refresh": int(len(original_refresh)),
        "multi_cell_retire": int((objects["multi_cell_action"] == "retire").sum()),
        "multi_cell_refresh": int((objects["multi_cell_action"] == "refresh").sum()),
        "false_retire_count": int(len(false_retire)),
        "false_retire_rate_among_original_retire": (
            float(len(false_retire) / len(original_retire))
            if len(original_retire)
            else 0.0
        ),
        "conservative_extra_refresh_count": int(len(conservative_refresh)),
        "object_action_agreement": float(
            (objects["original_action"] == objects["multi_cell_action"]).mean()
        ),
        "retire_safety_rate": (
            float(
                (original_retire["multi_cell_action"] == "retire").mean()
            )
            if len(original_retire)
            else float("nan")
        ),
        "max_lower_qerror_over_all_sampled_cells": float(
            cells["lower_order_qerror"].max()
        ),
        "p95_object_max_lower_qerror": float(
            objects["max_lower_qerror"].quantile(0.95)
        ),
        "median_object_max_lower_qerror": float(
            objects["max_lower_qerror"].median()
        ),
    }

    objects_path = out_dir / "object_multicell_summary.csv"
    cells_path = out_dir / "cell_level_audit.csv"
    false_path = out_dir / "false_retire_objects.csv"
    report_path = out_dir / "REPORT.txt"
    manifest_path = out_dir / "run_manifest.json"

    objects.sort_values(
        ["action_flip", "max_lower_qerror"],
        ascending=[False, False],
    ).to_csv(objects_path, index=False)
    cells.sort_values(
        ["variable_i", "variable_j", "lower_order_qerror"],
        ascending=[True, True, False],
    ).to_csv(cells_path, index=False)
    false_retire.sort_values(
        "max_lower_qerror", ascending=False
    ).to_csv(false_path, index=False)
    manifest_path.write_text(
        json.dumps(summary, indent=2, allow_nan=True),
        encoding="utf-8",
    )

    lines = [
        "=" * 88,
        "EVOSTATS PHASE 6B - MULTI-CELL RETIREMENT SAFETY AUDIT",
        "=" * 88,
        f"Reference snapshot                    : {ref_path}",
        f"Current snapshot                      : {cur_path}",
        f"Rows reference / current              : {n_ref} / {n_cur}",
        f"Objects audited                       : {len(objects)}",
        f"Cells audited                         : {len(cells)}",
        f"Support floor                         : {args.support_floor}",
        f"Action threshold                      : Q <= {args.action_threshold:g}",
        "",
        "ACTION ROBUSTNESS",
        f"  Original retire                     : {len(original_retire)}",
        f"  Original refresh                    : {len(original_refresh)}",
        f"  Multi-cell retire                   : {(objects['multi_cell_action'] == 'retire').sum()}",
        f"  Multi-cell refresh                  : {(objects['multi_cell_action'] == 'refresh').sum()}",
        f"  False-retire objects                : {len(false_retire)}",
        f"  False-retire rate among retire      : {summary['false_retire_rate_among_original_retire']:.4f}",
        f"  Conservative extra refresh          : {len(conservative_refresh)}",
        f"  Object action agreement             : {summary['object_action_agreement']:.4f}",
        f"  Retire safety rate                  : {summary['retire_safety_rate']:.4f}",
        "",
        "LOWER-ORDER WORST-CELL DISTRIBUTION",
        f"  Median object maximum Q             : {summary['median_object_max_lower_qerror']:.4f}",
        f"  95th percentile object maximum Q    : {summary['p95_object_max_lower_qerror']:.4f}",
        f"  Global maximum sampled-cell Q       : {summary['max_lower_qerror_over_all_sampled_cells']:.4f}",
        "",
        "INTERPRETATION",
    ]
    if len(false_retire) == 0:
        lines.extend(
            [
                "No original retire decision failed on the expanded supported-cell audit.",
                "This supports object-level retirement within the sampled equality-predicate scope.",
                "It still does not establish safety for arbitrary unseen SQL predicates.",
            ]
        )
    else:
        lines.extend(
            [
                "At least one single-cell retire decision fails on another supported cell.",
                "Use false_retire_objects.csv to identify which objects must be refreshed",
                "or change the classifier to require multi-cell adequacy before retirement.",
            ]
        )
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("=" * 88)
    print("PHASE 6B COMPLETE")
    print("=" * 88)
    for k, v in summary.items():
        print(f"{k:42s}: {v}")
    print(f"[write] {objects_path}")
    print(f"[write] {cells_path}")
    print(f"[write] {false_path}")
    print(f"[write] {report_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        raise
