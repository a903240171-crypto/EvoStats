#!/usr/bin/env python3
"""
EvoStats Phase 5F — Clean d=109 audit
=====================================

This version separates three claims cleanly:

1. Support audit
   Reconstruct the exact Phase-4G data pipeline and measure the support-aware
   max-ratio screen over all C(109, 2)=5,886 pairs.

2. Refresh-only runtime
   Measure PostgreSQL refresh plans from the same reconstructed stale state.
   This preserves the original Table-3 definition.

3. Deployable end-to-end runtime
   Use a frozen, label-independent candidate rule:

       candidate iff eligible and qhat >= --screen-threshold

   The end-to-end timer includes:
       pair-count materialization
       + support-aware scoring
       + PostgreSQL candidate verification
       + refresh execution

   It does NOT choose the candidate cutoff using true severe labels.
   Ground-truth labels are used only after execution to report recall,
   precision, false negatives, and repair.

The selected-cell repair metric checks the same predicate cell used to define
each severe pair. It is not a multi-cell safety claim.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import itertools
import json
import random
import re
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score


def choose2(n: int) -> int:
    return n * (n - 1) // 2


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)

    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import helper module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def reconstruct_names(qframe: pd.DataFrame) -> list[str]:
    d = 1 + int(max(qframe["i"].max(), qframe["j"].max()))
    names: list[str | None] = [None] * d

    for row in qframe.itertuples(index=False):
        for idx, value in (
            (int(row.i), str(row.variable_i)),
            (int(row.j), str(row.variable_j)),
        ):
            if names[idx] is not None and names[idx] != value:
                raise RuntimeError(f"Variable mismatch at index {idx}")
            names[idx] = value

    if any(value is None for value in names):
        raise RuntimeError("Incomplete variable order in qerrors_d109.csv")
    return [str(value) for value in names]


def reconstruct_exact_phase4g(args, qframe: pd.DataFrame):
    """Re-run the exact Phase-4G sampling, joining, and encoding pipeline."""
    pg4g = load_module(args.phase4g_helper, "phase4g_exact_helper")

    p19 = pg4g.find_person_csv(args.person_cache, 2019)
    p21 = pg4g.find_person_csv(args.person_cache, 2021)

    hpaths: dict[int, Path] = {}
    for year in (2019, 2021):
        zip_path = args.data_dir / f"acs_{year}_hca.zip"
        if not pg4g.valid_zip(zip_path):
            raise FileNotFoundError(
                f"Missing exact Phase-4G housing cache: {zip_path}"
            )
        hpaths[year] = pg4g.extract_csv(
            zip_path, args.data_dir, year, "housing"
        )

    pa = pg4g.uniform_sample_csv(p19, args.rows, 2019)
    pb = pg4g.uniform_sample_csv(p21, args.rows, 2021)

    ha = pg4g.load_matching_housing(
        hpaths[2019], set(pa["SERIALNO"].astype(str))
    )
    hb = pg4g.load_matching_housing(
        hpaths[2021], set(pb["SERIALNO"].astype(str))
    )

    pvars, _ = pg4g.select_vars(pa, pb, "P", 50, 24, 0.2)
    hvars, _ = pg4g.select_vars(ha, hb, "H", 80, 24, 0.3)

    ja, jb, names = pg4g.build_join(pa, pb, ha, hb, pvars, hvars)
    A, B, cards = pg4g.encode(ja, jb, names)

    stored_names = reconstruct_names(qframe)
    if names != stored_names:
        mismatch = [
            (idx, expected, actual)
            for idx, (expected, actual)
            in enumerate(zip(stored_names, names))
            if expected != actual
        ]
        raise RuntimeError(
            "Exact Phase-4G variable order mismatch: "
            f"first mismatches={mismatch[:10]}"
        )

    metadata = {
        "pipeline": "exact_phase4g_import",
        "person_2019": str(p19),
        "person_2021": str(p21),
        "housing_2019": str(hpaths[2019]),
        "housing_2021": str(hpaths[2021]),
        "rows_reference": len(A),
        "rows_current": len(B),
        "person_variables": len(pvars),
        "housing_variables": len(hvars),
        "d": len(names),
        "sampling": (
            "Phase4G streaming random-key reservoir; seed=year; "
            "sample Person first; load matching Housing by SERIALNO"
        ),
        "normalization": "Phase4G '<NA>' normalization and lexical coding",
        "stale_transition": "reference ANALYZE, then TRUNCATE+COPY current rows",
    }
    return pg4g, A, B, cards, names, metadata


def pair_counts(
    A: np.ndarray,
    B: np.ndarray,
    i: int,
    j: int,
    ci: int,
    cj: int,
) -> tuple[np.ndarray, np.ndarray]:
    c0 = np.bincount(
        A[:, i].astype(np.int64) * cj + A[:, j].astype(np.int64),
        minlength=ci * cj,
    ).reshape(ci, cj)

    c1 = np.bincount(
        B[:, i].astype(np.int64) * cj + B[:, j].astype(np.int64),
        minlength=ci * cj,
    ).reshape(ci, cj)
    return c0, c1


def materialize_pair_counts(
    A: np.ndarray,
    B: np.ndarray,
    cards: list[int],
    pairs: list[tuple[int, int]],
    *,
    progress: bool,
) -> dict[tuple[int, int], tuple[np.ndarray, np.ndarray]]:
    counts: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]] = {}
    total = len(pairs)

    for idx, (i, j) in enumerate(pairs, start=1):
        counts[(i, j)] = pair_counts(A, B, i, j, cards[i], cards[j])
        if progress and (idx % 1000 == 0 or idx == total):
            print(f"[counts] {idx}/{total}", flush=True)
    return counts


def select_cell(
    c0: np.ndarray,
    c1: np.ndarray,
    n0: int,
    n1: int,
    floor: int,
) -> dict[str, Any]:
    eligible = c1 >= floor
    if not np.any(eligible):
        return {
            "eligible": 0,
            "qhat": 1.0,
            "value_i": -1,
            "value_j": -1,
            "old_count": 0,
            "current_count": 0,
        }

    p0 = np.maximum(c0 / n0, 1.0 / n0)
    p1 = c1 / n1
    ratio = np.ones_like(p1, dtype=float)
    ratio[eligible] = np.maximum(
        p0[eligible] / p1[eligible],
        p1[eligible] / p0[eligible],
    )

    flat = int(np.argmax(ratio))
    vi, vj = np.unravel_index(flat, ratio.shape)
    return {
        "eligible": 1,
        "qhat": float(ratio[vi, vj]),
        "value_i": int(vi),
        "value_j": int(vj),
        "old_count": int(c0[vi, vj]),
        "current_count": int(c1[vi, vj]),
    }


def screen_floor(
    counts: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]],
    pairs: list[tuple[int, int]],
    names: list[str],
    n0: int,
    n1: int,
    floor: int,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for i, j in pairs:
        cell = select_cell(*counts[(i, j)], n0, n1, floor)
        rows.append(
            {
                "floor": floor,
                "i": i,
                "j": j,
                "variable_i": names[i],
                "variable_j": names[j],
                **cell,
            }
        )
    return rows


def template_match(
    A: np.ndarray,
    B: np.ndarray,
    qframe: pd.DataFrame,
) -> float:
    cards = [
        int(max(A[:, col].max(), B[:, col].max())) + 1
        for col in range(A.shape[1])
    ]

    matches = 0
    for row in qframe.itertuples(index=False):
        c0, c1 = pair_counts(
            A,
            B,
            int(row.i),
            int(row.j),
            cards[int(row.i)],
            cards[int(row.j)],
        )
        cell = select_cell(c0, c1, len(A), len(B), 1)
        matches += int(
            cell["value_i"] == int(row.worst_i)
            and cell["value_j"] == int(row.worst_j)
        )
    return matches / len(qframe)


def establish_stale(pg4g, conn, schema, A, B, target) -> None:
    pg4g.replace_rows(conn, schema, A)
    pg4g.analyze_all(conn, schema, target)
    pg4g.replace_rows(conn, schema, B)


def bounded_greedy(
    edges: set[tuple[int, int]],
    width: int,
) -> list[set[int]]:
    if width < 2:
        raise ValueError("Batch width must be at least 2")

    degree: dict[int, int] = {}
    for u, v in edges:
        degree[u] = degree.get(u, 0) + 1
        degree[v] = degree.get(v, 0) + 1

    ordered = sorted(
        edges,
        key=lambda edge: (
            -(degree[edge[0]] + degree[edge[1]]),
            edge,
        ),
    )

    groups: list[set[int]] = []
    for edge in ordered:
        best_index: int | None = None
        best_increment: int | None = None

        for index, group in enumerate(groups):
            merged = group | set(edge)
            if len(merged) > width:
                continue

            increment = choose2(len(merged)) - choose2(len(group))
            if (
                best_increment is None
                or increment < best_increment
                or (
                    increment == best_increment
                    and tuple(sorted(group))
                    < tuple(sorted(groups[best_index]))
                )
            ):
                best_index = index
                best_increment = increment

        if best_index is None:
            groups.append(set(edge))
        else:
            groups[best_index].update(edge)

    return groups


def covered_objects(groups: list[set[int]]) -> set[tuple[int, int]]:
    covered: set[tuple[int, int]] = set()
    for group in groups:
        covered.update(itertools.combinations(sorted(group), 2))
    return covered


def plan_metrics(groups: list[set[int]]) -> dict[str, int]:
    return {
        "calls": len(groups),
        "object_ops": sum(choose2(len(group)) for group in groups),
        "max_width": max((len(group) for group in groups), default=0),
    }


def build_plans(
    d: int,
    edges: set[tuple[int, int]],
) -> dict[str, list[set[int]]]:
    active = {vertex for edge in edges for vertex in edge}
    plans: dict[str, list[set[int]]] = {
        "one_closure": [active],
        "per_edge": [set(edge) for edge in sorted(edges)],
    }
    for width in (4, 6, 8, 12, 16):
        plans[f"B{width}"] = bounded_greedy(edges, width)

    for name, groups in plans.items():
        missing = edges - covered_objects(groups)
        if missing:
            raise RuntimeError(
                f"Plan {name} misses severe edges: {sorted(missing)[:10]}"
            )
    return plans


def build_deployment_groups(
    verified: set[tuple[int, int]],
    plan_name: str,
) -> list[set[int]]:
    if not verified:
        return []
    if plan_name == "per_edge":
        return [set(edge) for edge in sorted(verified)]
    if plan_name == "one_closure":
        return [{vertex for edge in verified for vertex in edge}]
    if re.fullmatch(r"B\d+", plan_name):
        return bounded_greedy(verified, int(plan_name[1:]))
    raise ValueError(f"Unsupported deployment plan: {plan_name}")


def run_plan(
    pg4g,
    conn,
    schema: str,
    name: str,
    groups: list[set[int]],
    target: int,
) -> float:
    start = time.perf_counter()

    if name == "full":
        pg4g.analyze_all(conn, schema, target)
    else:
        for group in groups:
            pg4g.analyze_group(conn, schema, group, target)

    return time.perf_counter() - start


def verify_selected_cell_repair(
    pg4g,
    conn,
    schema: str,
    row_lookup: dict[tuple[int, int], dict[str, Any]],
    severe: set[tuple[int, int]],
) -> dict[str, float]:
    qvalues: list[float] = []

    for edge in sorted(severe):
        row = row_lookup[edge]
        qerror, _, _ = pg4g.explain_q(
            conn,
            schema,
            edge[0],
            edge[1],
            int(row["value_i"]),
            int(row["value_j"]),
        )
        qvalues.append(float(qerror))

    if not qvalues:
        return {
            "selected_cell_repair": 1.0,
            "selected_cell_fresh_qgeo": 1.0,
        }

    return {
        "selected_cell_repair": (
            sum(value <= 2.0 for value in qvalues) / len(qvalues)
        ),
        "selected_cell_fresh_qgeo": statistics.geometric_mean(qvalues),
    }


def graph_geometry(
    d: int,
    edges: set[tuple[int, int]],
) -> dict[str, float | int]:
    active = {vertex for edge in edges for vertex in edge}
    degree = {vertex: 0 for vertex in active}
    for u, v in edges:
        degree[u] += 1
        degree[v] += 1

    return {
        "active_vertices": len(active),
        "active_fraction": len(active) / d,
        "max_degree": max(degree.values(), default=0),
        "top1_edge_fraction": (
            max(degree.values(), default=0) / max(len(edges), 1)
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase4g-helper", type=Path, required=True)
    parser.add_argument("--person-cache", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--qerrors", type=Path, required=True)
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--out", type=Path, required=True)

    parser.add_argument("--schema", default="evostats_phase5f_clean")
    parser.add_argument("--rows", type=int, default=40_000)
    parser.add_argument("--statistics-target", type=int, default=500)
    parser.add_argument("--q-threshold", type=float, default=10.0)
    parser.add_argument(
        "--support-thresholds",
        default="1,5,10,20,50,100",
    )
    parser.add_argument("--runtime-supports", default="10,20")
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--e2e-repeats", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260718)

    parser.add_argument(
        "--screen-threshold",
        type=float,
        default=10.0,
        help=(
            "Frozen label-independent qhat threshold used to select "
            "deployment candidates."
        ),
    )
    parser.add_argument(
        "--deployment-plan",
        default="B8",
        help="Frozen refresh plan for deployable end-to-end runs.",
    )
    parser.add_argument("--audit-only", action="store_true")
    args = parser.parse_args()

    if not args.audit_only and args.repeats < 10:
        raise ValueError("Final refresh runtime audit requires repeats >= 10")
    if not args.audit_only and args.e2e_repeats < 10:
        raise ValueError("Final end-to-end audit requires e2e-repeats >= 10")

    floors = sorted(
        {int(value) for value in args.support_thresholds.split(",")}
    )
    runtime_floors = sorted(
        {int(value) for value in args.runtime_supports.split(",")}
    )

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    qframe = pd.read_csv(args.qerrors)
    stored_names = reconstruct_names(qframe)
    d = len(stored_names)
    M = choose2(d)

    if d != 109 or len(qframe) != 5886:
        raise RuntimeError(
            f"Expected d=109 and M=5886; got d={d}, rows={len(qframe)}"
        )

    pg4g, A, B, cards, names, metadata = reconstruct_exact_phase4g(
        args, qframe
    )

    match = template_match(A, B, qframe)
    metadata["worst_template_match"] = match
    metadata["screen_threshold"] = args.screen_threshold
    metadata["deployment_plan"] = args.deployment_plan

    (out / "reconstruction_metadata.json").write_text(
        json.dumps(metadata, indent=2),
        encoding="utf-8",
    )

    if match < 0.999999:
        raise RuntimeError(
            "Phase-4G reconstruction failed: "
            f"worst-template match={match:.6f}"
        )

    np.savez_compressed(
        out / "joined_d109_encoded.npz",
        A=A,
        B=B,
        variables=np.asarray(names, dtype=object),
    )

    pairs = list(itertools.combinations(range(d), 2))

    # ------------------------------------------------------------------
    # Frozen support audit
    # ------------------------------------------------------------------
    materialize_start = time.perf_counter()
    counts = materialize_pair_counts(
        A, B, cards, pairs, progress=True
    )
    support_count_seconds = time.perf_counter() - materialize_start

    screens: dict[int, list[dict[str, Any]]] = {}
    score_times: dict[int, list[float]] = {
        floor: [] for floor in floors
    }

    for repeat in range(args.repeats):
        for floor in floors:
            start = time.perf_counter()
            rows = screen_floor(
                counts, pairs, names, len(A), len(B), floor
            )
            score_times[floor].append(time.perf_counter() - start)
            if repeat == 0:
                screens[floor] = rows
        print(f"[screen] {repeat + 1}/{args.repeats}", flush=True)

    # ------------------------------------------------------------------
    # PostgreSQL labels for selected templates
    # ------------------------------------------------------------------
    conn = pg4g.connect(args.dsn)
    query_cache: dict[tuple[int, int, int, int], dict[str, float]] = {}

    try:
        pg4g.create_schema(conn, args.schema, d)
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, d)
        establish_stale(
            pg4g, conn, args.schema, A, B, args.statistics_target
        )

        templates = sorted(
            {
                (
                    int(row["i"]),
                    int(row["j"]),
                    int(row["value_i"]),
                    int(row["value_j"]),
                )
                for floor in floors
                if floor != 1
                for row in screens[floor]
                if row["eligible"]
            }
        )

        print(
            f"[pg] unique selected templates={len(templates)}",
            flush=True,
        )

        for idx, template in enumerate(templates, start=1):
            i, j, vi, vj = template
            start = time.perf_counter()
            qerror, estimated_rows, actual_rows = pg4g.explain_q(
                conn, args.schema, i, j, vi, vj
            )
            query_cache[template] = {
                "q_error": float(qerror),
                "estimated_rows": float(estimated_rows),
                "actual_rows": float(actual_rows),
                "seconds": time.perf_counter() - start,
            }
            if idx % 1000 == 0 or idx == len(templates):
                print(
                    f"[pg-query] {idx}/{len(templates)}",
                    flush=True,
                )
    finally:
        conn.close()

    stored_m1 = {
        (int(row.i), int(row.j))
        for row in qframe.itertuples(index=False)
        if float(row.stale_qerror) >= args.q_threshold
    }

    severe_sets: dict[int, set[tuple[int, int]]] = {1: stored_m1}
    summaries: list[dict[str, Any]] = []
    pair_rows: list[dict[str, Any]] = []

    for floor in floors:
        rows = screens[floor]
        labels: list[int] = []
        scores: list[float] = []
        severe: set[tuple[int, int]] = set()

        stored_lookup = (
            {
                (int(row.i), int(row.j)): row
                for row in qframe.itertuples(index=False)
            }
            if floor == 1
            else None
        )

        for row in rows:
            edge = (int(row["i"]), int(row["j"]))

            if floor == 1:
                source = stored_lookup[edge]
                qerror = float(source.stale_qerror)
                actual = float(
                    getattr(source, "actual_rows", row["current_count"])
                )
            elif row["eligible"]:
                result = query_cache[
                    (
                        edge[0],
                        edge[1],
                        int(row["value_i"]),
                        int(row["value_j"]),
                    )
                ]
                qerror = float(result["q_error"])
                actual = float(result["actual_rows"])
            else:
                qerror = 1.0
                actual = 0.0

            label = int(qerror >= args.q_threshold)
            if label:
                severe.add(edge)

            labels.append(label)
            scores.append(float(row["qhat"]))
            pair_rows.append(
                {
                    **row,
                    "pg_qerror": qerror,
                    "pg_actual_rows": actual,
                    "pg_severe": label,
                }
            )

        severe_sets[floor] = severe

        y = np.asarray(labels)
        score_array = np.log10(
            np.maximum(np.asarray(scores), 1.0)
        )

        auroc = (
            float(roc_auc_score(y, score_array))
            if len(set(labels)) == 2
            else float("nan")
        )
        auprc = (
            float(average_precision_score(y, score_array))
            if any(labels)
            else float("nan")
        )

        candidates = {
            (int(row["i"]), int(row["j"]))
            for row in rows
            if row["eligible"]
            and float(row["qhat"]) >= args.screen_threshold
        }

        geometry = graph_geometry(d, severe)
        summaries.append(
            {
                "floor": floor,
                "severe_edges": len(severe),
                "base_rate": len(severe) / M,
                "auroc": auroc,
                "auprc": auprc,
                "deployment_candidates": len(candidates),
                "deployment_candidate_fraction": len(candidates) / M,
                "deployment_candidate_recall": (
                    len(candidates & severe) / len(severe)
                    if severe else 1.0
                ),
                "deployment_candidate_precision": (
                    len(candidates & severe) / len(candidates)
                    if candidates else 1.0
                ),
                "score_seconds_median_excluding_counts":
                    statistics.median(score_times[floor]),
                "support_count_materialization_seconds":
                    support_count_seconds,
                "m1_retained": (
                    len(severe & stored_m1) / len(stored_m1)
                    if stored_m1 else 1.0
                ),
                **geometry,
            }
        )

    write_csv(out / "support_pairs.csv", pair_rows)
    write_csv(out / "support_summary.csv", summaries)

    runtime_floors = [
        floor
        for floor in runtime_floors
        if floor in severe_sets and severe_sets[floor]
    ]

    if args.audit_only:
        report = {
            "d": d,
            "M": M,
            "template_match": match,
            "support_summary": summaries,
            "runtime_executed": False,
            "deployment_rule": {
                "screen_threshold": args.screen_threshold,
                "deployment_plan": args.deployment_plan,
                "oracle_cutoff_used": False,
            },
        }
        (out / "gate_report.json").write_text(
            json.dumps(report, indent=2),
            encoding="utf-8",
        )
        print(json.dumps(report, indent=2))
        return

    # ------------------------------------------------------------------
    # Refresh-only runtime: preserves Table-3 semantics
    # ------------------------------------------------------------------
    plans = {
        floor: build_plans(d, severe_sets[floor])
        for floor in runtime_floors
    }
    strategies = ["full"] + [
        f"m{floor}_{name}"
        for floor in runtime_floors
        for name in plans[floor]
    ]

    runtime_trials: list[dict[str, Any]] = []
    runtime_summary: list[dict[str, Any]] = []

    conn = pg4g.connect(args.dsn)
    rng = random.Random(args.seed)

    try:
        for repeat in range(1, args.repeats + 1):
            order_names = strategies.copy()
            rng.shuffle(order_names)

            for order_index, strategy in enumerate(
                order_names, start=1
            ):
                if strategy == "full":
                    floor = -1
                    name = "full"
                    groups = [set(range(d))]
                    severe_edges = -1
                else:
                    match_obj = re.fullmatch(r"m(\d+)_(.+)", strategy)
                    if match_obj is None:
                        raise RuntimeError(
                            f"Invalid strategy name: {strategy}"
                        )
                    floor = int(match_obj.group(1))
                    name = match_obj.group(2)
                    groups = plans[floor][name]
                    severe_edges = len(severe_sets[floor])

                metrics = plan_metrics(groups)
                print(
                    f"[runtime] rep={repeat}/{args.repeats} "
                    f"strategy={strategy} calls={metrics['calls']} "
                    f"objects={metrics['object_ops']}",
                    flush=True,
                )

                establish_stale(
                    pg4g,
                    conn,
                    args.schema,
                    A,
                    B,
                    args.statistics_target,
                )

                seconds = run_plan(
                    pg4g,
                    conn,
                    args.schema,
                    name,
                    groups,
                    args.statistics_target,
                )

                if strategy == "full":
                    repair = {
                        "selected_cell_repair": 1.0,
                        "selected_cell_fresh_qgeo": 1.0,
                    }
                else:
                    row_lookup = {
                        (int(row["i"]), int(row["j"])): row
                        for row in screens[floor]
                    }
                    repair = verify_selected_cell_repair(
                        pg4g,
                        conn,
                        args.schema,
                        row_lookup,
                        severe_sets[floor],
                    )

                runtime_trials.append(
                    {
                        "repeat": repeat,
                        "order": order_index,
                        "strategy": strategy,
                        "floor": floor,
                        "severe_edges": severe_edges,
                        **metrics,
                        "seconds": seconds,
                        **repair,
                    }
                )
    finally:
        conn.close()

    for strategy in strategies:
        rows = [
            row for row in runtime_trials
            if row["strategy"] == strategy
        ]
        values = [float(row["seconds"]) for row in rows]
        first = rows[0]

        runtime_summary.append(
            {
                "strategy": strategy,
                "floor": first["floor"],
                "severe_edges": first["severe_edges"],
                "calls": first["calls"],
                "object_ops": first["object_ops"],
                "seconds_median": statistics.median(values),
                "seconds_iqr": (
                    qtile(values, 0.75) - qtile(values, 0.25)
                ),
                "selected_cell_repair_median": statistics.median(
                    float(row["selected_cell_repair"])
                    for row in rows
                ),
            }
        )

    full_time = next(
        row["seconds_median"]
        for row in runtime_summary
        if row["strategy"] == "full"
    )

    for row in runtime_summary:
        row["speedup_vs_full"] = (
            full_time / row["seconds_median"]
        )

    runtime_summary.sort(
        key=lambda row: row["seconds_median"]
    )

    write_csv(out / "runtime_trials.csv", runtime_trials)
    write_csv(out / "runtime_summary.csv", runtime_summary)

    # ------------------------------------------------------------------
    # Deployable end-to-end audit: no oracle candidate cutoff
    # ------------------------------------------------------------------
    deployment_trials: list[dict[str, Any]] = []
    deployment_summary: list[dict[str, Any]] = []

    conn = pg4g.connect(args.dsn)

    try:
        for floor in runtime_floors:
            true_severe = severe_sets[floor]

            for repeat in range(1, args.e2e_repeats + 1):
                establish_stale(
                    pg4g,
                    conn,
                    args.schema,
                    A,
                    B,
                    args.statistics_target,
                )

                total_start = time.perf_counter()

                count_start = time.perf_counter()
                repeat_counts = materialize_pair_counts(
                    A, B, cards, pairs, progress=False
                )
                count_seconds = time.perf_counter() - count_start

                score_start = time.perf_counter()
                repeat_rows = screen_floor(
                    repeat_counts,
                    pairs,
                    names,
                    len(A),
                    len(B),
                    floor,
                )
                score_seconds = time.perf_counter() - score_start

                row_lookup = {
                    (int(row["i"]), int(row["j"])): row
                    for row in repeat_rows
                }

                candidates = sorted(
                    (
                        (int(row["i"]), int(row["j"]))
                        for row in repeat_rows
                        if row["eligible"]
                        and float(row["qhat"])
                        >= args.screen_threshold
                    ),
                    key=lambda edge: (
                        -float(row_lookup[edge]["qhat"]),
                        edge,
                    ),
                )

                verify_start = time.perf_counter()
                verified: set[tuple[int, int]] = set()

                for edge in candidates:
                    row = row_lookup[edge]
                    qerror, _, _ = pg4g.explain_q(
                        conn,
                        args.schema,
                        edge[0],
                        edge[1],
                        int(row["value_i"]),
                        int(row["value_j"]),
                    )
                    if float(qerror) >= args.q_threshold:
                        verified.add(edge)

                verify_seconds = time.perf_counter() - verify_start

                groups = build_deployment_groups(
                    verified, args.deployment_plan
                )
                metrics = plan_metrics(groups)

                refresh_seconds = run_plan(
                    pg4g,
                    conn,
                    args.schema,
                    args.deployment_plan,
                    groups,
                    args.statistics_target,
                )

                end2end_seconds = time.perf_counter() - total_start

                repair = verify_selected_cell_repair(
                    pg4g,
                    conn,
                    args.schema,
                    {
                        edge: screens[floor][
                            pairs.index(edge)
                        ]
                        for edge in true_severe
                    },
                    true_severe,
                )

                tp = len(verified & true_severe)
                fp = len(verified - true_severe)
                fn = len(true_severe - verified)

                deployment_trials.append(
                    {
                        "repeat": repeat,
                        "floor": floor,
                        "screen_threshold": args.screen_threshold,
                        "deployment_plan": args.deployment_plan,
                        "true_severe_edges": len(true_severe),
                        "candidate_count": len(candidates),
                        "verified_edges": len(verified),
                        "true_positive": tp,
                        "false_positive": fp,
                        "false_negative": fn,
                        "verified_recall": (
                            tp / len(true_severe)
                            if true_severe else 1.0
                        ),
                        "verified_precision": (
                            tp / len(verified)
                            if verified else 1.0
                        ),
                        **metrics,
                        "count_seconds": count_seconds,
                        "score_seconds": score_seconds,
                        "verify_seconds": verify_seconds,
                        "refresh_seconds": refresh_seconds,
                        "end2end_seconds": end2end_seconds,
                        **repair,
                    }
                )

                print(
                    f"[e2e] floor={floor} "
                    f"rep={repeat}/{args.e2e_repeats} "
                    f"cand={len(candidates)} verified={len(verified)} "
                    f"recall={tp / len(true_severe):.3f} "
                    f"time={end2end_seconds:.3f}s",
                    flush=True,
                )
    finally:
        conn.close()

    for floor in runtime_floors:
        rows = [
            row for row in deployment_trials
            if row["floor"] == floor
        ]
        values = [
            float(row["end2end_seconds"]) for row in rows
        ]

        deployment_summary.append(
            {
                "floor": floor,
                "screen_threshold": args.screen_threshold,
                "deployment_plan": args.deployment_plan,
                "true_severe_edges": rows[0]["true_severe_edges"],
                "candidate_count_median": statistics.median(
                    int(row["candidate_count"]) for row in rows
                ),
                "verified_edges_median": statistics.median(
                    int(row["verified_edges"]) for row in rows
                ),
                "verified_recall_median": statistics.median(
                    float(row["verified_recall"]) for row in rows
                ),
                "verified_precision_median": statistics.median(
                    float(row["verified_precision"]) for row in rows
                ),
                "count_seconds_median": statistics.median(
                    float(row["count_seconds"]) for row in rows
                ),
                "score_seconds_median": statistics.median(
                    float(row["score_seconds"]) for row in rows
                ),
                "verify_seconds_median": statistics.median(
                    float(row["verify_seconds"]) for row in rows
                ),
                "refresh_seconds_median": statistics.median(
                    float(row["refresh_seconds"]) for row in rows
                ),
                "end2end_seconds_median": statistics.median(values),
                "end2end_seconds_iqr": (
                    qtile(values, 0.75) - qtile(values, 0.25)
                ),
                "full_seconds_median": full_time,
                "speedup_vs_full": (
                    full_time / statistics.median(values)
                ),
                "selected_cell_repair_median": statistics.median(
                    float(row["selected_cell_repair"])
                    for row in rows
                ),
            }
        )

    write_csv(
        out / "deployment_end2end_trials.csv",
        deployment_trials,
    )
    write_csv(
        out / "deployment_end2end_summary.csv",
        deployment_summary,
    )

    report = {
        "d": d,
        "M": M,
        "template_match": match,
        "support_summary": summaries,
        "runtime_summary": runtime_summary,
        "deployment_end2end_summary": deployment_summary,
        "deployment_rule": {
            "candidate_rule": (
                "eligible and qhat >= screen_threshold"
            ),
            "screen_threshold": args.screen_threshold,
            "deployment_plan": args.deployment_plan,
            "oracle_cutoff_used": False,
            "count_materialization_included": True,
            "repair_scope": "selected predicate cell only",
        },
    }

    (out / "gate_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 78)
    print("CLEAN PHASE-5F AUDIT COMPLETE")
    print("=" * 78)
    for row in deployment_summary:
        print(
            f"m={row['floor']:3d} "
            f"candidates={row['candidate_count_median']:.0f} "
            f"recall={row['verified_recall_median']:.3f} "
            f"precision={row['verified_precision_median']:.3f} "
            f"end2end={row['end2end_seconds_median']:.3f}s "
            f"speedup={row['speedup_vs_full']:.3f}x "
            f"repair={row['selected_cell_repair_median']:.3f}"
        )


if __name__ == "__main__":
    main()
