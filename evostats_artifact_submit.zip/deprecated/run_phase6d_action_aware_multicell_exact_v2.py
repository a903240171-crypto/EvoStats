#!/usr/bin/env python3
"""
Phase 6D: recompute and time the action-aware cover for the Phase 6C
multi-cell retirement policy.

Inputs
------
- Frozen Phase 5F reconstruction and support table.
- Phase 5J retrospective oracle actions (only to reproduce Phase 5K labels).
- Phase 6C object_multicell_gate.csv (the new 90-retire / 51-refresh labels).
- Phase 6C selected_cells_lower_order.csv (the expanded supported predicates).

Policies
--------
1. b8_refresh
   Retire nothing; execute the original frozen B8 refresh-only groups.

2. phase5k_action_aware
   Reproduce Phase 5K's 131-retire / 10-refresh classifier, build a fresh
   action-aware cover, drop the 131 predicted-retire objects, and execute
   that cover.

3. phase6c_action_aware
   Read the Phase 6C 90-retire / 51-refresh labels, build a fresh
   action-aware cover, drop the 90 multi-cell-certified retire objects,
   and execute that cover.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import random
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def qtile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    return float(np.quantile(np.asarray(values, dtype=float), q))


def geometric_mean(values: list[float]) -> float:
    if not values:
        return float("nan")
    return float(
        math.exp(
            sum(math.log(max(float(v), 1e-300)) for v in values)
            / len(values)
        )
    )


def slots(groups: list[set[int]]) -> int:
    return sum(len(group) * (len(group) - 1) // 2 for group in groups)


def active_vertices(edges: set[tuple[int, int]]) -> set[int]:
    return {v for edge in edges for v in edge}


def connected_components(
    vertices: set[int],
    edges: set[tuple[int, int]],
) -> list[set[int]]:
    adjacency = {v: set() for v in vertices}
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)

    seen: set[int] = set()
    components: list[set[int]] = []
    for start in sorted(vertices):
        if start in seen:
            continue
        stack = [start]
        seen.add(start)
        component: set[int] = set()
        while stack:
            node = stack.pop()
            component.add(node)
            for nxt in sorted(adjacency[node], reverse=True):
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        components.append(component)

    components.sort(key=lambda c: (-len(c), tuple(sorted(c))))
    return components


def balanced_capacities(h: int, k: int) -> list[int]:
    q, p = divmod(h, k)
    return [q + 1] * p + [q] * (k - p)


def exact_pack_components(
    components: list[set[int]],
    capacities: list[int],
) -> list[set[int]] | None:
    if sum(len(c) for c in components) != sum(capacities):
        return None
    if components and len(components[0]) > max(capacities):
        return None

    comps = [set(c) for c in components]
    bins = [set() for _ in capacities]
    remaining = list(capacities)

    suffix = [0] * (len(comps) + 1)
    for idx in range(len(comps) - 1, -1, -1):
        suffix[idx] = suffix[idx + 1] + len(comps[idx])

    def search(index: int) -> bool:
        if index == len(comps):
            return all(value == 0 for value in remaining)
        component = comps[index]
        size = len(component)
        if suffix[index] != sum(remaining):
            return False
        if size > max(remaining):
            return False

        tried: set[tuple[int, int]] = set()
        order = sorted(
            range(len(remaining)),
            key=lambda b: (
                remaining[b] - size if remaining[b] >= size else 10**9,
                remaining[b],
                b,
            ),
        )
        for b in order:
            if remaining[b] < size:
                continue
            state = (remaining[b], len(bins[b]))
            if state in tried:
                continue
            tried.add(state)

            bins[b].update(component)
            remaining[b] -= size
            if search(index + 1):
                return True
            remaining[b] += size
            bins[b].difference_update(component)
        return False

    if not search(0):
        return None
    return [set(group) for group in bins]


def greedy_feasible_action_cover(
    active: set[int],
    retained: set[tuple[int, int]],
    width: int,
) -> list[set[int]]:
    uncovered = set(tuple(sorted(edge)) for edge in retained)
    groups: list[set[int]] = []

    while uncovered:
        degree: dict[int, int] = {}
        for u, v in uncovered:
            degree[u] = degree.get(u, 0) + 1
            degree[v] = degree.get(v, 0) + 1

        seed = max(sorted(degree), key=lambda v: (degree[v], -v))
        group = {seed}

        while len(group) < width:
            best = None
            best_key = None
            for candidate in sorted(active - group):
                trial = group | {candidate}
                gain = sum(
                    1 for u, v in uncovered
                    if u in trial and v in trial
                )
                key = (gain, degree.get(candidate, 0), -candidate)
                if best_key is None or key > best_key:
                    best = candidate
                    best_key = key
            if best is None or best_key[0] <= 0:
                break
            group.add(best)

        newly = {
            edge for edge in uncovered
            if edge[0] in group and edge[1] in group
        }
        if not newly:
            u, v = min(uncovered)
            group = {u, v}
            newly = {(u, v)}

        groups.append(group)
        uncovered.difference_update(newly)

    covered = set().union(*groups) if groups else set()
    for vertex in sorted(active - covered):
        candidates = [
            idx for idx, group in enumerate(groups)
            if len(group) < width
        ]
        if candidates:
            idx = min(candidates, key=lambda x: (len(groups[x]), x))
            groups[idx].add(vertex)
        else:
            groups.append({vertex})

    return groups


def validate_cover(
    groups: list[set[int]],
    active: set[int],
    retained: set[tuple[int, int]],
    width: int,
) -> dict[str, Any]:
    union = set().union(*groups) if groups else set()
    missing_vertices = sorted(active - union)
    uncovered_edges = sorted(
        edge
        for edge in retained
        if not any(edge[0] in group and edge[1] in group for group in groups)
    )
    oversized = [sorted(group) for group in groups if len(group) > width]
    return {
        "feasible": not missing_vertices and not uncovered_edges and not oversized,
        "missing_vertices": missing_vertices,
        "uncovered_edges": uncovered_edges,
        "oversized_groups": oversized,
    }


def build_action_cover(
    harmful: set[tuple[int, int]],
    retained: set[tuple[int, int]],
    width: int,
) -> tuple[list[set[int]], dict[str, Any]]:
    active = active_vertices(harmful)
    components = connected_components(active, retained)
    h = len(active)
    k_lb = math.ceil(h / width)
    capacities = balanced_capacities(h, k_lb)
    slot_lb = sum(c * (c - 1) // 2 for c in capacities)

    groups = exact_pack_components(components, capacities)
    if groups is not None:
        method = "component_packable_optimum"
    else:
        groups = greedy_feasible_action_cover(active, retained, width)
        method = "greedy_feasible_fallback"

    validation = validate_cover(groups, active, retained, width)
    if not validation["feasible"]:
        raise RuntimeError(f"Infeasible cover: {validation}")

    info = {
        "method": method,
        "active_vertices": h,
        "retained_edges": len(retained),
        "component_count": len(components),
        "component_sizes": [len(c) for c in components],
        "call_lower_bound": k_lb,
        "balanced_slot_lower_bound": slot_lb,
        "calls": len(groups),
        "slots": slots(groups),
        "max_width": max(len(group) for group in groups),
        "attains_call_lower_bound": len(groups) == k_lb,
        "attains_slot_lower_bound": slots(groups) == slot_lb,
        "groups": [sorted(group) for group in groups],
    }
    return groups, info


def load_phase6c_actions(
    path: Path,
) -> tuple[set[tuple[int, int]], set[tuple[int, int]]]:
    frame = pd.read_csv(path)
    required = {"i", "j", "multicell_action"}
    if not required.issubset(frame.columns):
        raise RuntimeError(
            f"Phase 6C action file lacks: {sorted(required - set(frame.columns))}"
        )
    retire, refresh = set(), set()
    for row in frame.itertuples(index=False):
        edge = tuple(sorted((int(row.i), int(row.j))))
        action = str(row.multicell_action)
        if action == "retire":
            retire.add(edge)
        elif action == "refresh":
            refresh.add(edge)
        else:
            raise RuntimeError(f"Unknown Phase 6C action: {action}")
    return retire, refresh


def load_expanded_cells(path: Path) -> list[dict[str, Any]]:
    frame = pd.read_csv(path)
    required = {"i", "j", "value_i", "value_j", "current_count"}
    if not required.issubset(frame.columns):
        raise RuntimeError(
            f"Expanded-cell file lacks: {sorted(required - set(frame.columns))}"
        )
    return frame.to_dict("records")


def evaluate_expanded_cells(
    pg4g,
    conn,
    schema: str,
    cells: list[dict[str, Any]],
    threshold: float,
) -> dict[str, Any]:
    qvalues = []
    failed = 0
    for row in cells:
        q, estimate, actual = pg4g.explain_q(
            conn,
            schema,
            int(row["i"]),
            int(row["j"]),
            int(row["value_i"]),
            int(row["value_j"]),
        )
        if int(round(float(actual))) != int(row["current_count"]):
            raise RuntimeError("Expanded-cell actual mismatch")
        qvalues.append(float(q))
        if float(q) > threshold:
            failed += 1
    return {
        "repair_fraction": 1.0 - failed / len(qvalues),
        "failed_cells": failed,
        "qerror_geomean": geometric_mean(qvalues),
        "qerror_max": max(qvalues),
    }


def summarize_trials(trials: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for policy in sorted({row["policy"] for row in trials}):
        rows = [row for row in trials if row["policy"] == policy]
        total = [float(row["total_seconds"]) for row in rows]
        result.append({
            "policy": policy,
            "repeats": len(rows),
            "calls": int(statistics.median(int(r["calls"]) for r in rows)),
            "slots": int(statistics.median(int(r["slots"]) for r in rows)),
            "retired_pairs": int(statistics.median(int(r["retired_pairs"]) for r in rows)),
            "refreshed_pairs": int(statistics.median(int(r["refreshed_pairs"]) for r in rows)),
            "total_seconds_median": statistics.median(total),
            "total_seconds_iqr": qtile(total, .75) - qtile(total, .25),
            "original_repair_fraction_median": statistics.median(float(r["original_repair_fraction"]) for r in rows),
            "expanded_repair_fraction_median": statistics.median(float(r["expanded_repair_fraction"]) for r in rows),
            "expanded_qgeo_median": statistics.median(float(r["expanded_qgeo"]) for r in rows),
            "expanded_qmax_max": max(float(r["expanded_qmax"]) for r in rows),
        })

    b8 = next(r["total_seconds_median"] for r in result if r["policy"] == "b8_refresh")
    for row in result:
        row["speedup_vs_b8"] = b8 / row["total_seconds_median"]
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase5f-script", type=Path, required=True)
    ap.add_argument("--phase4g-helper", type=Path, required=True)
    ap.add_argument("--phase5k-script", type=Path, required=True)
    ap.add_argument("--person-cache", type=Path, required=True)
    ap.add_argument("--data-dir", type=Path, required=True)
    ap.add_argument("--qerrors", type=Path, required=True)
    ap.add_argument("--support-pairs", type=Path, required=True)
    ap.add_argument("--oracle-actions", type=Path, required=True)
    ap.add_argument("--phase6c-actions", type=Path, required=True)
    ap.add_argument("--phase6c-cells", type=Path, required=True)
    ap.add_argument("--dsn", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--schema", default="evostats_phase6d_action_aware")
    ap.add_argument("--rows", type=int, default=40000)
    ap.add_argument("--statistics-target", type=int, default=500)
    ap.add_argument("--support-floor", type=int, default=20)
    ap.add_argument("--retire-threshold", type=float, default=2.0)
    ap.add_argument("--width", type=int, default=8)
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--seed", type=int, default=20260722)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    phase5f = load_module(args.phase5f_script.resolve(), "phase5f_phase6d")
    pg4g = load_module(args.phase4g_helper.resolve(), "phase4g_phase6d")
    phase5k = load_module(args.phase5k_script.resolve(), "phase5k_phase6d")

    qframe = pd.read_csv(args.qerrors)
    support = pd.read_csv(args.support_pairs)
    _, A, B, cards, names, metadata = phase5f.reconstruct_exact_phase4g(args, qframe)

    severe_frame = support[
        (support["floor"] == args.support_floor)
        & (support["pg_severe"] == 1)
    ].copy()

    harmful = {
        tuple(sorted((int(row.i), int(row.j))))
        for row in severe_frame.itertuples(index=False)
    }
    rows_by_edge = {
        tuple(sorted((int(row["i"]), int(row["j"])))): row
        for row in severe_frame.to_dict("records")
    }

    p5k_retire, p5k_refresh, detail, _ = phase5k.classify_from_current_snapshot(
        B, rows_by_edge, args.retire_threshold
    )
    oracle = phase5k.load_oracle_actions(args.oracle_actions)
    agreement = phase5k.agreement_report(detail, oracle)

    if (len(harmful), len(p5k_retire), len(p5k_refresh)) != (141, 131, 10):
        raise RuntimeError("Phase 5K split failed to reproduce 141/131/10")
    if abs(float(agreement["exact_agreement"]) - 140 / 141) > 1e-12:
        raise RuntimeError("Phase 5K agreement failed to reproduce 140/141")
    if int(agreement["fn_refresh"]) != 0:
        raise RuntimeError("Phase 5K has a false retire")

    p6c_retire, p6c_refresh = load_phase6c_actions(args.phase6c_actions)
    if p6c_retire | p6c_refresh != harmful:
        raise RuntimeError("Phase 6C labels do not partition the harmful set")
    if (len(p6c_retire), len(p6c_refresh)) != (90, 51):
        raise RuntimeError(
            f"Expected Phase 6C split 90/51, got {len(p6c_retire)}/{len(p6c_refresh)}"
        )

    expanded_cells = load_expanded_cells(args.phase6c_cells)
    b8_groups = phase5f.bounded_greedy(harmful, args.width)
    p5k_groups, p5k_plan = build_action_cover(harmful, set(p5k_refresh), args.width)
    p6c_groups, p6c_plan = build_action_cover(harmful, set(p6c_refresh), args.width)

    print("=" * 72)
    print("ACTION-AWARE PLANS")
    print("=" * 72)
    print(
        f"phase5k_action_aware: method={p5k_plan['method']} "
        f"components={p5k_plan['component_sizes']} "
        f"calls={p5k_plan['calls']} slots={p5k_plan['slots']} "
        f"LB={p5k_plan['call_lower_bound']}/{p5k_plan['balanced_slot_lower_bound']}"
    )
    print(
        f"phase6c_action_aware: method={p6c_plan['method']} "
        f"components={p6c_plan['component_sizes']} "
        f"calls={p6c_plan['calls']} slots={p6c_plan['slots']} "
        f"LB={p6c_plan['call_lower_bound']}/{p6c_plan['balanced_slot_lower_bound']}"
    )

    policies = {
        "b8_refresh": (set(), harmful, b8_groups),
        "phase5k_action_aware": (set(p5k_retire), set(p5k_refresh), p5k_groups),
        "phase6c_action_aware": (set(p6c_retire), set(p6c_refresh), p6c_groups),
    }

    rng = random.Random(args.seed)
    trials = []

    conn = pg4g.connect(args.dsn)
    try:
        pg4g.create_schema(conn, args.schema, len(names))
        pg4g.load_array(conn, args.schema, A)
        pg4g.create_stats(conn, args.schema, len(names))

        for rep in range(1, args.repeats + 1):
            order = list(policies)
            rng.shuffle(order)

            for idx, name in enumerate(order, start=1):
                retire_edges, refresh_edges, groups = policies[name]
                print(
                    f"[runtime] rep={rep}/{args.repeats} "
                    f"order={idx} policy={name}",
                    flush=True,
                )

                phase5k.ensure_pair_statistics(conn, args.schema, harmful)
                phase5f.establish_stale(
                    pg4g, conn, args.schema, A, B, args.statistics_target
                )

                start = time.perf_counter()
                if retire_edges:
                    phase5k.drop_pair_statistics(
                        conn, args.schema, set(retire_edges)
                    )
                phase5k.run_groups(
                    pg4g, conn, args.schema,
                    [set(g) for g in groups],
                    args.statistics_target,
                )
                total_seconds = time.perf_counter() - start

                original = phase5f.verify_repair(
                    pg4g,
                    conn,
                    args.schema,
                    severe_frame.to_dict("records"),
                    harmful,
                )
                expanded = evaluate_expanded_cells(
                    pg4g,
                    conn,
                    args.schema,
                    expanded_cells,
                    args.retire_threshold,
                )

                trials.append({
                    "repeat": rep,
                    "order": idx,
                    "policy": name,
                    "retired_pairs": len(retire_edges),
                    "refreshed_pairs": len(refresh_edges),
                    "calls": len(groups),
                    "slots": slots(groups),
                    "total_seconds": total_seconds,
                    "original_repair_fraction": float(original["repair"]),
                    "original_qgeo": float(original["fresh_qgeo"]),
                    "expanded_repair_fraction": float(expanded["repair_fraction"]),
                    "expanded_qgeo": float(expanded["qerror_geomean"]),
                    "expanded_qmax": float(expanded["qerror_max"]),
                })
    finally:
        conn.close()

    summary = summarize_trials(trials)

    write_csv(args.out / "runtime_trials.csv", trials)
    write_csv(args.out / "runtime_summary.csv", summary)
    write_csv(
        args.out / "plan_groups.csv",
        [
            {
                "policy": name,
                "group_index": idx,
                "width": len(group),
                "columns": "|".join(map(str, sorted(group))),
            }
            for name, (_, _, groups) in policies.items()
            for idx, group in enumerate(groups, start=1)
        ],
    )

    report = {
        "phase5k_plan": p5k_plan,
        "phase6c_plan": p6c_plan,
        "runtime_summary": summary,
        "reconstruction_metadata": metadata,
    }
    (args.out / "gate_report.json").write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 72)
    print("PHASE 6D COMPLETE")
    print("=" * 72)
    for row in summary:
        print(
            f"{row['policy']}: calls={row['calls']} "
            f"slots={row['slots']} "
            f"time={row['total_seconds_median']:.4f}s "
            f"speedup={row['speedup_vs_b8']:.4f}x "
            f"original_repair={row['original_repair_fraction_median']:.4f} "
            f"expanded_repair={row['expanded_repair_fraction_median']:.4f} "
            f"Qgeo/Qmax={row['expanded_qgeo_median']:.4f}/"
            f"{row['expanded_qmax_max']:.4f}"
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
