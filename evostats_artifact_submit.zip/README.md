# EvoStats Artifact

This artifact contains frozen experiment code, result files, generated paper tables, environment metadata, and claim-level provenance.

## Quick validation

```powershell
python validate_artifact.py
python reproduce_tables.py
```

## Full reproduction

Final experiment runners are under `code/phase5_validation/`. The most important scripts are Phase 5C, 5D, 5F, and 5G. Full reproduction requires PostgreSQL and public ACS PUMS files.

## Data policy

Raw ACS files, caches, credentials, PostgreSQL storage, and virtual environments are excluded. Derived encoded arrays included: **True**.

## Canonical result selection

The artifact packages the frozen result directories below:

```text
phase0_unified                 catalog-blindness audit
pg_relabel_figure1             controlled relabeling witness
phase1_statistic               diagnostic statistic evaluation
phase2_v2_theory_aligned       final theory-aligned discovery run
phase3_pg_end_to_end_v2        final PostgreSQL hub witness
phase5b_detection_audit        negative residual-selector audit
phase5b_qratio_audit           protocol-fixed max-ratio audit
phase5c_frontier_audit         exact/greedy frontier audit
phase5d_support_sensitivity    d=50 support-floor sensitivity
phase5f_d109_support_runtime   final d=109 system evaluation
phase5g_query_feedback         oracle feedback baseline
```

Superseded runs such as `phase2_sparse_localization` and
`phase3_pg_end_to_end` are intentionally excluded.

## Provenance

- `CLAIMS_PROVENANCE.csv`: paper claim to exact CSV row.
- `MANIFEST.json`: packaged file inventory.
- `checksums.sha256`: byte-level verification.

## Claim boundaries

- Exact optimum is claimed only for enumerated small graphs.
- The 1.286 greedy gap is empirical, not a universal guarantee.
- Max-ratio ranks candidates; PostgreSQL Q-error verifies them.
- Support floor is a workload axis.
- Query feedback receives exact Q-error and exact pair attribution.
- Absolute times from different phases must not be mixed.

## Final reproduction map

The single entry point is `run_all.py`. Final stages included in this package are:

- `5f`: canonical d=109 support spectrum and refresh runtime.
- `5i`: binning sensitivity.
- `5j_four`: four-state attribution.
- `5j_retire`: oracle retire/refresh attribution.
- `5k`: cheap classifier and end-to-end audit.
- `5l`: action-aware cover.
- `6a`: leave-one-hub-out geometry with the Phase 5F planner.
- `6c`: conservative multi-cell gate.
- `6d`: paired B8 / one-cell / multi-cell action audit.
- `6e`: PostgreSQL verification-cost observations.
- `6f`: theorem-to-verification bridge.

Use a disposable PostgreSQL database: database-backed runners create and drop experiment schemas.

## Timing scopes

The paper's 0.066 s screen time measures max-ratio scoring and ranking over already materialized per-pair cell counts. Phase 6E's `screen_seconds` additionally reconstructs all 5,886 contingency tables from the encoded arrays with `pair_counts` before applying `select_cell`; the values therefore measure different scopes.

Table 3 reports a cold-cache B8 measurement (22.61 s). The action audit reports B8 inside a paired warm-buffer protocol (14.08 s). Comparisons within each table share the same runtime state; absolute times across the two protocols should not be mixed.

## Portable offline checks

```text
python validate_artifact.py
python reproduce_tables.py
python run_all.py --verify-only
python run_all.py --offline-only --dry-run
python offline_verification/reproduce_all.py
python offline_verification/verify_classifier.py
python offline_verification/verify_star_bound.py
```
